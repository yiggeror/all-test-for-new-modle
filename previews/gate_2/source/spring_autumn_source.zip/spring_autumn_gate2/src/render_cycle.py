#!/usr/bin/env python3
"""Build fixed geometry once; render one native cycle; deliver two exact repetitions."""
import argparse, importlib, json, os, sys, tempfile, subprocess, hashlib, time
from pathlib import Path
from PIL import Image,ImageFont,ImageDraw
import numpy as np
from engine import fx,pix,render as ray
from engine.world import MASK_NEAR
from motion_math import N,FPS,PERIOD
from numba import njit,prange

ROOT=Path(__file__).resolve().parent.parent
W,H=320,180

def set_font_fallback():
    orig=ImageFont.truetype
    def f(font,size=10,index=0,*a,**kw):
        try:return orig(font,size,index,*a,**kw)
        except OSError:
            if not isinstance(font,(str,Path)):raise
            text=Path(font).name
            serif=text in ('ukai.ttc','uming.ttc') or 'Serif' in text
            v=Path('/usr/share/fonts/opentype/noto')/('NotoSerifCJK-Regular.ttc' if serif else 'NotoSansCJK-Regular.ttc')
            if v.exists():return orig(str(v),size,2,*a,**kw)
            raise
    ImageFont.truetype=f

@njit(cache=True,parallel=True)
def _nearest(a, pal, colors, noise, strength):
    out=np.empty((len(a),3),np.uint8)
    for i in prange(len(a)):
        x,y,z=a[i];best0=1e20;best1=1e20
        j0=-1;j1=-1
        for k in range(len(pal)):
            px,py,pz=pal[k]
            d0=x-px;d1=y-py;d2=z-pz
            d=d0*d0+d1*d1+d2*d2
            if d<best0:
                j1=j0;best1=best0;j0=k;best0=d
            elif d<best1:
                j1=k;best1=d
        p0=pal[j0];p1=pal[j1]
        q0=p1[0]-p0[0];q1=p1[1]-p0[1];q2=p1[2]-p0[2]
        w=((x-p0[0])*q0+(y-p0[1])*q1+(z-p0[2])*q2)/max(q0*q0+q1*q1+q2*q2,1e-9)
        j=(j1 if min(1.,max(w,0.))*strength>noise[i] else j0)
        out[i]=colors[j]
    return out

class Palette:
    def __init__(self,scene):
        home=ROOT/'reference'
        self.meta=json.loads((home/(scene+'.json')).read_text())
        self.rgb=np.array(self.meta['palette_rgb'],np.uint8)
        note=Image.open(home/f'{scene}_320x180_native.png').convert('RGB')
        self.approved=np.asarray(note).copy()
        extras={'spring':[[245,155,93],[214,127,78]],'autumn':[[126,82,129],[192,145,121]]}[scene]
        # Reserve a few tiny motion accents without changing the dominant approved palette.
        for swatch in extras:
            if np.min(np.sum((self.rgb.astype(float)-swatch)**2,axis=1))<18:continue
            counts=np.sum(np.all(self.approved.reshape(-1,1,3)==self.rgb[None],axis=2),axis=0)
            i=np.argmin(np.where(counts==0,0,counts))
            self.rgb[i]=np.asarray(swatch,np.uint8)
        self.lab=pix.oklab(self.rgb/255.)*pix.LABW
        self.th=np.ascontiguousarray(pix.threshold_map(H,W,'mix',seed=177).ravel())
        self.strength=self.meta['dither_strength']
        self.vignette=fx.vignette(H,W,.15)
    def map(self,lin,grade):
        image=pix.tonemap(lin*self.vignette,**grade)
        out=_nearest(np.ascontiguousarray((pix.oklab(image)*pix.LABW).reshape(-1,3)),self.lab,
                     self.rgb,self.th,float(self.strength))
        return out.reshape(H,W,3)

def save_draft(scene, frames,target,count):
    target.mkdir(parents=True,exist_ok=True)
    pics=[]
    for a in frames:
        im=Image.fromarray(a)
        if scene=='spring':
            times=[(146,123,164,136),(132,83,151,103)]
        else:
            times=[(138,5,177,33),(68,113,86,142)]
        nd=im.resize((640,360),Image.Resampling.NEAREST)
        pics.append(nd)
    delay=round(1000*count/FPS)
    name=target/(scene+'_actual_draft.gif')
    pics[0].save(name,save_all=True,append_images=pics[1:],duration=delay,loop=0,optimize=False)
    parts=[]
    for a in frames:
        detail=Image.new('RGB',(460,200),'#21242a')
        image=Image.fromarray(a)
        for i,box in enumerate(times):
            one=image.crop(box)
            mag=min(186//max(one.height,1),214//max(one.width,1))
            one=one.resize((one.width*mag,one.height*mag),Image.Resampling.NEAREST)
            detail.paste(one,(10+229*i,8))
        parts.append(detail)
    parts[0].save(target/(scene+'_detail_draft.gif'),save_all=True,append_images=parts[1:],duration=delay,loop=0,optimize=False)
    print('ACTUAL_DRAFT',name,flush=True)

def encode(frames, path, strict=True, scale=6, threads=2):
    tmp=path.with_suffix('.part.mp4')
    filt=f'scale={W*scale}:{H*scale}:flags=neighbor:out_color_matrix=bt709,format=yuv420p'
    cmd=['ffmpeg','-v','error','-nostdin','-y','-filter_threads','1','-f','rawvideo','-pixel_format','rgb24',
         '-video_size',f'{W}x{H}','-framerate',str(FPS),'-i','-','-an','-vf',filt,'-c:v','libx264',
         '-preset','veryfast','-threads',str(threads),'-qp','0' if strict else '17',
         '-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709',
         '-movflags','+faststart',str(tmp)]
    if not strict:
        i=cmd.index('-qp');cmd[i]='-crf'
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    try:
        plane=np.ascontiguousarray(frames)
        data=memoryview(plane).cast('B')
        p.stdin.write(data);p.stdin.write(data);p.stdin.close()
    except BrokenPipeError:
        p.wait();raise
    if p.wait()!=0:raise RuntimeError('encoding failed')
    os.replace(tmp,path)

def setup(scene):
    mod=importlib.import_module(scene+'_motion')
    shot=mod.shot
    c=shot.camera(W,H)
    fx.SC=W/480.
    world=mod.build()
    plate,acc=ray.render(world,c,shot.sky,S=3,**shot.RENDER)
    plate['lights']=world.lights
    if hasattr(world,'chim'):plate['chim']=world.chim
    if hasattr(mod,'plate_setup'):
        ctx=mod.plate_setup(plate,c,world,acc)
    else:
        fx.denoise(plate,**shot.DENOISE)
        ctx=mod.prepare(plate,c,world=world,acc=acc)
    return mod,shot,ctx

def main():
    p=argparse.ArgumentParser();p.add_argument('season',choices=['spring','autumn'])
    p.add_argument('--draft-only',action='store_true');p.add_argument('--quickstep',type=int,default=8)
    p.add_argument('--reencode-only',action='store_true');p.add_argument('--review-copy',action='store_true')
    args=p.parse_args();name=args.season
    set_font_fallback()
    out=ROOT/'out';out.mkdir(exist_ok=True);qa=ROOT/'qa';qa.mkdir(exist_ok=True)
    native=qa/f'{name}_native.npy'
    if args.reencode_only:
        a=np.load(native)
        if args.review_copy:encode(a,out/f'{name}_review.mp4',strict=False)
        else:encode(a,out/f'{name}_loop.mp4')
        return
    t0=time.monotonic()
    mod,shot,c=setup(name);pa=Palette(name)
    def at(i,**k):return pa.map(mod.frame(c,i/N,**k),shot.GRADE)
    cache={}
    print('PLATE_READY',name,round(time.monotonic()-t0,2),flush=True)
    for i in range(0,N,args.quickstep):
        cache[i]=at(i)
    save_draft(name,list(cache.values()),ROOT/'draft',args.quickstep)
    if name=='autumn':
        roi=np.s_[114:138,72:87,:]
        proof=[]
        # Compare against actual same-phase render with the new actors absent; early/late irrelevant birds lie elsewhere.
        for i in range(0,N,11):
            b=at(i,actors=False,weather=False);a=at(i,actors=True,weather=False)
            delta=np.abs(a[roi].astype(np.int16)-b[roi].astype(np.int16))
            proof.append((float(delta.sum()),i,a,b))
        val,i,a,b=max(proof,key=lambda t:t[0])
        info={'frame':i,'seconds':i/FPS,'roi_xyxy':[72,114,87,138],'sum_abs_rgb':val}
        proofpanel=Image.new('RGB',(434,364),'#2c2322');pn=ImageDraw.Draw(proofpanel)
        pn.text((12,8),f'Native plume at {i/FPS:0.2f}s (8x crop)',fill='#fff0dc')
        box=(66,108,91,142)
        for j,(frame,label) in enumerate(((b,'without plume'),(a,'with plume'))):
            x=12+211*j;pn.text((x,39),label,fill='#e1cfab')
            im=Image.fromarray(frame).crop(box)
            proofpanel.paste(im.resize((im.width*8,im.height*8),Image.Resampling.NEAREST),(x,63))
        proofpanel.save(ROOT/'draft'/'autumn_plume_actual.png')
        (ROOT/'qa'/'autumn_plume_probe.json').write_text(json.dumps(info,indent=2)+chr(10))
        print('PLUME_PROOF',info,flush=True)
    if args.draft_only:return
    frames=np.empty((N,H,W,3),np.uint8)
    for i in range(N):
        frames[i]=cache[i] if i in cache else at(i)
        if i%55==0:print('FRAME',name,i,N,round(time.monotonic()-t0,2),flush=True)
    tmp=native.with_suffix('.tmp.npy');np.save(tmp,frames);os.replace(tmp,native)
    final=out/f'{name}_loop.mp4'
    print('NATIVE_READY',native,flush=True)
    encode(frames,final)
    if args.review_copy:encode(frames,out/f'{name}_review.mp4',strict=False)
    # A true one-frame phase-aligned compare: rerender twice, once suppressing newly introduced actors.
    im=at(.31*N,actors=False)
    Image.fromarray(im).save(qa/f'{name}_motion_reference_native.png')
    Image.fromarray(frames[int(.31*N)]).save(qa/f'{name}_phase031_native.png')
    info={'season':name,'N':N,'cycle_seconds':PERIOD,'fps':FPS,'cycles':2,
          'native':[W,H],'encoded':[W*6,H*6],'palette_rgb':pa.rgb.tolist(),
          'phase_1_equals_0':bool(np.array_equal(at(0),at(N))),
          'elapsed_s':round(time.monotonic()-t0,2)}
    (qa/f'{name}_render.json').write_text(json.dumps(info,indent=2)+'\n')
    print('MOVIE_READY',final,final.stat().st_size,flush=True)

if __name__=='__main__':main()
