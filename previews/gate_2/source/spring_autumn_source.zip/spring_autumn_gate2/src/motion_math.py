"""Frame clock and strictly periodic signals for the Spring and Autumn loops."""
import numpy as np
from engine import fx

N=330; FPS=30; PERIOD=N/FPS; STILL_PHASE=.31

def phases():
    return tuple(i/N for i in range(N))

def smooth(x):
    x=np.clip(x,0,1)
    return x*x*(3-2*x)

def locked_noise(p,n,seed,level,amount):
    return level+amount*(fx.loopnoise(p%1,n,seed)-fx.loopnoise(STILL_PHASE,n,seed))

def bird(p,i):
    p=p%1
    start=(.276,.351,.414)[i]; end=(.724,.802,.883)[i]
    q=(p-start)/(end-start)
    t=np.clip(q,0,1)
    ease=t+.047*np.sin(2*np.pi*t+(.10,.0,-.14)[i])
    x=(129.5,131.3,128.8)[i]+(47.8,48.0,47.2)[i]*ease
    y=(13.1,19.7,16.4)[i]+(2.8,-1.9,1.6)[i]*np.sin(np.pi*t)+.71*np.sin(2*np.pi*t+i*1.8)
    phase=(p-start)*(8.4,7.9,7.2)[i]+(.19,.62,.85)[i]
    flap=.18+.63*np.sin(2*np.pi*phase)
    al=float(smooth(q/.12)*smooth((1-q)/.15))
    if not 0<q<1: al=0.
    return float(x),float(y),float(flap),al

def breath(p):
    q=p%1
    return float(.5-.5*np.cos(2*np.pi*(2*q+.035*np.sin(2*np.pi*q))))

def tail(p):
    q=p%1
    def sweep(a,b):
        u=(q-a)/(b-a)
        if not 0<u<1:return 0.
        return float(np.sin(np.pi*u)**3*np.sin((1.66*u-.31)*np.pi))
    f=sweep(.388,.715)+.47*sweep(.751,.935)
    return f,.39*f

def moths(p):
    p=p%1
    th=2*np.pi*(p+np.array([.075,.372,.691]))
    x=.03+np.array([.42,.53,.33])*np.cos(th)+.052*np.cos(3*th)
    y=-np.array([.56,.92,1.12])+np.array([.23,.23,.19])*np.sin(np.array([1,2,1])*th+.35)
    z=np.array([.31,.22,.06])+np.array([.26,.32,.25])*np.sin(th+.25)
    beam=.24+.76*smooth((np.sin(th+.14)+.70)/1.65)
    return np.stack((x,y,z,beam),axis=1)
