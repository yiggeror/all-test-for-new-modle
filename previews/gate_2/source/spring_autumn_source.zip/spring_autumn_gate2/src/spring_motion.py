"""Mesh-animated roof cat and three depth-lit slow moths in the approved spring courtyard."""
import numpy as np
from scipy.ndimage import binary_dilation
from engine import fx,render as ray
from engine.rt import Accel
from engine.world import MASK_NEAR,MASK_HIDDEN,_n
from motion_math import PERIOD,smooth,moths,tail,breath,locked_noise
from dynamic_fx import BreathingCanopy, timed_particles, finer_particles, gauss
import spring_g15 as shot

def build():return shot.build()

def _preserve_cat_neighborhood(plate):
    cover=plate[f'tag{shot.CAT_TAG}']
    coords=np.argwhere(cover>0)
    lo=np.maximum(0,coords.min(0)-2);hi=np.minimum(cover.shape,coords.max(0)+3)
    r=np.s_[:,lo[0]:hi[0],lo[1]:hi[1],:]
    original=plate['layers'][r].copy()
    fx.denoise(plate,**shot.DENOISE)
    plate['layers'][r]=original

class RoofCat:
    def __init__(self,world,cam,acc,plate,behind):
        self.cam=cam;self.acc=acc
        g=world.finalize()
        ff=g['tf'];ids=np.flatnonzero(g['F']['tag'][ff]==shot.CAT_TAG)
        self.faces=g['F'];self.f=ff[ids]
        self.initial=np.stack([g[k][ids] for k in ('v0','v1','v2')]).astype(np.float32)
        self.mat=self.faces['col'][self.f].copy()
        # Mesh order is pinned to adopted Gate 1.5: torso sphere, muzzle, forepaw, tail joints, bevelled head.
        n=len(ids)
        assert n==492,(n,'Gate 1.5 cat mesh changed; review definition of anatomical intervals')
        self.body=np.arange(n)<168
        self.tail=(np.arange(n)>=328)&(np.arange(n)<384)
        self.head=np.arange(n)>=384
        self.nearmask=np.zeros(n,np.uint8)
        self.anchor=np.asarray(shot.CAT_AT,np.float32)
        self.tail_coeff=smooth((self.initial[:,self.tail,2]-self.anchor[2]-.045)/.218).astype(np.float32)
        self.base_depth=behind['depth']
        self.rect=np.s_[121:139,145:165]
        hy,wx=18,20;self.size=(hy,wx)
        self.original=binary_dilation(plate[f'tag{shot.CAT_TAG}'][self.rect]>0,iterations=2)
        o,d=cam.rays(3,np.random.default_rng(0))
        o=o.reshape(180,3,320,3,3)[121:139,:,145:165,:].transpose(0,2,1,3,4).reshape(-1,3)
        d=d.reshape(180,3,320,3,3)[121:139,:,145:165,:].transpose(0,2,1,3,4).reshape(-1,3)
        self.ro=np.ascontiguousarray(o,np.float32);self.rd=np.ascontiguousarray(d,np.float32)
        t0,h0=acc.closest(self.ro,self.rd,mask=MASK_NEAR|MASK_HIDDEN)
        self.far_t=np.where(h0>=0,t0,1e9).astype(np.float32)
        self.front_base=plate
        self.lamp=[dict(q,mask=q.get('mask',0)|MASK_NEAR) for q in world.lights if q['grp']==shot.base.G_LAMP and 'axis' in q]
        self.expand_ys=np.broadcast_to(np.arange(121,139)[:,None],self.size)
        self.expand_xs=np.broadcast_to(np.arange(145,165)[None,:],self.size)
    def pose(self,p):
        v=self.initial.copy()
        # Weight-stable loaf: back rises ~0.7 native px; paws and head stay on the ridge.
        breathe=breath(p)-.45
        y=v[:,self.body,1]
        weight=np.clip((y-self.anchor[1])/.25,0,1)
        v[:,self.body,1]+=.055*breathe*weight
        swing,swing_z=tail(p)
        c=self.tail_coeff
        v[:,self.tail,0]+=(.165*swing-.016)*c
        v[:,self.tail,1]+=(-.098+.040*swing)*c
        v[:,self.tail,2]+=(.086+.16*swing_z)*c
        return v
    def draw(self,lin,background,p,lamp_gain):
        v=self.pose(p)
        p0,p1,p2=[np.ascontiguousarray(vv,np.float32) for vv in v]
        r=Accel(p0,p1,p2,self.nearmask)
        tt,i=r.closest(self.ro,self.rd)
        hit=(i>=0)&(tt<self.far_t)
        ii=np.flatnonzero(hit)
        face=i[ii]
        pos=self.ro[ii]+self.rd[ii]*tt[ii,None]
        normals=_n(np.cross(p1[face]-p0[face],p2[face]-p0[face]))
        normals*=np.where((normals*self.rd[ii]).sum(1)>0,-1,1)[:,None]
        diffuse=ray.direct(self.lamp,self.acc,pos,normals,np.random.default_rng(87),shot.K)[shot.base.G_LAMP]
        col=self.mat[face]
        hemi=(.054+.045*np.clip(normals[:,1],0,1))
        rgb=(col*hemi[:,None]+np.array([.015,.013,.026],np.float32)+
            .115*col*diffuse*lamp_gain)
        raw=np.zeros((len(hit),3),np.float32);raw[ii]=rgb
        A=hit.reshape(*self.size,9).mean(2).astype(np.float32)
        C=raw.reshape(*self.size,9,3).mean(2)/np.maximum(A[...,None],1e-6)
        a=smooth((A-.22)/.58)
        dominant=A>=.43
        prior=np.pad(dominant,((1,0),(0,0)),mode='constant')[:-1]
        top=dominant&~prior
        rim=top&((self.expand_ys<128)|((self.expand_xs>154)&(self.expand_ys<=129)))
        # Warm single-pixel edge follows actual changing mesh coverage and is not a painted screen overlay.
        C[rim]=C[rim]*.25+np.array([.345,.085,.033],np.float32)[None]*(.75*lamp_gain)
        tile=lin[self.rect]
        tile[self.original]=background[self.rect][self.original]
        tile+= (C-tile)*a[...,None]
        # Expose the true nearest dynamic depth to foreground petals and moths.
        mixed=np.minimum(self.far_t,np.where(hit,tt,1e9)).reshape(*self.size,9)
        self.front_base['depth'][self.rect]=np.sort(mixed,axis=2)

def plate_setup(plate,cam,world,acc):
    _preserve_cat_neighborhood(plate)
    far,_=ray.render(world,cam,shot.sky,S=3,acc=acc,cam_mask=MASK_NEAR,**shot.RENDER)
    fx.denoise(far,**shot.DENOISE)
    plate['far']=far
    ctx=shot.setup(plate,cam)
    timed_particles([*ctx['pet'],ctx['shed']])
    for cup in ctx['smoke']:
        cup.T=PERIOD
        cup.rise*=9/PERIOD;cup.wind*=.78
    ctx['canopy']=BreathingCanopy(plate.get('tag1',np.zeros((180,320),np.float32)),'spring')
    ctx['cat']=RoofCat(world,cam,acc,plate,far)
    ctx['main_lamp']=next(q for q in ctx['lamps'] if q['grp']==shot.base.G_LAMP)
    return ctx

def _original_tv(p):
    tv=.45+.9*fx.stepnoise(p,36,11)*(.6+.4*fx.stepnoise(p,9,12))
    tint=np.array([.8,.95,1.25])*(1-fx.stepnoise(p,13,14)*.5)+np.array([1.2,1.,.7])*fx.stepnoise(p,13,14)*.5
    return (tv*tint).astype(np.float32)
REF_TV=_original_tv(.31)
REF_L=float(shot.base.gains(.31)[shot.base.G_LAMP])

def lamps(p):
    l=locked_noise(p,6,3,REF_L,.026)
    tv=locked_noise(p,7,11,1.,.108)
    tint=locked_noise(p,4,14,0.,.064)
    return l,REF_TV*tv+np.array([tint*.6,tint*.23,-tint*.6],np.float32)

def around_lamp(lin,ctx,p):
    lamp=ctx['main_lamp'];cam=ctx['cam'];depth=ctx['plate']['depth']
    for x0,y0,z0,a in moths(p):
        pos=lamp['pos']+np.array([x0,y0,z0])
        r=pos-lamp['pos'];cosine=float(_n(r)@lamp['axis'])
        x,y,dist,_=cam.project(pos)
        a*=smooth((cosine-.18)/.70)*.88
        color=np.array([.295,.095,.028],np.float32)
        gauss(lin,x,y,.29,.31,a,color,depth,dist,emissive=True)

def frame(c,p,actors=True,weather=True):
    p=p%1
    lamp,tv=lamps(p)
    L=c['plate']['layers']
    lin=c['sky']+L[0]+lamp*L[shot.base.G_LAMP]+L[shot.base.G_TV]*tv[None,None]
    if actors:
        far=c['plate']['far']['layers']
        bg=c['sky']+far[0]+lamp*far[shot.base.G_LAMP]+far[shot.base.G_TV]*tv[None,None]
        c['cat'].draw(lin,bg,p,lamp)
    else:
        cat=c['cat'];c['plate']['depth'][cat.rect]=cat.base_depth[cat.rect]
    if weather:
        for s in c['smoke']:s.draw(lin,p,c['amb']*.4)
        lin=c['canopy'].draw(lin,p)
        ls=[(q['pos'],q['color']*(lamp if q['grp']==shot.base.G_LAMP else 1.)*.45,.8,q['axis'],q['cone']) for q in c['lamps']]
        finer_particles(c['pet'][0],lin,p,c['amb'],ls,.52)
        finer_particles(c['pet'][1],lin,p,c['amb'],ls,.75)
        finer_particles(c['shed'],lin,p,c['amb'],ls,.79)
        finer_particles(c['pet'][2],lin,p,c['amb']*1.09,ls,.77)
    if actors:around_lamp(lin,c,p)
    x,y,_,_=c['lamp_px']
    for i,q in enumerate(c['lamps']):
        fx.glow(lin,x[i],y[i],q['color']*.010*(lamp if q['grp']==shot.base.G_LAMP else 1.),r0=2.4,power=1.3)
    return fx.bloom(lin,thresh=.5,sig=(1.2,4.5),gain=(.28,.2))
