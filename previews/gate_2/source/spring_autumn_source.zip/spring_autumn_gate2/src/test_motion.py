import unittest
import numpy as np
from importlib.util import find_spec

class Playback(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(find_spec('motion_math'),'lack Gate 2 schedule')
        import motion_math as m
        self.m=m
    def test_exact_forward_phases_no_endpoint(self):
        m=self.m
        for n,p in enumerate(m.phases()):
            self.assertEqual(p,n/330)
        self.assertEqual(len(m.phases()),330)
        self.assertLess(m.phases()[-1],1.0)
    def test_approved_phase_and_nonspiking_light_gate(self):
        m=self.m
        for base in [1.09283507,.98923171,.65]:
            f=lambda p:m.locked_noise(p,8,11,base,.09)
            self.assertAlmostEqual(f(.31),base,places=12)
            self.assertEqual(f(0),f(1))
            self.assertLess(abs(f(329/330)-f(0)),.003)
    def test_birds_once_motion_positive_and_absent_at_wrap(self):
        m=self.m
        for idx in range(3):
            out=[m.bird(p,idx) for p in m.phases()]
            spans=[i for i,a in enumerate(out) if a[-1] > 0]
            self.assertGreater(len(spans),30)
            self.assertEqual(spans,list(range(min(spans),max(spans)+1)))
            self.assertTrue(np.all(np.diff([out[i][0] for i in spans])>0))
            self.assertEqual(out[0][-1],0)
            self.assertEqual(out[-1][-1],0)
    def test_poses_do_not_reset_between_last_and_first(self):
        m=self.m
        self.assertTrue(all(abs(v)<1e-9 for v in m.tail(0)))
        self.assertAlmostEqual(m.breath(0),m.breath(1))
        np.testing.assert_allclose(m.moths(0),m.moths(1))
        self.assertLess(np.max(np.abs(m.moths(0)-m.moths(329/330))),.025)
    def test_allowed_moth_count_and_width(self):
        self.assertEqual(self.m.moths(.3).shape,(3,4))
        for q in np.linspace(0,1,90):self.assertTrue(np.all((self.m.moths(q)[:,3]>=0)&(self.m.moths(q)[:,3]<=1)))

if __name__=='__main__': unittest.main()
