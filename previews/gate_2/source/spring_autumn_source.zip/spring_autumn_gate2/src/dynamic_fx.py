"""Velocity-, coverage- and depth-aware native animation. Assets are produced at runtime."""
import numpy as np
from scipy.ndimage import gaussian_filter
from engine import fx
from engine.noise import fbm2
from motion_math import smooth, PERIOD

def finer_particles(p, lin, ph, amb, lights, alpha=.70):
    cam=p.cam; H,W=lin.shape[:2]
    P,f=p.positions(ph)
    px,py,dist,zf=cam.project(P)
    ok=(zf>.50)&(px>-.8)&(px<W+.8)&(py>-.8)&(py<H+.8)&(P[:,1]>.025)&(f>0)
    ii=np.flatnonzero(ok)
    if not len(ii):return
    P=P[ii]; px=px[ii]-.5;py=py[ii]-.5
    x=np.floor(px).astype(np.int32);y=np.floor(py).astype(np.int32)
    d=dist[ii]; sx=(px-x).astype(np.float32);sy=(py-y).astype(np.float32)
    # Conservative size/motion blur as integrated subpixel coverage, never nearest-pixel jumps.
    size=np.minimum(p.size[ii]*(.50*W/cam.th)/d,1.32)
    a=np.minimum(size**1.14*smooth(f[ii])*alpha*1.14,1.0)
    col=np.broadcast_to(np.asarray(amb,np.float32),(len(ii),3)).copy()
    if p.tint is not None: col*=p.tint[ii]
    for lp,lc,r0,axis,cone in lights:
        v=lp[None]-P;d2=(v*v).sum(1);wg=1/(d2+r0*r0)
        if axis is not None:
            facing=-(v/np.maximum(np.sqrt(d2)[:,None],1e-6)*axis[None]).sum(1)
            wg*=smooth((facing-cone[0])/max(cone[1]-cone[0],1e-6))
        col+=wg[:,None]*lc[None]
    A=np.zeros((H,W),np.float32);C=np.zeros((H,W,3),np.float32)
    for dx,dy,wx,wy in [(0,0,1-sx,1-sy),(1,0,sx,1-sy),(0,1,1-sx,sy),(1,1,sx,sy)]:
        xx=x+dx;yy=y+dy;m=(xx>=0)&(xx<W)&(yy>=0)&(yy<H)
        xx=xx[m];yy=yy[m]
        occ=(p.plate['depth'][yy,xx,:]>d[m,None]).mean(1)
        strengths=(a[m]*wx[m]*wy[m]*occ).astype(np.float32)
        np.add.at(A,(yy,xx),strengths)
        np.add.at(C,(yy,xx),strengths[:,None]*col[m])
    ks=np.minimum(A,.96)
    lin*=1-ks[...,None]
    lin+=C*(ks/np.maximum(A,1e-8))[...,None]

class BreathingCanopy:
    def __init__(self, foliage, season):
        H,W=foliage.shape
        yy,xx=np.mgrid[:H,:W]
        self.field=fbm2(xx*.038,yy*.04,708 if season=='spring' else 709,3).astype(np.float32)*3.8
        self.field2=fbm2(xx*.059-.34,yy*.05+1.73,731,2).astype(np.float32)*3.5
        self.mask=(smooth((foliage-.21)/.64)*np.minimum(foliage,1.0)).astype(np.float32)
        self.ref=.31
        self.phi=((self.ref+self.field)*2*np.pi).astype(np.float32)
        self.amp=.31 if season=='spring' else .23
        self.xm=np.maximum(np.arange(W)-1,0);self.xp=np.minimum(np.arange(W)+1,W-1)
        self.ym=np.maximum(np.arange(H)-1,0);self.yp=np.minimum(np.arange(H)+1,H-1)
        # Neighbor influence must remain within genuine foliage on both sides.
        self.sides=[self.mask*self.mask[:,j] for j in (self.xm,self.xp)]
        self.verticals=[self.mask*self.mask[j] for j in (self.ym,self.yp)]
    def draw(self,lin,p):
        # Coherent, spatially varying subpixel leaf-group sway with clamped boundaries.
        u=self.amp*np.sin(2*np.pi*(p+self.field))
        v=.11*np.sin(2*np.pi*(p+self.field2))
        left=lin[:,self.xm];right=lin[:,self.xp]
        above=lin[self.ym];below=lin[self.yp]
        return lin+(np.maximum(u,0)*self.sides[0])[...,None]*(left-lin)\
                  +(np.maximum(-u,0)*self.sides[1])[...,None]*(right-lin)\
                  +(np.maximum(v,0)*self.verticals[0])[...,None]*(above-lin)\
                  +(np.maximum(-v,0)*self.verticals[1])[...,None]*(below-lin)

def timed_particles(ps):
    for p in ps:
        p.vel*=p.T/PERIOD  # Same travelled distance as the approved artwork over a slower cycle.
        p.T=PERIOD; p.life=PERIOD/p.loops

def gauss(lin,x,y,sx,sy,alpha,color,depth=None,dist=0,occlusion=None,emissive=False):
    H,W=lin.shape[:2]
    if alpha<=1e-7:return
    x0=max(0,int(np.floor(x-3*sx)));x1=min(W,int(np.ceil(x+3*sx))+1)
    y0=max(0,int(np.floor(y-3*sy)));y1=min(H,int(np.ceil(y+3*sy))+1)
    if x0>=x1 or y0>=y1:return
    yy,xx=np.mgrid[y0:y1,x0:x1]
    a=(alpha*np.exp(-.5*((xx+.5-x)/sx)**2-.5*((yy+.5-y)/sy)**2)).astype(np.float32)
    if depth is not None:a*=np.mean(depth[y0:y1,x0:x1,:]>dist,2)
    if occlusion is not None:a*=occlusion[y0:y1,x0:x1]
    tile=lin[y0:y1,x0:x1]
    if emissive:tile+=a[...,None]*color
    else:tile+=(color[None,None]-tile)*a[...,None]

def line(lin, pts, width, opacity, color, sky):
    P=np.asarray(pts,dtype=np.float32);H,W=lin.shape[:2]; C=.5*width
    lo=np.maximum([0,0],np.floor(P.min(0)-2).astype(int));hi=np.minimum([W,H],np.ceil(P.max(0)+2).astype(int))
    if np.any(hi<=lo) or opacity<=1e-7:return
    x0,y0=lo;x1,y1=hi; yy,xx=np.mgrid[y0:y1,x0:x1]
    cov=np.zeros(yy.shape,np.float32)
    for i,j in zip(P[:-1],P[1:]):
        v=j-i; vx=xx+.5-i[0];vy=yy+.5-i[1]
        pr=np.clip((vx*v[0]+vy*v[1])/max(float(v@v),1e-7),0,1)
        dist=np.sqrt((vx-pr*v[0])**2+(vy-pr*v[1])**2)
        cov=np.maximum(cov,smooth((C+.57-dist)/.89))
    cov*=opacity*sky[y0:y1,x0:x1]
    tile=lin[y0:y1,x0:x1];tile+=(color[None,None]-tile)*cov[...,None]
