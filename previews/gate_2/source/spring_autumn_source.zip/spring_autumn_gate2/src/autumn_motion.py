"""Approved autumn environment, 11-second warm steam and independently timed distant birds."""
import numpy as np
from scipy.ndimage import gaussian_filter
from engine import fx
from engine.world import srgb
from motion_math import PERIOD, locked_noise, bird, smooth
from dynamic_fx import BreathingCanopy, timed_particles, finer_particles, gauss, line
import autumn_g15 as shot

def build():return shot.build(tea_offset=(.60,0.,.40))

def prepare(plate,cam,**unused):
    c=shot.setup(plate,cam)
    timed_particles(c['lv'])
    c['canopy']=BreathingCanopy(plate.get('tag1',np.zeros((180,320),np.float32)),'autumn')
    coverage=plate.get('tag1',np.zeros((180,320),np.float32))
    density=gaussian_filter(coverage,.93)
    c['cov']=coverage
    c['denom']=np.maximum(density[...,None],1e-6)
    c['weights']=.57*smooth((coverage-.46)/.44)*smooth((density-.31)/.39)
    c['bird_access']=smooth((plate['sky']-.14)/.86)
    c['tea_at']=np.asarray(plate['chim'][0])+np.array([.027,.023,.065])
    return c

def lamps(phase):
    # Exact approved frame at .31, gentle cycles with continuous zero-phase derivative.
    return (locked_noise(phase,8,11,1.09283507,.080),
            locked_noise(phase,9,7,.98923171,.014),
            locked_noise(phase,7,3,.99749154,.021))

def steam_and_birds(lin,c,p):
    # Five small rising parcels; none survives its phase wrap; depth hides portions behind a tree.
    for i,offset in enumerate((.08,.29,.48,.685,.864)):
        t=(p+offset)%1
        span=(.375,.359,.397,.383,.366)[i]
        u=t/span
        if u>=1:continue
        at=c['tea_at']+np.array([.13*u+.065*np.sin(4.9*u+i*.67)*u,
                                 1.13*u+.013*i*(1-u),.38*u])
        x,y,dist,_=c['cam'].project(at)
        alp=(.47-.018*i)*smooth(u/.19)*(1-smooth((u-.31)/.69))
        col=np.array([.375,.272,.173],np.float32)*(1-.14*u)
        # Warm, mildly asymmetric core + a less luminous translucent fringe. Native coverage never draws a square.
        gauss(lin,x-.10,y,.36+.55*u,.80+1.12*u,alp*.31,col,c['plate']['depth'],dist)
        gauss(lin,x,y,.35+.33*u,.61+.94*u,alp,col,c['plate']['depth'],dist)
    col=np.array([.094,.043,.103],np.float32)
    sky=c['bird_access']
    for i in range(3):
        x,y,w,alpha=bird(p,i)
        if alpha<=0:continue
        # Each wing is a small asymmetric curve rather than two translated stock pixels.
        span=(1.19,1.08,1.16)[i]
        width=(.63,.58,.61)[i]
        line(lin,[(x-span,y-w+.12),(x-.43,y-.28*w),(x+.07,y+.15),
                  (x+.52,y-.51*w+.07),(x+span,y-w-.12)],width,.77*alpha,col,sky)

def frame(c,p,actors=True,weather=True):
    p=p%1
    tv,kiosk,lamp=lamps(p)
    L=c['plate']['layers']
    lin=c['sky']+L[0]+lamp*L[shot.G_LAMP]+kiosk*L[shot.G_KIOSK]
    lin+=L[shot.G_TV]*(tv*np.array([.9,1.,1.2],np.float32))[None,None]
    fl=gaussian_filter(lin*c['cov'][...,None],(.93,.93,0))/c['denom']
    lin+= (fl-lin)*c['weights'][...,None]
    if weather:
        lin=c['canopy'].draw(lin,p)
        ll=[(q['pos'],q['color']*(lamp if q['grp']==shot.G_LAMP else 1.0)*.4,.9,q['axis'],q['cone']) for q in c['lamps']]
        for j,al in enumerate((.64,.74,.75)):
            finer_particles(c['lv'][j],lin,p,c['amb']*(1.04 if j==2 else 1),ll,al)
    if actors: steam_and_birds(lin,c,p)
    x,y,_,_=c['lamp_px']
    for i,q in enumerate(c['lamps']):
        fx.glow(lin,x[i],y[i],q['color']*.012*(lamp if q['grp']==shot.G_LAMP else 1.),r0=2.4,power=1.3)
    return fx.bloom(lin,thresh=.5,sig=(1.2,4.5),gain=(.28,.2))
