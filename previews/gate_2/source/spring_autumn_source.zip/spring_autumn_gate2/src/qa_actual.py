"""Independent actual native and 1080p-decoded checks on one completed Gate 2 candidate."""
from pathlib import Path
import argparse,hashlib,json,subprocess,struct
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from scipy.ndimage import uniform_filter
from motion_math import N,FPS

ROOT=Path(__file__).resolve().parent.parent
ROIS={
'spring':{'cat':(145,123,166,137),'moths':(130,86,153,106),'TV spill':(105,63,126,86),
          'wall candidate':(12,35,64,61)},
'autumn':{'plume':(72,114,87,139),'birds':(141,5,176,32),'kiosk':(31,117,58,144),'TV / building':(270,91,302,112),
          'wall candidate':(275,57,320,100)}}
BORDERFRAMES=list(range(321,330))+list(range(9))

def ffcheck(path):
    q=['ffprobe','-v','error','-select_streams','v:0','-show_streams','-show_packets','-show_entries',
       'packet=pts,duration:stream=width,height,avg_frame_rate,r_frame_rate,nb_frames,pix_fmt,profile,duration,codec_name,time_base','-of','json',str(path)]
    p=json.loads(subprocess.check_output(q,text=True))
    s=p['streams'][0]; seq=np.sort([int(x['pts']) for x in p['packets']]);dt=np.diff(seq)
    numer,denom=map(int,s['time_base'].split('/'))
    assert s['width']==1920 and s['height']==1080 and s['codec_name']=='h264'
    assert tuple(map(int,s['avg_frame_rate'].split('/')))==(30,1)
    assert len(seq)==N*2 and seq[0]==0 and np.all(dt*numer*FPS==denom) and abs(float(s['duration'])-2*N/FPS)<1e-8
    atoms=[]
    with path.open('rb') as f:
        end=path.stat().st_size
        while f.tell()+8<end:
            pos=f.tell();n,four=struct.unpack('>I4s',f.read(8));four=four.decode('latin1');atoms.append(four)
            if n==1:n=struct.unpack('>Q',f.read(8))[0]
            if n==0:break
            assert n>0
            f.seek(pos+n)
    assert atoms.index('moov')<atoms.index('mdat')
    return dict(profile=s['profile'],pix_fmt=s['pix_fmt'],frames=len(seq),duration=float(s['duration']),fps=s['avg_frame_rate'],pts_steps=[int(d) for d in np.unique(dt)],moov_before_mdat=True)

def decode(path):
    spans=[(0,8),(321,338),(651,659)]
    idx=[i for a,b in spans for i in range(a,b+1)]
    sel='+'.join(f'between(n,{a},{b})' for a,b in spans)
    P=subprocess.Popen(['ffmpeg','-v','error','-nostdin','-threads','2','-i',str(path),
         '-vf',f"select='{sel}'",'-fps_mode','passthrough','-f','rawvideo','-pix_fmt','yuv420p','-threads','1','pipe:1'],
         stdout=subprocess.PIPE)
    result={};py=1920*1080;pc=py//4
    wrong={0:0,1:0,2:0}
    for i in idx:
        b=P.stdout.read(py+2*pc);assert len(b)==py+2*pc,(i,len(b))
        a=np.frombuffer(b,dtype=np.uint8)
        planes=[a[:py].reshape(1080,1920),a[py:py+pc].reshape(540,960),a[py+pc:].reshape(540,960)]
        native=[]
        for k,v in enumerate(planes):
            side=6 if k==0 else 3
            blocks=v.reshape(180,side,320,side).transpose(0,2,1,3)
            color=blocks[:,:,0,0]
            wrong[k]+=int((blocks!=color[:,:,None,None]).any((2,3)).sum())
            native.append(color.copy())
        result[i]=np.stack(native,2)
    assert not P.stdout.read(1) and P.wait()==0
    tests=[(i,N+i) for i in range(0,9)]+[(i,N+i) for i in range(321,330)]
    assert all(np.array_equal(result[a],result[b]) for a,b in tests)
    assert not sum(wrong.values()),wrong
    return result,dict(check_frames=len(idx),nonuniform_6x6_luma_result=wrong[0],
             nonuniform_3x3_chroma_UV_result=[wrong[1],wrong[2]],cycle_matching_pairs=len(tests),
             decoded_luma_wrap_mae=float(np.abs(result[330][:,:,0].astype(np.int16)-result[329][:,:,0]).mean()))

def sem_stats(frames,roi,decoded=None):
    x0,y0,x1,y1=roi
    a=frames[:,y0:y1,x0:x1].astype(np.int16)
    delta=a-np.roll(a,1,axis=0)
    absd=np.abs(delta)
    ev=absd.mean((1,2,3))
    nz=(delta!=0).any(3).mean((1,2))
    return {'roi_xyxy':list(roi),'N-2_to_N-1':float(ev[-1]),'N-1_to_0':float(ev[0]),'0_to_1':float(ev[1]),
            'wrap_pixels_changed':float(nz[0]),'wrap_mean_signed_RGB':delta[0].mean((0,1)).round(5).tolist(),
            'neighbor_transition_p95':float(np.quantile(ev[np.r_[1:9,322:330]],.95)),
            'near_wrap_mae_clock':[[i,float(ev[i])] for i in BORDERFRAMES]}

def fixed_patch(a,rect):
    x0,y0,x1,y1=rect
    m=np.all(a[:,y0:y1,x0:x1]==a[0,y0:y1,x0:x1],axis=(0,3)).astype(np.float64)
    for h in range(min(14,m.shape[0]),0,-1):
        for w in range(min(18,m.shape[1]),0,-1):
            if w*h<12:continue
            u=uniform_filter(m,size=(h,w),mode='constant')
            iy,ix=np.unravel_index(u.argmax(),u.shape)
            if u[iy,ix]>.99999:
                xa=ix-w//2;ya=iy-h//2
                cut=m[ya:ya+h,xa:xa+w]
                if cut.shape==(h,w) and np.all(cut):return tuple(map(int,(x0+xa,y0+ya,x0+xa+w,y0+ya+h)))
    return None

def imgfmt(n):
    try:return ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',n,index=2)
    except OSError:return ImageFont.truetype('DejaVuSans.ttf',n)

def sheet(scene,a,target):
    ids=[321,325,328,329,0,1,4,8]
    W,H,hh=320,180,257
    p=Image.new('RGB',(W*4+64,hh*2+112),'#17262a')
    d=ImageDraw.Draw(p);d.text((24,10),('春' if scene=='spring' else '秋')+' / 11 秒单周期连帧验收',font=imgfmt(25),fill='#fff1d7')
    d.text((25,46),'帧号 329 → 000 为接缝；净图仅在验收表中附标注。',font=imgfmt(17),fill='#c7d9d7')
    boxes=list(ROIS[scene].values())[:2]
    for j,k in enumerate(ids):
        x=20+(j%4)*(W+7);y=77+(j//4)*hh
        tim=f'{k:03d} / {k/FPS:05.2f} s'
        d.text((x,y),tim,font=imgfmt(17),fill='#f5b66a' if k in (329,0) else '#b9d4d2')
        f=Image.fromarray(a[k]);p.paste(f.resize((W,H),Image.Resampling.NEAREST),(x,y+28))
        for oi,box in enumerate(boxes):
            v=f.crop(box)
            p.paste(v.resize((v.width*2,v.height*2),Image.Resampling.NEAREST),(x+oi*(W//2),y+209))
    p.save(target,quality=96,subsampling=0)

def main():
    c=argparse.ArgumentParser()
    c.add_argument('scene',choices=ROIS);opt=c.parse_args();s=opt.scene
    qa=ROOT/'qa'
    a=np.load(qa/f'{s}_native.npy',mmap_mode='r')
    f=ROOT/'out'/f'{s}_loop.mp4'
    assert a.shape==(330,180,320,3) and a.dtype==np.uint8
    meta=json.loads((qa/f'{s}_render.json').read_text())
    assert meta['phase_1_equals_0']
    sr=ffcheck(f)
    dec,ex=decode(f)
    metrics={k:sem_stats(a,v) for k,v in ROIS[s].items() if k!='wall candidate'}
    xy=fixed_patch(a,ROIS[s]['wall candidate'])
    if xy is not None:
        guard=sem_stats(a,xy)
        y0,y1=xy[1],xy[3];x0,x1=xy[0],xy[2]
        guard['max_delta_all_native_frames']=int(np.abs(a[:,y0:y1,x0:x1].astype(np.int16)-a[:1,y0:y1,x0:x1]).max())
        metrics['static wall mask']=guard
    report=dict(season=s,native_shapes=list(a.shape),native_phase_0_equals_1=True,video=sr,decoded_sample=ex,
       full_native=sem_stats(a,(0,0,320,180)),regions=metrics,bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())
    (qa/f'{s}_actual_qa.json').write_text(json.dumps(report,indent=2)+'\n')
    sheet(s,a,qa/f'{s}_seam_contact.jpg')
    print(json.dumps(dict([(k,report[k]) for k in ('scene',) if k in report]+
     [('native_wrap',report['full_native']['N-1_to_0']),('decoded',ex),('encoded',sr),('static',xy)]),ensure_ascii=False),flush=True)

if __name__=='__main__':main()
