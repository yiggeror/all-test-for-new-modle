# Gate 2 / 春秋两段原生像素循环

以 `1d2682d` 获批的 Gate 1.5 构图、静态空间和色板作为基础，按 `9e49b96` Round 2 制作。每段实际渲染 330 张 320×180，播放两次，22 秒 / 660 帧 / 30 fps。没有渲染 phase=1 的额外末帧。

- **春**：实体猫仍贴瓦脊。每帧只对小范围真实猫体网格重新求交，头/前爪基本不动，背缓呼吸，尾尖垂过檐口并缓慢摆两次；暖橘边随实际几何覆盖取单像素，不是扣图平移。3 粒暖蛾以独立的缓慢椭圆和八字，在路灯光锥内受光并按强度淡隐。粉色花瓣保持 3D 轨迹、受光与正确遮挡。
- **秋**：同一亭旁实际小茶桌避开亮货架，热汽从茶壶以暖白窄芯缓升，软边散去。三只极小紫影鸟各走一次独立曲线、振翅错拍，仅出现在真实天空，随后自然被树冠遮住。电视、亭和路灯均使用跨环平滑的周期驱动；相位 .31 的灯值维持已审静帧的原值。
- **静区和技术**：静态底板只建一次；固定 60 色、固定有序抖动，花叶只以自身覆盖内的小尺度周期形变和次像素连续权重受风。源文件先 6× 最近邻再转 yuv420p，H.264 `qp=0`，faststart。此主验收版的 x264 profile 标签可能在部分播放器不被硬解；需要普适播放可以另外生成 CRF 17 review 副本，不能拿它代替主验收版的逐块结果。

## 制作复现

具有 Python 3.12、FFmpeg/libx264、Noto CJK 字体的 Linux 环境。依赖见 `requirements.txt`。`src/engine` 为采用时原型引擎快照；`src/spring_g15.py`、`src/autumn_g15.py` 是发给制作用的场景基线（秋的默认机位与环境不变，新增可复用茶桌位置参数）。已审色板和 .31 帧在 `reference/`。输出均写本目录。

```sh
export NUMBA_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python src/render_cycle.py spring
python src/render_cycle.py autumn
python src/qa_actual.py spring
python src/qa_actual.py autumn
cd src && python -m unittest -v test_motion.py
```

主交件为 `out/{spring,autumn}_loop.mp4`。原生帧、接缝抽样、技术报告在 `qa/`，动态预看和实拍蒸汽对照在 `draft/`。循环无定稿音乐；音乐候选/试听单独制作。
