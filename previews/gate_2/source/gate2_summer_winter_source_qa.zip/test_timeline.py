"""Hard timeline rules tested without the ray tracer."""
import unittest
import numpy as np
try:
    import timeline as t
except ModuleNotFoundError as exc:
    if exc.name != "timeline":
        raise
    t = None


class Loops(unittest.TestCase):
    def test_two_cycles_do_not_repeat_the_endpoint(self):
        self.assertIsNotNone(t, "11-second timing API not implemented yet")
        first = tuple(t.frame_time(i) for i in range(330))
        self.assertEqual(len(set(first)), 330)
        self.assertEqual(first[-1], 329/30)
        self.assertEqual(tuple(t.frame_time(i) for i in range(330,660)), first)
        self.assertEqual(t.frame_time(330), 0)

    def test_reader_lifts_once_and_otherwise_rests(self):
        self.assertIsNotNone(t, "reader event timing isn't implemented yet")
        vals = np.array([t.reader_controls(t.frame_time(i)) for i in range(330)])
        active = vals[:,0] > 1e-6
        self.assertEqual(np.count_nonzero(active & ~np.roll(active,1)),1)
        self.assertGreater(np.count_nonzero(~active),.697*330)
        self.assertLessEqual(np.count_nonzero(~active),.801*330)
        self.assertEqual(t.reader_controls(0),t.reader_controls(11))
        self.assertLess(np.max(np.abs(np.diff(vals[:,0]))),.1)

    def test_small_flicker_is_coupled_and_periodic(self):
        self.assertIsNotNone(t, "sign timing API isn't implemented yet")
        v = np.array([t.neon(t.frame_time(i)) for i in range(330)])
        self.assertGreater(v.max()-v.min(),.05)
        self.assertGreater(v.min(),.86)
        self.assertEqual(t.neon(0),t.neon(11))


if __name__ == "__main__":
    unittest.main()
