"""Winter's separate physical layers animate without moving the approved camera."""
from math import pi,sin,cos
import numpy as np

from engine import fx
from engine.world import World, srgb
from shots import winter_gate15 as frozen
from shots import winter_world_gate15 as sc
from framework import NativeActor, plate
from timeline import PERIOD, wave, envelope, reader_controls


class Winter:
    OMIT = ("actor","smoke","snow","desk","stairs","tv","lamp")
    WALL = (109,33,120,45)
    INTEREST = {"window":(246,97,277,119),"lamp_snow":(37,66,78,125),"chimney":(274,62,306,89)}
    GRADE,VIGNETTE = frozen.GRADE,frozen.VIGNETTE

    def __init__(self):
        self.b,self.cam=plate(frozen)
        self.c=sc.setup(self.b,self.cam)
        self.actor=NativeActor(self.cam,self.b,(235,92,277,125),samples=4)
        w,d,_=sc.GUARD_SIZE
        xa,ya,*_=sc.READING_OPENING
        self.xform=(xa-w/2,ya,d/2-.16)
        self.roof=frozen.ANCHORS["值班室小烟管"]
        self.lamp_pt=frozen.guard_world((self.xform[0]+1.62,self.xform[1]+.73,self.xform[2]-.32))
        wind=tuple(.144*self.cam.r+np.array([0,0,.01]))
        self.smoke=fx.Smoke(self.cam,self.b,self.roof,n=12,T=PERIOD,loops=3,
                             rise=.353,wind=wind,r0=.088,grow=.124,seed=314,alpha=.218)
        self.stats={
            "visible_lighting_groups_energy":[round(float(np.mean(np.abs(x))),9) for x in self.b["layers"]],
            "reader_anchor":tuple(map(float,self.cam.project(frozen.ANCHORS["值班室暖窗伏案人"])[:2])),
            "flue_anchor":tuple(map(float,self.cam.project(self.roof)[:2])),
        }
        print("winter diagnostics",self.stats,flush=True)

    def controls(self,t):
        g=np.ones(sc.K,np.float32)
        g[sc.G_LAMP]=1.+.010*wave(t,2,.39)
        g[sc.G_DESK]=1.+.037*wave(t,2,.40)+.013*wave(t,3,.21)
        for k in range(5):
            start=.94+1.36*k
            g[sc.G_ST+k]=.085+.91*envelope(t,start,2.34,.28,.35)
        g[sc.G_TV]=.87+.22*(fx.loopnoise(t/PERIOD,14,31)-.5)+.045*wave(t,7,.21)
        return g

    def arm(self,t):
        lift,turn,visible=reader_controls(t)
        breath=.012*wave(t,3,.10)
        start=(.73,.563+breath,-.123)
        elbow=(.915+.061*lift,.357+.132*lift+breath,-.030+.024*lift)
        lead=.28*(.48+.52*sin(pi*turn))-.34*turn
        hand=(1.191+lead*lift,.338+.244*lift+.056*lift*sin(pi*turn),-.005+.041*lift)
        model=World(seed=23)
        dark=dict(mat="plain",col="#5a403c",prm=(.22,0,0,0))
        with model.at(sc.GUARD_POS,yaw=sc.GUARD_YAW):
            with model.at(self.xform):
                model.tube(start,elbow,.076,.060,sides=8,caps=True,**dark)
                model.tube(elbow,hand,.058,.028,sides=8,caps=True,**dark)
                model.sphere(hand,.043,n=8,squash=.80,mat="plain",col="#975e4f",prm=(.31,0,0,0))
                if visible>.013:
                    # Page turns around the actual binding. At both flat endpoints the
                    # pre-existing lower sheets are at the same depth/colour.
                    angle=pi*(.05+.90*turn)
                    hinge=np.array([1.279,.350,-.022])
                    length=.222
                    root=hinge+np.array([0,0,-.088])
                    left=hinge+np.array([0,0,.088])
                    curl=hinge+np.array([length*cos(angle),length*sin(angle),.089])
                    far=hinge+np.array([length*cos(angle)*.93,length*sin(angle)*1.10,-.072])
                    if visible < .8:
                        curl[1]=.353+(curl[1]-.353)*visible/.8
                        far[1]=.353+(far[1]-.353)*visible/.8
                    model.quads(root,far,curl,left,mat="plain",col="#cdb896",prm=(.55,0,0,0))
                    # A narrow glint on the tilted free leaf only: its rising edge
                    # briefly catches the desk lamp. The motion and hand size stay the same.
                    paper_glint=visible*max(0.,sin(angle))**.65
                    if paper_glint>.09:
                        model.tube(far,curl,.033*paper_glint,.027*paper_glint,sides=7,caps=True,
                                   mat="plain",col="#fff0cf",prm=(1.26,0,0,0))
        return model

    def frame(self,t,omit=()):
        t=t%PERIOD
        f=t/PERIOD
        g=self.controls(t)
        tv=1. if "tv" in omit else g[sc.G_TV]
        if "desk" in omit:g[sc.G_DESK]=1.
        if "stairs" in omit:g[sc.G_ST:sc.G_ST+5]=.36
        if "lamp" in omit:g[sc.G_LAMP]=1.
        g[sc.G_TV]=tv
        out=self.c["sky"].copy()
        for i, k in enumerate(g):out+=k*self.b["layers"][i]
        if "actor" not in omit:
            self.actor.composite(out,self.arm(t),self.lamp_pt,float(g[sc.G_DESK]))
        if "smoke" not in omit:
            self.smoke.draw(out,f,np.array([.113,.101,.107],np.float32))
        lamp=self.c["lamp"]
        if "snow" not in omit:
            light=[(lamp["pos"],lamp["color"]*g[sc.G_LAMP]*.55,.80,lamp["axis"],lamp["cone"]),
                   (np.asarray(self.lamp_pt),srgb("#ffe0a6")*g[sc.G_DESK]*.45,.55,None,None)]
            for o,a in zip(self.c["snow"],(.51,.60,.69)):
                o.draw(out,f,self.c["amb"],light,alpha=a)
        lamp_x,lamp_y,_,_=self.c["lamp_px"]
        fx.glow(out,lamp_x[0],lamp_y[0],lamp["color"]*.012*g[sc.G_LAMP],r0=2.2,power=1.3)
        return fx.bloom(out,thresh=.55,sig=(1.0,3.5),gain=(.22,.14))
