#!/usr/bin/env python3
"""Target the faint existing TV window at its visible peak, independent of snow or smoke."""
import json
import numpy as np
from PIL import Image

from framework import FixedColors, ROOT, use_cjk
from shots.winter_world_gate15 import G_TV
from winter_loop_scene import Winter


def main():
    use_cjk()
    w=Winter()
    q=FixedColors("winter",w.GRADE,w.VIGNETTE)
    off=("actor","snow","lamp","smoke","stairs","desk")
    best=(-1,None,None,None)
    for t in np.arange(0.,11.,.237):
        no=q.quantize(w.frame(t,omit=off+("tv",)))
        yes=q.quantize(w.frame(t,omit=off))
        n=int(np.any(no!=yes,axis=2).sum())
        if n>best[0]:best=(n,float(t),yes,no)
    n,t,yes,no=best
    assert n>0, "television scarcely reaches any quantized pixels"
    yy,xx=np.nonzero(np.any(yes!=no,axis=2))
    d={
        "actual_tv_changed_pixels":n,"time_s":round(t,3),"tv_gain":float(w.controls(t)[G_TV]),
        "comparison":"static no-weather with TV on vs reference-gain neutral TV at the same time/code",
        "bbox_xyxy":[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)],
    }
    out=ROOT/"qa"/"layers"
    out.mkdir(parents=True,exist_ok=True)
    Image.fromarray(np.concatenate([yes,no],axis=1)).save(out/"winter_tv_peak_on_left_neutral_right.png")
    (out/"winter_tv_peak.json").write_text(json.dumps(d,indent=2)+"\n")
    print(json.dumps(d,ensure_ascii=False),flush=True)


if __name__=="__main__":
    main()
