"""Rain visible in real 3D; reflected red light is broken by local impacts on the road."""
from math import pi
import numpy as np
from scipy.ndimage import gaussian_filter

from engine import fx
from engine.noise import fbm2
from engine.mats import sstep
from engine.world import World,srgb
from shots import summer_gate15 as frozen
from shots import summer_world_gate15 as sc
from framework import NativeActor,over_line,plate
from timeline import PERIOD,cat_controls,ease,neon,wave

GUTTER = (
    (.37,4.92,2.06), (1.55,5.18,2.06), (3.19,4.86,2.08), (4.68,5.12,2.04),
    (6.21,4.82,2.08), (8.16,5.21,2.045), (9.82,4.97,2.07),
)
SPATTER = (
    (.16,1.81,8.13),(.72,3.09,7.15),(1.33,.86,8.51),(2.08,2.18,7.90),
    (2.79,.75,8.92),(3.16,2.74,7.54),(3.69,1.87,8.21),(4.36,3.24,7.38),
    (4.88,1.21,8.46),(5.30,2.20,8.06),(5.98,.57,8.59),(6.42,2.96,7.40),
    (7.01,.95,8.65),(7.79,2.23,7.91),(8.26,1.43,8.65),(9.00,3.15,7.55),
    (9.73,1.89,8.10),(10.52,.78,8.97),
)


class WetStreet:
    ROI = np.s_[115:180,122:313]

    def __init__(self,b,cam):
        p=b["P"][self.ROI]
        x,z=(np.ascontiguousarray(p[...,j]) for j in (0,2))
        self.x,self.z=x,z
        self.ground=np.clip((b["tag2"][self.ROI]-.51)*2.03,0,1)
        self.gutter_mask=np.clip((b["N"][self.ROI][...,1]-.52)*2.,0,1) * (p[...,1]<.235)
        dx,dz=x-1.9,z-8.03
        self.u=(dx*cam.f[0]+dz*cam.f[2]).astype(np.float32)
        self.v=(dx*cam.r[0]+dz*cam.r[2]).astype(np.float32)
        n=fbm2(x*1.16+4.3,z*1.07,815,3)
        crude=np.exp(-((self.u/2.93)**2+((self.v+.08*self.u)/1.27)**2))
        self.shore=sstep(.102,.57,crude*(.49+.93*n))
        xvary=fbm2(self.u*2.8,self.v*3.65+48,659,3)
        self.texture=.22+.78*sstep(.29,.71,xvary)
        self.amber=.049*np.exp(-(((x-.53)/2.26)**2+((z-4.57)/1.26)**2))*(.60+.40*n)*self.ground
        self.blue=.015*np.exp(-(((x-1.7)/15.)**2+((z-8.)/7.)**2))*self.ground
        self.red_centers=tuple((a,np.hypot(x-px,z-pz)) for a,px,pz in SPATTER)
        self.gutter_centers=tuple((a,np.hypot(x-px,z-pz)) for a,px,pz in GUTTER)
        self.ribs=(
            (2.19,-.18,.126,.49,.65),(1.79,.16,.143,.68,.90),(1.20,-.12,.118,.57,1.),
            (.75,.17,.108,.58,.85),(.27,-.13,.145,.71,1.0),(-.27,.14,.123,.65,.95),
            (-.72,-.19,.140,.64,.92),(-1.28,.13,.144,.77,.81),
            (-1.78,-.09,.143,.60,.70),(-2.17,.11,.123,.57,.59),(-2.62,-.13,.138,.40,.32),
        )

    def fracture(self,t):
        delta_u=np.zeros_like(self.u)
        split=np.zeros_like(self.u)
        glint=np.zeros_like(self.u)
        for at,dist in self.red_centers:
            p=((t-at)%PERIOD)/.91
            if p >= 1.: continue
            strength=ease(p/.10)*ease((1.-p)/.45)
            r=.034+.46*p
            front=np.exp(-((dist-r)/.055)**2)*strength
            trough=np.exp(-((dist-max(.016,r-.088))/.061)**2)*strength
            delta_u+=.157*front-.069*trough
            split+=.76*front+.26*trough
            glint+=.036*trough
        return delta_u,np.clip(split,0.,.86),glint

    def draw(self,out,t,g,omit=()):
        view=out[self.ROI]
        if "wet" not in omit:
            displacement,split,curls=self.fracture(t)
            out_red=np.zeros_like(self.u)
            for j,(depth,cross,thickness,spread,weight) in enumerate(self.ribs):
                # Water-facing streaks sit at comparable depth across the camera;
                # actual raindrop rings displace their near edge and cut inky gaps.
                crest=.045*wave(t,3,.11+j*.12)*np.cos(1.87*self.v+j*.47)
                x=(self.u-depth+displacement+crest+.030*self.v)/thickness
                y=(self.v-cross+.059*self.u)/spread
                breakup=1.
                if j==2:
                    breakup=.28+.72*(1.-sstep(.16,.54,self.v))
                elif j==5:
                    breakup=1.-.67*np.exp(-((self.v+.07+.06*wave(t,2,.27))/.147)**2)
                elif j==8:
                    breakup=.40+.60*sstep(-.38,.08,self.v)
                out_red += weight*np.exp(-(x*x+y*y))*breakup
            out_red=gaussian_filter(out_red,sigma=.245)
            red=(.0028+(1-split)*out_red*.29*self.texture+curls)*self.shore*self.ground
            view+=red[...,None]*srgb("#ff483c")*g[sc.G_NEON]
            view+=self.amber[...,None]*srgb("#f3b26b")*g[sc.G_SIGN]
            view+=self.blue[...,None]*srgb("#6286bb")
        if "drops" not in omit:
            for at,dist in self.gutter_centers:
                p=((t-at)%PERIOD)/.68
                if p>=1.:continue
                amp=ease(p/.09)*ease((1.-p)/.43)
                rim=np.exp(-((dist-(.029+.38*p))/.056)**2)
                second=np.exp(-((dist-(.013+.22*p))/.046)**2)
                local=(.148*rim-.035*second)*amp*self.gutter_mask
                view+=local[...,None]*srgb("#ffbb71")


class Summer:
    OMIT=("cat","rain","drops","wet","neon","tv","barber","steam")
    WALL=(26,42,49,59)
    INTEREST={"neon_puddle":(212,130,290,176),"shelter_cat":(168,100,188,116),"gutter":(189,84,212,130)}
    GRADE,VIGNETTE=frozen.GRADE,frozen.VIGNETTE

    def __init__(self):
        self.b,self.cam=plate(frozen)
        self.c=sc.setup(self.b,self.cam)
        # Keep the weather particle life in seconds; eleven life windows per loop.
        for o in self.c["rain"]:
            o.loops=11
            o.life=PERIOD/o.loops
        self.actor=NativeActor(self.cam,self.b,(159,96,193,123),samples=4)
        self.light=(3.16,2.40,.42)
        self.street=WetStreet(self.b,self.cam)
        Y,X=np.mgrid[:180,:320]
        px,py=self.c["pole"]
        self.barber=(Y*.46+X*.46)
        self.barb_mask=((abs(X-px.mean())<3.7)&(Y>py.min()-1)&(Y<py.max()+1))[...,None]
        self.barber_rgb=np.array([[1.16,.18,.14],[1.04,1.02,1.0],[.19,.32,1.20]],np.float32)
        self.stats={
            "visible_lighting_groups_energy":[round(float(np.mean(np.abs(x))),9) for x in self.b["layers"]],
            "neon_bounds":[float(min(neon(i/30) for i in range(330))),float(max(neon(i/30) for i in range(330)))],
            "roof_spout_drop_sites":GUTTER,"red_impact_count":len(SPATTER),
        }
        print("summer diagnostics",self.stats,flush=True)

    def gain(self,t):
        g=np.ones(sc.K,np.float32)
        g[sc.G_FLUO]=.995+.009*wave(t,3,.31)
        g[sc.G_NEON]=neon(t)
        g[sc.G_BULB]=.83+.12*fx.loopnoise(t/PERIOD,16,31)
        g[sc.G_SIGN]=.975+.013*wave(t,2,.57)
        g[sc.G_TV]=.76+.26*fx.loopnoise(t/PERIOD,18,21)+.026*wave(t,7,.52)
        g[sc.G_TLR],g[sc.G_TLG]=.45,.55
        return g

    def cat_pose(self,t):
        ears,tail=cat_controls(t)
        rise=.011*wave(t,3,.26)
        shape=World(seed=61)
        fur=dict(mat="plain",col="#33262d",prm=(.16,0,0,0))
        rim=dict(mat="plain",col="#8c5a45",prm=(.24,0,0,0))
        with shape.at((4.18,1.039,.43),yaw=-.63,scale=1.24):
            shape.sphere((.08,.179+rise,0),.225,n=10,squash=.76,**fur)
            shape.sphere((-.116,.235+rise,.024),.134,n=9,squash=1.30,**fur)
            shape.sphere((-.232,.326+rise,.037),.124,n=10,squash=.92,**fur)
            shape.sphere((-.305,.285+rise,.109),.053,n=7,squash=.75,**fur)
            for x,top,amount in ((-.306,.514,1.0),(-.149,.498,.6)):
                a=(x-.046,.378+rise,.085)
                b=(x+amount*.058*ears-.014,top+rise-.037*amount*ears,.071+.036*ears)
                c=(x+.049,.379+rise,.098)
                shape.poly([a,b,c],**fur)
                shape.poly([(x-.028,.391+rise,.090),
                            (b[0]-.001,b[1]-.021,b[2]+.007),(x+.015,.396+rise,.104)],**rim)
            for x in (-.230,-.113):
                shape.sphere((x,.061,.11),.064,n=7,squash=.72,**fur)
            p=(.248,.126,-.027)
            path = [((.35,.169,.069),.048,.042),((.445,.128+.026*tail,.156),.042,.037),
                    ((.393+.035*tail,.078+.071*tail,.259+.072*tail),.037,.029),
                    ((.22+.06*tail,.082+.114*tail,.252+.080*tail),.028,.018)]
            for q,a,b in path:
                shape.tube(p,q,a,b,sides=7,caps=True,**fur)
                p=q
        return shape

    def roof_drips(self,out,t):
        for at,x,z in GUTTER:
            left=(at-t)%PERIOD
            if left>.71: continue
            q=(.71-left)/.71
            y=.161+2.35*(1.-q*q)
            v=.052+.122*q*q
            alpha=ease(q/.16)*ease((1-q)/.12)
            over_line(out,self.cam,self.b,(x,y+v,z),(x+.015*q,y,z+.013*q),
                      (.445,.238,.107),.73*alpha)

    def frame(self,t,omit=()):
        t=t%PERIOD
        f=t/PERIOD
        g=self.gain(t)
        if "neon" in omit:g[sc.G_NEON]=1.
        if "tv" in omit:g[sc.G_TV]=1.
        out=self.c["sky"].copy()
        for i,k in enumerate(g):
            if i!=sc.G_POLE:out+=k*self.b["layers"][i]
        if "barber" in omit:
            out+=self.b["layers"][sc.G_POLE]*np.array([.66,.58,.69],np.float32)
        else:
            shift=(self.barber+f*27.)%3
            a=np.floor(shift).astype(np.int32)
            q=(shift-a)[...,None]
            q=q*q*(3.-2.*q)
            color=(self.barber_rgb[a]*(1.-q) + self.barber_rgb[(a+1)%3]*q).astype(np.float32)
            out+=self.b["layers"][sc.G_POLE]*np.where(self.barb_mask,color,np.array([.77,.51,.65],np.float32))
        self.street.draw(out,t,g,omit)
        if "cat" not in omit:
            self.actor.composite(out,self.cat_pose(t),self.light)
        if "drops" not in omit:self.roof_drips(out,t)
        if "steam" not in omit:
            self.c["steam"].draw(out,f,np.array([.40,.328,.25],np.float32))
        if "rain" not in omit:
            lights=[(p,c*g[k]*.22,.7,x,cone) for p,c,k,x,cone in self.c["lts"]]
            ambient=np.array([.0055,.007,.011],np.float32)
            for i,(a,s) in enumerate(((.40,.020),(.57,.027),(.36,.027))):
                self.c["rain"][i].draw(out,f,ambient*(1. if i<2 else 1.7),lights,alpha=a,streak=s,additive=True)
        return fx.bloom(out,thresh=.60,sig=(1.0,3.5),gain=(.25,.16))
