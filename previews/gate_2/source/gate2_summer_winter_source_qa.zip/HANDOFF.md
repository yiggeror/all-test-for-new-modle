# Gate 2 · 夏雨与冬雪

范围：按 [Round 2 / `9e49b96`](https://github.com/yiggeror/all-test-for-new-modle/blob/9e49b969e8b549c39f947c1fd8e3783d170bfc40/REVIEW_LOG.md) 从 Gate 1.5 的夏、冬相机与色板接续，交两条**无声审片循环**。没有制作四季整片或定稿配乐。

## 文件

目标放入仓库的 `previews/gate_2/`：

| 文件 | 帧数 / 时长 | 大小 | SHA-256 |
|---|---:|---:|---|
| `outputs/summer_loop.mp4` | 660 / 22.000 s | 69,092,069 B | `07384fd999c083bb537f3f3691ab20982701880ac2f919533132c2d23cc697b6` |
| `outputs/winter_loop.mp4` | 660 / 22.000 s | 26,843,953 B | `49946d800865741bf413c0002508d554e8a2baf16bd235d836063f512a699bae` |

每条均为 1920×1080、30 fps、RGB 320×180 原生精确近邻 6×，H.264 QP 0、yuv420p、faststart；两轮写入的是同一套 **0–329 帧**，没有复制多余尾帧。QP 0 文件由 FFmpeg 实际完整解码，工具识别的 Profile 为 High 4:4:4 Predictive（像素仍为 yuv420p）。如设备只接受标准 High Profile，可用 `mobile/{summer,winter}_preview.mp4`，这是额外播放器预览版，不是精确块校验母版。

## 动作与分层

- **夏：**右下反光是街道真实世界坐标上的短横波，不再叠亮色椭圆。18 个确定的降雨撞点形成外扩物理水波，局部位移、割断红波并拉出边缘；网吧牌和红反光读同一个电流增益，同两次小微闪。棚前缘 7 次落滴带重力轨迹、真实深度遮挡，打到对应墙边暖地再开小环。背光猫是每帧重建的少量 3D 几何，只在 6.65–7.51 s 偶尔抖耳和 8.70–9.99 s 微动尾尖，保留暖架、理发红白蓝转灯、电视和受光雨丝。
- **冬：**保持原暖窗和室内静态肩颈。4.30–6.90 s 一次伸臂、掀页、收回，不变更机位或搬整块人像。仅翻起的轮廓边接一点暖色台灯；其余约 77% 时长静伏。读书手肘与书页都按真正三维相机投影到原生局部，再做窗口/桌面的深度测试。台灯、窗布光和入射雪采用同一独立组；暖烟从实际屋顶管口出现，微微右飘。左路灯和右窗均会染暖附近雪点；楼梯和 TV 使用各自保留的灯光组。

## 质检

`qa/{summer,winter}_native.npy` 是首轮真实 RGB 帧，uint8，轴顺序 `330×180×320×3`。每条全部 660 解码帧比较：第二轮与第一轮 **330/330 逐帧字节相同**（解码 YUV）；两轮相邻的 `329→0` 不重复。

| 静帧链／解码 QA | 夏 | 冬 |
|---|---:|---:|
| 接缝原生 RGB 平均绝对差 `329→0` | 2.19166 | 0.81021 |
| `321..329,0..8` 邻域最大非接缝一步差 | 2.34310 | 0.87650 |
| 动态层消隐后，静止墙 ROI 的 RGB 变化量 | 0 | 0 |
| 解码抽查 19 帧的均匀块错误（Y 6×6 + U/V 3×3） | 0 | 0 |

查看 `qa/*_verified.json`（完整原生跨缝逐步差分、各关注区、解码信息）；`qa/*_action_contact.png`（动作局部原生放大）；`qa/*_seam_contact.png` / `qa/*_seam.gif`（实际跨缝帧）。`qa/layers/*_on_left_off_right.png` 左半是场景完整帧，右半是同时间只消隐该层/固定该组增益的对照。夏在 3.64 s 实测，仅把同组红灯增益固定，牌附近 272 个原生像素与水面附近 219 个像素同步发生可见变化。雨、晕、雪等真实移动经过墙前仍会改变完整帧中的像素，不把它们误标为墙材质闪动。

冬季 TV 在 3.000 s 的对照恰好没有跨过色阶；单独寻找可见相位后，6.873 s 右后方墙窗及其近旁 33 个原生像素过色阶（包围盒 x=300–316、y=58–96）。附加的 `qa/layers/winter_tv_peak.json` 和同名对照图只对比电视增益，关闭雪／烟／动手等干扰。

## 从源复现

所用源是 Gate 1.5 的场景与 Rainroji 光追引擎的隔离副本，非指向另一个子工作区。批准版 `references/{summer,winter}.json` 提供固定色板和分镜；图像不做插帧或裁切生成动片。Linux Python 3.12，Noto Sans CJK（常规/粗体）、Noto Serif CJK、FFmpeg with libx264。独立运行：

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
export NUMBA_NUM_THREADS=3 OPENBLAS_NUM_THREADS=1
.venv/bin/python -m unittest discover -v
for s in summer winter; do
  .venv/bin/python render_loops.py "$s"
  .venv/bin/python verify_loops.py "$s"
done
.venv/bin/python audit_winter_tv.py
```

只快速看方向时，`render_loops.py winter --proxy` 会用同场景状态抽成 720p10fps 真动片，供早期配乐对齐，不替换正式版本。
