#!/usr/bin/env python3
"""Create an independently decodable mobile review proxy, with each encoded cycle identical."""
import argparse,hashlib,json,subprocess,tempfile
from pathlib import Path

def proc(cmd):
    subprocess.run(cmd,check=True)

def run(src,dst):
    dst=dst.resolve();dst.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=dst.parent,prefix='.review_') as td:
        d=Path(td);part=d/'one.mp4';passlog=str(d/'x264')
        common=['ffmpeg','-v','error','-nostdin','-y','-threads','2','-i',str(src.resolve()),
                '-map','0:v:0','-an','-frames:v','330','-profile:v','high','-level:v','4.0',
                '-pix_fmt','yuv420p','-threads','2','-c:v','libx264','-preset','fast','-tune','animation','-b:v','2960k',
                '-g','110','-keyint_min','110','-sc_threshold','0','-colorspace','bt709','-color_trc','bt709',
                '-color_primaries','bt709','-color_range','tv','-x264-params','aq-mode=3:aq-strength=.74:scenecut=0:open-gop=0']
        proc(common+['-pass','1','-passlogfile',passlog,'-f','mp4','/dev/null'])
        proc(common+['-pass','2','-passlogfile',passlog,str(part)])
        cat=d/'same_duration.txt';cat.write_text("file one.mp4\nfile one.mp4\n")
        out=d/'whole.mp4'
        proc(['ffmpeg','-v','error','-nostdin','-y','-f','concat','-safe','1','-i',str(cat),
              '-map','0:v:0','-an','-c:v','copy','-movflags','+faststart',str(out)])
        if out.stat().st_size>8_450_000:raise RuntimeError('Review copy exceeds the connector cap')
        q=subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_streams','-show_packets',
                                   '-show_data_hash','sha256','-of','json',str(out)])
        probe=json.loads(q);a=probe['streams'][0]
        assert (a['profile'],a['width'],a['height'],a['avg_frame_rate'],a['pix_fmt'],a['nb_frames'],float(a['duration']))==('High',1920,1080,'30/1','yuv420p','660',22.0)
        h=[k['data_hash'] for k in probe['packets']]
        assert len(h)==660 and h[:330]==h[330:]
        proc(['ffmpeg','-v','error','-nostdin','-xerror','-threads','2','-i',str(out),'-map','0:v:0','-f','null','-'])
        out.replace(dst)
    data={'destination':dst.name,'bytes':dst.stat().st_size,'packet_pairs_identical':330,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest()}
    print(json.dumps(data,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('destination',type=Path);a=p.parse_args();run(a.source,a.destination)
