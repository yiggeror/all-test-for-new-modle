"""Prototype-style short, shallow, integer-frame ballast events from the existing fixture groups."""
import numpy as np
from pixel_wind import N

# Half-open [frame start, frame stop) from the prototype's late-cycle pressure events.
# All restored fixtures stay on; there is no extinction or fade envelope.
EVENTS={'autumn':((203,208,.201),(217,221,.168)),
        'winter':((203,209,.185),)}
def gains(fx,n,scene):
    n=int(n)%N;p=n/N;s=19 if scene=='winter' else 5
    nominal=1.+.025*(2.*fx.loopnoise(p,23,s)-1.)
    edge=nominal
    for a,b,d in EVENTS[scene]:
        if a<=n<b:edge=nominal*(1.-d)
    # Small lamp tube variation/CRT picture chatter. State remains inside physical light group.
    kiosk=1.+.02*(2*fx.stepnoise(p,29,71)-1.)
    flick=1.+(.086 if scene=='autumn' else .099)*(2*fx.loopnoise(p,19,17)-1.)
    hue=(2*fx.loopnoise(p,9,47)-1.)
    tv=flick*np.array([1.+.045*hue,1.,1.-.064*hue],np.float32)
    return dict(lamp=float(edge),nominal_lamp=float(nominal),kiosk=float(kiosk),tv=tv)
