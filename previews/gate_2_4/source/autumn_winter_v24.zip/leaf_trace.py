#!/usr/bin/env python3
"""Inspect exact world-space leaf calls to the frozen v2.3 leaf renderer, one known ID at a time."""
from pathlib import Path
import argparse,copy,hashlib,json,sys,zipfile
import numpy as np
from render import basis,sha,V23_SOURCE_SHA,N,FPS

def trace(s,out):
    import autumn23
    old_fn=autumn23.paint_leaf
    sample=np.full((44,N,8),np.nan,np.float32)
    signature=np.zeros((44,N),np.uint32)
    stage=s.static.copy()
    trip=(copy.copy(s.leaves),copy.copy(s.extra))
    leaf_id=-1;f=0;last=(-1,-1)
    def read(lin,cam,b,P,V,value,alpha,shadow=False):
        nonlocal last
        if shadow or last==(leaf_id,f):return
        x,y,d,z=cam.project(P)
        u=int(np.floor(x));v=int(np.floor(y))
        coeff=float(np.mean(b['depth'][v,u]>d-.042)) if 0<=u<320 and 0<=v<180 else 0.
        sample[leaf_id,f]=(x,y,d,float(alpha),coeff,*P)
        signature[leaf_id,f]=int.from_bytes(hashlib.sha256(np.asarray(V,dtype=np.float32).tobytes()).digest()[:4],'little')
        last=(leaf_id,f)
    autumn23.paint_leaf=read
    try:
        for particles in trip:
            rows=particles.air[:]
            for p in rows:
                particles.air=[p];leaf_id+=1
                for f in range(N):particles.draw(stage,f/FPS)
    finally:autumn23.paint_leaf=old_fn
    hit=np.isfinite(sample[...,0])&(sample[...,3]>.3)&(sample[...,4]>=.34)
    visible=np.count_nonzero(hit,axis=1)
    assert leaf_id+1==44 and np.count_nonzero(visible[24:])>=16
    np.savez_compressed(out/'autumn_exact_aloft_paths.npz',path=sample,pose_signature_u32=signature)
    x={'count':44,'heading_for_path':list('x y depth alpha center_visibility wx wy wz'.split()),
       'id_by_row':[f'A{i:02d}' for i in range(44)],
       'visible_native_depth_frames_by_id':visible.tolist(),
       'new_ids_read_some_frames':int(np.count_nonzero(visible[24:])),'previous_ids_not_changed':list(range(24))}
    (out/'autumn_airborne_trace_summary.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x),flush=True)

def main():
    a=argparse.ArgumentParser();a.add_argument('--repo',type=Path,required=True);a.add_argument('--work',type=Path,required=True);args=a.parse_args()
    repo=args.repo.resolve();work=args.work.resolve()
    source=repo/'previews'/'gate_2_3'/'source'/'autumn_winter_v23.zip'
    if sha(source)!=V23_SOURCE_SHA:raise ValueError('Unexpected v2.3 source')
    dst=work/'basis_23';dst.mkdir(exist_ok=True,parents=True)
    with zipfile.ZipFile(source) as z:z.extractall(dst)
    sys.path[:0]=[str(basis(repo,work,'autumn')),str(dst)]
    from autumn24 import AutumnV24
    out=work/'qa';out.mkdir(exist_ok=True,parents=True)
    trace(AutumnV24(),out)
if __name__=='__main__':main()
