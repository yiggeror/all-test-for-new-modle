#!/usr/bin/env python3
"""Gate 2.4 additional sparse native motion, exact restored physical fixture signals and locked effects."""
import argparse, hashlib, json, os, subprocess, sys, time, zipfile
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
N=330;FPS=30
BASIS={'autumn':('spring_autumn_source.zip','9c4e69ee6d6b1944cfc36a3030d24fe1db790ef74a83e9885d3abf6ca8354898','spring_autumn_gate2/src'),
       'winter':('gate2_summer_winter_source_qa.zip','758fd46755f7ad8259b9ee20e1ba6e6f6472c485b89e67db03110d4b6f1b99ce','.')}
V23_SOURCE_SHA='6b6be061999ce67c7585907eddc7b9fea1819ae34d35c4be52d12916045e8e2a'
RAW23={'autumn':'f23694966d61f31bee3f8b15493040bb7e952a67c3495cc904e1a7d46df97a86',
       'winter':'bb296199e15acfe4b876fdaa7d06d88f58bdc0fec05586bdcd9052ad8c93d3d0'}
PEAK={'autumn':[(142,'bilateral_leaf_patches'),(152,'birds_and_rolling'),(154,'warm_ground_dapple'),(202,'lamp_before'),(205,'lamp_drop'),(209,'lamp_after')],
      'winter':[(145,'twig_tips'),(150,'holiday_banner'),(165,'separate_page'),(202,'lamp_before'),(205,'lamp_drop'),(209,'lamp_after'),(224,'snow_pulse')]}
AB={'autumn':{'leaf_tremor':(31,61,114,121,130,136,142,149,155,165,175,183,196,205,218),
              'dapple':(96,111,119,125,135,142,148,154,161,169,175,183,194,203,220,234),
              'extra_aloft':(31,115,123,140,142,149,155,166,174,178,196,208,221,248,280),
              'lamp':tuple(range(199,223)), 'kiosk':(31,123,140,165,203,204,208,214,247,265),
              'tv':(0,31,110,114,121,142,165,203,218,248,277),
              'rolling':(0,134,145,152,165,173,178,193,210),
              'steam':(0,121,134,165,184,204,208), 'birds':(126,132,145,152,161,175,185,206)},
    'winter':{'twig_tremor':(111,121,125,132,143,145,150,156,163,176,188,195,207,218,226,240),
              'banner':tuple(range(110,252,5)), 'lamp':tuple(range(199,216)), 'tv':(1,31,115,121,149,165,201,208,218,242,277),
              'page':(0,*range(128,210,2),165,221),'smoke':(0,134,165,192,214,220),
              'powder':(146,157,164,177,191,214,220,224,241),'window_snow':(0,112,145,155,164,167,170,184,214,221),
              'gust':(0,130,153,164,173,209,214,224)}}
STRIPS={'autumn':{'aloft':((40,56,275,131),tuple(range(115,145,3)),2,3),
                  'rolling':((80,137,212,176),tuple(range(140,185,3)),3,3),
                  'steam':((69,112,85,139),tuple(range(160,185,2)),8,6),
                  'birds':((130,3,180,25),tuple(range(125,165,3)),5,4),
                  'lamp':((158,56,195,89),tuple(range(199,212)),5,5),
                  'dapple':((42,139,101,168),tuple(range(115,180,5)),4,5)},
        'winter':{'page':((243,99,274,119),tuple(range(128,209,2)),5,6),
                  'powder':((10,22,62,108),tuple(range(150,233,7)),3,5),
                  'lamp':((32,37,77,79),tuple(range(199,212)),4,5),
                  'window_snow':((240,95,277,125),tuple(range(146,180,3)),5,5),
                  'facade':((232,19,245,85),tuple(range(148,204,4)),4,10),
                  'banner':((68,55,153,74),tuple(range(121,178,4)),4,4)}}
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as ff:
        for b in iter(lambda:ff.read(2<<20),b''):h.update(b)
    return h.hexdigest()
def basis(repo,work,scene):
    filename,hash,root=BASIS[scene]
    f=repo/'previews'/'gate_2'/'source'/filename
    if not f.is_file() or sha(f)!=hash:raise ValueError(f'Wrong frozen source: {f}')
    p=work/'base'/scene;p.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(f) as z:z.extractall(p)
    return p/root
def encode(a,out):
    pth=out.with_suffix('.pending.mp4')
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-nostdin','-y','-filter_threads','1','-f','rawvideo','-pixel_format','rgb24',
         '-video_size','320x180','-framerate','30','-i','-','-an','-vf','scale=1920:1080:flags=neighbor:out_color_matrix=bt709:out_range=tv,format=yuv420p',
         '-c:v','libx264','-preset','veryfast','-threads','2','-g','330','-keyint_min','330','-sc_threshold','0','-qp','0','-pix_fmt','yuv420p',
         '-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-color_range','tv','-movflags','+faststart',str(pth)]
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    for _ in range(2):p.stdin.write(memoryview(np.ascontiguousarray(a)).cast('B'))
    p.stdin.close()
    if p.wait():raise RuntimeError('QP0 encode failed')
    pth.replace(out)
def still(mp4,frame,out):
    expr=f'select=eq(n\\,{frame})'
    tmp=out.with_name(out.stem+'.pending.png')
    cmd=['ffmpeg','-v','error','-xerror','-y','-threads','2','-i',str(mp4),'-vf',expr,'-vsync','vfr','-frames:v','1','-threads','1',str(tmp)]
    subprocess.run(cmd,check=True)
    with Image.open(tmp) as im:
        if im.size!=(1920,1080):raise ValueError('Incorrect full-size peak still')
    tmp.replace(out)
def strips(scene,frames,qa):
    for k,(r,picks,m,cols) in STRIPS[scene].items():
        x,y,X,Y=r;w=(X-x)*m;h=(Y-y)*m
        out=Image.new('RGB',(cols*(w+5),((len(picks)+cols-1)//cols)*(h+16)),(31,30,34))
        dr=ImageDraw.Draw(out)
        for i,f in enumerate(picks):
            x0=(i%cols)*(w+5);y0=(i//cols)*(h+16)
            im=Image.fromarray(frames[f,y:Y,x:X]).resize((w,h),Image.Resampling.NEAREST)
            out.paste(im,(x0,y0))
            dr.text((x0+1,y0+h+1),f'{f:03d} / {f/30:.2f} s',fill=(231,225,215))
        out.save(qa/f'{scene}_{k}_strip.png')

def structural_and_signals(s,scene,frames,qa):
    actual_tree=s.b.get('tag5',np.zeros((180,320),np.float32))
    actual_crown=s.b.get('tag1',np.zeros((180,320),np.float32))
    affected=s.angles.all_mask;protected=s.angles.protected
    if np.any(affected&protected):raise AssertionError('neighborhood intersects branch/street fixture lock')
    stepmap=np.empty((N,180,320),np.int8)
    x=np.broadcast_to(np.arange(320,dtype=np.int16)[None],(180,320))
    for n in range(N):stepmap[n]=s.angles.apply(x,n)-x
    assert np.max(np.abs(stepmap))==1
    assert not stepmap[:,protected].any()
    assert np.all(stepmap.reshape(N//5,5,180,320)==stepmap[::5,None])
    np.savez_compressed(qa/f'{scene}_anchor_masks.npz',wood_coverage=actual_tree,
                        foliage_coverage=actual_crown,protected=protected,moving_support=affected,
                        donor_dx_330=np.asfortranarray(stepmap))
    paint=np.zeros((180,320,3),np.uint8);paint[protected]=(78,109,157);paint[affected]=(254,175,68)
    Image.fromarray(paint).resize((960,540),Image.Resampling.NEAREST).save(qa/f'{scene}_anchor_mask.png')
    # At exactly the same production call path, turn off the new mechanisms and
    # verify the entire raw sequence against the independently frozen v2.3 fingerprint.
    hh=hashlib.sha256()
    for i in range(N):hh.update(s.frame(i/FPS,omit=s.NEW).tobytes('C'))
    back=hh.hexdigest()
    if back!=RAW23[scene]:raise AssertionError(f'Previous tag behavior changed for {scene}: {back}')
    verify_live=[]
    if scene=='winter':
        # Keep the *new* light signals active and isolate weather/paper. Every one
        # of the original suspect facade's native pixels must remain byte-identical.
        rm=tuple(k for k in s.GROUPS if k not in ('lamp','tv'))
        view=[229,18,250,94];a,b,c,d=view
        f0=s.frame(0.,omit=rm)[b:d,a:c].copy()
        verify_live=[int(np.abs(s.frame(i/FPS,omit=rm)[b:d,a:c].astype(np.int16)-f0).max()) for i in range(N)]
        if max(verify_live)!=0:raise AssertionError('Nonphysical x237 illumination')
    gg=[s.gains_at(i) for i in range(N)]
    direction_by_frame=[s.angles.directions(i) for i in range(N)]
    nudge=[{k:(v.tolist() if isinstance(v,np.ndarray) else float(v)) for k,v in z.items()} for z in gg]
    signal={'parameters_by_frame':nudge,'direction_by_frame':direction_by_frame,
            'held_native_frames':5,'winter_facade_max_rgb_delta_by_frame':verify_live}
    if scene=='winter':
        banner=s.banner
        y=np.broadcast_to(np.arange(180,dtype=np.int16)[:,None],(180,320))
        dy=np.stack([(banner.apply(y,i)-y).astype(np.int8) for i in range(N)])
        assert np.abs(dy).max()==1 and not dy[:,banner.protected].any()
        assert np.all(dy.reshape(N//5,5,180,320)==dy[::5,None])
        assert not np.any(dy[:105]) and not np.any(dy[255:])
        np.savez_compressed(qa/'winter_banner_native_support.npz',donor_dy_330=np.asfortranarray(dy),
                            protected= banner.protected,targets=banner.mask)
        signal['banner_by_frame']=[banner.directions(i) for i in range(N)]
    else:
        np.save(qa/'autumn_dapple_scope.npy',s.dapple.support)
        signal['dapple_by_frame']=[s.dapple.at(xx) for xx in direction_by_frame]
    (qa/f'{scene}_signals.json').write_text(json.dumps(signal,separators=(',',':'))+'\n')
    h=np.zeros((180,320),np.int16);peak=np.zeros((180,320),np.uint8)
    for i in range(N):
        delta=np.abs(frames[i].astype('i2')-frames[(i-1)%N]).max(2)
        h+=delta>8;peak=np.maximum(peak,delta.astype(np.uint8))
    v=np.clip(115.*np.log1p(h)/np.log1p(max(12.,float(h.max()))),0,115)
    colors=np.stack([np.clip(v*2.,0,255),v*.78,v*.32],axis=-1).astype(np.uint8)
    Image.fromarray(colors).resize((960,540),Image.Resampling.NEAREST).save(qa/f'{scene}_motion.png')
    np.savez_compressed(qa/f'{scene}_motion_arrays.npz',transitions=h,max_rgb_delta=peak)
    return {'verified_base_v23_all_330_raw_sha256':back,'max_abs_native_displacement':1,'all_directions_hold_exactly_5_frames':True,
            'protected_pixels_no_displacement_count':int(protected.sum()),'total_movable_support_px':int(affected.sum()),
            'max_simultaneous_shift_px':int(np.count_nonzero(stepmap,axis=(1,2)).max()),
            'actual_lamp_gain_range':[min(z['lamp'] for z in gg),max(z['lamp'] for z in gg)],
            'max_winter_unsupported_facade_delta_all_330':max(verify_live) if verify_live else None}

def localized_strip(s,scene,frames,qa):
    # The panel of exact clip boxes depends on actual tagged-pixel hits.
    choices=s.angles.describe()
    if scene=='autumn':
        a=next(g for g in choices if g['side']=='left');b=next(g for g in choices if g['side']=='right')
        bins=[a,b];pts=[q['center_xy'] for q in bins]
        mid=[q['gust_f']+12 for q in bins]
    else:
        pts=[q['candidate_xy'] for q in choices[:2]];mid=[q['gust_start_f']+11 for q in choices[:2]]
    scale=8;dx=16;dy=13;W=(2*dx+1)*scale;H=(2*dy+1)*scale
    out=Image.new('RGB',(4*(W+5),4*(H+17)),(30,29,35));dr=ImageDraw.Draw(out)
    for j,((x,y),at) in enumerate(zip(pts,mid)):
        a=max(0,x-dx);b=max(0,y-dy);c=min(320,x+dx+1);d=min(180,y+dy+1)
        for k,v in enumerate((at-14,at-9,at-4,at+1)):
            f=v%N;on=frames[f];off=s.frame(f/FPS,omit=('leaf_tremor' if scene=='autumn' else 'twig_tremor',))
            for l,im in enumerate((on,off)):
                xx=k*(W+5);yy=(j*2+l)*(H+17)
                pane=Image.fromarray(im[b:d,a:c]).resize(((c-a)*scale,(d-b)*scale),Image.Resampling.NEAREST)
                out.paste(pane,(xx,yy))
                dr.text((xx+1,yy+H),f'{scene} f{f} {"ON" if l==0 else "OFF"} | {x},{y}',fill='white')
    out.save(qa/f'{scene}_local_integer_motion_strips.png')

def split(scene,mp4,work):
    root=work/'publish';base=root/'lossless_parts'/scene;base.mkdir(parents=True,exist_ok=True)
    parts=[];h=hashlib.sha256();size=0
    with mp4.open('rb') as src:
        for i,b in enumerate(iter(lambda:src.read(8_000_000),b'')):
            f=base/f'part-{i:02d}.bin';f.write_bytes(b)
            h.update(f.read_bytes());size+=len(b)
            parts.append({'path':str(f.relative_to(root)),'bytes':len(b),'sha256':sha(f)})
    whole=sha(mp4)
    if h.hexdigest()!=whole or size!=mp4.stat().st_size:raise AssertionError('lossless parts mismatch')
    entry={'output':mp4.name,'bytes':size,'sha256':whole,'parts':parts}
    (root/f'{scene}_parts.json').write_text(json.dumps(entry,indent=2)+'\n')
    return entry['bytes'],len(parts)

def render(scene,repo,work,component,scout):
    source23=repo/'previews'/'gate_2_3'/'source'/'autumn_winter_v23.zip'
    if not source23.is_file() or sha(source23)!=V23_SOURCE_SHA:raise ValueError('Wrong frozen v2.3 author source')
    src23=work/'basis_23';src23.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(source23) as z:z.extractall(src23)
    sys.path.insert(0,str(src23.resolve()))
    sys.path.insert(0,str(basis(repo,work,scene).resolve()))
    if scene=='autumn':
        from autumn24 import AutumnV24
        s=AutumnV24()
    else:
        from winter24 import WinterV24
        s=WinterV24()
    print('PLATE',scene,s.info,flush=True)
    target=work/'out';target.mkdir(parents=True,exist_ok=True)
    qa=work/'qa';qa.mkdir(parents=True,exist_ok=True)
    atlas=qa/'layer_native';atlas.mkdir(parents=True,exist_ok=True)
    draft=work/'drafts';draft.mkdir(parents=True,exist_ok=True)
    if scout:
        fs=sorted(set([0,*[x for x,_ in PEAK[scene]],*[x for v in AB[scene].values() for x in v]]))
        base={}
        for i in fs:
            base[i]=s.frame(i/FPS)
            Image.fromarray(base[i]).save(draft/f'{scene}_{i:03d}.png')
        for layer,fr in AB[scene].items():
            for i in fr:Image.fromarray(s.frame(i/FPS,omit=(layer,))).save(draft/f'{scene}_{i:03d}_no_{layer}.png')
        (qa/(scene+'_scene.json')).write_text(json.dumps(s.info,indent=2)+'\n')
        return
    t0=time.monotonic()
    tmp=target/(f'.{scene}_native.pending')
    frames=np.lib.format.open_memmap(tmp,mode='w+',dtype=np.uint8,shape=(N,180,320,3))
    for j in range(N):
        frames[j]=s.frame(j/FPS)
        if j%55==0:print('FRAMES',scene,j,round(time.monotonic()-t0,2),flush=True)
    assert np.array_equal(frames[0],s.frame(N/FPS))
    frames.flush(); final=target/(scene+'_native.npy');tmp.replace(final)
    mp4=target/(scene+'_loop.mp4')
    print('NATIVE_READY',scene,sha(final),flush=True)
    encode(frames,mp4)
    print('MP4_READY',scene,sha(mp4),flush=True)
    for i,ename in PEAK[scene]:
        still(mp4,i,target/f'{scene}_{ename}_f{i:03d}_1080p.png')
    bytes_,parts=split(scene,mp4,work)
    proof={};stat={}
    if component:
        stat=structural_and_signals(s,scene,frames,qa)
        strips(scene,frames,qa)
        localized_strip(s,scene,frames,qa)
        for layer,indices in AB[scene].items():
            rows=[]
            for i in indices:
                off=s.frame(i/FPS,omit=(layer,))
                on=frames[i].copy()
                both=np.concatenate((on,off),axis=1)
                Image.fromarray(both).save(atlas/f'{scene}_{layer}_f{i:03d}_on-left_off-right.png')
                delta=np.abs(on.astype(np.int16)-off).max(2);y,x=np.where(delta>2)
                rows.append({'index':i,'pixels':int(len(x)),'bbox_xyxy':[int(x.min()),int(y.min()),int(x.max()+1),int(y.max()+1)] if len(x) else None,'max_rgb_delta':int(delta.max())})
            proof[layer]=rows
    (qa/(scene+'_scene.json')).write_text(json.dumps({'scene':scene,'movie':s.info,'fps':FPS,'period_frames':N,'full_peaks':PEAK[scene],
           'loop_mp4_sha256':sha(mp4),'native_npy_sha256':sha(final),'mp4_bytes':bytes_,'lossless_parts':parts,'anchors':stat,'layers':proof},indent=2)+'\n')
    print('READY',scene,round(time.monotonic()-t0,2),flush=True)
def main():
    a=argparse.ArgumentParser();a.add_argument('scene',choices=['autumn','winter','both']);a.add_argument('--repo',type=Path,required=True);a.add_argument('--work',type=Path,required=True);a.add_argument('--scout',action='store_true');a.add_argument('--no-proof',action='store_true');args=a.parse_args()
    if args.scene=='both':
        for c in ('autumn','winter'):
            subprocess.run([sys.executable,str(Path(__file__).resolve()),c,*sys.argv[2:]],check=True)
    else:render(args.scene,args.repo.resolve(),args.work.resolve(),not args.no_proof,args.scout)
if __name__=='__main__':main()
