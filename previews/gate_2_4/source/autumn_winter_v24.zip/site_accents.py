"""Optional Round 15 supplement. Local physical light and fixed-end banner samples."""
from __future__ import annotations
import numpy as np
from pixel_wind import step
from engine.noise import fbm2

def smooth(x):
    q=np.clip(x,0.,1.);return q*q*(3.-2*q)

class Dapple:
    def __init__(self,b,lin,lamps,clusters):
        x,y=np.meshgrid(np.arange(320),np.arange(180))
        P=b['P'];xx,yy,zz=P.transpose(2,0,1);N=b['N']
        up=(N[...,1]>.65)&(yy>-.09)&(yy<.23)&(y>=112)&(y<=176)
        up&=b['tag5']<.07
        self.uses=[];products=[]
        sodium=[q for q in lamps if q['color'][0]>q['color'][1]*1.3 and q['grp'] in (0,1)]
        mottle=.42+.58*smooth((fbm2(xx*2.55+zz*.41,zz*1.84,445,3)-.32)/.61)
        # Four local shade-breaks on the two side pavements, never the centre/zebra line.
        for j,(cx,cy,wx,wy,side,link) in enumerate(((61,152,15.,7.7,'left',1),(86,145,12.,7.6,'left',3),
                                                   (232,150,14.,8.4,'right',1),(250,156,15.,7.5,'right',4))):
            pick=[i for i,q in enumerate(clusters.groups) if q[1]==side]
            which=(pick[link%len(pick)],pick[(link+1)%len(pick)])
            # Patch can only exist on the actual side paving, not tree, air or crossing paint.
            q=.86*(x-cx)+(y-cy)*.30;r=(y-cy)-.23*(x-cx)
            geom=smooth((1.-(q/wx)**2-(r/wy)**2)*1.5)
            same_x=(xx<-4.65)&(xx>-8.6) if side=='left' else (xx>4.65)&(xx<8.6)
            mask=geom*same_x*up*mottle
            lum=np.zeros_like(lin)
            for light in sodium:
                v=light['pos'][None,None]-P;D=np.maximum(.1,(v*v).sum(2));r0=np.sqrt(D);aim=(-v*light['axis']).sum(2)/r0
                cone=smooth((aim-light['cone'][0])/(light['cone'][1]-light['cone'][0]))
                lambert=np.maximum(0,(v*N).sum(2)/r0)
                local=(1-smooth((r0-11.)/9.))*lambert*cone/(D+.7)
                lum+=b['alb']*light['color']*local[...,None]
            # Existing lamp changes only its ground contact; restrained highlight below optical bloom.
            lum=np.minimum(lum,np.maximum(lin,0.)*np.array([.62,.56,.51],np.float32))
            area=lum*mask[...,None]*(.075+.013*(j%2))
            if np.count_nonzero(area.max(2)>.0002)<9:continue
            products.append(area.astype(np.float32));self.uses.append((which,[cx,cy],side))
        if len(self.uses)<2 or len({x[2] for x in self.uses})<2:raise ValueError('Need warm ray landing on both side pavements')
        self.parts=products;self.support=np.any(np.sum(np.abs(products),axis=0)>1e-8,axis=2)
    def at(self,dirs):
        return [float((.78*dirs[p]+.22*dirs[q])*(1. if i%2==0 else -.52)) for i,((p,q),_,_) in enumerate(self.uses)]
    def draw(self,out,dirs):
        for a,f in zip(self.parts,self.at(dirs)):
            if f:out+=a*f
    def describe(self):
        return [dict(crown_group_indices=indices,spot_center_xy=xy,side=side) for indices,xy,side in self.uses]

BUNTING_PHRASES=((0,1,1,1,0,0,-1,-1,0,0,1,1,0,0,-1,0),(0,0,1,1,0,-1,-1,0,0,1,1,1,0,-1,0,0),
                 (0,-1,0,0,1,1,0,0,-1,-1,0,0,1,0,0,0))
class Banner:
    """The approved holiday cloth, at its original world-space ties and baseline dimension."""
    def __init__(self,b,cam):
        a=np.array([-14.3,6.3,-13.5]);z=np.array([-6.5,6.1,-15.]);r=np.linspace(0.,1.,8)
        top=a+(z-a)*r[:,None];top[:,1]-=.15*4*r*(1-r)
        low=top-np.array([0.,1.,0.])
        xx,yy,D,_=cam.project(top);_,ey,_,_=cam.project(low)
        dep=b['depth'][...,4];tex=b['tag4'];wire=b.get('tag6',np.zeros(dep.shape))
        self.tie_xy=[[float(xx[0]),float(yy[0])],[float(xx[-1]),float(yy[-1])]]
        self.box=[int(xx[0])-1,int(min(yy))-1,int(xx[-1])+2,int(max(ey))+2]
        self.protected=np.ones((180,320),bool);self.mask=np.zeros((180,320),bool)
        self.groups=[]
        for k,(u,v) in enumerate(((92,107),(109,122),(124,137))):
            runs=[]
            for x in range(u,v):
                T=float(np.interp(x+.5,xx,yy));B=float(np.interp(x+.5,xx,ey))
                depth=float(np.interp(x+.5,xx,D));yl=int(np.ceil(T+3.05))
                ys=[y for y in range(yl,int(B+.50)) if abs(float(dep[y,x])-depth)<.64 and tex[y,x]>.25]
                if len(ys)<3 or np.any(wire[yl-1:max(ys)+2,x]>.07):continue
                y0,y1=ys[0],ys[-1]+1
                if len(ys)!=y1-y0:continue
                # Top attachment remains the source pixel, but is never a destination.
                self.mask[y0:y1+1,x]=True;self.protected[y0:y1+1,x]=False
                runs.append((x,y0,y1))
            if len(runs)<4:continue
            self.groups.append((runs,115+k*10,BUNTING_PHRASES[k]))
        if len(self.groups)<2:raise ValueError('Holiday banner physical coverage not found')
    def directions(self,n):
        return [step(n,p,a) or step(n,p+85,a[:10][::-1]) if 105<=n<255 else 0 for _,p,a in self.groups]
    def apply(self,out,n):
        src=out;dst=out.copy()
        for (runs,_,_),f in zip(self.groups,self.directions(n)):
            for x,y0,y1 in runs:
                if f==1:dst[y0:y1+1,x]=src[y0-1:y1,x]
                if f==-1:dst[y0:y1,x]=src[y0+1:y1+1,x]
        return dst
    def describe(self):
        return dict(box=self.box,world_height_m=1.,tie_centers_projected=self.tie_xy,
                    horizontal_extents_fixed=True,targets_support_px=int(self.mask.sum()),
                    spans=[dict(start=p,source_runs_x_y0_y1=r) for r,p,_ in self.groups])
