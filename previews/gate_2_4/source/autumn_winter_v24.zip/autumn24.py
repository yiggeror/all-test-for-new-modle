"""Controlled Gate 2.4 additions on the byte-verifiable autumn 2.3 renderer."""
from __future__ import annotations
import copy
import numpy as np
from scipy.ndimage import gaussian_filter
from autumn23 import Autumn,shot,fx,tea_vapor,dusk_birds
from pixel_wind import LeafClusters,frame_no,T
from fixture import gains,EVENTS
from site_accents import Dapple

def anchored_extra(owner):
    rng=np.random.default_rng(2423)
    b=owner.b;cam=owner.cam
    pos=b['P'];d=b['depth'][...,4];wood=b['tag5']
    y,x=np.mgrid[:180,:320]
    air0=owner.leaves.air
    backup=[]
    for l,r,c in [('left',np.count_nonzero([row[0]<0 for row in air0]),-1),
                  ('right',np.count_nonzero([row[0]>0 for row in air0]),1)]:
        qty=22-r
        axis=pos[...,0]*c
        belong=((x>17)&(x<150)) if c<0 else ((x>170)&(x<303))
        pool=(belong&(b['tag1']>.9)&(wood<.05)&(pos[...,1]>6.15)&(pos[...,1]<9.85)
             &(axis>2.25)&(axis<8.8)&(d>17.)&(d<48.)&(y>5)&(y<84))
        permitted=np.argwhere(pool)
        rng.shuffle(permitted)
        packed=[]
        for py,px in permitted:
            if len(packed)>=qty:break
            if any((px-oldx)**2+(py-oldy)**2<69 for oldy,oldx in packed):continue
            packed.append((int(py),int(px)))
        if len(packed)!=qty:raise RuntimeError(f'Missing physical source leaves: {l} {len(packed)}/{qty}')
        for i,(py,px) in enumerate(packed):
            p=pos[py,px].astype(float).copy()
            # Start slightly below actual tagged foliage, inside the old projected canopy.
            # A detach from behind a card still has to pass the original renderer's depth test.
            p[1]-=.013
            length=rng.uniform(.137,.218) if d[py,px]<33 else rng.uniform(.158,.233)
            # Releases stagger at two incommensurate rates across tree sides.
            begin=(1.15+i*3.095+(2.01 if c>0 else 0.))%T
            life=rng.uniform(4.02,7.18)
            dx=rng.uniform(.58,1.78);dz=rng.uniform(-.71,1.06)
            dy=-np.clip(.67*p[1]+rng.uniform(.05,1.08),4.6,7.15)
            row=(float(p[0]),float(p[2]),float(p[1]),float(length),float(begin),float(life),
                 float(dx),float(dz),float(dy),0.,0,float(rng.uniform(0.,2*np.pi)),
                 float(rng.uniform(.65,1.50)),int(rng.integers(0,len(owner.leaves.colors))))
            info={'id':f'A{24+len(backup):02d}','side':l,'source_xy':[px,py],'source_native_foliage_coverage':float(b['tag1'][py,px]),
                  'source_depth_m':float(d[py,px]),'world_xyz':p.tolist(),'release_s':float(begin),'life_s':float(life),
                  'pose_hold_frames':5}
            backup.append((row,info))
    side_sum=[sum(q[0]<0 for q in air0)+sum(a[0]<0 for a,_ in backup),sum(q[0]>0 for q in air0)+sum(a[0]>0 for a,_ in backup)]
    assert side_sum==[22,22]
    return [a for a,b in backup],[b for a,b in backup]

class AutumnV24(Autumn):
    NEW=('leaf_tremor','extra_aloft','lamp','kiosk','tv','dapple')
    GROUPS=Autumn.GROUPS+NEW
    def __init__(self):
        super().__init__()
        b=self.b;L=b['layers']
        cov=b['tag1'];d=gaussian_filter(cov,.78)
        w=.52*np.clip((cov-.56)/.40,0,1)**2*(3-2*np.clip((cov-.56)/.40,0,1))
        gate=np.clip((d-.37)/.41,0,1)
        w*=gate*gate*(3-2*gate)
        def mood(layer):
            lc=gaussian_filter(layer*cov[...,None],(.78,.78,0))/np.maximum(d[...,None],1e-6)
            return layer+(lc-layer)*w[...,None]
        self.lamp_r=mood(L[shot.G_LAMP]*.99749)
        self.tube_r=mood(L[shot.G_KIOSK]*.98923)
        self.tv_r=mood(L[shot.G_TV]*(np.array([.9,1.,1.2],np.float32)*1.092835))
        x,y,*_=self.cam.project(np.array([q['pos'] for q in self.lamps])+[0.,.15,0.])
        lamps=[]
        for i,q in enumerate(self.lamps):
            lamps.append([float(x[i]),float(y[i])])
            if q['grp']==shot.G_LAMP:
                fx.glow(self.lamp_r,x[i],y[i],q['color']*.012,r0=2.4,power=1.3)
        self.clusters=LeafClusters(b,self.static,lamps)
        self.angles=self.clusters
        self.dapple=Dapple(b,self.static,self.lamps,self.clusters)
        self.extra=copy.copy(self.leaves)
        self.extra.air,new=anchored_extra(self);self.extra.road=[]
        old=[dict(id=f'A{i:02d}',side='left' if z[0]<0 else 'right',world_xyz=[z[0],z[2],z[1]],release_s=z[4],
                  life_s=z[5],pose_hold_frames=5,source='v2.3 entry retained') for i,z in enumerate(self.leaves.air)]
        self.info.update({'native_leaf_tremor_spots':self.clusters.describe(),'air_all_44':old+new,'left_right_totals':[22,22],
                          'added_aloft_count':len(self.extra.air),'lamp_fixture_pxs_runtime':lamps,
                          'lamp_hard_drop_events_f':EVENTS['autumn'],'wind_dapple':self.dapple.describe(),'ground_tea_birds':'unmodified v2.3 functions'})
    def gains_at(self,n):return gains(fx,n,'autumn')
    def frame(self,t,omit=()):
        t%=T;n=frame_no(t);g=self.gains_at(n)
        lin=self.static.copy()
        if 'lamp' not in omit:lin+=self.lamp_r*(g['lamp']-1.)
        if 'kiosk' not in omit:lin+=self.tube_r*(g['kiosk']-1.)
        if 'tv' not in omit:lin+=self.tv_r*(g['tv']-1.)
        if 'leaf_tremor' not in omit:lin=self.clusters.apply(lin,n)
        if 'dapple' not in omit:self.dapple.draw(lin,self.clusters.directions(n))
        if 'rolling' not in omit:self.leaves.draw(lin,t,True)
        if 'aloft' not in omit:self.leaves.draw(lin,t)
        if 'extra_aloft' not in omit:self.extra.draw(lin,t)
        if 'steam' not in omit:tea_vapor(lin,self.cam,self.b,self.tea,t)
        if 'birds' not in omit:dusk_birds(lin,self.b,t)
        return self.pa.quantize(fx.bloom(lin,thresh=.50,sig=(1.2,4.5),gain=(.28,.20)))
