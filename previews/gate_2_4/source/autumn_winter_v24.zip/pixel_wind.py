"""Very local native-pixel motion sampled at six poses a second.

The source and destination of a change are neighbors one pixel apart. No
resampling, interpolation, image-domain deformation, or synthesized strips.
"""
from __future__ import annotations
import numpy as np
from scipy.ndimage import binary_dilation,binary_erosion,binary_opening,maximum_filter
FPS=30
N=330
T=N/FPS

def frame_no(t):
    return int(round(t*FPS))%N if abs(t*FPS-round(t*FPS))<1e-5 else int(t*FPS)%N

def step(n,start,score):
    k=n//5-start//5
    return 0 if not 0<=k<len(score) else score[k]

# No clusters flip at once. Direction changes have a one-pose neutral
# between opposite exposures. Their 5-frame hold is hard, not eased.
LEAF_PHRASES=((0,1,1,0,0,-1,-1,0,0,1,0),(0,0,-1,-1,0,1,1,0,0,-1,0),(0,1,1,1,0,-1,0,0,1,1,0),
              (0,-1,-1,0,0,1,1,1,0,-1,0))
TWIG_PHRASES=((0,-1,-1,0,0,1,1,0,0,-1,-1,0,1,0),(0,1,1,0,-1,-1,0,0,1,1,0,0,-1,0),
               (0,-1,-1,0,-1,0,1,1,0,0,-1,-1,0,0))

def peer(a, shift):
    # Edges never eligible, so the formal periodic boundary is never sampled.
    return np.roll(a,-shift,axis=1)

class LeafClusters:
    def __init__(self,b,lin,lamps_xy):
        self.tissue=b['tag1']
        y,x=np.mgrid[:180,:320]
        dep=b['depth'][...,4]
        protected=binary_dilation((b['tag5']>.025)|(b.get('tag6',0.)>.025),iterations=2)
        for a,c in lamps_xy:protected|=(x+.5-a)**2+(y+.5-c)**2<6.9**2
        self.protected=protected
        leaf=(self.tissue>=.885)&(b['sky']<.02)&~protected
        leaf&=(x>=4)&(x<=315)&(y>=4)&(y<=110)&(dep<85.)
        stable=leaf&peer(leaf,1)&peer(leaf,-1)
        safe=stable&(np.abs(peer(dep,1)-dep)<1.66)&(np.abs(peer(dep,-1)-dep)<1.66)
        mu=np.max(np.abs(lin-peer(lin,1)),axis=2)
        mv=np.max(np.abs(lin-peer(lin,-1)),axis=2)
        # From the same lit leaf plane; do not move a dark outline or sharp hot spark.
        safe&=(mu<.099)&(mv<.099)
        candidates=maximum_filter((mu+mv)*safe,size=(3,5))>.013
        main=((y<86)&safe&candidates)
        self.eligibility=safe
        self.groups=[];rng=np.random.default_rng(42763)
        for side,band in [('left',(18,132)),('right',(182,301))]:
            pool=np.argwhere(main&(x>=band[0])&(x<=band[1]))
            rng.shuffle(pool)
            sites=[]
            for yy,xx in pool:
                if len(sites)>=8:break
                if any((yy-j)**2+.9*(xx-i)**2 < 14**2 for j,i in sites):continue
                i=len(sites);av=rng.uniform(4.5,7.7);bv=rng.uniform(2.3,3.9);theta=rng.uniform(-.65,.65)
                xc=(x-xx)*np.cos(theta)+(y-yy)*np.sin(theta)
                yc=(y-yy)*np.cos(theta)-(x-xx)*np.sin(theta)
                m=safe&((xc/av)**2+(yc/bv)**2<1.)
                count=int(m.sum())
                if count<10:continue
                sites.append((int(yy),int(xx)))
                a=(105+5*((7*i)%12)+15*(side=='right'))
                b0=20+5*((5*i)%9)+5*(side=='left')
                shift=tuple(int(q) for q in LEAF_PHRASES[i%len(LEAF_PHRASES)])
                self.groups.append((np.where(m),side,(int(xx),int(yy)),a,b0,shift))
            if len(sites)<6:raise ValueError(f'Insufficient genuine crown spots: {side} {len(sites)}')
        self.all_mask=np.zeros((180,320),bool)
        for m,*_ in self.groups:self.all_mask[m]=True
        if np.any(self.all_mask&protected):raise ValueError('Canopy touched trunk/wire')
    def directions(self,n):
        return [step(n,when,q) or step(n,quiet,q[::-1]) for _,_,_,when,quiet,q in self.groups]
    def describe(self):
        return [dict(center_xy=p,side=side,pixel_count=len(m[0]),gust_f=a,quiet_f=b) for m,side,p,a,b,_ in self.groups]
    def apply(self,source,n):
        dst=source.copy()
        for ((y,x),*_ ),d in zip(self.groups,self.directions(n)):
            if d:dst[y,x]=source[y,x+d]
        return dst

class TwigTips:
    """Short, isolated runs of genuine wood, translated one native pixel per pose."""
    def __init__(self,b,lin,branch_xy):
        wood=b['tag5'];front=b['depth'][...,0];dep=b['depth'][...,4]
        y,x=np.mgrid[:180,:320]
        core=binary_opening((wood>.74)&(front<32.),
                            structure=np.ones((4,4),bool))
        core=binary_dilation(core,iterations=1)
        # The fixed main forks, snow release anchor, crop/outlines and lamp cannot enter a run or be donors.
        fixed=(y>=55)|(x>=84)|(x<=3)|core|(b.get('tag6',0.)>.04)
        fixed|=(x-52)**2+(y-44)**2<6.3**2
        fixed|=(x-branch_xy[0])**2+(y-branch_xy[1])**2<2.8**2
        tagged=(wood>.21)&(front<31.)
        candidates=[]
        for j in range(6,53):
            for a,c in np.flatnonzero(np.diff(np.r_[False,tagged[j],False])).reshape(-1,2):
                if not(4<=a<c<83) or c-a>3 or np.any(fixed[j,a-1:c+1]):continue
                if wood[j,a-1]>.22 or wood[j,c]>.22:continue
                if abs(dep[j,a-1]-dep[j,c])>9.:continue
                if min(dep[j,a-1],dep[j,c])<front[j,a:c].min()+.8:continue
                ll,rr=lin[j,a-1],lin[j,c];body=lin[j,a:c]
                if np.max(np.abs(ll-rr))>.038 or body.mean()>.94*min(ll.mean(),rr.mean()):continue
                candidates.append((int(j),int(a),int(c)))
        self.core,self.protected=core,fixed
        self.groups=[];self.eligible=np.zeros(fixed.shape,bool);self.all_mask=np.zeros(fixed.shape,bool)
        # End runs on the actual three finest paths seen through their blue background.
        # Coordinates guide selection only. Source pixels must always satisfy the physical tests above.
        for j,(cx,cy,rx,ry) in enumerate(((11,17,3.5,6),(21,23,3.0,7),(12,40,3.7,7),(34,8,3.8,3.2))):
            a=np.array([c for c in candidates if ((.5*(c[1]+c[2]-1)-cx)/rx)**2+((c[0]-cy)/ry)**2<1
                        and not np.any(self.all_mask[c[0],c[1]-1:c[2]+1])],dtype=int)
            if len(a)<3:continue
            # One continuous strand per row. Do not borrow from a neighboring twig.
            chosen=[]
            for v in np.unique(a[:,0]):
                rr=a[a[:,0]==v]
                chosen.append(rr[np.argmin(np.abs(.5*(rr[:,1]+rr[:,2]-1)-cx))])
            a=np.array(chosen,dtype=int)
            if len(a)<3:continue
            self.groups.append((a,(cx,cy),110+5*j,TWIG_PHRASES[j%len(TWIG_PHRASES)]))
            for yl,x0,x1 in a:
                self.eligible[yl,x0:x1]=True
                self.all_mask[yl,x0-1:x1+1]=True
        if len(self.groups)<3:raise ValueError(f'Thin credible twig runs unavailable: {len(self.groups)}')
        if np.any(fixed&self.all_mask):raise ValueError('Tip masks overlap fixed structure')
    def directions(self,n):
        return [step(n,start,q) or step(n,start+75,q[:11][::-1]) for _,_,start,q in self.groups]
    def describe(self):
        return [dict(candidate_xy=p,selected_source_count=int(np.sum(a[:,2]-a[:,1])),
                     source_runs_yl_x0_x1=a.tolist(),gust_start_f=f) for a,p,f,_ in self.groups]
    def apply(self,source,n):
        dst=source.copy()
        for (runs,*_),d in zip(self.groups,self.directions(n)):
            if not d:continue
            for y,x0,x1 in runs:
                # All donors offset exactly one pixel, including the side of the
                # strand just vacated. Source is never a partially updated frame.
                if d==1:dst[y,x0:x1+1]=source[y,x0-1:x1]
                if d==-1:dst[y,x0-1:x1]=source[y,x0:x1+1]
        return dst
