"""Controlled Gate 2.4 additions on the byte-verifiable winter 2.3 renderer."""
from __future__ import annotations
import numpy as np
from winter23 import Winter,sc,fx,chimney_plume,world_snow
from pixel_fx import flow,sm,T
from pixel_wind import TwigTips,frame_no
from fixture import gains,EVENTS
from site_accents import Banner

class WinterV24(Winter):
    NEW=('twig_tremor','lamp','tv','banner')
    GROUPS=Winter.GROUPS+NEW
    def __init__(self):
        super().__init__()
        b=self.b;L=b['layers'];c=self.st.c
        self.tint=TwigTips(b,self.static,self.branch_px)
        self.angles=self.tint
        self.banner=Banner(b,self.cam)
        # Grouped rays only: old x237 rectangle is not a light fixture and stays excluded.
        self.lamp_exposure_radius_m=(11.0,18.1)
        lamp=c['lamp']
        dst=np.linalg.norm(b['P']-lamp['pos'][None,None],axis=-1)
        # Fade only the modulation of the bulb: stable baked indirect light
        # remains untouched. Physical near-field falloff is already in L.
        local=(sm((18.1-dst)/7.1)*(1-b['sky'])).astype(np.float32)
        self.lamp_radiance=L[sc.G_LAMP]*local[...,None]
        x,y,_,_=c['lamp_px']
        glow=np.zeros_like(self.static)
        fx.glow(glow,x[0],y[0],lamp['color']*.012,r0=2.2,power=1.3)
        ys,xs=np.mgrid[:180,:320]
        r=np.hypot(xs+.5-x[0],ys+.5-y[0])
        self.lamp_radiance+=glow*sm((44-r)/17.)[...,None]
        self.tv_r=L[sc.G_TV]*np.array([.80,.84,.96],np.float32)[None,None]
        self.info.update({'native_twig_spots':self.tint.describe(),
                          'lamp_hard_drop_events_f':EVENTS['winter'],'lamp_exposure_radius_m':self.lamp_exposure_radius_m,'lamp_xy':[float(x[0]),float(y[0])],
                          'f165_locked_phase':True,'old_facade_watch_bbox':[229,18,250,94],'banner':self.banner.describe()})
    def gains_at(self,n):return gains(fx,n,'winter')
    def frame(self,t,omit=()):
        t%=T;p=t/T;n=frame_no(t);w=flow(t,.11);c=self.st.c
        g=self.gains_at(n)
        ballast=g['lamp'] if 'lamp' not in omit else 1.
        out=self.static.copy()
        if 'lamp' not in omit:out+=self.lamp_radiance*(ballast-1.)
        if 'tv' not in omit:out+=self.tv_r*(g['tv']-1.)
        if 'twig_tremor' not in omit:out=self.tint.apply(out,n)
        if 'banner' not in omit:out=self.banner.apply(out,n)
        self.st.actor.composite(out,self.st.arm(0. if 'page' in omit else t),self.st.lamp_pt,1.)
        if 'smoke' not in omit:chimney_plume(self.cam,self.b,t,self.st.roof,out,w)
        lamp=self.L
        l=[(lamp['pos'],lamp['color']*.48*ballast,.83,lamp['axis'],lamp['cone'],7.5),
           (self.ext,self.ext_col,.47,self.ext_axis,(0.,.60),3.2)]
        if 'snow' not in omit:
            for j,obj in enumerate(c['snow']):
                P,fade=obj.positions(p)
                incone=np.exp(-((P[:,2]-lamp['pos'][2])*.18)**2-((P[:,0]-lamp['pos'][0])*.22)**2)
                eddy=P[:,1]*.49-P[:,2]*.39+t*1.15
                P[:,0]-=w*(.74+.75*incone*(.57+.43*np.sin(eddy)))
                P[:,1]+=w*incone*(.38*np.sin(eddy+.93))
                world_snow(out,self.cam,self.b,P,obj.size,fade,l,c['amb']*(1.02 if j==2 else 1.),alpha=(.56,.64,.73)[j])
        if 'window_snow' not in omit:self.window_snow(out,t,l,w)
        if 'powder' not in omit:self.powder(out,t,l,w)
        if 'gust' not in omit:self.cone_flow(out,t,l,w)
        return self.pa.quantize(fx.bloom(out,thresh=.55,sig=(1.,3.5),gain=(.22,.14)))
