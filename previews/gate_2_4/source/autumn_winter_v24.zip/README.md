# Gate 2.4｜秋冬原生像素短动作

依照固定评审 [Round 15 / f496b686](https://github.com/yiggeror/all-test-for-new-modle/blob/f496b686d45c00f6016e2837f2ee4ebe9b46567c/REVIEW_LOG.md) 及同轮补遗 [953967b6](https://github.com/yiggeror/all-test-for-new-modle/blob/953967b611f63f424a8df90b9609c3dadb8cc5a4/REVIEW_LOG.md)。不继承 v2.2 的画面扭曲，未增加新的楼梯灯、人物光斑或远处车辆，未制作总片。

## 从仓库复现

需要 Python 3.12、FFmpeg/libx264、Noto CJK Serif/Sans（Debian 包 `fonts-noto-cjk`）。入口只使用同仓库内三份锁定的原始制图包：

- `previews/gate_2/source/spring_autumn_source.zip` → `9c4e69ee6d6b1944cfc36a3030d24fe1db790ef74a83e9885d3abf6ca8354898`
- `previews/gate_2/source/gate2_summer_winter_source_qa.zip` → `758fd46755f7ad8259b9ee20e1ba6e6f6472c485b89e67db03110d4b6f1b99ce`
- `previews/gate_2_3/source/autumn_winter_v23.zip` → `6b6be061999ce67c7585907eddc7b9fea1819ae34d35c4be52d12916045e8e2a`

仓库根目录：

```bash
repo="$PWD"
work="$repo/build/gate24_aw"
mkdir -p "$work/src"
unzip -q -o previews/gate_2_4/source/autumn_winter_v24.zip -d "$work/src"
python3.12 -m venv "$work/venv"
"$work/venv/bin/python" -m pip install -r "$work/src/requirements.txt"
export NUMBA_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1
"$work/venv/bin/python" "$work/src/render.py" both --repo "$repo" --work "$work"
for season in autumn winter; do
  "$work/venv/bin/python" "$work/src/verify.py" "$season" --repo "$repo" --output "$work/out" --json "$work/qa/${season}_verified.json"
  "$work/venv/bin/python" "$work/src/mobile.py" "$work/out/${season}_loop.mp4" "$work/out/mobile/${season}_loop.mp4"
done
"$work/venv/bin/python" "$work/src/leaf_trace.py" --repo "$repo" --work "$work"
```

`both` 可改为单季；`--scout` 只跑指定原生 A/B。正本为 `out/{season}_loop.mp4`（QP0，1920×1080、6×整像素放大、BT.709、30 fps、22 秒、660 帧）及单周期 330 帧 RGB。无损分卷 `publish/lossless_parts/{season}/` 单卷最多 8,000,000 字节，附分卷 SHA 和 MP4 SHA。兼容审片视频 `out/mobile` 独立编解码一次 11s，再流拷贝两次，所以两轮 330 对压缩包也完全相同。

## 秋

- 16 处稀疏梧桐冠内叶簇取样自真正的三维采样遮罩，两边各 8 处，实际被激活的是子集。每 5 帧更换姿态，单个出图像素只读取左/右正邻或原位；叶覆盖、邻居深度、树干/电线及路灯保留圈同时限制范围。**静态轮廓、树干与灯体不参与移动。** 没有连续波纹或混合坐标取样。
- 空中飘叶 **44 片，左右各 22**。v2.3 的 24 路保留；新增 20 路发源于实有的世界树冠落点，用相同的掌裂轮廓、受光/遮挡、5 帧叶面持样。地上 19 路卷叶、亭侧茶汽、3 只紫暮鸟的姿势、轨迹、时刻均用锁定源。
- 左右路缘的小暖斑由同侧两组冠叶方向驱动，限制在钠灯照及的真正朝上铺地。没有改变整画曝光、没有新增人工光源。
- 使用已有光组同步变更主钠灯及其小光晕：约 ±2.5% 背景波动，第 203–207 帧快速压降 20.1% / 0.167 s，第 217–220 帧压降 16.8% / 0.133 s。既有亭灯 ±2%，已有电视窗微弱自然色亮变化。

## 冬

- 只在真实上部细梢（1–3 个原生像素宽）进行有界单像素邻接步进。两侧替代像素经过背景深度与色差验证；保留粗主干、连接点、灯杆及枝头原雪粉出发点。最大水平位移 **±1 px**，每 5 帧保持。
- 原有 `欢度春节` 红布横幅的 3 个中下摆片段在约 3.5–8.5 秒微缓折动（纵向 **±1 px**，5 帧保持）。世界布高 1 m、原红布字样与遮挡未替换，两端及上沿原像素保持固定；`winter_banner_strip.png` 是逐帧 4× 局部查看。
- 左边灯具第 203–208 帧骤降 18.5% / 0.200 s，不熄灭。既有灯本体、正下锥区和参与近场散射的雪共享同一信号；灯周 ±2.5% 微颤。改变的光限于真灯近场（完全衰减约 18.1 m），远楼仅既有实体电视窗微动。
- 右侧原假灯整列区域以全部 330 帧在**新灯开启**的条件检查，剔除真实天气遮挡后无人工亮变。暖窗独立源不调亮；翻页/纸声原时相、右灯罩、烟、风雪的三维路径与浓度全部沿用 v2.3，只令左侧近场雪受对应灯光改变。

## 核查材料

- `*_anchor_masks.npz` 含源三角面采样覆盖、排除掩码、实际取样的全 330 帧原生偏移，正负邻居只有 ±1 且连续每 5 帧不动。冬横幅同类纵向图单独存为 `winter_banner_native_support.npz`。
- `*_signals.json` 含全部 330 真实亮度与色调、叶梢的整数状态、两侧暖斑因果驱动和远楼无假灯检验。秋的两侧叶片各自起末时间、真实新增源头列于 `autumn_scene.json`；`leaf_trace.py` 可原地证明全物件族的三维出图路径和朝向。
- `qa/layer_native` 同一帧左边实际开启、右边只关闭对应物理层；另给 `*_motion.png`、近照条带与从 QP0 正本解出的 1080p 整幅峰值。
- 新开关全部关闭时，调用**同一个**生产 frame 入口，遍历 330 帧并与独立归档 v2.3 RGB 哈希验证；不单独返回一套静态图。QP0 解码完整 660 帧后逐块检查所有 YUV 6×6/3×3 样点、对应两轮完全相同与 330 原生 RGB 复原精确。
