"""Canopy-only discrete texture taps and real triangle-anchored drifting petals."""
import numpy as np

from spring23 import base,fx

DIP=(138,144)
TV_TINT=np.array([.62,.69,.81],np.float32)


def gains(j,drop=True):
    k=j%330
    p=k/330
    ballast=1+.047*(fx.loopnoise(p,24,3)-.5)
    lamp=ballast*(.82 if drop and DIP[0]<=k<DIP[1] else 1.)
    tv=.935+.13*fx.loopnoise(p,23,11)
    tone=fx.loopnoise(p,17,14)-.5
    tint=TV_TINT*tv*(1+tone*np.array([.103,.015,-.082],np.float32))
    return float(lamp),tint


def smooth(x):
    x=np.clip(x,0.,1.)
    return x*x*(3-2*x)


class LeafShiver:
    """Integer neighbor sampling for a handful of depth-consistent inner leaf clusters."""
    def __init__(self,mask,depth,seed=741):
        self.mask=np.asarray(mask,bool).copy()
        self.dep=depth
        rng=np.random.default_rng(seed)
        nrow,ncol=self.mask.shape
        Y,X=np.mgrid[:nrow,:ncol]
        # Clusters are offset on alternate 5×5 tile rows; fixed, no framewise noise.
        gid=(Y//5)*(ncol//5+2)+(X+2*(Y//5%2))//5
        ids=gid[mask]
        anchors=np.unique(ids)
        # Sparse small patches among genuine leaf pixels, no global crown translation.
        eligible=anchors[rng.random(len(anchors))<.49]
        local=mask & np.isin(gid,eligible)
        pad=np.pad(mask,1)
        # A locked one-pixel moat protects every twiggier/nonleaf pixel and skyline.
        interior=np.ones_like(local)
        for dx,dy in [(-1,0),(1,0),(0,-1),(0,1)]:
            interior &= pad[1+dy:1+dy+nrow,1+dx:1+dx+ncol]
        self.y,self.x=np.where(local & interior)
        self.g=gid[self.y,self.x]
        count=int(gid.max())+1
        self.offset=rng.integers(0,22,size=count)
        self.bias=rng.integers(0,4,size=count)
        self.choice=rng.integers(0,2,size=count,dtype=np.int8)
        self.state=np.array([0,0,0,0,1,1,0,0,0,-1,-1,0,0,0,1,1,0,0,0,0,-1,0],np.int8)

    def taps(self,j):
        i=(j%330)//5
        a=self.state[(i+self.offset[self.g]+self.bias[self.g])%22]
        vert=self.choice[self.g]>0
        yy=self.y+a*vert
        xx=self.x+a*(~vert)
        b=(a!=0)&self.mask[yy,xx]&(np.abs(self.dep[self.y,self.x]-self.dep[yy,xx])<1.50)
        return self.y[b],self.x[b],yy[b],xx[b]

    def apply(self,lin,j):
        y,x,yy,xx=self.taps(j)
        # NumPy advanced index uses a value copy: every target reads the same original plate.
        lin[y,x]=lin[yy,xx]
        return y,x,yy,xx


class FlowerShower:
    """Seed positions are barycentric samples of real, face-tagged blossom triangles."""
    X_BINS=(.6,3.8,7.4,11.25)
    def __init__(self,g,near_faces):
        r=np.random.default_rng(325241)
        low,high=near_faces
        ids=np.flatnonzero((g['tf']>=low)&(g['tf']<high)&(g['F']['tag'][g['tf']]==base.pr.TAG_FOLIAGE))
        tri=np.stack([g[k][ids] for k in ('v0','v1','v2')],1)
        center=tri.mean(1)
        self.sources=[]
        for band,(lo,hi) in enumerate(zip(self.X_BINS,self.X_BINS[1:])):
            c=(center[:,0]>=lo)&(center[:,0]<hi)&(center[:,1]>4.25)&(center[:,1]<9.4)&(center[:,2]>5.2)
            if not c.any():raise ValueError(('no actual blossoms in source band',band,min(center[:,0]),max(center[:,0])))
            pool=np.flatnonzero(c)
            weights=smooth((center[pool,2]-5.2)/5)*.8+.2
            weights*=.40+.60*smooth((8.8-center[pool,1])/3.7)
            indices=r.choice(pool,size=65,replace=len(pool)<65,p=weights/weights.sum())
            b=r.random((65,3)); b/=b.sum(1)[:,None]
            p=(tri[indices]*b[...,None]).sum(1)
            launch=np.r_[r.uniform(0,11,30),r.uniform(4.27,7.03,35)]
            for i in range(len(launch)):
                burst=i>=30
                vx=-r.uniform(.76,1.45) if burst else -r.uniform(.46,.93)
                self.sources.append([
                    *p[i],launch[i],vx,-r.uniform(.53,.89),r.uniform(.24,.68),
                    r.uniform(2.24,4.36) if burst else r.uniform(1.58,3.35),
                    r.uniform(0,2*np.pi),int(r.integers(0,7)),int(r.integers(0,3)),
                    int(ids[indices[i]]),band,*b[i],int(burst)
                ])
        self.s=np.array(self.sources,np.float64)
        self.tint=np.asarray([[1,.66,.76],[1,.82,.84],[1,.71,.88]],np.float32)

    def export(self):
        columns='world_x world_y world_z release_s vx vy vz lifetime_s flutter_rad size_code tint_id geometry_triangle zone bary_u bary_v bary_w is_gust'.split()
        return {'columns':columns,'data':self.s.tolist(),
                'physical_source':'The approved tree only: barycentric origin on the tagged source flower card; all drift paths move negative x, descend, and individually pass through point-depth occlusion.'}

    def positions(self,j):
        tau=((j%330//2*2)/30-self.s[:,3])%11
        valid=np.flatnonzero((tau<self.s[:,7]-.07)&(tau>.075))
        age=tau[valid]
        d=self.s[valid]
        p=d[:,:3]+d[:,4:7]*age[:,None]
        p[:,0]+=.033*(np.sin(age*3.5+d[:,8])-np.sin(d[:,8]))
        p[:,2]+=.12*(np.sin(age*3.2+d[:,8])-np.sin(d[:,8]))
        return valid,age,p

    def draw(self,lin,dep,cam,frame,lamp,lightgain,catdepth=None):
        I,t,p=self.positions(frame)
        if not len(I):return [],np.empty((0,2),np.int16)
        d=self.s[I]
        u,v,zdist,forward=cam.project(p)
        xx=np.floor(u).astype(int); yy=np.floor(v).astype(int)
        active=(p[:,1]>.03)&(forward>0)&(xx>=0)&(xx<320)&(yy>=0)&(yy<180)
        L=lamp['pos']-p
        dd=np.sum(L*L,axis=1)
        cone=-(L/np.sqrt(dd)[:,None]*lamp['axis']).sum(1)
        c0,c1=lamp['cone']
        warm=(smooth((cone-c0)/(c1-c0))/(dd+.84))[:,None]*lamp['color'][None]*(.30*lightgain)
        c=np.minimum(np.array([.234,.135,.177],np.float32)[None]+warm,[.71,.418,.332])
        c*=self.tint[d[:,10].astype(int)]*np.exp(-zdist[:,None]*.0042)
        dims=d[:,9].astype(int)
        orient=np.floor(t*4+d[:,8]).astype(int)%3
        coverage=[]
        dots=[]
        def cover(y,x,z):
            a=float(np.mean(dep[y,x]>z))
            if catdepth is not None:
                cx,cy,cd=catdepth
                if cy<=y<cy+cd.shape[0] and cx<=x<cx+cd.shape[1]:
                    a=min(a,float(np.mean(cd[y-cy,x-cx]>z)))
            return a
        for k in np.argsort(forward)[::-1]:
            if not active[k]:continue
            x,y=xx[k],yy[k]
            cv=cover(y,x,zdist[k])
            a=(.70 if dims[k] else .53)*cv
            # Do not draw a floating first bright pixel in front of the bloom.
            if a<.18:continue
            lin[y,x]=lin[y,x]*(1-a)+c[k]*a
            coverage.append([int(I[k]),int(d[k,12]),int(x),int(y),round(float(zdist[k]),3),round(cv,3)])
            dots.append([y,x])
            if dims[k]>=5 and zdist[k]<31:
                dx,dy=((1,0),(0,1),(-1,1))[orient[k]]
                z,w=x+dx,y+dy
                if 0<=z<320 and 0<=w<180:
                    b=.50*cover(w,z,zdist[k])
                    if b>.05:
                        lin[w,z]=lin[w,z]*(1-b)+c[k]*b*.75
                        dots.append([w,z])
        return coverage,np.array(dots,np.int16).reshape(-1,2)

def moth_glints(lin,depth,cam,j,lamp,lightgain):
    """Two non-emissive 1px flutter glints located beside the physical lamp."""
    ret=[]
    for k in range(2):
        ph=(j%330//3*3)/330.*(2*np.pi)
        seed=1.2+k*1.87
        pos=lamp['pos'] + np.array([
            -.21+.28*np.cos(2*ph+seed)+.08*np.cos(5*ph+seed),
            -.46-.10*k+.19*np.sin(3*ph+seed),.23+.18*np.sin(2*ph+seed)])
        xx,yy,ds,_=cam.project(pos)
        x,y=int(xx),int(yy)
        if not (0<=x<320 and 0<=y<180):continue
        occ=float(np.mean(depth[y,x]>ds));wing=(.43+.50*(abs(np.sin(8*ph+seed))**2))*occ
        # Reflected sodium color. When it crosses the luminous core its contrast is naturally lost.
        reflect=np.minimum(lamp['color']*lightgain*np.array([.084,.088,.12]),[1.05,.60,.28])
        a=.30*wing
        lin[y,x]=lin[y,x]*(1-a)+reflect*a
        if wing>.05:ret.append([k,x,y,round(float(ds),4),round(occ,3)])
    return ret
