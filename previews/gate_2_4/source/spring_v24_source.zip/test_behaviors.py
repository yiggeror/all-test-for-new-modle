import unittest
import numpy as np

from cat24 import route, mesh, CAT_BODY_M, CAT_TAIL
from nature24 import gains, LeafShiver


class Round15Geometry(unittest.TestCase):
    def test_stage_path_preserves_its_fixed_intermission(self):
        a=route(120)[0]
        for f in range(120,180):
            self.assertTrue(np.array_equal(route(f)[0],a))
        self.assertEqual(a[1],0)
        self.assertGreater(route(285)[0][0],a[0])

    def test_cat_model_cannot_grow_with_camera(self):
        self.assertTrue(.42<=CAT_BODY_M<=.48)
        for frame in (0,40,80,120,145,165,220,295,329):
            w,info=mesh(frame)
            q=w.finalize(); v=np.vstack([q[p] for p in ['v0','v1','v2']])
            self.assertTrue((v[:,1]>=-2e-5).all())
            # Reviewer limits head, not the raised tail. Validate all non-tail faces.
            b=q['F']['tag'][q['tf']] != CAT_TAIL
            head_and_body=np.vstack([q[p][b] for p in ('v0','v1','v2')])
            self.assertTrue((head_and_body[:,1]<=.34).all())
            self.assertTrue((v[:,1]<.37).all())
            self.assertTrue(any(info['feet_planted']))
            self.assertEqual(v.shape[1],3)

    def test_single_instant_dip_at_exact_cadence(self):
        base=np.array([gains(j,False)[0] for j in range(330)])
        full=np.array([gains(j,True)[0] for j in range(330)])
        self.assertTrue((np.abs(base-1)<.031).all())
        self.assertEqual(np.flatnonzero(full/base<.85).tolist(),list(range(138,144)))
        self.assertTrue(np.allclose(full[138:144]/base[138:144],.82))
        self.assertAlmostEqual(gains(0)[0],gains(330)[0])

    def test_integer_tap_never_takes_from_non_leaf(self):
        mask=np.zeros((40,50),bool);mask[5:33,8:41]=1;mask[:,20:22]=0
        near=np.full(mask.shape,31.,dtype=np.float32)
        leaf=LeafShiver(mask,near,seed=731)
        valid_ct=0
        for k in range(0,330,5):
            y,x,yy,xx=leaf.taps(k)
            valid_ct+=len(y)
            self.assertTrue(mask[y,x].all() and mask[yy,xx].all())
            self.assertTrue(((abs(y-yy)<=1)&(abs(x-xx)<=1)).all())
        self.assertGreater(valid_ct,0)
