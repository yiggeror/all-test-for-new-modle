"""Spring Gate 2.3. The full spring tree is immutable. Cloth advances on discrete pose holds."""
import numpy as np
from pathlib import Path
import sys, os
here=Path(__file__).resolve()
choices=[Path(os.environ['RAINROJI_SOURCE_ROOT'])] if 'RAINROJI_SOURCE_ROOT' in os.environ else [*here.parents, *(p/'alltest_gate1_prod' for p in here.parents)]
ROOT=next((p for p in choices if (p/'shots/spring_g15.py').is_file() and (p/'prototype/film/engine/rt.py').is_file()),None)
if ROOT is None: raise SystemExit("Set RAINROJI_SOURCE_ROOT to the pinned all-test-for-new-modle checkout.")
for p in (ROOT/'shots', ROOT/'prototype/film'):
 sys.path.insert(0,str(p))
from engine.world import World, roty, _n, srgb, MASK_HIDDEN, MASK_NOSHADOW
from engine import render as ray, fx, pix, mats
from engine.rt import Accel
from scenes import spring as base
import spring_g15 as shot

RACK = np.array([10.,0.,13.]); RMAT = roty(.4)
CLOTH_TAG=81
TAU=2*np.pi
PHASE_FRAMES=330
def smooth(x):
 x=np.clip(x,0,1); return x*x*(3-2*x)

def shower_gain(j):
 p=(j%330)/330
 return smooth((p-.402)/.125)*smooth((.785-p)/.135)
def cloth_points(which,p):
 p=(int(p)%330//5)/66
 u,v=np.meshgrid(np.linspace(0.,1.,25),np.linspace(0.,1.,19))
 # Two cloths from real rack coordinates; fixed clipped top leaves a short visual air gap.
 if which==0:
  start,width,length,z0=-2.18,1.29,1.18,-.55
 else:
  start,width,length,z0=-.67,.83,.72,0.
 x=start+width*u
 sag=.1*np.maximum(0.,1.-(2*x/5)**2)
 h=2-sag-.013
 w=TAU*(2*p - .53*u-.13*v) + which*.82
 level=.65+.27*shower_gain((int(p*330)+10)%330)
 billow=level*(.30+.27*np.sin(w)+.12*np.sin(w*1.5+TAU*p)) * v**1.48
 shift=v**1.53*(.21*np.sin(TAU*(p+.12))+.075*np.sin(w-.4))
 fold=.075*np.sin(TAU*(2.55*u-.22*v))+ .030*np.sin(TAU*(5.5*u+.15*v))
 hem=.036*np.sin(TAU*(2.3*u+p)) * v**3
 y=h-length*v+.23*billow**2+hem
 z=z0+fold*v**.8-billow
 return np.stack((x+shift,y,z),axis=-1)@RMAT.T+RACK

@mats.mat('gate22_washed')
def cloth_mat(s):
 # No emission; dye and seam both filter incident light.
 return s.col * (.925+.075*np.cos(s.seed*8.3))[:,None]

def add_cloth(w,p):
 # Keep both dye-dark, but resolve the load-bearing 3-D wire and attached clips
 # at native raster sampling, rather than air-gapping pale fabric from its rack.
 with w.at(RACK,yaw=.4):
  for z0 in (-.55,0.):
   base.pr.wire(w,(-2.5,2.,z0),(2.5,2.,z0),sag=.1,r=.018,n=24,col='#64524e')
 for i in range(2):
  q=cloth_points(i,p); r,c=np.indices((q.shape[0]-1,q.shape[1]-1))
  palette=[['#e4d5d1','#c9b9bb','#b8a7ad'],['#99a7c1','#8591ab','#a7acc0']][i]
  colors=np.broadcast_to(srgb(palette[0]),(*r.shape,3)).copy()
  colors[(r==q.shape[0]-2)|(c==0)|(c==q.shape[1]-2)]=srgb(palette[1])
  if i==0: colors[(r>=q.shape[0]-6)&(r<q.shape[0]-4)]=srgb(palette[2])
  else: colors[(c>=4)&(c<6)]=srgb(palette[2])
  w.quads(q[:-1,:-1].reshape(-1,3),q[:-1,1:].reshape(-1,3),q[1:,1:].reshape(-1,3),q[1:,:-1].reshape(-1,3),local=False,mat='gate22_washed',col=colors.reshape(-1,3),tag=CLOTH_TAG,seed=(r*.13+c*.11).ravel())
  for k in (3,21):
   x,y,z=q[0,k]
   w.box((x,y+.012,z),(.066,.11,.048),mat='plain',col='#aa8266')

class SplitAccel:
 def __init__(self,static,dynamic): self.static,self.dynamic=static,dynamic
 def anyhit(self,o,d,tmax,mask=0):
  return self.static.anyhit(o,d,tmax,mask)|self.dynamic.anyhit(o,d,tmax,mask)


def make_world():
 w=base.build()
 for L in w.lights:
  if L['grp']==base.G_LAMP and 'axis' in L:
   L['vol']*=.54; L['color']*=np.array([.94,.875,.78],np.float32); L['cone']=(-.16,.72)
 with w.at((-1.78,0,13.30),yaw=.21):
  t=-.095; M=np.array([[1,0,0],[0,np.cos(t),-np.sin(t)],[0,np.sin(t),np.cos(t)]])
  with w.at((0,0,0),M=M): shot._roadster(w)
 return w

class Petals:
 def __init__(self):
  r=np.random.default_rng(329)
  # Small distinct groups released along the existing blossom edge, not all in sync.
  n=94
  launch=np.linspace(4.46,6.65,12)[r.integers(12,size=n)] + r.uniform(-.22,.22,n)
  x=r.uniform(.6,4.6,n); y=r.uniform(4.9,7.2,n);z=r.uniform(9,14.5,n)
  self.start=np.stack((x,y,z),1);self.time=launch
  self.velocity=np.stack((-r.uniform(.88,1.64,n),-r.uniform(.57,.98,n),r.uniform(.08,.41,n)),1)
  self.lifetime=r.uniform(1.28,2.65,n);self.roll=r.uniform(0,TAU,n);self.size=r.integers(0,5,n)
  self.tint=r.integers(3,size=n)
  n2=24
  self.start=np.r_[self.start,np.stack((r.uniform(-1.8,5.2,n2),r.uniform(3.8,8.5,n2),r.uniform(8,22,n2)),1)]
  self.time=np.r_[self.time,r.uniform(0,11,n2)]
  self.velocity=np.r_[self.velocity,np.stack((-r.uniform(.19,.55,n2),-r.uniform(.34,.61,n2),r.uniform(-.13,.19,n2)),1)]
  self.lifetime=np.r_[self.lifetime,r.uniform(1.6,3.8,n2)]
  self.roll=np.r_[self.roll,r.uniform(0,TAU,n2)];self.size=np.r_[self.size,r.integers(0,4,n2)];self.tint=np.r_[self.tint,r.integers(3,size=n2)]
 def draw(self,lin,dep,cam,j,lamp):
  # World trajectories are projected at 15 fps onto discrete native pixel patterns.
  t=(j//2*2)/30.
  tau=(t-self.time)%11
  valid=tau < self.lifetime
  age=tau[valid]; f=self.roll[valid]
  p=self.start[valid]+self.velocity[valid]*age[:,None]
  p[:,0]+=.14*np.sin(age*4+f);p[:,2]+=.19*np.sin(age*3.2+f)
  u,v,d,z=cam.project(p); px=np.floor(u).astype(int);py=np.floor(v).astype(int)
  lv=lamp['pos']-p; dd=np.sum(lv*lv,axis=1)
  cone=-(lv/np.sqrt(dd)[:,None]*lamp['axis']).sum(1)
  c0,c1=lamp['cone']; cone=smooth((cone-c0)/(c1-c0))
  radiance=np.array([.24,.146,.205])[None]+(cone/(dd+.80))[:,None]*lamp['color'][None]*.33
  radiance=np.minimum(radiance,[.82,.46,.34])*np.asarray([[1,.58,.69],[1,.75,.74],[1,.71,.83]])[self.tint[valid]]
  radiance = radiance*np.exp(-d[:,None]*.0055)
  dims=self.size[valid]; orient=np.floor(age*5+f).astype(int)%3
  for k in np.argsort(z)[::-1]:
   x,y=px[k],py[k]
   if z[k]<0 or not (0<=x<320 and 0<=y<180):continue
   cover=np.mean(dep[y,x]>d[k]); a=(.79 if dims[k] else .57)*cover
   if a<.18 or age[k]<.06 or self.lifetime[valid][k]-age[k]<.06:continue
   lin[y,x]=lin[y,x]*(1-a)+radiance[k]*a
   # Flat two-pixel folded silhouettes on the handful of nearer petals.
   if dims[k]==4 and d[k]<28:
    dx,dy=[(1,0),(0,1),(-1,1)][orient[k]]
    xx=x+dx; yy=y+dy
    if 0<=xx<320 and 0<=yy<180:
      b=.63*np.mean(dep[yy,xx]>d[k]);lin[yy,xx]=lin[yy,xx]*(1-b)+radiance[k]*b*.74

def main():
 import argparse,json
 from PIL import Image
 from scipy.ndimage import gaussian_filter
 ap=argparse.ArgumentParser();ap.add_argument('--out',required=True,type=Path);ap.add_argument('--span',default='0:330')
 ap.add_argument('--frames',help='comma-separated real full-size draft stills')
 args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
 cam=shot.camera();H,W,S=180,320,3
 fx.SC=W/480.
 w=make_world();g=w.finalize()
 st=Accel(g['v0'],g['v1'],g['v2'],g['tm'])
 cache=args.out.parent/'spring23_fixed_9samples.npz'
 if cache.is_file():
  with np.load(cache) as a: pl={k:a[k] for k in a.files}
 else:
  print('Tracing fixed crown and yard.',flush=True)
  pl,_=ray.render(w,cam,shot.sky,S=S,acc=st,**dict(shot.RENDER,hook=base.petal_hook))
  fx.denoise(pl,**shot.DENOISE)
  tmp=cache.with_suffix('.partial.npz');np.savez_compressed(tmp,**pl);tmp.replace(cache)
 sky=fx.native_sky(base,cam,H,W)*pl['sky'][...,None]
 bg=sky+pl['layers'][0]+pl['layers'][base.G_LAMP]+pl['layers'][base.G_TV]*np.array([.62,.69,.81])[None,None]
 lamps=[l for l in w.lights if l['kind']=='point' and 'axis' in l]
 for l in lamps:
  x,y,*_=cam.project(l['pos']+np.array([0,.15,0]))
  fx.glow(bg,x,y,l['color']*.010,r0=2.4,power=1.3)
 # Apply glow to the static scene only, preserving hard particle/cloth edges.
 bg=fx.bloom(bg,thresh=.5,sig=(1.2,4.5),gain=(.24,.17))
 crop=(241,320,141,180)
 x0,x1,y0,y1=crop
 o,d=cam.rays(S,np.random.default_rng(682));select=np.zeros((H*S,W*S),bool);select[y0*S:y1*S,x0*S:x1*S]=True
 ix=np.flatnonzero(select.ravel());o=o[ix];d=d[ix]
 td,ids=st.closest(o,d,mask=MASK_HIDDEN);td[ids<0]=1e9
 p=pl['P'];gx,gy,gz=p.transpose(2,0,1)
 gr=np.where((gx>7.1)&(gx<12.7)&(gy>-.08)&(gy<.18)&(gz>9.1)&(gz<18.9))
 pa=p[gr].astype(np.float32);pa[:,1]+=.007
 vd=np.array([8.6,2.7,6.2])-pa; dd=np.linalg.norm(vd,axis=1);vd/=dd[:,None]
 centers=[dict(v,radius=0.,soft=0.) for v in w.lights]
 petals=Petals()
 vig=fx.vignette(H,W,.15)
 aa,bb=map(int,args.span.split(':')); fs=list(range(aa,bb)) if not args.frames else list(map(int,args.frames.split(',')))
 if not args.frames:
  stem=f'spring_raw_{aa:03d}_{bb:03d}'
  store=np.lib.format.open_memmap(args.out/f'{stem}.partial.npy','w+',dtype='uint8',shape=(bb-aa,H,W,3))
 last=-1;geometry=[]
 for i,j in enumerate(fs):
  key=j%330//5*5
  if key!=last:
   last=key
   c=World(seed=6001);c.pixang=2*cam.th/W;add_cloth(c,key)
   gg=c.finalize();da=Accel(gg['v0'],gg['v1'],gg['v2'],gg['tm'])
   t,tr=da.closest(o,d,tmax=td,mask=MASK_HIDDEN)
   sel=np.where(tr>=0)[0];q=o[sel]+d[sel]*t[sel,None]
   sf=ray.surface(c,gg,tr[sel],q,d[sel],t[sel])
   E=ray.direct(centers,SplitAccel(st,da),q,sf['N'],np.random.default_rng(93),base.K)
   # Warm low-level bounce and cool diffuse skylight, with real lamps and occlusion above.
   E[0]+=np.array([.225,.150,.164])[None]* (.78+.25*np.abs(sf['N'][:,1,None]))
   L=E.sum(0)*sf['alb']
   T=ray.fog_T(shot.RENDER['fog'],o[sel],q,t[sel]);L=L*T[:,None]+shot.RENDER['fog']['color'](d[sel])*(1-T[:,None])
   def aggregate(a):
    return a.reshape(y1-y0,S,x1-x0,S,*a.shape[1:]).mean((1,3))
   m=np.zeros(len(ix),np.float32);m[sel]=1; cover=aggregate(m)
   rgb=np.zeros((len(ix),3),np.float32);rgb[sel]=L
   still=bg.copy()
   shadow=np.zeros((H,W),np.float32); shadow[gr]=da.anyhit(pa,vd,dd-.03,mask=MASK_NOSHADOW)*.24
   still*=1-gaussian_filter(shadow,.42)[...,None]
   still[y0:y1,x0:x1]=(1-cover[...,None])*still[y0:y1,x0:x1]+aggregate(rgb)
   dn=td.copy();dn[sel]=t[sel]
   dep=pl['depth'].copy()
   dep[y0:y1,x0:x1]=dn.reshape(y1-y0,S,x1-x0,S).transpose(0,2,1,3).reshape(y1-y0,x1-x0,S*S)
   geometry.append([key,len(sel),int(np.count_nonzero(sf['tag']==CLOTH_TAG))])
  lin=still.copy();petals.draw(lin,dep,cam,j,lamps[0])
  a=np.round(pix.tonemap(lin*vig,**shot.GRADE)*255).clip(0,255).astype(np.uint8)
  if args.frames: Image.fromarray(a).resize((1920,1080),Image.Resampling.NEAREST).save(args.out/f'spring_{j:03d}.png')
  else:store[i]=a
  if i%15==0: print('frame',j,'pose',key,'cloth samples',geometry[-1][-1],flush=True)
 if not args.frames:
  store.flush();del store
  (args.out/f'{stem}.partial.npy').replace(args.out/f'{stem}.npy')
  (args.out/f'{stem}.json').write_text(json.dumps(geometry)+'\n')
if __name__=='__main__':main()
