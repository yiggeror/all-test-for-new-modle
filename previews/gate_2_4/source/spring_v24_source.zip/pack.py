"""Nearest-neighbor 1080p double-cycle encoding and palette-locked quantizer."""
import os, subprocess
from pathlib import Path
import numpy as np
from spring23 import pix

H,W,S=180,320,6

def encode(frames, path, strict, kbps=2840, work=Path('.')):
    dest=path.with_suffix('.tmp.mp4')
    filt=f'scale={W*S}:{H*S}:flags=neighbor:out_color_matrix=bt709,format=yuv420p'
    base=['ffmpeg','-v','error','-nostdin','-y','-filter_threads','1','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate','30','-i','-','-an','-vf',filt,'-c:v','libx264','-threads','3']
    mov=['-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-movflags','+faststart']
    if strict:
        passes=[base+['-preset','veryfast','-qp','0']+mov+[str(dest)]]
    else:
        common=base+['-preset','slow','-profile:v','high','-b:v',f'{kbps}k','-passlogfile',str(work/'s22_pass')]
        passes=[common+['-pass','1','-f','null',os.devnull], common+['-pass','2']+mov+[str(dest)]]
    for args in passes:
        with subprocess.Popen(args,stdin=subprocess.PIPE) as p:
            buf=memoryview(np.ascontiguousarray(frames)).cast('B')
            p.stdin.write(buf);p.stdin.write(buf);p.stdin.close()
            if p.wait()!=0: raise RuntimeError('ffmpeg encode')
    dest.replace(path)

def rgb_key(rgb):
    rgb=rgb.astype(np.uint32)
    return (rgb[...,0]<<16)|(rgb[...,1]<<8)|rgb[...,2]
def quantize_clip(raw,pal,thr,strength):
    # Identity with original pix.quantize for uint8 source, amortizing nearest
    # palette and projected dither weights across repeated 24-bit colors.
    found=np.zeros(1<<24,bool)
    for frame in raw: found[rgb_key(frame)]=True
    keys=np.flatnonzero(found)
    l1=np.zeros(1<<24,np.uint8);l2=np.zeros(1<<24,np.uint8);cut=np.zeros(1<<24,np.float32)
    pl=pal['lab']*pix.LABW
    for aa in range(0,len(keys),32768):
        kk=keys[aa:aa+32768]
        rgb=(np.column_stack((kk>>16,kk>>8&255,kk&255)).astype(np.float32))/255
        lab=pix.oklab(rgb)*pix.LABW
        d=((lab[:,None]-pl[None])**2).sum(-1)
        i1=d.argmin(1);d[np.arange(len(kk)),i1]=1e9;i2=d.argmin(1)
        c1=pl[i1]; v=pl[i2]-c1
        t=((lab-c1)*v).sum(-1)/np.maximum((v*v).sum(-1),1e-9)
        l1[kk]=i1;l2[kk]=i2;cut[kk]=np.clip(t,0,1)*strength
    out=np.empty_like(raw)
    for j,frame in enumerate(raw):
        k=rgb_key(frame);out[j]=pal['rgb'][np.where(cut[k]>thr,l2[k],l1[k])]
    return out
