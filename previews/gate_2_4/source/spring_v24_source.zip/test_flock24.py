import unittest
import numpy as np
from spring23 import shot
from flock24 import SpringFlock
class Flock(unittest.TestCase):
 def test_geometry_is_held_on_five_frames(self):
  a=SpringFlock(shot.camera(),np.full((180,320,9),1e9,np.float32))
  frames=[np.ones((180,320,3),np.float32) for _ in range(5)]
  evidence=[a.draw(v,j) for j,v in enumerate(frames,120)]
  self.assertEqual(len(evidence[0]),6)
  self.assertEqual(evidence[0],evidence[4])
  np.testing.assert_array_equal(frames[0],frames[4])
  self.assertTrue(all(2 <= it['projected_width_px'] <= 4 for it in evidence[0]))
  self.assertFalse(np.array_equal(frames[0],np.ones_like(frames[0])))
 def test_primary_geometry_cannot_paint_through_foreground(self):
  a=SpringFlock(shot.camera(),np.full((180,320,9),10,np.float32))
  v=np.ones((180,320,3),np.float32)
  proof=a.draw(v,120)
  self.assertTrue(all(it['visible_pixels']==0 and it['physical_pixels']>0 for it in proof))
  np.testing.assert_array_equal(v,1)
 def test_glide_and_opposed_wingbeats_are_different_world_shapes(self):
  a=SpringFlock(shot.camera(),np.full((180,320,9),1e9,np.float32))
  _,u,_,_,g=a._bird(0,140,8,57.0,65)
  _,v,_,_,d=a._bird(0,140,8,57.0,95)
  self.assertNotEqual(g,d)
  np.testing.assert_array_equal(u[:6],v[:6])
  self.assertFalse(np.array_equal(u[6:],v[6:]))
 def test_outside_natural_transit_is_unchanged(self):
  a=SpringFlock(shot.camera(),np.full((180,320,9),1e9,np.float32))
  v=np.ones((180,320,3),np.float32)
  for j in (0,49,210,329):self.assertEqual(a.draw(v,j),[])
  np.testing.assert_array_equal(v,1)
