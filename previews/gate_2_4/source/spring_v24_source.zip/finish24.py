"""Encode the true Gate 2.4 render, then prepare readback stills/strips and physical controls."""
import argparse
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy.ndimage import label
from pack import encode, rgb_key
from scene24 import gains, palette, CLOTH_RECT
from spring23 import shot, roty
from verify_exact import exact_master

W,H,S=320,180,6
HERE=Path(__file__).resolve().parent

def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def wr(path,x):
    path.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def font(size):
    p=Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
    return ImageFont.truetype(str(p) if p.is_file() else 'DejaVuSans.ttf',size,index=2 if p.is_file() else 0)

def contiguous_pts(media):
    p=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_streams','-show_packets',
                                          '-show_entries','stream=time_base,nb_frames,avg_frame_rate:packet=pts,duration',
                                          '-of','json',str(media)]))
    v,=p['streams']; t=Fraction(v['time_base'])
    frames=[int(x['pts'])*t for x in p['packets']]
    durations={int(x['duration'])*t for x in p['packets']}
    assert sorted(frames)==[Fraction(i,30) for i in range(660)]
    assert durations=={Fraction(1,30)} and v['nb_frames']=='660' and v['avg_frame_rate']=='30/1'
    return {'pts_count_checked':len(frames),'packet_time_base':str(t),'step_frame_seconds':'1/30',
            'min_pts':'0','max_pts':'659/30','identical_timestamps':0,'missing_timestamps':0}

def principal_wheel_px():
    cam=shot.camera()
    t=-.095
    M=roty(.21)@np.array([[1.,0,0],[0,np.cos(t),-np.sin(t)],[0,np.sin(t),np.cos(t)]])
    a=np.linspace(0,np.pi*2,181)
    roots=np.array([-1.78,0,13.30])
    vals=[]
    for x in [-.54,.54]:
        pos=np.column_stack((x+.398*np.cos(a),.40+.398*np.sin(a),np.zeros_like(a)))
        xx,yy,_,_=cam.project(pos@M.T+roots)
        vals.append({'approx_roadster_tire_world_diameter_m':.796,'height_approx_native_px':float(np.ptp(yy)),
                     'pixel_bounds':[float(v) for v in (min(xx),min(yy),max(xx),max(yy))]})
    return vals

def components(m):
    feat,n=label(m,np.ones((3,3),int))
    return feat,n

def read_layers(out,native,old=None):
    trace=json.loads((out/'spring_physical.json').read_bytes())
    petals=json.loads((out/'spring_petal_origins.json').read_bytes())
    q=np.load(out/'spring_layer_proof.npz',allow_pickle=False)
    p=np.load(out/'spring_cloth_pose_proof.npz',allow_pickle=False)
    cat=q['cat_samples']; ctex=q['cat_candidate_and_blocked']; sh=q['cat_shadow']; leaf=q['leaf_offset']
    control=q['rgb_control']
    keyed={(int(f),str(k)):i for i,(f,k) in enumerate(zip(q['control_frame'],q['control_name']))}
    def off(i,key):return control[keyed[i,key]]
    assert native.shape==(330,180,320,3) and q['frame_ids'].tolist()==list(range(330))
    assert p['pose_frames'].tolist()==list(range(0,330,5))
    locked=set(map(int,rgb_key(palette()['rgb'])))
    used={int(k) for frame in native for k in np.unique(rgb_key(frame))}
    assert len(used)<=60 and used.issubset(locked)
    np.testing.assert_equal(ctex[:,0]-ctex[:,1],cat.sum(1))
    branch=q['static_branch_and_wire'];eligible=q['eligible_leaf']
    leaf_targets=leaf.any(1)
    assert int(np.count_nonzero(leaf_targets & branch))==0
    yy,xx=np.mgrid[:H,:W]
    for j in range(330):
        D=leaf[j]; ok=leaf_targets[j]
        assert np.all(eligible[ok]) and np.all(eligible[(yy+D[0])[ok],(xx+D[1])[ok]])
        assert np.max(np.sum(np.abs(D),axis=0))<=1
    for i in range(0,330,5):
        assert all(np.array_equal(leaf[i],leaf[j]) for j in range(i,i+5))
        assert all(np.array_equal(cat[i],cat[j]) for j in range(i,i+5))
    assert np.max(np.abs(np.diff(np.concatenate((leaf,leaf[:1])),axis=0)))<=1
    assert max(t['visible_cat']['edge_static_collision_count'] for t in trace)==0
    for sf in (0,329):
        k=trace[sf]['visible_cat'];before=k['ray_hits_before_world_depth']
        assert before>100 and before==k['occluded_samples'] and k['ray_hits_after_world_and_cloth_depth']==0
        assert sh[sf].max()<=3 and np.array_equal(native[sf],off(sf,'cat'))
    j0=trace[120]['visible_cat']['root']
    assert all(np.array_equal(row['visible_cat']['root'],j0) for row in trace[120:180])
    left_index=next(t['frame'] for t in trace if t['visible_cat']['ray_hits_after_world_and_cloth_depth'])
    right_index=max(t['frame'] for t in trace if t['visible_cat']['ray_hits_after_world_and_cloth_depth'])
    assert 35<=left_index<=50 and right_index<329
    pv=[x['visible_cat'] for x in trace]
    boxes=[k['body_box_native_without_tail'] for k in pv if k['body_box_native_without_tail']]
    wheel=principal_wheel_px()
    bodyH=max(x[3]-x[1]+1 for x in boxes)
    assert bodyH+2<min(o['height_approx_native_px'] for o in wheel)
    test_head=[]
    for i in (65,85,100,120,132,140,150,155,165,175,225,250,295,310):
        hm,tm=cat[i,0]>2,cat[i,1]>2
        feat,n=components(hm|tm)
        head=set(np.unique(feat[hm]))-{0}; torso=set(np.unique(feat[tm]))-{0}
        overlap=bool(head&torso)
        test_head.append([i,int(hm.sum()),int(tm.sum()),overlap])
    assert all(row[-1] for row in test_head if row[1] and row[2])
    look=[120,141,150,165,175]
    curl=[]
    for i in look:
        pxy=np.column_stack(np.nonzero(cat[i,3]>=3))
        cdx=(native[i].astype(np.int16)-off(i,'cat').astype(np.int16))
        d=np.any(cdx,axis=2)&(cat[i,3]>=3)
        curl.append({'f':i,'tail_present_bounds_yx':[pxy.min(0).tolist(),pxy.max(0).tolist()] if len(pxy) else [],
                     'tail_pixel_changed_vs_cat_off':int(d.sum()),'tail_curl_weight':pv[i]['tail_curl_weight']})
    assert max(k['tail_pixel_changed_vs_cat_off'] for k in curl)>0
    first=curl[0]['tail_present_bounds_yx'][0][0]
    assert any(abs(j['tail_present_bounds_yx'][0][0]-first)>=1 for j in curl if j['tail_present_bounds_yx'])
    shade_frames={}
    weights=np.array([.2126,.7152,.0722])
    for i in (137,138,141,143,144):
        a=native[i,82:130,109:168]@weights
        b=off(i,'lamp_drop')[82:130,109:168]@weights
        shade_frames[str(i)]={'roi_native_xyxy':[109,82,168,130],'mean_y8_with_dip':float(a.mean()),
                              'mean_y8_notch_disabled':float(b.mean()),'preserved_bright_ratio':float(a.mean()/b.mean()),
                              'actual_dif_pixels':int(np.count_nonzero(a!=b))}
    g0=np.array([gains(i,False)[0] for i in range(330)])
    g=np.array([t['lamp_gain'] for t in trace])
    assert np.array_equal(np.flatnonzero(g/g0<.9),np.arange(138,144))
    assert np.allclose(g[138:144]/g0[138:144],.82)
    assert g.min()>.79 and g0.max()<1.025 and g0.min()>.975
    p0=np.array(petals['data'])
    assert len(p0)==195 and set(p0[:,12])=={0,1,2}
    assert np.all(p0[:,4]<0) and np.all(p0[:,5]<0) and np.allclose(p0[:,13:16].sum(1),1)
    by_zone=np.zeros((330,3),int)
    for i,pl in enumerate(trace):
        for j in pl['petal_meta']: by_zone[i,j[1]]+=1
    assert (by_zone.max(0)>7).all()
    bird_stats={}
    for i in (115,120,141,150,165,175):
        a=native[i]
        b=off(i,'bird')
        m=np.any(a!=b,axis=2)
        birds=trace[i]['birds']
        bird_stats[i]={
            'actual_affected_quantized_pixels':int(m.sum()),
            'visible_ids': [r['id'] for r in birds if r['visible_pixels']>0],
            'occulted_ids_some_or_all':[r['id'] for r in birds if r['occluded_pixels']>.1],
            'projection_extents_px':[r['projected_width_px'] for r in birds]}
    assert min(bird_stats[i]['actual_affected_quantized_pixels'] for i in (120,165,175))>=10
    for bb in (120,175):
        assert len(bird_stats[bb]['visible_ids'])>=5
    assert len(bird_stats[141]['visible_ids'])<6
    leaf_counts={j:int(np.count_nonzero(np.any(native[j]!=off(j,'leaf'),axis=2))) for j in (65,85,100,120,150,175,225,250)}
    assert min(leaf_counts.values())>100
    cloth={}
    if old:
        v23=np.load(old,mmap_mode='r',allow_pickle=False)
        a,b,c,d=CLOTH_RECT
        mask=p['cover'][np.arange(330)//5]>0.999
        f=native[:,c:d,a:b];z=v23[:,c:d,a:b]
        same=np.all(f==z,axis=-1)
        total=int(mask.sum());changed=int((mask&~same).sum())
        cloth={'fully_covered_cloth_pixels_over_330_frames_compared':total,
               'pure_cloth_pixel_exact_count_against_approved_v2_3':total-changed,'different':changed}
    seam=np.abs(native[-1].astype(np.int16)-native[0].astype(np.int16))
    dif=np.abs(native[np.r_[1:330,0]].astype(np.int16)-native.astype(np.int16))
    seam_d=float(seam.mean())
    cat_stage={'first_fully_hidden':0,'entry_first_visible':left_index,'hold_frames_half_open':[120,180],
               'exit_last_visible':right_index,'exit_f0_f329_ab_exact':True,'invisible_prequantized_shadow_max_0_255':[int(sh[i].max()) for i in (0,329)],'stance_root_world':j0,'cat_height_max_px_including_ground_angle':bodyH,
               'visible_body_dimensions':[[int(x),int(y)] for x,y in sorted({(p[2]-p[0]+1,p[3]-p[1]+1) for p in boxes})],
               'wheel_native_height_reference':wheel,'head_body_connection_samples':test_head,'tail_confirmed':curl,
               'first_occluder_counts':pv[0]['first_static_blocker_materials'],
               'last_occluder_counts':pv[329]['first_static_blocker_materials'],
               'triangle_edge_collisions_with_static_through_66_distinct_poses':0,
               'fixed_camera_z16_5_to20_ground_feet_offscreen_y192_to230':True}
    return dict(palette_count=len(used),visual_hold_poses_5frames=66,clothing=cloth,
                lamp={'notch_frames_half_open':[138,144],'relative_real_radiance_gain':.82,'seconds':.2,
                      'no_notch_min_max':[float(g0.min()),float(g0.max())],'layer_controls':shade_frames},
                cat=cat_stage,seasonal_leaf={'support_pixels':int(eligible.sum()),'max_original_pixel_tap':1,
                'before_after_changed_pixels_same_phase':leaf_counts,'protected_tree_branch_wires_intersect_taps':0},
                blossom={'source_bands_left_center_right':[int((p0[:,12]==x).sum()) for x in range(3)],
                    'count_relative_to_v23':{'v23_launch_sources':118,'v24_launch_sources':len(p0)},
                    'positive_x_launch_trajectories':0,'visible_max_per_crown_band':by_zone.max(0).tolist(),
                    'actual_visible_samples_by_band_all330':by_zone.tolist()},bird_counts=bird_stats,
                television={'same_phase_quantized_diffs':{i:int(np.any(native[i]!=off(i,'tv'),axis=2).sum()) for i in (0,45,65,85,100,115,120,141,150,175,225,250)}, 'controls_are_existing_light_group_only':True},
                native_seam={'mean_abs_rgb':seam_d,'median_of_all_frame_phase_steps':float(np.median(dif.mean((1,2,3)))),
                    'held_pose_boundary_median_excluding_notch':float(np.median(dif[(np.arange(0,330,5)[(np.arange(0,330,5)<135)|(np.arange(0,330,5)>145)]-1)%330].mean((1,2,3))))}),off,trace

def split(out,f):
    whole=hashlib.sha256(); rows=[]
    p=out/'lossless_parts/spring';p.mkdir(parents=True,exist_ok=True)
    with f.open('rb') as fp:
        i=0
        while b:=fp.read(8_000_000):
            n=p/f'part-{i:02d}.bin';n.write_bytes(b)
            whole.update(b)
            rows.append({'path':str(n.relative_to(out)),'bytes':len(b),'sha256':sha(n)})
            i+=1
    doc={'output':f.name,'bytes':f.stat().st_size,'sha256':whole.hexdigest(),'parts':rows}
    with f.open('rb') as fp:
        assert all((out/r['path']).read_bytes()==fp.read(r['bytes']) for r in rows)
        assert not fp.read(1)
    assert sha(f)==doc['sha256']
    wr(out/'lossless_parts/MANIFEST.json',{'spring':doc})
    return doc

def thumbnail(plate,rect,up=4):
    x0,y0,x1,y1=rect
    return Image.fromarray(plate).crop(rect).resize(((x1-x0)*up,(y1-y0)*up),Image.Resampling.NEAREST)

def contact(name,text,rows,path,cols=7):
    pw,ph=rows[0][1].size
    nrows=(len(rows)+cols-1)//cols
    r=Image.new('RGB',(24+(pw+6)*cols,max(79+nrows*(ph+20),98)),'#261f2c')
    d=ImageDraw.Draw(r)
    d.text((12,5),name,fill='#ffead5',font=font(21))
    d.text((12,35),text,fill='#d0b8c5',font=font(14))
    for i,(cap,im) in enumerate(rows):
        yy=61+(i//cols)*(ph+20);xx=12+(i%cols)*(pw+6)
        r.paste(im,(xx,yy));d.text((xx,yy+ph+1),cap,fill='#f3dfc8',font=font(12))
    r.save(path,quality=96,subsampling=0) if path.suffix=='.jpg' else r.save(path,optimize=True)

def evidence(out,mp4,native,off,trace):
    peaks={45:'cat_emerges',150:'cat_looks_and_curls',225:'bilateral_petal_shower',238:'warm_petal_sweep',
           315:'cat_behind_right_eave',120:'dusk_birds_before_crown',175:'dusk_birds_after_crown',
           137:'lamp_before_brief_drop',141:'lamp_drop',144:'lamp_recovered'}
    cycles={'sunken_entry':range(34,56),'warm_pause':range(120,180),'right_occlusion':range(303,330)}
    birds={'entry_sky':range(115,125),'tree_occlusion':range(140,150),'reappearance_sky':range(165,175)}
    needed=sorted(set([*peaks,*[j for rr in cycles.values() for j in rr],*[j for rr in birds.values() for j in rr]]))
    # Fold adjacent frames into ranges so libavutil does not hit its expression-depth limit.
    intervals=[]
    for j in needed:
        if intervals and j==intervals[-1][-1]+1:
            intervals[-1][1]=j
        else:
            intervals.append([j,j])
    clauses=[f'eq(n,{a})' if a==b else f'between(n,{a},{b})' for a,b in intervals]
    filt="select='"+'+'.join(clauses)+"',scale=in_color_matrix=bt709:in_range=tv:out_range=pc,format=rgb24" 
    cmd=['ffmpeg','-v','error','-xerror','-nostdin','-threads','4','-filter_threads','1','-i',str(mp4),'-an',
         '-vf',filt,'-fps_mode','passthrough','-frames:v',str(len(needed)),'-threads','1','-pix_fmt','rgb24','-f','rawvideo','pipe:1']
    planes={}; rendered={}
    with subprocess.Popen(cmd,stdout=subprocess.PIPE) as p:
        for key in needed:
            b=p.stdout.read(1920*1080*3)
            if len(b)!=1920*1080*3: raise RuntimeError(('actual decoded evidence incomplete',key,len(b)))
            frame=np.frombuffer(b,np.uint8).reshape(1080,1920,3)
            planes[key]=frame[3::6,3::6].copy()
            if key in peaks:
                path=out/f'spring_peak_{key:03d}_{peaks[key]}.png'
                Image.fromarray(frame).save(path,optimize=True)
                rendered[path.name]={'frame_zero_based':key,'bytes':path.stat().st_size,'sha256':sha(path)}
        assert not p.stdout.read(1) and p.wait()==0
    for kind,rr in cycles.items():
        panels=[]
        for j in rr:
            c=trace[j]['visible_cat']
            px,py=c['projected_root']
            x=max(0,min(288,int(px)-15)); y=max(0,min(162,int(py)-10))
            r=(x,y,x+32,y+18)
            panels.append((f'F{j:03d}/{j/30:.2f}s',thumbnail(planes[j],r)))
        contact('春猫 · 实解相邻帧 ×4','实体遮挡；裁框沿猫的世界投影取样，非跟焦或修改片中镜头。',
                panels,out/f'spring_cat_4x_{kind}.png',cols=8)
    for kind,rr in birds.items():
        pans=[]
        for j in rr:
            bs=trace[j]['birds']; c=[x['bbox'] for x in bs if x['bbox']]
            lead=max((x[2] for x in c), default=200)
            lead=max(58,min(320,lead+9));r=(lead-58,0,lead,18)
            pans.append((f'F{j:03d} · {len(c)}',thumbnail(planes[j],r)))
        contact('暮燕 · 实解相邻 4×','5 帧一换；保留近树冠遮挡及真实空间滑翔。',pans,out/f'spring_birds_4x_{kind}.png',cols=3)
    lamp=[]
    for j in (137,141,144):
        lamp.append((f'F{j:03d} H.264',thumbnail(planes[j],(113,83,167,130),4)))
    lamp.append(('F141 同相关闭压降',thumbnail(off(141,'lamp_drop'),(113,83,167,130),4)))
    contact('原路灯 · 一次 0.20 秒微压降','前三项为真实 QP0 抽帧，最后为同相原生仅关压降，无其他改动。',
            lamp,out/'spring_lamp_a_b4x.png',cols=4)
    leaf=[]
    cr=(166,20,231,70)
    for j in (85,150):
        leaf+=[(f'F{j:03d} 正常',thumbnail(native[j],cr,4)),(f'F{j:03d} 叶颤关',thumbnail(off(j,'leaf'),cr,4))]
    contact('樱树 · 只对原生叶面整数 ±1','同相位开关；不改树干枝桠、杆线、相机和其他层。',
            leaf,out/'spring_leaf_a_b4x.png',cols=4)
    images=(native!=np.roll(native,1,axis=0)).any(-1)
    m=images.sum(0); norm=np.sqrt(m/np.max(m));heat=np.uint8(np.stack([norm, norm*.64,np.clip(1.4*norm,0,1)*.77],-1)*255)
    Image.fromarray(heat).resize((1280,720),Image.Resampling.NEAREST).save(out/'spring_motion_heatmap.png',optimize=True)
    wr(out/'spring_decoded_evidence_manifest.json',rendered)

def package(out):
    names=['README.md','base_bindings.json','requirements.txt','spring23.py','cat24.py','flock24.py','nature24.py','scene24.py','palette24.json',
           'pack.py','verify_exact.py','finish24.py','test_behaviors.py','test_flock24.py']
    with zipfile.ZipFile(out/'spring_v24_source.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as pack_:
        for f in names:
            path=HERE/f
            item=zipfile.ZipInfo(f,date_time=(2026,11,24,0,0,0))
            item.compress_type=zipfile.ZIP_DEFLATED
            pack_.writestr(item,path.read_bytes())
    with zipfile.ZipFile(out/'spring_v24_source.zip') as z:
        assert z.testzip() is None and set(z.namelist())==set(names)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--out',required=True,type=Path)
    ap.add_argument('--baseline-audit-only',type=Path)
    ap.add_argument('--use-rendered-mp4',action='store_true',help='Do not overwrite an existing QP0 master when repeating checks')
    a=ap.parse_args();out=a.out
    native=np.load(out/'spring_native.npy',mmap_mode='r',allow_pickle=False)
    print('Checking root path, cloth, lamp, all 330 leaf masks, petals, birds and cat before final encodes',flush=True)
    stats,off,trace=read_layers(out,native,a.baseline_audit_only)
    wr(out/'spring_gate24_art_proof.json',stats)
    print('ART', {k:v for k,v in stats['cat'].items() if k in ('entry_first_visible','exit_last_visible','tail_confirmed')},stats['seasonal_leaf'],flush=True)
    master=out/'spring_loop.mp4'
    if not a.use_rendered_mp4:
        if master.exists():raise ValueError('final QP0 already exists; switch to read-only media checks')
        encode(native,master,True)
    media=out/'mobile';media.mkdir(exist_ok=True)
    proxy=media/'spring_loop.mp4'
    if not a.use_rendered_mp4 or not proxy.exists():
        encode(native,proxy,False,work=media)
        if proxy.stat().st_size>8_450_000:encode(native,proxy,False,kbps=2600,work=media)
        assert proxy.stat().st_size<=8_450_000
    proof=exact_master('spring',out/'spring_native.npy',master)
    proof['lossless_pts']=contiguous_pts(master)
    q=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_streams','-of','json',str(proxy)]))
    v,=q['streams']
    assert (v['codec_name'],v['profile'],v['width'],v['height'],v['pix_fmt'])==('h264','High',1920,1080,'yuv420p')
    proof['browser_proxy']={'bytes':proxy.stat().st_size,'sha256':sha(proxy),'pts':contiguous_pts(proxy),'profile':v['profile']}
    wr(out/'spring_decoded_qa.json',proof)
    rec=split(out,master)
    wr(out/'spring_gate24_provenance.json',{
          'requirement_commit':'f496b686d45c00f6016e2837f2ee4ebe9b46567c',
          'birds_requirement_commit':'953967b611f63f424a8df90b9609c3dadb8cc5a4',
          'base_approved':'d491fe13aaa2ff4b5addd296d42f1a40b73c85fc',
          'reused_only':['camera','scene static geometry','5-frame cloth pose','60 RGB palette'],
          'compiled_with_no_static_cache':True,'lossless':rec,
          'native_npy_sha256':proof['npy_sha256'],'proxy_sha256':proof['browser_proxy']['sha256']})
    evidence(out,master,native,off,trace)
    package(out)
    print('FROZEN SPRING',rec['bytes'],rec['sha256'],'parts',len(rec['parts']),'proxy',proxy.stat().st_size,
          sha(proxy),'native',proof['npy_sha256'],flush=True)

if __name__=='__main__':main()
