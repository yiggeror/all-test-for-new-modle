"""One continuous torso–neck–head loft, independently planted 3-D paws, optically hidden seam."""
import numpy as np
from scipy.interpolate import PchipInterpolator
from spring23 import World,mats,srgb

CAT_HEAD,CAT_BODY,CAT_FOOT,CAT_TAIL=91,92,93,94
CAT_BODY_M=.466
HOLD=(120,180)
K=np.array([0,22,34,48,70,120,180,211,248,280,310,325,329],np.float64)
X=np.array([1.34,1.34,1.78,2.65,3.24,4.88,4.88,5.43,7.45,9.40,11.45,12.16,12.16])
Z=np.array([12.41,12.41,12.414,12.412,12.43,12.06,12.06,9.73,9.64,9.56,9.55,9.55,9.55])
PATH=PchipInterpolator(K,np.stack((X,Z),1),axis=0)
TAN=PATH.derivative()
CURVE=PATH(np.linspace(0,329,660))
ARC_F=np.linspace(0,329,660)
ARC=np.r_[0,np.cumsum(np.linalg.norm(np.diff(CURVE,axis=0),axis=1))]

@mats.mat('spring24_fur')
def fur(s):
    # Broad, low contrast coat markings. All response is reflected incident light.
    return s.col*(.93+.07*np.cos(s.seed*7.4))[:,None]


def route(j):
    f=min(329.,max(0.,float(j)))
    x,z=PATH(f)
    vx,vz=TAN(f)
    if np.hypot(vx,vz)<1e-5:
        vx,vz=1.,-.05 if f>180 else -.32 if f>=120 else 0.
    yaw=-np.arctan2(vz,vx)
    if 109<f<190:
        # Use the same world-facing heading when both front paws settle.
        a=min(max((f-109)/11,0),max((190-f)/10,0),1)
        yaw=(1-a)*yaw+a*.31
    return np.array([x,0.,z]),yaw,float(np.interp(f,ARC_F,ARC))


def tone_seed(x,y,z):
    return .47 + .6*(x+.08) + .18*(y-.2) - .2*z


def sm(x):
    x=np.clip(x,0.,1.)
    return x*x*(3-2*x)


def muscle(f,s):
    stop=sm((f-115)/8)*sm((186-f)/8)
    lift=(sm((f-124)/22)-.60*sm((f-164)/14)) * (f<180)
    # Change only neck loft/head and ears, not the feet. At full pause tail tip curls.
    return float(stop),float(max(0.,lift)),float(.005*np.sin(4*np.pi*s/.52)*(1-stop))


def mesh(frame):
    j=float(frame)
    root,yaw,s=route(j)
    stop,look,bob=muscle(j,s)
    prof=np.array([
        [-.230,.172,.005,.012],[-.219,.175,.048,.049],[-.179,.173,.076,.066],
        [-.113,.166,.076,.065],[-.025,.168,.075,.058],[.046,.180,.073,.056],
        [.102,.193,.068,.050],[.145,.229,.050,.047],
        [.181,.237,.053,.047],[.211,.220,.034,.040],[.236,.213,.012,.024],
    ],float)
    # A single watertight, connected loft; look changes the vertex heights of
    # the last rings continuously through the shoulder transition.
    cross=sm((prof[:,0]-.048)/.17)
    prof[:,1]+=bob+.025*look*cross
    w=World(seed=2415)
    with w.at(root,yaw=yaw):
        a=np.linspace(0,2*np.pi,13)[:-1]
        c=np.cos(a); d=np.sin(a)
        rings=np.stack([np.broadcast_to(prof[:,0,None],(len(prof),len(a))),
          prof[:,1,None]+prof[:,2,None]*c,prof[:,3,None]*d],axis=-1)
        rr=np.roll(rings,-1,axis=1)
        shade=np.clip((c*.16+.84),.72,1.)
        F=srgb('#92634b')
        H=srgb('#a97550')
        D=srgb('#775248')
        col=np.array([D if k==0 else H if k>6 else F for k in range(len(prof)-1)])
        w.quads(rings[:-1].reshape(-1,3),rr[:-1].reshape(-1,3),rr[1:].reshape(-1,3),rings[1:].reshape(-1,3),
                mat='spring24_fur',col=(col[:,None]*shade[None,:,None]).reshape(-1,3),
                seed=(.24+prof[:-1,0,None]*.6+c[None,:]*.09).ravel(),
                tag=np.repeat(np.where(prof[:-1,0]>.13,CAT_HEAD,CAT_BODY),len(a)))
        w.poly(rings[0][::-1],mat='spring24_fur',col=F,tag=CAT_BODY)
        w.poly(rings[-1],mat='spring24_fur',col=H,tag=CAT_HEAD)
        # The ears grow through the skull crown; no independently drawn head or edges.
        for k,side in enumerate((-1,1)):
            z=side*.028
            by=.269+.020*look+bob
            ear=np.array([[.132,by,z+side*.005],[.179,by-.006,z+side*.012],
                          [.159+k*.008,min(.333,.320+.013*look+bob),z+side*.006],
                          [.146,by-.007,z-side*.015]])
            for u,v,r in ((0,1,2),(1,3,2),(3,0,2),(0,3,1)):
                w.poly(ear[[u,v,r]],mat='spring24_fur',col='#9c684d' if v!=3 else '#6e4b45',tag=CAT_HEAD)
        # Four feet, stance coordinates fixed in arclength until real swing.
        planted=[]
        feet=[]
        for q,(hx,hz,phase) in enumerate(((.095,.041,.06),(-.155,-.044,.29),(.095,-.041,.58),(-.155,.044,.79))):
            stride=.54;dt=.55
            p=s/stride+phase
            cycle=np.floor(p);t=p-cycle
            ref=(cycle+dt*.5-phase)*stride
            xloc=(ref-s); ylift=0.
            if t>=dt:
                u=(t-dt)/(1-dt)
                xloc+=stride*sm(u)
                ylift=.052*np.sin(np.pi*u)
            xloc=(1-stop)*float(np.clip(xloc,-.119,.119))
            ylift*=1-stop
            # Ensure it never takes a flying pose; y==0 remains a real sole.
            if q==0 and not any(planted) and t<.64:ylift=0.
            ank=(hx+xloc,.027+ylift,hz)
            kn=(hx+.25*xloc+(.018 if hx>0 else -.014),.119+.34*ylift+bob,hz)
            hip=(hx,.183+bob,hz*.86)
            w.tube(hip,kn,.031,.021,sides=7,mat='spring24_fur',col='#886049',tag=CAT_FOOT)
            w.tube(kn,ank,.021,.014,sides=7,mat='spring24_fur',col='#694d43',tag=CAT_FOOT)
            # Its world-space mesh shares the cat's body transform, not a floaty decal.
            w.box((ank[0]+.010,.009+ylift,ank[2]),(.053,.018,.031),
                    mat='spring24_fur',col='#815946',tag=CAT_FOOT)
            planted.append(bool(ylift<=.001))
            feet.append(w.xf((ank[0]+.010,ylift,ank[2])).tolist())
        phase=2*np.pi*(s/.87 + j/330*.7)
        curl=stop*sm((j-125)/20)*(1-sm((j-153)/25))
        t=np.array([[-.192,.170,.006],[-.263,.165,.022],[-.328,.191,.048],[-.380,.241,.062],
                    [-.407+.022*curl,.266+.037*curl,.060],[-.430+.055*curl,.290+.058*curl,.059+.040*curl]])
        t[1:,2]+=np.sin(phase+np.arange(1,6)*.63)*np.linspace(.003,.025,5)
        t[:,1]+=bob
        rr=[.033,.029,.025,.023,.018,.013]
        for i in range(len(t)-1):
            w.tube(t[i],t[i+1],rr[i],rr[i+1],sides=7,mat='spring24_fur',col='#90634b',tag=CAT_TAIL)
        w.sphere(t[-1],.013,n=5,mat='spring24_fur',col='#825949',tag=CAT_TAIL)
    return w,{'frame':j,'root':root.tolist(),'yaw_radians':yaw,'arc_m':s,'pause_weight':stop,'head_look_weight':look,
              'feet_planted':planted,'soles_world':feet,'body_length_m':CAT_BODY_M,'shoulder_height_m':.261,
              'head_and_ears_max_m':float(ear[:,1].max()),'tail_curl_weight':float(curl)}
