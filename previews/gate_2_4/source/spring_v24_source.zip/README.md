# 春 · 老巷暮色落花 / Gate 2.4

原镜头、静物和 60 色保持 v2.3。衣物继续用通过审批的 3D 布面及 5 帧保持；树干、电线杆、线和主枝不参与叶面动效。树冠纯叶像素只在同深度叶簇从邻接原生位点作 ±1 整数取位，不插值；真实花卡三角形上出生的落瓣从左／中／右往左斜吹，深度级实际挡住。左楼 TV 在旧发光窗框内柔变。原暖灯分组、受照和辉光同因变化：138–143 帧（起点含、终点144不含）对正常镇流曲线瞬时乘 0.82，0.20 秒后复原。

同机位下 y=0、z=16.5–20 的脚点在原生 y≈192–230 画幅外；猫沿真正可见的院落地面走，z≈9.55–12.43、y=0，从原砖门楼后的物理空隙探出，在连续暖面观察落花，随后走进原屋檐／墙的深处。没有改镜头、重画背景或透明隐去。0.466m 头颈躯干连体实体、0.261m 肩高，姿态 6fps，有低高度的真实落脚与接地受光阴影，尾端物理卷起回位。天空晚燕以世界空间微型翼形和遮挡采样，实际 5 帧持形；二枚暖灯旁小虫仅在可照的 1 像素内亮起。

在能读取审定场景源码的仓库本地运行：

    export RAINROJI_SOURCE_ROOT=/absolute/path/to/approved/all-test-for-new-modle
    export OPENBLAS_NUM_THREADS=1 NUMBA_NUM_THREADS=3
    python -m pip install -r requirements.txt
    python -m unittest discover -s . -v
    python scene24.py --out render --span 0:330
    python finish24.py --out render

Python 3.12.14、NumPy 2.3.5、Numba（见 requirements）、FFmpeg 7.1.5 和 x264。在干净复现实跑中不使用历史光照缓存、旧成片或代理／原生帧。仅用锁定源码里的 shots/spring_g15.py、prototype/film 下的真正引擎／场景，以及源码包内的 60 色 JSON。可选 --baseline-audit-only 对照 Gate 2.3 的原生 NPY；该路径只为验布，不参与渲染或编码。输出 330 帧原生相位、22秒双周期 1080p30、QP0 逐帧与 PTS 验真、单季清单、分卷与兼容代理。证据条带来自解码后的实际 QP0，不在成片上加标记。
