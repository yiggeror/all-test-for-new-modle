"""Small world-space spring flock. No camera warp or arbitrary foreground overdraw."""
import numpy as np

# Each offset belongs to an individual trajectory, not one displaced group stamp.
_OFF = np.array([[0,0,0],[-5,4.0,1.8],[-10,-2.1,-.8],[-17,2.7,3.2],[-22,-1.6,.6],[-31,4.8,2.7]])
_PATTERN = ((0.,.8,-.64,.1,0.,.72,-.46,0.), (0.,.38,-.95,.36,0.,.31,-.80,.2), (0.,.05,-.99,.17,0.,.05,-.99,.17))
_JITTER = np.array([[.18,.32],[.52,.13],[.82,.29],[.29,.59],[.64,.49],[.89,.57],[.13,.90],[.49,.85],[.78,.94]])

def _inside(q,A):
    d0=A[1]-A[0];d1=A[2]-A[0];r=q-A[0]
    den=d0[0]*d1[1]-d1[0]*d0[1]
    if abs(den)<1e-9: return None
    u=(r[0]*d1[1]-d1[0]*r[1])/den; v=(d0[0]*r[1]-r[0]*d0[1])/den
    if u>=0 and v>=0 and u+v<=1: return np.array([1-u-v,u,v])

class SpringFlock:
    def __init__(self,cam,depth):
        self.cam=cam
        self.depth=np.asarray(depth)
        if self.depth.shape!=(180,320,9): raise ValueError('expected locked 320×180×9 ray-depth samples')
        self._last=-1
        self._geometry=[]
        self.right=cam.r*.82-cam.f*.57236
        self.span=cam.r*.57236+cam.f*.82
        self.dist=57.
    def _lift(self,x,y,z):
        c=self.cam
        a=(2*x/320-1)*c.th
        b=(1-2*y/180)*c.tv+c.shift
        return c.pos+(c.f+c.r*a+c.u*b)*z
    def _bird(self,i,x,y,depth,key):
        c=self.cam; p=self._lift(x,y,depth)
        f=self.right;s=self.span;u=c.u
        alpha=(key//5+i*3)%13
        # Two held glide poses separate short wingbeats, staggered among birds.
        beat=([.02,.20,.58,.86,.28,-.28,-.55,-.19,.08,.10,.12,.09,.07][alpha])
        amp=[1.03,.94,1.03,1.07,.92,1.0][i]
        wing=.53*amp
        nodes=[p+f*.125,p+u*.068-s*.055,p+u*.064+s*.055,p-f*.28,p-f*.335+s*.10,p-f*.335-s*.10]
        poly=[[0,1,3],[0,2,3],[0,1,2],[3,4,5]]
        for sign,w in ((-1,beat),(1,beat+.05*np.sin(i))):
            j=len(nodes)
            nodes.extend((p-f*.012, p+s*sign*wing*.49+u*w*.27+f*.12,
              p+s*sign*wing+u*w*.47-f*.17, p+s*sign*wing*.60+u*w*.33-f*.38))
            poly.extend(([j,j+1,j+2],[j,j+2,j+3]))
        points=p+(np.array(nodes)-p)*.528
        xs,ys,ds,zs=c.project(points)
        return np.column_stack((xs,ys)),points,zs,np.array(poly),float(beat)
    def _refresh(self,key):
        self._geometry=[]
        if not 50<=key<=205:return
        lead=-15+(key-50)*2.49
        for i,(dx,dy,dz) in enumerate(_OFF):
            x=lead+dx
            y=5.15+4.4*np.sin(np.pi*np.clip(x,0,319)/320)+dy+.82*np.sin(key*.065+i*1.51)
            z=self.dist+dz-2.3*np.sin(key*.011+i*.32)
            screen,world,depth,poly,beat=self._bird(i,x,y,z,key)
            # Keep any candidate which is visible in the canvas or clipped by the viewport.
            mins=np.maximum(0,np.floor(screen.min(0)).astype(int))
            maxs=np.minimum((319,179),np.floor(screen.max(0)).astype(int))
            rows=[]
            full=0.; occluded=0.; actual=0.; changed=[]
            for yy in range(mins[1],maxs[1]+1):
              for xx in range(mins[0],maxs[0]+1):
                hits=[]
                for off in _JITTER:
                  q=off+(xx,yy)
                  nearest=np.inf
                  for indices in poly:
                    bary=_inside(q,screen[indices])
                    if bary is None:continue
                    w=bary/depth[indices]; w/=w.sum()
                    nearest=min(nearest,np.linalg.norm(w@world[indices]-self.cam.pos))
                  if np.isfinite(nearest):hits.append(nearest)
                if not hits:continue
                observed=len(hits)/9.
                pass_fraction=float(np.mean(self.depth[yy,xx]>np.median(hits)))
                contribution=observed*pass_fraction
                full+=observed;actual+=contribution;occluded+=observed-contribution
                if contribution>.045: rows.append((yy,xx,contribution));changed.append((xx,yy))
            bounds=([min(x for x,y in changed),min(y for x,y in changed),max(x for x,y in changed)+1,max(y for x,y in changed)+1] if changed else None)
            info=dict(id=i,hold_frame=key,pose='glide' if abs(beat)<.23 else ('upstroke' if beat>0 else 'downstroke'), projected_width_px=round(float(np.ptp(screen[:,0])),3),projected_height_px=round(float(np.ptp(screen[:,1])),3),depth_m=round(z,3),physical_pixels=round(full,3),visible_pixels=round(actual,3),occluded_pixels=round(occluded,3),bbox=bounds)
            self._geometry.append((i,rows,info))
    def draw(self,lin,j):
        j=int(j)%330;key=j//5*5
        if key!=self._last:
            self._refresh(key);self._last=key
        for i,rows,info in self._geometry:
            for y,x,cover in rows:
                # Warm gray-violet lit silhouette, compressed toward the same sky as distant roofs.
                reduction=np.array([.47,.45,.39])*(.91+.08*((i+1)%3))
                lin[y,x]*=1-reduction*min(1.,cover*3.15)
        return [info.copy() for _,_,info in self._geometry]
