"""Autumn 2.3: three native-scale accents on a physically fixed, sharp silhouette."""
from __future__ import annotations
import json
from pathlib import Path
from math import pi,sin,cos
import numpy as np
from numba import njit,prange
from PIL import Image,ImageFont
from scipy.ndimage import gaussian_filter
from engine import fx,pix,render as ray
from engine.world import roty,srgb
import autumn_g15 as shot
from pixel_fx import T,sm,flow

@njit(cache=True,parallel=True)
def nearest(a, pal, colors, noise, strength):
    out=np.empty((len(a),3),np.uint8)
    for i in prange(len(a)):
        x,y,z=a[i];best0=1e20;best1=1e20;j0=0;j1=0
        for k in range(len(pal)):
            px,py,pz=pal[k];dx=x-px;dy=y-py;dz=z-pz
            dd=dx*dx+dy*dy+dz*dz
            if dd<best0:
                j1=j0;best1=best0;j0=k;best0=dd
            elif dd<best1:
                j1=k;best1=dd
        p0=pal[j0];p1=pal[j1]
        q0=p1[0]-p0[0];q1=p1[1]-p0[1];q2=p1[2]-p0[2]
        w=((x-p0[0])*q0+(y-p0[1])*q1+(z-p0[2])*q2)/max(q0*q0+q1*q1+q2*q2,1e-9)
        j=j1 if min(1.,max(w,0.))*strength>noise[i] else j0
        out[i]=colors[j]
    return out

class FixedAutumn:
    def __init__(self):
        doc=Path(shot.__file__).resolve().parent.parent/'reference'
        info=json.loads((doc/'autumn.json').read_text())
        self.rgb=np.array(info['palette_rgb'],np.uint8)
        a=np.asarray(Image.open(doc/'autumn_320x180_native.png').convert('RGB'))
        for swatch in ([126,82,129],[192,145,121]):
            if np.min(np.sum((self.rgb.astype(float)-swatch)**2,axis=1))<18:continue
            counts=np.sum(np.all(a.reshape(-1,1,3)==self.rgb[None],axis=2),axis=0)
            self.rgb[np.argmin(counts)]=np.asarray(swatch,np.uint8)
        self.lab=pix.oklab(self.rgb/255.)*pix.LABW
        self.th=np.ascontiguousarray(pix.threshold_map(180,320,'mix',seed=177).ravel())
        self.strength=float(info['dither_strength']);self.vig=fx.vignette(180,320,.15)
    def quantize(self,lin):
        raw=pix.tonemap(lin*self.vig,**shot.GRADE)
        lab=np.ascontiguousarray((pix.oklab(raw)*pix.LABW).reshape(-1,3))
        return nearest(lab,self.lab,self.rgb,self.th,self.strength).reshape(180,320,3)

def font():
    raw=ImageFont.truetype
    def use(name,size=10,index=0,*a,**kw):
        try:return raw(name,size,index,*a,**kw)
        except OSError:
            if not isinstance(name,(str,Path)):raise
            base=Path(name).name
            serif=base in ('ukai.ttc','uming.ttc') or 'Serif' in base
            f='NotoSerifCJK-Regular.ttc' if serif else 'NotoSansCJK-Regular.ttc'
            return raw('/usr/share/fonts/opentype/noto/'+f,size,2,*a,**kw)
    ImageFont.truetype=use

def in_poly(x,y,P):
    """Native footprint of the world-space polygon; no texture resampling."""
    mask=np.zeros(x.shape,bool)
    for a,b in zip(P,np.roll(P,-1,axis=0)):
        if abs(b[1]-a[1])<1e-10:continue
        cross=((a[1]>y)!=(b[1]>y))&(x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0])
        mask^=cross
    return mask

def paint_leaf(lin,cam,plate,P,V,value,alpha,shadow=False):
    q=np.append(P[None],P+V,axis=0)
    x,y,d,z=cam.project(q)
    if z[0]<5:return
    x=x[1:]-(x[0]-np.floor(x[0])-.5)
    y=y[1:]-(y[0]-np.floor(y[0])-.5)
    left,right=max(0,int(np.floor(x.min()))),min(320,int(np.ceil(x.max()))+1)
    top,bottom=max(0,int(np.floor(y.min()))),min(180,int(np.ceil(y.max()))+1)
    if right<=left or bottom<=top:return
    yy,xx=np.mgrid[top:bottom,left:right];inside=np.zeros(yy.shape,np.float32)
    pts=np.stack([x,y],axis=-1)
    for xoff,yoff in ((.29,.29),(.71,.29),(.29,.71),(.71,.71)):
        inside+=in_poly(xx+xoff,yy+yoff,pts)
    if not np.any(inside):return
    ar=lin[top:bottom,left:right];dist=plate['depth'][top:bottom,left:right,:]
    if shadow:
        scat=(np.abs(dist[...,4]-d[0])<.58)&(plate['N'][top:bottom,left:right,1]>.63)
        ar*=1.-(.25*inside*alpha*scat)[...,None]*np.array([.72,.78,.90],np.float32)
        return
    blocked=(dist>d[0]-.042).mean(2)
    coverage=np.where(inside>=3,1.,np.where(inside==2,.79,.31))* (inside>0)
    ag=coverage*blocked*alpha
    ar+=(value-ar)*ag[...,None]

class Leaves:
    """Two physically placed strata; leaf attitude is authored in six poses/second."""
    def __init__(self,cam,b,lamps):
        self.cam,self.b,self.lamps=cam,b,lamps
        rng=np.random.default_rng(170)
        self.pattern=np.array([[-.52,0.,0.],[-.34,0.,-.23],[-.08,0.,-.23],[-.02,0.,-.48],[.22,0.,-.29],[.51,0.,-.03],
                               [.22,0.,.29],[-.02,0.,.48],[-.09,0.,.22],[-.34,0.,.23]])
        self.half=self.pattern[[0,1,2,3,4,5]].copy()
        self.colors=np.stack([srgb(x) for x in ('#c48336','#d5a147','#b37630','#bd8c39','#d0a657','#c38342')])
        def pp(x,z,y,length,start,life,endx,endz,endy,h,k):
            return (x,z,y,length,start,life,endx,endz,endy,h,k,float(rng.uniform(0.,2*pi)),float(rng.uniform(.6,1.55)),int(rng.integers(0,len(self.colors))))
        self.air=[]; self.road=[]
        # Individually staggered branch detachments, restrained counts by depth.
        for i in range(24):
            if i<11:
                z=rng.uniform(1.3,11.7);side=-1 if i%3!=2 else 1
                x=side*rng.uniform(2.7,6.1);y=rng.uniform(6.5,8.4)
                L=rng.uniform(.138,.216); dx=rng.uniform(.4,1.6);dz=rng.uniform(-.9,.65)
            elif i<19:
                z=rng.uniform(-20.,.8);side=-1 if i%2 else 1
                x=side*rng.uniform(2.5,5.9);y=rng.uniform(6.0,8.6)
                L=rng.uniform(.157,.232);dx=rng.uniform(.5,1.6);dz=rng.uniform(-.7,1.2)
            else:
                z=rng.uniform(-41.,-17.);side=-1 if i%2 else 1
                x=side*rng.uniform(2.6,5.2);y=rng.uniform(6.5,8.4)
                L=rng.uniform(.18,.24);dx=rng.uniform(.5,2.2);dz=rng.uniform(-.7,1.6)
            s=(i*5.602+.317)%T
            self.air.append(pp(x,z,y,L,s,rng.uniform(4.5,7.87),dx,dz,-rng.uniform(4.8,6.7),0.,0))
        # One visually coherent gust along diagonal edge/center; the event is physically varied,
        # not a thousand pinpricks. Road pitch remains at or just above actual pavement.
        for i in range(19):
            z=rng.uniform(2.4,6.2) if i<14 else rng.uniform(6.,9.8)
            x=rng.uniform(-5.7,-2.5)
            t=3.48+i*.070+rng.uniform(-.095,.105)
            self.road.append(pp(x,z,0.,rng.uniform(.141,.226),t,rng.uniform(2.8,4.3),
                                rng.uniform(6.0,8.9),rng.uniform(-1.9,-.42),0.,rng.uniform(.14,.45),1))
    def draw(self,lin,t,road=False):
        gust=flow(t)
        for x0,z0,y0,length,start,life,dx,dz,dy,height,ground,phase,nrot,ik in (self.road if road else self.air):
            age=(t-start)%T;u=age/life
            if not 0<u<1:continue
            a=float(sm(u/(.11 if road else .15))*sm((1-u)/(.18 if road else .25)))
            q=.24*u+.76*sm(u) if road else u
            x=x0+dx*q+(.13 if road else .38)*a*sin(9*u+phase)
            z=z0+dz*q+.19*sin(7*u+phase)*a
            if road:
                ybase=.151*float(sm((abs(x)-4.52)/.27))
                y=ybase+.028+height*a*(.35+.65*sin(2*pi*(1.37*u)+phase)**2)
            else:
                x+=gust*(.21+.52*float(sm(u/.3)))
                x+=.24*sin(age*2.0+phase)*a
                y=y0+dy*u+.19*sin(u*3*pi+phase)*a
            P=np.array([x,y,z])
            sx,sy,d,_=self.cam.project(P)
            if not(-3<sx<323 and -3<sy<182):continue
            if road and sy<133:continue
            if not road and sy>153:continue
            # Position follows one native pixel at a time; orientation held exactly every 5 frames.
            hold=(int(t*30+.000001)//5*5/30-start)%T
            ur=age/life if not (0<=hold<life) else hold/life
            yaw=roty(phase+6.2*nrot*ur)
            bank=(.75 if road else .98)*sin(11.4*nrot*ur+phase)+(.24 if road else .50)
            flat=np.array([[1,0,0],[0,cos(bank),-sin(bank)],[0,sin(bank),cos(bank)]])
            lean=.46*sin(7.1*ur+phase) if road else .52+.40*sin(5.83*ur+phase)
            tilt=np.array([[cos(lean),-sin(lean),0],[sin(lean),cos(lean),0],[0,0,1]])
            R=yaw@tilt@flat;N=R[:,1]
            amb=np.array([.140,.107,.085],np.float32)
            for lamp in self.lamps[:4]:
                v=lamp['pos']-P;dd=float(v@v);un=v/np.sqrt(dd)
                cone=float(sm(((-un)@lamp['axis']-lamp['cone'][0])/(lamp['cone'][1]-lamp['cone'][0])))
                amb+=lamp['color']*(.86*cone/(dd+.63))*(.35+.65*abs(float(N@un)))
            surface=self.colors[ik]*amb*(.85+.23*abs(N[1]))
            bg=lin[np.clip(int(sy),0,179),np.clip(int(sx),0,319)]
            surface=surface*.89+.11*bg
            if road:
                p=P.copy();p[1]=ybase+.004;p[0]+=.12*(y-ybase)
                g=(self.pattern*length)@yaw.T;paint_leaf(lin,self.cam,self.b,p,g,surface,a*.25,True)
            edge=(self.pattern*length)@R.T
            paint_leaf(lin,self.cam,self.b,P,edge,surface,a*.99)
            # At the larger scale this actual fold catches local amber; it disappears edge-on.
            if length>=.177 and d<51 and abs(N[1])>.53:
                half=(self.half*length)@R.T
                paint_leaf(lin,self.cam,self.b,P,half,surface*1.31,a*.42)

def tea_vapor(lin,cam,b,source,t):
    """Small compact, layered warm optical parcels. No broad haze plate or white outline."""
    # Track two staggered strands above the same real kettle nozzle.
    for j in range(13):
        p=(t*3./T+(j+.23*cos(7*j+.8))/13)%1.
        e=float(sm(p/.13)*sm((1-p)/.38))
        if e<.008:continue
        offset=(.22*p+.19*p*sin(2*pi*(t*2/T-p*1.15)+.57)
                +.075*p*sin(5.8*j+p*3.))
        pos=np.asarray(source)+cam.r*offset+cam.f*(.046*p*sin(7.3*j))
        pos[1]+=1.24*p*(.96+.055*cos(4.3*j))
        x,y,d,z=cam.project(pos)
        if z<1:continue
        r=(.060+.16*p)*(160/cam.th)/z;ry=r*(1.12+.37*p)
        x0,x1=max(0,int(np.floor(x-r))),min(320,int(np.ceil(x+r))+1)
        y0,y1=max(0,int(np.floor(y-ry))),min(180,int(np.ceil(y+ry))+1)
        xx,yy=np.meshgrid(np.arange(x0,x1)+.5,np.arange(y0,y1)+.5)
        ell=((xx-x)/max(.42,r))**2+((yy-y)/max(.42,ry))**2
        tone=np.array([.41-.13*p,.235-.052*p,.113-.005*p],np.float32)
        a=e*(1.-.46*p)*.175*np.maximum(0.,1.-ell)**1.2
        a*=np.mean(b['depth'][y0:y1,x0:x1,:]>d-.044,axis=2)
        area=lin[y0:y1,x0:x1];area+=(tone-area)*a[...,None]

# Feather anatomy drawn as native stipples; at this distance wingspan 3–5 px, not 1 px or a sprite over the road.
BIRD=[((0,0,1.),(-1,-1,.86),(-2,-2,.66),(1,-1,.84),(2,-2,.66)),
      ((-2,0,.66),(-1,0,.96),(0,0,1.),(1,0,.95),(2,0,.60),(0,1,.56)),
      ((0,0,1.),(-1,0,.93),(-2,1,.67),(1,0,.90),(2,1,.62),(0,1,.62))]
def dusk_birds(lin,b,t):
    tracks=((1.07,6.90,6.6,1.03,0),(1.36,7.68,12.1,1.08,1),(2.07,8.84,16.9,.83,0))
    for j,(begin,end,hh,delta,wide) in enumerate(tracks):
        k=(t-begin)/(end-begin)
        if not 0.<k<1.:continue
        x=int(round(124.+61.8*(.85*k+.15*float(sm(k)))+.64*sin(2*pi*k+j)))
        y=int(round(hh+delta*sin(pi*k)+.69*sin(2*pi*k+j*.9)))
        fl=(int(t*6+1.e-5)+2*j)%12
        shape=(0,1,2,1,1,1,0,1,2,1,1,1)[fl]
        amount=.88*float(sm(k/.19)*sm((1-k)/.19))
        for i,jj,w in BIRD[shape]:
            if wide and i==2:continue
            cx,cy=x+i,y+jj
            m=b['sky'][cy,cx]
            if m<.35:continue
            v=lin[cy,cx].copy()
            # Distant atmospheric return, integrated with the actual pink-violet sky beneath.
            tone=v*np.array([.27,.28,.36],np.float32)+np.array([.022,.016,.044],np.float32)
            lin[cy,cx]+=(tone-v)*amount*sm((m-.20)/.80)*w

class Autumn:
    GROUPS=('aloft','rolling','steam','birds')
    def __init__(self):
        font();fx.SC=320/480
        self.cam=shot.camera(320,180)
        world=shot.build(tea_offset=(.60,0.,.40))
        b,_=ray.render(world,self.cam,shot.sky,S=3,**shot.RENDER)
        fx.denoise(b,**shot.DENOISE)
        b['lights']=world.lights
        self.b=b;self.plate=b;self.pa=FixedAutumn();self.palette=self.pa.rgb
        self.tea=np.asarray(world.chim[0])+np.array([.027,.023,.065])
        self.lamps=sorted((v for v in b['lights'] if v.get('kind')=='point' and 'axis' in v),
                          key=lambda L:np.linalg.norm(L['pos']-self.cam.pos))[:6]
        self.leaves=Leaves(self.cam,b,self.lamps)
        L=b['layers']
        lin=fx.native_sky(shot,self.cam,180,320)*b['sky'][...,None]+L[0]
        # Physically existing fixtures fixed at the previously approved dusk exposure.
        lin+=.99749*L[shot.G_LAMP]+.98923*L[shot.G_KIOSK]
        lin+=L[shot.G_TV]*(np.array([.9,1.,1.2],np.float32)*1.092835)
        # The immutable interior clusters retain the original cohesive palette; edge samples
        # and every trunk are untouched. Done once before any frame or particle is evaluated.
        cov=b['tag1'];den=gaussian_filter(cov,.78)
        fc=gaussian_filter(lin*cov[...,None],(.78,.78,0))/np.maximum(den[...,None],1e-6)
        w=.52*sm((cov-.56)/.40)*sm((den-.37)/.41)
        lin+=(fc-lin)*w[...,None]
        x,y,*_=self.cam.project(np.array([q['pos'] for q in self.lamps])+[0.,.15,0.])
        for i,q in enumerate(self.lamps):
            fx.glow(lin,x[i],y[i],q['color']*.012,r0=2.4,power=1.3)
        self.static=lin
        self.info={'steam_xy':[float(v) for v in self.cam.project(self.tea)[:2]],'leaf_always_schedule':len(self.leaves.air),
                   'gust_leaf_schedule':len(self.leaves.road),'bird_count':3,'fixed_geometry_groups':['trunk','thick_branch','leaf_crown','sodium_streetlights','buildings']}
    def frame(self,t,omit=()):
        t=t%T;lin=self.static.copy()
        if 'rolling' not in omit:self.leaves.draw(lin,t,True)
        if 'aloft' not in omit:self.leaves.draw(lin,t)
        if 'steam' not in omit:tea_vapor(lin,self.cam,self.b,self.tea,t)
        if 'birds' not in omit:dusk_birds(lin,self.b,t)
        return self.pa.quantize(fx.bloom(lin,thresh=.50,sig=(1.2,4.5),gain=(.28,.20)))
