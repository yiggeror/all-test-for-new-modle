#!/usr/bin/env python3
"""Gate 2.3 autumn/winter frozen linework and native frame build."""
import argparse, hashlib, json, os, subprocess, sys, time, zipfile
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
N=330;FPS=30
BASIS={'autumn':('spring_autumn_source.zip','9c4e69ee6d6b1944cfc36a3030d24fe1db790ef74a83e9885d3abf6ca8354898','spring_autumn_gate2/src'),
       'winter':('gate2_summer_winter_source_qa.zip','758fd46755f7ad8259b9ee20e1ba6e6f6472c485b89e67db03110d4b6f1b99ce','.')}
# Draft stills list selected action moments. All full-frame PNG files come from final QP0 decoding.
PEAK={'autumn':[(123,'aloft'),(149,'gust_and_birds'),(152,'bird_wings'),(178,'roll_and_vapor')],
      'winter':[(153,'warm_window'),(165,'page'),(220,'snow_gust')]}
AB={'autumn':{'aloft':(0,103,109,117,123,129,134,145,156,211),
              'rolling':(0,123,134,145,149,152,155,158,162,166,172,178,184,196,211),
              'steam':(0,123,149,166,172,178,184,196),
              'birds':(0,105,118,128,131,135,138,142,146,149,152,155,158,162,168,172,178,196)},
    'winter':{'page':(0,*range(128,210,2),165,221),'smoke':(0,134,165,192,214,220),
              'powder':(146,157,164,177,191,214,220,224,241),'window_snow':(0,112,145,155,164,167,170,184,214,221),
              'gust':(0,130,153,164,173,209,214,224)}}
STRIPS={'autumn':{'aloft':((40,66,275,123),tuple(range(114,136,2)),2,3),
                  'rolling':((80,137,212,176),tuple(range(140,185,3)),3,3),
                  'steam':((69,112,85,139),tuple(range(160,185,2)),8,6),
                  'birds':((130,3,180,25),tuple(range(125,165,3)),5,4)},
        'winter':{'page':((243,99,274,119),tuple(range(141,193,2)),6,5),
                  'smoke':((270,60,302,88),tuple(range(155,187,3)),5,5),
                  'powder':((10,22,62,108),tuple(range(150,233,7)),3,5),
                  'window_snow':((240,95,277,125),tuple(range(146,180,3)),5,5),
                  'facade':((232,19,245,85),tuple(range(148,204,4)),4,10)}}
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as ff:
        for b in iter(lambda:ff.read(2<<20),b''):h.update(b)
    return h.hexdigest()
def basis(repo,work,scene):
    filename,hash,root=BASIS[scene]
    f=repo/'previews'/'gate_2'/'source'/filename
    if not f.is_file() or sha(f)!=hash:raise ValueError(f'Wrong frozen source: {f}')
    p=work/'base'/scene;p.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(f) as z:z.extractall(p)
    return p/root
def encode(a,out):
    pth=out.with_suffix('.pending.mp4')
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-nostdin','-y','-filter_threads','1','-f','rawvideo','-pixel_format','rgb24',
         '-video_size','320x180','-framerate','30','-i','-','-an','-vf','scale=1920:1080:flags=neighbor:out_color_matrix=bt709:out_range=tv,format=yuv420p',
         '-c:v','libx264','-preset','veryfast','-threads','2','-g','330','-keyint_min','330','-sc_threshold','0','-qp','0','-pix_fmt','yuv420p',
         '-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-color_range','tv','-movflags','+faststart',str(pth)]
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    for _ in range(2):p.stdin.write(memoryview(np.ascontiguousarray(a)).cast('B'))
    p.stdin.close()
    if p.wait():raise RuntimeError('QP0 encode failed')
    pth.replace(out)
def still(mp4,frame,out):
    expr=f'select=eq(n\\,{frame})'
    tmp=out.with_name(out.stem+'.pending.png')
    cmd=['ffmpeg','-v','error','-xerror','-y','-threads','2','-i',str(mp4),'-vf',expr,'-vsync','vfr','-frames:v','1','-threads','1',str(tmp)]
    subprocess.run(cmd,check=True)
    with Image.open(tmp) as im:
        if im.size!=(1920,1080):raise ValueError('Incorrect full-size peak still')
    tmp.replace(out)
def strips(scene,frames,qa):
    for k,(r,picks,m,cols) in STRIPS[scene].items():
        x,y,X,Y=r;w=(X-x)*m;h=(Y-y)*m
        out=Image.new('RGB',(cols*(w+5),((len(picks)+cols-1)//cols)*(h+16)),(31,30,34))
        dr=ImageDraw.Draw(out)
        for i,f in enumerate(picks):
            x0=(i%cols)*(w+5);y0=(i//cols)*(h+16)
            im=Image.fromarray(frames[f,y:Y,x:X]).resize((w,h),Image.Resampling.NEAREST)
            out.paste(im,(x0,y0))
            dr.text((x0+1,y0+h+1),f'{f:03d} / {f/30:.2f} s',fill=(231,225,215))
        out.save(qa/f'{scene}_{k}_strip.png')

def anchors_and_motion(s,scene,frames,qa):
    tree=s.b.get('tag5',np.zeros((180,320),np.float32))
    crown=s.b.get('tag1',np.zeros((180,320),np.float32))
    hard=tree>=.72;leaves=crown>=.82
    facade=np.zeros((180,320),bool)
    if scene=='winter':facade[18:94,229:250]=True
    np.savez_compressed(qa/f'{scene}_anchor_masks.npz',trunks_branches=hard,fixed_crown=leaves,facade_roi=facade)
    labels=np.zeros((180,320,3),np.uint8);labels[hard]=(255,165,65);labels[leaves]=(87,201,149);labels[facade]=(131,171,232)
    Image.fromarray(labels).resize((960,540),Image.Resampling.NEAREST).save(qa/f'{scene}_anchor_mask.png')
    # This calls the same production frame entrypoint. Only physical moving emitters
    # (leaves, smoke, snow, book, etc.) are omitted, not a separate static geometry branch.
    control=np.stack([s.frame(i/FPS,omit=s.GROUPS) for i in range(N)])
    if not np.all(control==control[0]):raise AssertionError('fixed geometry/exposure changed')
    control_file=qa/f'{scene}_fixed_control_330.npz'
    np.savez_compressed(control_file,frames=np.asfortranarray(control))
    Image.fromarray(control[0]).save(qa/f'{scene}_fixed_control_native.png')
    del control
    heat=np.zeros((180,320),np.int16);peak=np.zeros((180,320),np.uint8)
    for i in range(N):
        delta=np.abs(frames[i].astype('i2')-frames[(i-1)%N]).max(2)
        heat+=delta>8;peak=np.maximum(peak,delta.astype(np.uint8))
    v=np.clip(115.*np.log1p(heat)/np.log1p(max(12.,float(heat.max()))),0,115)
    paint=np.stack([np.clip(v*2.,0,255),v*.78,v*.32],axis=-1).astype(np.uint8)
    Image.fromarray(paint).resize((960,540),Image.Resampling.NEAREST).save(qa/f'{scene}_motion.png')
    np.savez_compressed(qa/f'{scene}_motion_arrays.npz',transition_counts=heat,max_rgb_delta=peak)
    return {'control_frames':N,'max_control_change_full_frame':0,'anchor_trunk_px':int(hard.sum()),
            'anchor_crown_px':int(leaves.sum()),'facade_observation_px':int(facade.sum()),
            'full_frame_motion_delta_threshold':8,'control_storage_fortran':True,
            'control_npz_bytes':control_file.stat().st_size}

def split(scene,mp4,work):
    root=work/'publish';base=root/'lossless_parts'/scene;base.mkdir(parents=True,exist_ok=True)
    parts=[];h=hashlib.sha256();size=0
    with mp4.open('rb') as src:
        for i,b in enumerate(iter(lambda:src.read(8_000_000),b'')):
            f=base/f'part-{i:02d}.bin';f.write_bytes(b)
            h.update(f.read_bytes());size+=len(b)
            parts.append({'path':str(f.relative_to(root)),'bytes':len(b),'sha256':sha(f)})
    whole=sha(mp4)
    if h.hexdigest()!=whole or size!=mp4.stat().st_size:raise AssertionError('lossless parts mismatch')
    entry={'output':mp4.name,'bytes':size,'sha256':whole,'parts':parts}
    (root/f'{scene}_parts.json').write_text(json.dumps(entry,indent=2)+'\n')
    return entry['bytes'],len(parts)

def render(scene,repo,work,component,scout):
    sys.path.insert(0,str(basis(repo,work,scene).resolve()))
    if scene=='autumn':
        from autumn23 import Autumn
        s=Autumn()
    else:
        from winter23 import Winter
        s=Winter()
    print('PLATE',scene,s.info,flush=True)
    target=work/'out';target.mkdir(parents=True,exist_ok=True)
    qa=work/'qa';qa.mkdir(parents=True,exist_ok=True)
    atlas=qa/'layer_native';atlas.mkdir(parents=True,exist_ok=True)
    draft=work/'drafts';draft.mkdir(parents=True,exist_ok=True)
    if scout:
        fs=sorted(set([0,*[x for x,_ in PEAK[scene]],*[x for v in AB[scene].values() for x in v]]))
        base={}
        for i in fs:
            base[i]=s.frame(i/FPS)
            Image.fromarray(base[i]).save(draft/f'{scene}_{i:03d}.png')
        for layer,fr in AB[scene].items():
            for i in fr:Image.fromarray(s.frame(i/FPS,omit=(layer,))).save(draft/f'{scene}_{i:03d}_no_{layer}.png')
        (qa/(scene+'_scene.json')).write_text(json.dumps(s.info,indent=2)+'\n')
        return
    t0=time.monotonic()
    tmp=target/(f'.{scene}_native.pending')
    frames=np.lib.format.open_memmap(tmp,mode='w+',dtype=np.uint8,shape=(N,180,320,3))
    for j in range(N):
        frames[j]=s.frame(j/FPS)
        if j%55==0:print('FRAMES',scene,j,round(time.monotonic()-t0,2),flush=True)
    assert np.array_equal(frames[0],s.frame(N/FPS))
    frames.flush(); final=target/(scene+'_native.npy');tmp.replace(final)
    mp4=target/(scene+'_loop.mp4')
    print('NATIVE_READY',scene,sha(final),flush=True)
    encode(frames,mp4)
    print('MP4_READY',scene,sha(mp4),flush=True)
    for i,ename in PEAK[scene]:
        still(mp4,i,target/f'{scene}_{ename}_f{i:03d}_1080p.png')
    bytes_,parts=split(scene,mp4,work)
    proof={};stat={}
    if component:
        stat=anchors_and_motion(s,scene,frames,qa)
        strips(scene,frames,qa)
        for layer,indices in AB[scene].items():
            rows=[]
            for i in indices:
                off=s.frame(i/FPS,omit=(layer,))
                on=frames[i].copy()
                both=np.concatenate((on,off),axis=1)
                Image.fromarray(both).save(atlas/f'{scene}_{layer}_f{i:03d}_on-left_off-right.png')
                delta=np.abs(on.astype(np.int16)-off).max(2);y,x=np.where(delta>2)
                rows.append({'index':i,'pixels':int(len(x)),'bbox_xyxy':[int(x.min()),int(y.min()),int(x.max()+1),int(y.max()+1)] if len(x) else None,'max_rgb_delta':int(delta.max())})
            proof[layer]=rows
    (qa/(scene+'_scene.json')).write_text(json.dumps({'scene':scene,'movie':s.info,'fps':FPS,'period_frames':N,'full_peaks':PEAK[scene],
           'loop_mp4_sha256':sha(mp4),'native_npy_sha256':sha(final),'mp4_bytes':bytes_,'lossless_parts':parts,'anchors':stat,'layers':proof},indent=2)+'\n')
    print('READY',scene,round(time.monotonic()-t0,2),flush=True)
def main():
    a=argparse.ArgumentParser();a.add_argument('scene',choices=['autumn','winter','both']);a.add_argument('--repo',type=Path,required=True);a.add_argument('--work',type=Path,required=True);a.add_argument('--scout',action='store_true');a.add_argument('--no-proof',action='store_true');args=a.parse_args()
    if args.scene=='both':
        for c in ('autumn','winter'):
            subprocess.run([sys.executable,str(Path(__file__).resolve()),c,*sys.argv[2:]],check=True)
    else:render(args.scene,args.repo.resolve(),args.work.resolve(),not args.no_proof,args.scout)
if __name__=='__main__':main()
