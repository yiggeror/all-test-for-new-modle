"""Winter 2.3: the environment and every electric fixture remain static; only paper and weather move."""
import numpy as np
from math import sin,cos,pi
from shots import winter_gate15 as frozen, winter_world_gate15 as sc
from timeline import reader_controls
from framework import use_cjk,FixedColors,plate,NativeActor
from engine import fx,props as pr
from engine.world import World,roty,srgb
from pixel_fx import T, sm, flow, depth_splat, chimney_plume, world_snow

def separate_reading_room(w,width,height):
    """Reuses the approved opening. Only book/desk and lamp move centimetres."""
    desk=sc.G_DESK
    light=dict(mat='emit',col='#e6a158',prm=(.56,0,0,0),tag=pr.TAG_NOSNOW,grp=desk)
    w.quads((-.25,-.16,-.64),(width+.22,-.16,-.64),(width+.22,height+.20,-.64),(-.25,height+.2,-.64),**light)
    w.quads((0,.01,-.61),(width,.01,-.61),(width,.25,-.61),(0,.25,-.61),mat='emit',col='#985e38',prm=(.47,0,0,0),tag=pr.TAG_NOSNOW,grp=desk)
    dl=dict(mat='plain',col='#453235',tag=pr.TAG_NOSNOW)
    w.sphere((.63,.39,-.27),.23,n=10,squash=1.45,**dl)
    w.tube((.69,.51,-.25),(.82,.76,-.23),.13,.10,sides=8,caps=True,**dl)
    w.sphere((.87,.83,-.21),.132,n=10,squash=1.03,**dl)
    w.sphere((.96,.79,-.22),.052,n=7,squash=.62,**dl)
    w.box((1.12,.26,-.18),(1.20,.105,.28),mat='wood',col='#714938',tag=pr.TAG_NOSNOW)
    for x in (1.065,1.241):
        w.box((x,.325,-.001),(.164,.025,.182),yaw=.13,mat='emit',col='#cab18b',prm=(.225,0,0,0),tag=pr.TAG_NOSNOW,grp=desk)
    # Narrow cloth shade, physically to the right of the entire book motion envelope.
    w.tube((1.815,.30,-.26),(1.805,.710,-.28),.021,sides=6,**dl)
    w.tube((1.805,.743,-.28),(1.805,.969,-.28),.17,.076,sides=10,caps=True,
           mat='emit',col='#ffd6a0',prm=(.76,0,0,0),tag=pr.TAG_NOSNOW,grp=desk)
    w.light('point',np.asarray(srgb('#ffd396'))*.68,pos=(1.755,.73,-.32),radius=.068,range=1.44,r0=.24,grp=desk)
    for x in (.025,width-.024):
        w.box((x,height/2,.02),(.09,height,.08),mat='wood',col='#483a37',tag=pr.TAG_NOSNOW)
    for y in (.029,height-.021):
        w.box((width/2,y,.02),(width,.072,.093),mat='wood',col='#483a37',tag=pr.TAG_NOSNOW)
    w.box((width/2,height-.19,.02),(width,.057,.068),mat='wood',col='#58423a',tag=pr.TAG_NOSNOW)

class Room:
    def __init__(self):
        before=sc.reading_room_window
        sc.reading_room_window=separate_reading_room
        try:
            self.b,self.cam=plate(frozen)
        finally:
            sc.reading_room_window=before
        self.c=sc.setup(self.b,self.cam)
        self.actor=NativeActor(self.cam,self.b,(235,92,277,125),samples=4)
        width,depth,_=sc.GUARD_SIZE
        a,b,*_=sc.READING_OPENING
        self.xform=(a-width/2,b,depth/2-.16)
        self.roof=frozen.ANCHORS['值班室小烟管']
        aa=self.xform
        self.lamp_pt=frozen.guard_world((aa[0]+1.755,aa[1]+.73,aa[2]-.32))
    def arm(self,t):
        lift,turn,shown=reader_controls(t)
        start=(.73,.563,-.123)
        ang=pi*(.04+.92*turn)
        hinge=np.array([1.161,.343,.030])
        leng=.247
        reach=cos(ang)*leng
        elbow=(.922+.045*lift,.357+.145*lift,-.043+.051*lift)
        tip=(1.132+lift*(hinge[0]+reach*.90-1.17),.334+lift*(.039+(.196+sin(ang)*.107)*shown),.002+.068*lift)
        # During the lifted page fingertips follow the near paper edge, not the glass or lamp.
        m=World(seed=23)
        with m.at(sc.GUARD_POS,yaw=sc.GUARD_YAW):
            with m.at(self.xform):
                dark=dict(mat='plain',col='#4c3739',prm=(.28,0,0,0))
                m.tube(start,elbow,.076,.060,sides=8,caps=True,**dark)
                m.tube(elbow,tip,.059,.032,sides=8,caps=True,**dark)
                m.sphere(tip,.041,n=8,squash=.81,mat='plain',col='#96654e',prm=(.35,0,0,0))
                if shown>.012:
                    # Actual single bent paper. Nonemissive warm flax, deliberately narrower than lamp's body.
                    def p(a,z):
                        return hinge+np.array([reach*a+.058*z*a,
                            shown*(leng*sin(ang)*a+.127*sin(.64*pi*a)*sin(ang)),z*(.104+.018*a)+.048*a])
                    for k in range(3):
                        a,b=k/3,(k+1)/3
                        m.quads(p(a,-1),p(b,-1),p(b,1),p(a,1),mat='plain',
                                col=('#c5ad87','#dbc7a5','#e0c9a5')[k],prm=(.36+.43*sin(ang),0,0,0))
                    if shown>.22:
                        m.tube(p(1,-1),p(1,1),.016*shown,.012*shown,sides=6,caps=True,mat='plain',
                               col='#e5cca3',prm=(.81,0,0,0))
        return m

class Winter:
    def __init__(self):
        use_cjk()
        self.st=Room()
        self.b,self.cam=self.st.b,self.st.cam
        self.pa=FixedColors('winter',frozen.GRADE,frozen.VIGNETTE);self.palette=self.pa.rgb
        # Use only original true geometry/fixtures. No animation is assigned to any facade window.
        c=self.st.c; L=self.b['layers']
        self.static=c['sky'].copy()+L[0]+L[sc.G_LAMP]+L[sc.G_DESK]
        self.static+=L[sc.G_TV]*np.array([.80,.84,.96],np.float32)[None,None]
        for j in range(sc.K-sc.G_ST-1):
            self.static+=L[sc.G_ST+j]*.10
        lamp=c['lamp'];x,y,_,_=c['lamp_px']
        fx.glow(self.static,x[0],y[0],lamp['color']*.012,r0=2.2,power=1.3)
        yy,xx=np.mgrid[:180,:320]
        tree=self.b['tag5'];P=self.b['P'];dep=self.b['depth'][...,4]
        sel=(tree>.21)&(tree<.94)&(dep<27)&(xx>=32)&(xx<=72)&(yy>=11)&(yy<=44)&(P[...,1]>7.7)
        jj,ii=np.nonzero(sel)
        if not len(jj):raise RuntimeError('Expected physical branch not found')
        idx=np.argmin((ii-48)**2+((jj-29)*1.2)**2-.53*tree[jj,ii])
        self.branch=self.b['P'][jj[idx],ii[idx]].astype(float); self.branch_px=[int(ii[idx]),int(jj[idx])]
        self.L=self.st.c['lamp']
        self.ext=frozen.guard_world((-.65,1.48,sc.GUARD_SIZE[1]*.5+.22));self.ext=np.array(self.ext)
        self.ext_axis=roty(sc.GUARD_YAW)@np.array([0.,-.67,1.]);self.ext_axis/=np.linalg.norm(self.ext_axis)
        self.ext_col=np.asarray(srgb('#fbb36d'))*.32
        r=np.random.default_rng(519)
        self.wt0=r.uniform(0,1,85);self.winlocal=np.column_stack([r.uniform(-1.80,.68,85),r.uniform(.87,3.79,85),r.uniform(1.79,3.46,85)])
        self.winvel=np.column_stack([r.uniform(.32,.73,85),-r.uniform(.53,1.12,85),r.uniform(-.09,.03,85)])
        self.wsz=r.uniform(.009,.031,85)
        self.p0=np.column_stack([r.uniform(-.19,.33,52),r.uniform(-.18,.1,52),r.uniform(-.17,.21,52)])
        self.p_delay=4.90+r.uniform(0,.70,52); self.prad=r.uniform(.008,.028,52)
        self.p_life=r.uniform(1.83,3.46,52);self.eddy=r.uniform(0,6.28,52);self.p_dir=r.uniform(.3,1.25,52)
        self.lamp_local=r.uniform(0,1,156)
        self.lamp_p=np.column_stack([r.uniform(-2.85,1.80,156),r.uniform(-3.9,1.7,156),r.uniform(-2.1,4.6,156)])
        self.lamp_r=r.uniform(.014,.039,156);self.lamp_fall=r.uniform(.50,1.12,156)
        self.info={'branch_px':self.branch_px,'branch_m':list(self.branch),'stove_px':[float(f) for f in self.cam.project(self.st.roof)[:2]],
            'facade_policy':'existing geometry only; fixed light groups, no electric changes',
            'page_window_s':[4.3,6.90],'paper_cues_s':[5.21,5.64,6.28],
            'lamp_nearest_local_x':1.635,'page_farthest_local_x':1.466,
            'window_snow_clip':(245,100,272,117),'wind_s':[3.23,8.85]}
    def window_snow(self,out,t,lights,k):
        age=(t/T*4.+self.wt0)%1.;u=(age-.5)*3.1
        a=self.winlocal+self.winvel*u[:,None]
        a[:,0]+=k*.47*(.68+.32*np.cos(self.wt0*13.4+t*2))
        W=roty(sc.GUARD_YAW);p=np.asarray(sc.GUARD_POS)+a@W.T
        f=sm(age/.15)*sm((1-age)/.15)
        x,y,*_=self.cam.project(p)
        f*=sm((x-243)/4)*sm((276-x)/3)*sm((y-97)/4)*sm((122-y)/5)
        world_snow(out,self.cam,self.b,p,self.wsz,f,lights,self.st.c['amb']*.70,alpha=.81)
    def powder(self,out,t,lights,k):
        age=t-self.p_delay;u=age/self.p_life;fade=sm(u/.095)*sm((1-u)/.29)
        if not np.any(fade):return
        a=np.maximum(age,0.)
        p=self.branch+self.p0*np.minimum(1.,.31+a[:,None]*.8)
        p[:,0]+=-.31*a-.16*a*a+.22*a*np.sin(self.eddy+3.0*a)
        p[:,1]+=-self.p_dir*.18*a-.58*a*a+.08*a*np.cos(self.eddy+2.4*a)
        p[:,2]+=.20*a+.27*a*np.cos(self.eddy+2.6*a)
        world_snow(out,self.cam,self.b,p,self.prad,fade,lights,self.st.c['amb']*.83,alpha=.83)
        # Ten local parcels render the finest ice dust as weak forward-scattering powder, not extra bright dots.
        take=np.arange(1,len(a),5)
        pa=p[take]; ag=a[take]; alp=fade[take]*.044
        colors=np.tile(np.array([.148,.123,.113],np.float32),(len(take),1))
        depth_splat(self.cam,self.b,pa,.030+.061*ag,alp,colors,out,anis=1.04,maxalpha=.071)
    def cone_flow(self,out,t,lights,k):
        if k<.006:return
        age=(t/T*2+self.lamp_local)%1.;u=(age-.5)*5.5
        a=self.lamp_p.copy()
        ring=self.lamp_p[:,1]*.67-self.lamp_p[:,2]*.45-.97*t
        a[:,0]+=-.310*u+1.39*k*np.cos(ring)
        a[:,1]+=-self.lamp_fall*u+.31*k*np.sin(ring)
        a[:,2]+=.25*u+.61*k*np.sin(ring+.5)
        g=sm(age/.16)*sm((1-age)/.18)*k
        world_snow(out,self.cam,self.b,self.L['pos']+a,self.lamp_r,g,lights,self.st.c['amb']*.87,alpha=.68)
    GROUPS=('page','smoke','snow','window_snow','powder','gust')
    def frame(self,t,omit=()):
        t=t%T;p=t/T;w=flow(t,.11);c=self.st.c
        out=self.static.copy()
        self.st.actor.composite(out,self.st.arm(0. if 'page' in omit else t),self.st.lamp_pt,1.)
        if 'smoke' not in omit:chimney_plume(self.cam,self.b,t,self.st.roof,out,w)
        lamp=self.L
        l=[(lamp['pos'],lamp['color']*.48,.83,lamp['axis'],lamp['cone'],7.5),
           (self.ext,self.ext_col,.47,self.ext_axis,(0.,.60),3.2)]
        if 'snow' not in omit:
            for j,obj in enumerate(c['snow']):
                P,fade=obj.positions(p)
                incone=np.exp(-((P[:,2]-lamp['pos'][2])*.18)**2-((P[:,0]-lamp['pos'][0])*.22)**2)
                eddy=P[:,1]*.49-P[:,2]*.39+t*1.15
                P[:,0]-=w*(.74+.75*incone*(.57+.43*np.sin(eddy)))
                P[:,1]+=w*incone*(.38*np.sin(eddy+.93))
                world_snow(out,self.cam,self.b,P,obj.size,fade,l,c['amb']*(1.02 if j==2 else 1.),alpha=(.56,.64,.73)[j])
        if 'window_snow' not in omit:self.window_snow(out,t,l,w)
        if 'powder' not in omit:self.powder(out,t,l,w)
        if 'gust' not in omit:self.cone_flow(out,t,l,w)
        return self.pa.quantize(fx.bloom(out,thresh=.55,sig=(1.,3.5),gain=(.22,.14)))
