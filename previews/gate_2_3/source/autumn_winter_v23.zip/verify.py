#!/usr/bin/env python3
"""逐帧校验无损 QP0 双循环：B站/手机兼容审片代理不作为输入。"""
import argparse,hashlib,json,subprocess
from pathlib import Path
import numpy as np

def run(scene,repo,out):
    a=np.load(out/(scene+'_native.npy'),mmap_mode='r')
    if a.shape!=(330,180,320,3) or a.dtype!=np.uint8:raise ValueError('Unexpected native grid')
    f=out/(scene+'_loop.mp4')
    stream=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(f)]))['streams']
    assert len(stream)==1
    s=stream[0];assert (s['width'],s['height'],s['avg_frame_rate'],s['nb_frames'],float(s['duration']),s['pix_fmt'])==(1920,1080,'30/1','660',22.,'yuv420p')
    map0=np.array(json.loads((repo/'tools/gate3/native_fingerprints.json').read_text())[scene]['yuv_to_rgb'],np.uint32)
    keys=map0[:,0]*65536+map0[:,1]*256+map0[:,2];idx=np.argsort(keys);keys=keys[idx];rgb=map0[idx,3:].astype(np.uint8)
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-xerror','-threads','2','-i',str(f),'-map','0:v:0','-an','-threads','1','-f','rawvideo','-pixel_format','yuv420p','-']
    p=subprocess.Popen(cmd,stdout=subprocess.PIPE)
    N=1920*1080;nch=N//4;blk=N+nch*2
    hashes=[];times=0
    for i in range(660):
        raw=p.stdout.read(blk)
        if len(raw)!=blk:raise AssertionError(f'truncated {i}')
        packet=np.frombuffer(raw,np.uint8)
        yp=packet[:N].reshape(180,6,320,6);up=packet[N:N+nch].reshape(180,3,320,3);vp=packet[N+nch:].reshape(180,3,320,3)
        planes=[]
        for ch in (yp,up,vp):
            one=ch[:,0,:,0]
            if not np.all(ch==one[:,None,:,None]):raise AssertionError(f'blurred grid f{i}')
            planes.append(one.astype(np.uint32))
        hash0=hashlib.sha256(raw).hexdigest()
        if i<330:
            hashes.append(hash0)
            key=planes[0]*65536+planes[1]*256+planes[2];j=np.searchsorted(keys,key)
            if j.max()>=len(keys) or not np.array_equal(keys[j],key):raise ValueError(f'palette mismatch f{i}')
            if not np.array_equal(rgb[j],a[i]):raise AssertionError(f'encoded != author RGB on frame {i}')
        elif hashes[i-330]!=hash0:raise AssertionError(f'cycle mismatch f{i}')
        times+=1
    if p.stdout.read(1):raise AssertionError('trailing frames')
    if p.wait():raise AssertionError('decode error')
    dif=lambda l,r:float(np.abs(l.astype(np.int16)-r).mean())
    near=[round(dif(a[(i-1)%330],a[i%330]),6) for i in range(-5,7)]
    return {'scene':scene,'unique_native_frames':len(set(hashes)),'decoded_frames':times,'first_second_cycle_identical_pairs':330,
       'all_three_planes_in_every_frame_uniform_native_blocks':True,'source_exact_native_rgb_pairs':330,'rgb_seam_mae':near[5],
       'near_seam_maes':near,'native_npy_sha256':hashlib.sha256((out/(scene+'_native.npy')).read_bytes()).hexdigest(),
       'loop_qp0_mp4_sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('scene',choices=['autumn','winter']);p.add_argument('--repo',type=Path,default=Path('.'));p.add_argument('--output',type=Path,required=True);p.add_argument('--json',type=Path);a=p.parse_args()
    st=json.dumps(run(a.scene,a.repo,a.output),indent=2)+'\n';print(st,end='')
    if a.json:a.json.write_text(st)
