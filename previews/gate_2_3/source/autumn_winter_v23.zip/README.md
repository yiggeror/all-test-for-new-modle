# Gate 2.3｜秋、冬：锁定像素线稿、分清天气与结构

执行 [Round 12 / 16951626](https://github.com/yiggeror/all-test-for-new-modle/blob/16951626d5db44eacf6ac0f9b52caf80cafd2a5b/REVIEW_LOG.md) 的返工要求。已删除旧画面重采样形变，秋、冬均不再调用树冠/树干形变函数。场景的建筑、树干、主枝和主冠由原三维模型一次投影、整场固定；没有生成式图片，没有帧插值，也没有调整总片、音乐、旧 Release 或 Drive。

## 一键重渲

Python 3.12、FFmpeg/libx264、Noto CJK Serif/Sans 字体（包 `fonts-noto-cjk`）。从仓库自身两份冻结 Gate 2 ZIP 读取已确认的三维场景和色板，不从 v2.2 或代理视频取帧：

- `previews/gate_2/source/spring_autumn_source.zip`：SHA-256 `9c4e69ee6d6b1944cfc36a3030d24fe1db790ef74a83e9885d3abf6ca8354898`
- `previews/gate_2/source/gate2_summer_winter_source_qa.zip`：SHA-256 `758fd46755f7ad8259b9ee20e1ba6e6f6472c485b89e67db03110d4b6f1b99ce`

从仓库根目录执行：

```bash
repo="$PWD"
work="$repo/build/gate23_aw"
mkdir -p "$work/src"
unzip -q -o previews/gate_2_3/source/autumn_winter_v23.zip -d "$work/src"
python3.12 -m venv "$work/venv"
"$work/venv/bin/python" -m pip install -r "$work/src/requirements.txt"
export NUMBA_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1
"$work/venv/bin/python" "$work/src/render.py" both --repo "$repo" --work "$work"
for season in autumn winter; do
  "$work/venv/bin/python" "$work/src/verify.py" "$season" --repo "$repo" --output "$work/out" --json "$work/qa/${season}_verified.json"
done
```

`both` 亦可改为一季；`--scout` 只抽原生 A/B 帧。成品为每季单周期 `330×180×320×3 uint8 RGB` NPY、两周期 QP0 `1920×1080 / 30fps / 660 帧 / 22s` MP4、秋四、冬三张正本视频真解码无裁剪原幅。分卷单片 ≤ 8,000,000 B，拼回正本逐字节一致。A/B、放大条带及 330 帧固定参考对照在 `qa/`。

## 秋 · 梧桐黄昏大道

- 删除 v2.2 报亭糊块人物和远处红雾车灯，不挪动主体构图。钠灯、电视窗照和亭照均为既有光组的固定状态。
- 落叶走两条物理层：稀疏的高层树际下落与路面阵风卷叶。风起时贴地叶从左路缘向中右斜穿斑马线；位置跳原生整像素，叶面朝向固定 5 帧才换一次，掌裂轮廓按世界投影画入；深度遮挡、灯照、叶面明暗和接触影取自原场景。
- 保留报刊亭右侧暗底的热汽：约 (75.49,135.38) 的既有汽源，小体积分团一起升起、迅速淡开。紧支撑轮廓配有限透明度与原色板固定有序织色，无大面积灰雾。
- 只在粉紫天空的真实开口飞过三只小归鸟。最宽姿态约 4–5 原生像素，滑翔间隔扇动，用天空覆盖遮住树冠、真实紫幕为底调色；无前景动物。

## 冬 · 雪夜家属院

- **所有居民楼既有照明静态。** 旧 x≈237, y≈28/45/63/80 的动态亮斑没有几何插入或发光路径；没有窗外跑马灯、呼吸灯或凭空亮灭。值班室台灯和左路灯亮度固定。
- 暖窗单次翻页仍在 4.30–6.90 秒；5.21、5.64、6.28 秒的原声音时相保持。暖窗开洞、台灯、桌面、纸面和手臂有实际三维距离；纸页的局部动作包络最右约 1.466 m，台灯罩最左约 1.635 m。纸页位置最险约 f153–166，可在 `winter_page_strip.png` 逐帧复查。
- 路灯光锥中保留多层次雪和阵雪；物理枝梢约 (48,29) 处随一阵风释出粉雪，粗树与细枝都不迁移。窗外独立雪体用灯影和实际深度叠到窗前；烟管位置 (279.8,86.2) 的烟低透明度向右上散开。

## 可独立检查的证据

- `*_anchor_masks.npz`：原场景逐像素三角面标签与覆盖度派生的固定树干、主枝/主冠；冬另标原假窗观察区域。不是手描来回经过的动画边缘。
- `*_fixed_control_330.npz`：**同一生产 frame()** 仅关闭真实运动物体（叶、鸟、汽、纸、雪），保留全部几何和灯光，出 330 张全幅；脚本逐像素核验全场最大 RGB 差为 0。真实天气仍会偶然越过某个固定枝片位置，`*_motion.png` 统计的是正常成片全 330 帧所有相邻对，含最后一到开头。
- `*_strip.png` 为原生区域高密度逐帧邻近放大，`qa/layer_native` 同相位、左开右关。需看整体审美时直接看视频和未经裁切的 1080p 峰帧。
- `verify.py` 全部解码 660 帧，亮度每 6×6、色度每 3×3 都是统一块；对应 330 帧对逐字节一致，借 Gate 2 锁定色板反查全部原生 RGB。
