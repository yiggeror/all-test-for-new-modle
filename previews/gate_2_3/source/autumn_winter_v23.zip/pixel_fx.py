"""Depth-tested weather on a frozen 3-D environment, using a locked pixel grid."""
from __future__ import annotations
import numpy as np
from math import pi,sin,cos
FPS=30
N=330
T=N/FPS
def sm(x):
    x=np.clip(x,0.,1.);return x*x*(3.-2.*x)
def pulse(t,a,b,c=.25,d=.43):
    u=(t-a)/(b-a)
    if not 0<u<1:return 0.
    return float(sm(u/c)*sm((1-u)/d))
def flow(t,salt=0):
    """One wind front: rising pressure, overshoot, then lower-frequency settling."""
    u=(t-3.12-salt)/5.62
    if not 0<u<1:return 0.
    return float(sm(u/.26)*sm((1-u)/.40)*(.82+.18*sin(2*pi*(u+.19))))
def depth_splat(cam, plate, P, radii, alpha, linear_colors, out=None, anis=None, maxalpha=.52, edge=None, additive=False):
    """Integrate projected Gaussian optical kernels, camera sample occlusion, and alpha-over.
    Positions/radii are 3-D metres, colors already lit; no rectangle or pre-drawn particle.
    """
    H,W=plate['sky'].shape
    x,y,dist,zf=cam.project(np.asarray(P))
    a=np.zeros((H,W),np.float32);rgb=np.zeros((H,W,3),np.float32);rads=np.asarray(radii)
    asp=np.broadcast_to(np.asarray(1. if anis is None else anis),(len(P),))
    for i in np.flatnonzero((zf>.8)&(alpha>1e-4)):
        radius=rads[i]*(W*.5/cam.th)/zf[i]
        if radius<.035:continue
        rx=max(.35,radius);ry=max(.34,radius*asp[i])
        x0,x1=max(0,int(x[i]-3*rx)),min(W,int(x[i]+3*rx)+1)
        y0,y1=max(0,int(y[i]-3*ry)),min(H,int(y[i]+3*ry)+1)
        if x1<=x0 or y1<=y0:continue
        yy,xx=np.ogrid[y0:y1,x0:x1]
        di=(plate['depth'][y0:y1,x0:x1]>dist[i]-.025).mean(axis=-1)
        if edge is not None:di*=edge[y0:y1,x0:x1]
        cov=alpha[i]*min(1.,(radius/.44)**1.5)*np.exp(-.5*(((xx+.5-x[i])/rx)**2+((yy+.5-y[i])/ry)**2))*di
        a[y0:y1,x0:x1]+=cov;rgb[y0:y1,x0:x1]+=cov[...,None]*linear_colors[i]
    if out is not None:
        sa=np.minimum(maxalpha,1-np.exp(-a))
        if not additive:out*=1-sa[...,None]
        out+=rgb*(sa/np.maximum(a,1e-8))[...,None]
    return a,rgb

def chimney_plume(cam,plate,t,origin,lin,wind_ref=0.):
    """Coupled optical density of several parcels from the same real point.
    Multi-lobed advection keeps the cap soft, no cone/profile artifact or hard white alpha.
    """
    n=18
    rng=np.random.default_rng(397)
    shift=(np.arange(n)+rng.uniform(.09,.87,n))/n; phases=rng.uniform(0,2*pi,n)
    loops=3
    age=(loops*(t%T)/T+shift)%1.
    work=rng.normal(size=(n,3))
    start=np.asarray(origin,float)
    wind=.49+.61*wind_ref
    rise=1.52+.45*wind_ref
    h=rise*(1+.10*work[:,1])*age
    # Slow push right through the knot followed by stretched out convection.
    bend=(wind*age**1.36+.218*np.sin(2*pi*t/T*2.-8.4*age+.44)*age
          +.14*work[:,0]*age)
    z=.12*work[:,2]*age+.07*np.cos(phases+age*8)*age
    P=start+cam.r[None]*bend[:,None]+cam.f[None]*z[:,None]
    P[:,1]+=h
    rad=(.045+.21*age**.88)*(.90+.15*rng.random(n))
    bands=.69+.31*np.cos(4*pi*t/T-13.5*age+.45)
    density=.106*sm(age/.084)*(1.-sm((age-.30)/.70))*(.58+.42*bands)*(.90+.10*np.cos(phases*.35+age*2.))
    # Tea takes its color from near tungsten; flue rapidly takes cool sky.
    c0=np.array([.142,.127,.127],np.float32)
    c1=np.array([.116,.124,.145],np.float32)
    colors=(1-age[...,None])*c0+age[...,None]*c1
    depth_splat(cam,plate,P,rad,density,colors,lin,anis=(.84+.48*age),maxalpha=.265)
    return P

def world_snow(lin,cam,plate,P,scale,fade,lights,ambient,alpha=.72,flurry=0.):
    X,Y,D,Z=cam.project(P);f=cam.W*.5/cam.th
    good=(Z>2.)&(Y>=-.8)&(Y<180.8)&(X>=-.8)&(X<320.8)&(P[:,1]>.04)&(fade>.005)
    if not good.any():return
    P=P[good];r=scale[good]*f/Z[good];X=X[good]-.50;Y=Y[good]-.50;D=D[good]
    ix=np.floor(X).astype(int);iy=np.floor(Y).astype(int);wx=X-ix;wy=Y-iy
    cov=np.minimum(r,1.35)**1.11*fade[good]*alpha
    c=np.broadcast_to(np.asarray(ambient,np.float32),(len(P),3)).copy()
    for lp,lc,roll,axis,cones,stop in lights:
        V=P-lp;d2=np.sum(V*V,axis=1)
        wt=1./(roll**2+d2)
        if axis is not None: wt*=sm((V@axis/np.maximum(np.sqrt(d2),.01)-cones[0])/(cones[1]-cones[0]))
        if stop is not None: wt*=sm((stop-np.sqrt(d2))/(stop*.36))
        c+=lc[None]*wt[...,None]
    c=np.minimum(c,np.array([.62,.43,.32],np.float32))
    A=np.zeros((180,320),np.float32);C=np.zeros((180,320,3),np.float32)
    for ex,ey,u,v in [(0,0,1-wx,1-wy),(1,0,wx,1-wy),(0,1,1-wx,wy),(1,1,wx,wy)]:
        a=ix+ex;b=iy+ey;s=(a>=0)&(a<320)&(b>=0)&(b<180)
        a=a[s];b=b[s];k=cov[s]*u[s]*v[s]*((plate['depth'][b,a,:]>D[s,None]).mean(axis=-1))
        np.add.at(A,(b,a),k);np.add.at(C,(b,a),c[s]*k[:,None])
    opacity=np.minimum(.89,A)
    lin*=1-opacity[...,None]
    lin+=C*(opacity/np.maximum(A,1.e-8))[...,None]
