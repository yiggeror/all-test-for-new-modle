"""Locked Gate 1.5 camera and grade, used for the re-lit Gate 2.2 scene."""
from engine.render import Camera
from shots import summer_world_gate15 as rain

NAME = "summer"
PHASE = 0.31
GATE1_DSTR = 0.20
VIGNETTE = 0.07
GRADE = dict(rain.GRADE, exposure=3.13, contrast=1.09, sat=1.02, lift=(0.012, 0.020, 0.040))
PAL = dict(chroma_w=4.3, extra=[(0.84, 0.24, 0.18), (0.66, 0.18, 0.18), (0.91, 0.62, 0.39), (0.89, 0.75, 0.58)])
DENOISE = dict(rain.DENOISE, r=1)
RENDER = dict(rain.RENDER, dirt=0.35, streak=0.28, refl_clamp=1.15)
sky = rain.sky

def camera(W, H):
    return Camera((-16.0, 5.05, 20.0), (2.4, 2.65, 0.7), fov=43, W=W, H=H)


def build():
    return rain.build()
