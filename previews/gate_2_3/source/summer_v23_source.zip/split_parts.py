"""Package one exact video as old-format 8 MB round-review parts and a mergeable manifest."""
from pathlib import Path
import argparse
import hashlib
import json

CHUNK=8_000_000

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('master',type=Path)
    p.add_argument('stage',type=Path)
    p.add_argument('--scene',default='summer',choices=('spring','summer','autumn','winter'))
    a=p.parse_args()
    d=a.stage/'lossless_parts'/a.scene
    d.mkdir(parents=True,exist_ok=False)
    files=[]; total=0; full=hashlib.sha256()
    with a.master.open('rb') as src:
        while data:=src.read(CHUNK):
            f=d/f'part-{len(files):02d}.bin';f.write_bytes(data)
            files.append({'path':f.relative_to(a.stage).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
            total+=len(data);full.update(data)
    entry={'output':a.scene+'_loop.mp4','bytes':total,'sha256':full.hexdigest(),'parts':files}
    (a.stage/'lossless_parts'/f'{a.scene}_manifest_entry.json').write_text(json.dumps(entry,indent=2)+'\n')
    restored=hashlib.sha256()
    for f in files:
        data=(a.stage/f['path']).read_bytes()
        if len(data)!=f['bytes'] or hashlib.sha256(data).hexdigest()!=f['sha256']:
            raise ValueError('round restore part mismatch')
        restored.update(data)
    if restored.hexdigest()!=entry['sha256']:
        raise ValueError('round restore video mismatch')
    print(a.scene,total,entry['sha256'],len(files),'parts restored exact')

if __name__=='__main__':main()
