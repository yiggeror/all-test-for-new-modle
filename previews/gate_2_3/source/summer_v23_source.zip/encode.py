"""Encode verified double summer cycle and extract unadorned full-frame peaks."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import tempfile
import numpy as np
from verify_master import exact_master

FPS=30
FRAMES=330
FILTER='scale=1920:1080:flags=neighbor:out_color_matrix=bt709:out_range=tv,format=yuv420p'
PEAKS={'headlight_road':124,'headlight_car_face':153,'neon_wet_road':190,'neon_dark_comparison':194,'rain_eave_drop':71}

def mp4_info(p):
    d=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]))
    return d['streams'][0]

def ffmpeg_base(threads):
    return ['ffmpeg','-loglevel','error','-nostdin','-y','-filter_threads',str(threads),'-threads',str(threads)]

def hash_file(p):
    with p.open('rb') as fp:
        return hashlib.file_digest(fp,'sha256').hexdigest()

def exact(rgb,out,threads):
    cmd=ffmpeg_base(threads)+['-f','rawvideo','-pixel_format','rgb24','-video_size','320x180','-framerate','30','-i','pipe:0',
          '-map','0:v:0','-an','-vf',FILTER,'-c:v','libx264','-qp','0','-preset','veryfast','-threads',str(threads),'-pix_fmt','yuv420p',
          '-colorspace','bt709','-color_range','tv','-color_primaries','bt709','-color_trc','bt709',
          '-g','330','-keyint_min','330','-sc_threshold','0','-movflags','+faststart',str(out)]
    with subprocess.Popen(cmd,stdin=subprocess.PIPE) as p:
        try:
            loop=memoryview(rgb).cast('B')
            for _ in range(2):
                p.stdin.write(loop)
        finally:
            p.stdin.close()
            code=p.wait()
        if code:
            raise subprocess.CalledProcessError(code,cmd)

def mobile(src,out,threads):
    with tempfile.TemporaryDirectory(prefix='gate22-summer-review-',dir=out.parent) as t:
        passlog=Path(t)/'pass'
        src=str(src.resolve())
        comp=ffmpeg_base(threads)+['-i',src,'-map','0:v:0','-an','-c:v','libx264','-profile:v','high','-level:v','4.0','-pix_fmt','yuv420p',
              '-threads',str(threads),'-preset','medium','-tune','animation','-b:v','2900k','-g','330','-colorspace','bt709',
              '-color_primaries','bt709','-color_trc','bt709','-color_range','tv','-x264-params','aq-mode=3:aq-strength=.78:scenecut=0:open-gop=0']
        subprocess.run(comp+['-pass','1','-passlogfile',str(passlog),'-f','mp4',os.devnull],check=True)
        draft=Path(t)/'summer_loop.mp4'
        subprocess.run(comp+['-pass','2','-passlogfile',str(passlog),'-movflags','+faststart',str(draft)],check=True)
        if draft.stat().st_size>8450000:
            raise ValueError('review proxy exceeds 8,450,000 bytes')
        v=mp4_info(draft)
        if (v['codec_name'],v['profile'],v['width'],v['height'],v['avg_frame_rate'],v['nb_frames'])!=('h264','High',1920,1080,'30/1','660'):
            raise ValueError('review proxy does not match the real double cycle')
        subprocess.run(ffmpeg_base(threads)+['-xerror','-i',str(draft),'-map','0:v:0','-f','null','-'],check=True)
        draft.replace(out)

def peaks(master,folder,threads):
    folder.mkdir(exist_ok=True,parents=True)
    data={}
    for name,i in PEAKS.items():
        out=folder/f'summer_{name}_F{i:03d}.png'
        subprocess.run(ffmpeg_base(threads)+['-xerror','-i',str(master),'-vf',
                 f'select=eq(n\\,{i}),scale=in_color_matrix=bt709:in_range=tv:out_range=pc',
                 '-frames:v','1','-f','image2','-pix_fmt','rgb24','-update','1',str(out)],check=True)
        data[name]={'frame_index':i,'t_seconds':round(i/30,6),'file':out.name,'sha256':hash_file(out)}
    return data

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,default=Path('out'))
    p.add_argument('--threads',type=int,default=2)
    p.add_argument('--reuse-master',action='store_true')
    p.add_argument('--skip-mobile',action='store_true')
    a=p.parse_args(); o=a.out
    n=o/'summer_native.npy';src=o/'summer_loop.mp4'
    v=np.load(n,allow_pickle=False)
    if v.dtype!=np.uint8 or v.shape!=(330,180,320,3) or not v.flags.c_contiguous:
        raise ValueError('Native input must be exactly 330 contiguous uint8 RGB 320×180 frames')
    if not a.reuse_master:
        print('encoding exact double cycle',flush=True)
        exact(v,src,a.threads)
    ev=peaks(src,o/'peaks',a.threads)
    print('verifying 660 decoded frames',flush=True)
    report=exact_master('summer',n,src)
    report['decoded_1080p_peak_stills']=ev
    if not a.skip_mobile:
        folder=o/'mobile';folder.mkdir(exist_ok=True)
        dest=folder/'summer_loop.mp4'
        print('encoding compatible browser review proxy',flush=True)
        mobile(src,dest,a.threads)
        report['mobile']={'bytes':dest.stat().st_size,'sha256':hash_file(dest),'video_spec':mp4_info(dest)}
    (o/'summer_verified.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print('complete',src.stat().st_size,report['master_sha256'],flush=True)

if __name__=='__main__':main()
