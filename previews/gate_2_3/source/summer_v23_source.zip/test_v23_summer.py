import unittest
import ast
from pathlib import Path
import headlight
import render_summer as s

class TrueFieldTests(unittest.TestCase):
    def test_every_render_phase_uses_own_lamp_field(self):
        class Spy:
            def __init__(self):self.calls=[]
            def shade(self,t):
                self.calls.append(t)
                return t*t
        a=s.Summer.__new__(s.Summer); a.head=Spy()
        seq=[105/30,106/30,107/30,124/30,125/30,126/30]
        self.assertEqual([a.light_at(t) for t in seq],[x*x for x in seq])
        self.assertEqual(a.head.calls,seq)

    def test_no_baked_light_frame_path(self):
        text=(Path(headlight.__file__).read_text()+'\n'+Path(s.__file__).read_text()).lower()
        tree=ast.parse(text)
        self.assertFalse(any(getattr(n,'name','') in ('bake','lerp_field') for n in ast.walk(tree)))
        for key in ('lerp_field','head_cache','--no-bake'):
            self.assertNotIn(key,text)

    def test_car_light_is_warm_amber_and_water_is_not_orange_paint(self):
        r,g,b=map(float,headlight.BEAM_COLOR)
        self.assertTrue(r>g>b and .43<g/r<.70 and .19<b/r<.40)
        rw,gw,bw=map(float,s.WATER_TINT)
        self.assertTrue(rw>gw>bw and bw/rw>.65)
        self.assertTrue(.35<s.HERO_RAIN_SCATTER<.8)

if __name__=='__main__':unittest.main()
