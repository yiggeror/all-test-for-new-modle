"""Gate 2.3 summer sources. A fixed scene plus real current-position street lighting."""
from pathlib import Path
import argparse
import json
from time import perf_counter
import numpy as np
from PIL import Image
from engine import fx
from engine.world import srgb
from shots import summer_world_gate15 as sc
from still_pass import setup_static,PixelGrade
from summer_motion import LIP,PERIOD,COUNT,neon_gain,roof_drop,tube_light
from wet_street import WetRoad
from headlight import Headlights,lamps,BEAM_CONE,BEAM_COLOR

HERO_RAIN_SCATTER=.61
WATER_TINT=(np.asarray(srgb("#fff4dd"),np.float32)*.221)


def draw_streak(lin,cam,plate,a,b,col,alpha):
    """Fractional pixel coverage of a falling 3D water segment, with per-pixel sample visibility."""
    P=np.asarray([a,b])
    x,y,d,v=cam.project(P)
    if np.min(v)<.08 or alpha<=0:
        return
    H,W=lin.shape[:2]
    x0=max(0,int(min(x)-2));x1=min(W,int(max(x)+3))
    y0=max(0,int(min(y)-2));y1=min(H,int(max(y)+3))
    if x0>=x1 or y0>=y1:
        return
    yy,xx=np.mgrid[y0:y1,x0:x1]
    dx=x[1]-x[0];dy=y[1]-y[0]
    u=np.clip(((xx+.5-x[0])*dx+(yy+.5-y[0])*dy)/max(dx*dx+dy*dy,1.e-8),0,1)
    dd=(xx+.5-x[0]-u*dx)**2+(yy+.5-y[0]-u*dy)**2
    dist=d[0]+(d[1]-d[0])*u
    visible=(plate['depth'][y0:y1,x0:x1,:]>=dist[...,None]-.015).mean(2)
    A=np.exp(-dd/.212)*visible*alpha*(.33+.67*u)
    lin[y0:y1,x0:x1]+=A[...,None]*np.asarray(col,np.float32)


class Summer:
    def __init__(self,samples=3,cache=None):
        self.w,self.b,self.cam,acc,self.sky=setup_static(samples,cache)
        self.grade=PixelGrade()
        self.wet=WetRoad(self.b,self.cam,acc)
        self.head=Headlights(self.w,self.cam,acc,2)
        print('wet true-surface count',int(self.wet.flat.sum()),'headlight subrays',len(self.head.p),flush=True)
        print('wet max sample radiance',max(float(x[2].max()) for x in self.wet.samples),flush=True)
        P=self.b['P']
        self.barber=4.6*(P[...,1]-1.55)+np.arctan2(P[...,2]-.20,P[...,0]-1.72)*(.55)
        self.barber_cov=np.clip((self.b['tag61']-.07)*1.28,0,1)
        self.barber_pal=np.asarray([[1.05,.15,.13],[.98,.93,.85],[.20,.32,1.09]],np.float32)
        points=sorted((a for a in self.w.lights if a['kind']=='point'),key=lambda q:np.linalg.norm(q['pos']-self.cam.pos))[:22]
        self.lights=[(x['pos'],x['color'],x['grp'],x.get('axis'),x.get('cone'),
                      HERO_RAIN_SCATTER if (abs(x['pos'][0]+6.0)<.4 and 5.7<x['pos'][1]<6.6) else 1.)
                     for x in points]
        mk=lambda **k:fx.Particles(self.cam,self.b,T=11.,loops=11,vel=(.46,-7.4,.25),vjit=.085,sway=0.,**k)
        self.rain=[
            mk(n=4310,seed=11,near=19,far=90,size=.037,dpow=.9),
            mk(n=1910,seed=12,near=6.4,far=23,size=.027,dpow=.72),
            mk(n=60,seed=13,near=2.4,far=6.4,size=.016,dpow=.52)]
        self.vapor=fx.Smoke(self.cam,self.b,sc.KETTLE_XYZ,n=17,T=11.,loops=6,rise=.54,
                            wind=(.065,0.,.060),r0=.045,grow=.09,seed=22,alpha=.19)

    def gain(self,i):
        t=(i%COUNT)/30
        ph=t/PERIOD
        g=np.ones(sc.K,np.float32)
        g[sc.G_FLUO]=tube_light(t)
        g[sc.G_NEON]=neon_gain(i)
        g[sc.G_TV]=.78+.34*fx.loopnoise(ph,14,21)
        g[sc.G_BULB]=.88+.20*fx.loopnoise(ph,13,31)
        g[sc.G_SIGN]=.976+.012*np.cos(4*np.pi*ph)
        g[sc.G_TLR],g[sc.G_TLG]=.50,.50
        return g

    def light_at(self,t):
        return self.head.shade(t)

    def frame(self,i,omit=(),wet_strength=1.,beam_strength=1.):
        i=int(i)%COUNT; t=i/30
        ph=t/PERIOD
        g=self.gain(i)
        if 'neon' in omit:
            g[sc.G_NEON]=0.
        lin=self.sky.copy()
        for k,L in enumerate(self.b['layers']):
            if k!=sc.G_POLE:
                lin+=g[k]*L
        # A helix on the actual 3D lamp cylinder: local height and normal, not a 2D screen stripe.
        u=(self.barber+ph*24)%3
        j=np.floor(u).astype(int)
        a=np.clip((u-j-.27)/.51,0,1)[...,None]
        a=a*a*(3-2*a)
        co=self.barber_pal[j]*(1-a)+self.barber_pal[(j+1)%3]*a
        lin+=self.b['layers'][sc.G_POLE]*(self.barber_cov[...,None]*co+(1-self.barber_cov[...,None])*.84)
        if 'headlight' not in omit:
            lin+=self.light_at(t)*beam_strength
        self.wet.draw(lin,t,g[sc.G_NEON],0. if 'wet' in omit else wet_strength,'eave' not in omit)
        if 'eave' not in omit:
            for at,x,z,c in LIP:
                a,b,opacity=roof_drop(at,x,z,c,t)
                draw_streak(lin,self.cam,self.b,a,b,WATER_TINT,opacity*.73)
        if 'steam' not in omit:
            self.vapor.draw(lin,ph,np.array([.163,.118,.085],np.float32)*(.78+.22*g[sc.G_FLUO]))
        if 'rain' not in omit:
            reaches=[(p,color*g[k]*(.202*optics),.69,axis,cone) for p,color,k,axis,cone,optics in self.lights]
            if 'headlight' not in omit:
                for pos,d,g0 in lamps(t):
                    if g0>.001:
                        reaches.append((pos,BEAM_COLOR*(.43*g0*beam_strength),.8,d,BEAM_CONE))
            amb=np.array([.00555,.0078,.0128],np.float32)
            for j,(r,a,s) in enumerate(zip(self.rain,[.40,.505,.27],[.020,.025,.019])):
                r.draw(lin,ph,amb*(1.8 if j==2 else 1.),reaches,alpha=a,streak=s,additive=True)
        return self.grade(fx.bloom(lin,thresh=.64,sig=(.84,2.78),gain=(.20,.128)))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,default=Path('out'))
    p.add_argument('--samples',type=int,default=3)
    p.add_argument('--cache',type=Path,default=None,help='testing cache for same geometry/samples only')
    p.add_argument('--scout',nargs='+',type=int,help='only the listed original frame indices')
    p.add_argument('--wet-strength',type=float,default=22.5)
    p.add_argument('--beam-strength',type=float,default=.59)
    p.add_argument('--tag',default='')
    a=p.parse_args();a.out.mkdir(exist_ok=True,parents=True)
    tstart=perf_counter()
    x=Summer(a.samples,a.cache)
    base_time=perf_counter()-tstart
    o=dict(wet_strength=a.wet_strength,beam_strength=a.beam_strength)
    if a.scout:
        for i in a.scout:
            fr=x.frame(i,**o)
            Image.fromarray(fr).resize((1920,1080),Image.Resampling.NEAREST).save(a.out/f'summer{a.tag}_f{i:03d}.png')
            omissions=[]
            if 19<=i<=174: omissions.append('headlight')
            if 190<=i<=235: omissions.append('wet')
            if i in (69,70,72,75,76,90): omissions.extend(('rain','eave'))
            for off in omissions:
                f=x.frame(i,(off,),**o)
                Image.fromarray(f).resize((1920,1080),Image.Resampling.NEAREST).save(a.out/f'summer{a.tag}_f{i:03d}_without_{off}.png')
            print('real frame',i,flush=True)
        fps=[m['wall_s'] for m in x.head.solved if m['emitters_evaluated']]
        print('measured on phases: mean/median/max (s)',[round(q,4) for q in [np.mean(fps),np.median(fps),max(fps,default=0)]],flush=True)
        (a.out/f'summer{a.tag}_scout_phases.json').write_text(json.dumps(x.head.solved,indent=2)+'\n')
        return
    n=np.empty((COUNT,180,320,3),np.uint8)
    for i in range(COUNT):
        n[i]=x.frame(i,**o)
        if i%30==0:
            print(f'rendered frame {i}/{COUNT}',flush=True)
    np.save(a.out/'summer_native.npy',n,allow_pickle=False)
    print('330 originals complete',flush=True)
    recipe={'samples':a.samples,'frame_count':COUNT,'wet_strength':a.wet_strength,'beam_strength':a.beam_strength,
            'view':'locked Gate 1.5, 320x180; square pixels',
            'per_frame_actual_lamp_evaluations':len(x.head.solved),'active_two_headlight_phase_count':sum(q['emitters_evaluated']==2 for q in x.head.solved),
            'base_setup_seconds':round(base_time,3),'total_baseline_and_phases_real_seconds':round(perf_counter()-tstart,3),
            'components':['locked source geometry','shadowed physical dual lamp camera-space samples','facing real sampled sign aperture',
                          'asphalt roughness and rain-derived normal slope','world-space depth-tested rain/eave/steam','original 60-color palette']}
    assert [q['frame'] for q in x.head.solved]==list(range(COUNT))
    (a.out/'summer_headlight_actual_phases.json').write_text(json.dumps(x.head.solved,indent=2)+'\n')
    (a.out/'summer_render.json').write_text(json.dumps(recipe,indent=2)+'\n')

if __name__=='__main__':main()
