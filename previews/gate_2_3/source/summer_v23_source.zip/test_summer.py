import unittest
import numpy as np
from summer_motion import CUTS, PERIOD, neon_gain, moving_light, cone_amount, RainImpacts, LIP, roof_drop

class Timing(unittest.TestCase):
    def test_approved_flickers_exactly(self):
        a=np.array([neon_gain(i) for i in range(330)])
        self.assertEqual(list(np.flatnonzero(a < .5)), [i for p,q,_ in CUTS for i in range(p,q)])
        self.assertEqual([round(float(a[p]),3) for p,_,_ in CUTS],[.22,.24,.21,.235])
        self.assertEqual(neon_gain(-1), neon_gain(329))
        self.assertEqual(neon_gain(330), neon_gain(0))

    def test_single_headlight_pass(self):
        weights=np.array([moving_light(i/30)[2] for i in range(330)])
        begins=np.flatnonzero(np.diff(np.r_[False, weights>0,False].astype(int))==1)
        self.assertEqual(len(begins),1)
        self.assertEqual(weights[0],0)
        self.assertTrue(np.all(weights[192:234]==0))
        self.assertGreater(weights.max(),.8)
        self.assertGreater(np.linalg.norm(moving_light(1.)[0]-moving_light(4.6)[0]),4)

    def test_cone_has_soft_edge_and_direction(self):
        d=np.array([[0,0,1],[0,0,-1],[.4,0,np.sqrt(.84)],[.8,0,.6]], np.float32)
        a=cone_amount(d,np.array([0,0,1],np.float32),.9,.99)
        self.assertEqual(a[0],1.)
        self.assertEqual(a[1],0.)
        self.assertGreater(a[2],0.)
        self.assertLess(a[2],1.)
        self.assertEqual(a[3],0.)

    def test_wet_impacts_wrap_and_return_to_zero(self):
        x,z=np.meshgrid(np.linspace(-2,2,21),np.linspace(-2,2,21))
        k=RainImpacts(x.astype(np.float32),z.astype(np.float32), [(1.0,0,0,.8,.25)])
        a=k.slope(.6)
        self.assertTrue(all(np.all(c==0) for c in a))
        b=k.slope(1.24)
        self.assertGreater(np.max(np.abs(b[0])),.001)
        self.assertGreater(np.max(np.abs(b[1])),.001)
        self.assertTrue(all(np.allclose(u,v,atol=1.e-7) for u,v in zip(b,k.slope(1.24+PERIOD))))

    def test_each_roof_drop_physically_lands_on_its_ripple(self):
        for at,x,z,m in LIP:
            _,root,_=roof_drop(at,x,z,m,at)
            self.assertTrue(np.allclose(root,[x+.064,.153,z+.037]))
            _,previous,_=roof_drop(at,x,z,m,at-.20)
            self.assertGreater(previous[1],root[1])
            self.assertTrue(np.allclose(previous,roof_drop(at,x,z,m,at-.20+PERIOD)[1]))

if __name__=='__main__': unittest.main()
