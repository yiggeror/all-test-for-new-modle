"""Fixed true ray-traced world for Gate 2.2, with raw per-pixel geometry buffers."""
from pathlib import Path
import json
import numpy as np
from PIL import ImageFont
from scipy.spatial import cKDTree
from engine import fx, pix, render as ray
from shots import summer_gate15 as f

HERE = Path(__file__).resolve().parent

def set_cjk():
    old=ImageFont.truetype
    options={
        'ukai.ttc':'NotoSerifCJK-Regular.ttc',
        'uming.ttc':'NotoSerifCJK-Regular.ttc',
        'wqy-zenhei.ttc':'NotoSansCJK-Regular.ttc',
    }
    def load(font,size=10,index=0,*a,**kw):
        try:
            return old(font,size,index,*a,**kw)
        except OSError:
            name=Path(font).name if isinstance(font,(str,Path)) else ''
            if name not in options:
                raise
            return old('/usr/share/fonts/opentype/noto/'+options[name],size,2,*a,**kw)
    ImageFont.truetype=load


def setup_static(samples, cache=None):
    fx.SC=320/480
    set_cjk()
    cam=f.camera(320,180); world=f.build()
    world.pixang=2*cam.th/cam.W
    if cache is None or not Path(cache).exists():
        p,acc=ray.render(world,cam,f.sky,S=samples,**f.RENDER)
        fx.denoise(p,**f.DENOISE)
        if cache:
            np.savez(cache,**p)
    else:
        with np.load(cache,allow_pickle=False) as z:
            p={k:z[k] for k in z.files}
        if p['depth'].shape!=(180,320,samples*samples):
            raise ValueError('static test cache sample count differs')
        g=world.finalize()
        acc=ray.Accel(g['v0'],g['v1'],g['v2'],g['tm'])
    p['lights']=world.lights
    sky=fx.native_sky(f,cam,180,320)*p['sky'][...,None]
    return world,p,cam,acc,sky


class PixelGrade:
    def __init__(self):
        meta=json.loads((HERE/'references'/'summer.json').read_text())
        self.rgb=np.asarray(meta['palette_rgb'],np.uint8)
        self.lab=pix.oklab(self.rgb/255.)*pix.LABW
        self.table=cKDTree(self.lab)
        self.thr=pix.threshold_map(180,320,meta.get('dither','mix'),seed=177)
        self.strength=meta['dither_strength']
        self.vig=fx.vignette(180,320,f.VIGNETTE)
    def __call__(self,l):
        c=pix.tonemap(np.maximum(l,0)*self.vig,**f.GRADE)
        a=pix.oklab(c)*pix.LABW
        _,j=self.table.query(a,k=2,workers=1)
        k=self.lab[j[...,0]]; d=self.lab[j[...,1]]-k
        share=np.sum((a-k)*d,axis=2)/np.maximum(np.sum(d*d,axis=2),1.e-9)
        return self.rgb[np.where(np.clip(share,0,1)*self.strength>self.thr,j[...,1],j[...,0])]

if __name__=='__main__':
    from PIL import Image
    import sys
    _,p,cam,_,sky=setup_static(int(sys.argv[1]),'../scout/base_s'+sys.argv[1]+'.npz')
    Image.fromarray(PixelGrade()(sky+p['layers'].sum(0))).resize((960,540),Image.Resampling.NEAREST).save('../scout/base_s'+sys.argv[1]+'.png')
    print('ungimmicked base tones and ground fraction:', np.mean(p['tag2']),flush=True)
