# Gate 2.3 夏 · 当前相位真实光场

这里是夏季独立源，重建不读取 v2.1 画面、旧缓存、网络资产或成片。旧场景继承仓库 Gate 2 源包 `previews/gate_2/source/gate2_summer_winter_source_qa.zip`，Git blob `b31db69db3e740574521759935c581803ea4fc15`（见 Round 9 审批树 `4c06e29619b2efa6ed8c4f9b75888417d91a4bb7`）。此次返工依据 Round 12（16951626d5db44eacf6ac0f9b52caf80cafd2a5b），直接由 Gate 2.2 审批夏源包 summer_v22_source.zip（Git blob db1528d41100121da4f87a935fa99f83ebfd75d3）解包修改。真实 3D 引擎和街景源已随包。环境：Linux x86-64，Python 3.12.14，NumPy 2.3.5，SciPy 1.17.0，Pillow 13.0.0，Numba 0.65.1，FFmpeg 7.1.5 + libx264，Noto CJK。使用 `fonts-noto-cjk` 的 SC 字面，或原细明体/楷体字体。

在本源码包解压后的根目录：
```bash
python -m pip install -r requirements.txt
python -m unittest -v test_summer test_v23_summer
NUMBA_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 python render_summer.py --out out
python encode.py --out out --threads 2
python split_parts.py out/summer_loop.mp4 staged
```

输出 330 原生 RGB 帧 `out/summer_native.npy`，两组完全相同的 11 秒原件 `out/summer_loop.mp4`、兼容审阅版 `out/mobile/summer_loop.mp4`、原件实解码峰值 PNG 与逐帧核查 JSON。原件是 320×180 精确 6× 放大后 H.264 QP0 / yuv420p / BT.709；第二周期不重复补上首尾帧。接缝先测原生 RGB 再测 660 帧同源 YUV 字节。审阅版仅用于手机播放。FFmpeg/x264 版本不同，封装 SHA 可以不同。

## 物理要点

- 固定审批机位、原小店、红车、天空色与接触阴影。没有猫、躲雨人或截取自旧片的区域；柜前能看到的形体是原货架、凳及 21 厘米真几何壶。壶盖蒸汽为深度遮挡的暖光半透明散射体积，不是白线。
- 一次画外双灯真实移动进深巷、转向道路再扫红车。每个 30fps 原生时刻重新获取两个发射体的三维位置和真实光束，再用亚像素命中点测试材质、法线、距离、雾及 BVH 投影；没有用相邻时刻的场叠加。对地面材质单独限能，保留车漆/墙面照度，把扫光压到暖琥珀并让红水反光仍可读。实际逐相灯位、遮挡射线计数保存到 summer_headlight_actual_phases.json。
- 网吧反光对着实际灯牌的发光区域做湿路微面元半向量计算。路面凹湿与颗粒使用世界米制；局部落雨产生独立圆形阻尼波，只扰动在其传播半径内的沥青法线与高光，不产生重复长条。灯牌与砖墙真实光组、湿地镜面接收同一个帧增益，锁定 [192,197)、[204,209)、[216,220)、[229,234) 四段 22%/24%/21%/23.5%。
- 主街雨仍由远／中／近三深度层遮挡，左暖灯对雨滴的散射系数单独压低，减少高亮白点；檐滴缩短且窄化，略暖水光在相同三维坐标落到 15cm 人行道，与半环同位置。保留三色理发灯实际柱面旋转、蓝电视和一次独立荧光微闪。
