"""Depth-matched wet-asphalt material: virtual-aperture radiance, real ground normals, raindrop height slope.
This is a shading term on actual visible ROAD rays, not a screen mask, stripe or displaced plate.
"""
import numpy as np
from engine.mats import sstep
from engine.noise import fbm2
from engine.props import TAG_GROUND
from engine.world import MASK_NOSHADOW,srgb
from summer_motion import LIP,RainImpacts,unit
from shots import summer_world_gate15 as sc

# Physical dimensions transcribed from vneon('网吧') in the actual pinned street geometry.
NEON_X=10.185
WARM_SOURCE=np.asarray([3.20,2.25,1.15],np.float32)

def visibility(acc,p,n,to):
    if not len(p):
        return np.zeros(0,np.float32)
    start=(p+n*.008).astype(np.float32)
    d=np.asarray(to,np.float32)-start
    length=np.linalg.norm(d,axis=1)
    ray=d/np.maximum(length[:,None],1.e-6)
    return (~acc.anyhit(start,ray.astype(np.float32),np.maximum(length-.040,.01).astype(np.float32),mask=MASK_NOSHADOW)).astype(np.float32)


class WetRoad:
    def __init__(self,p,cam,acc):
        self.flat=(p['tag'+str(TAG_GROUND)]>.51)&(p['N'][...,1]>.72)
        self.p=p['P'][self.flat]
        self.n=unit(p['N'][self.flat])
        self.v=unit(cam.pos[None]-self.p).astype(np.float32)
        self.cov=p['tag'+str(TAG_GROUND)][self.flat].astype(np.float32)
        self.T=p['T'][self.flat].astype(np.float32)
        x,z=self.p[:,0],self.p[:,2]
        n0=fbm2(x*1.48+4.2,z*1.29-7.0,705,3)
        n1=fbm2(x*3.9+12.,z*4.3-8.6,976,3)
        n2=fbm2(x*8.3,z*8.9,48,2)
        # The outer drain has an irregular thin film. Its wetness and foam are world-space procedural
        # materials, dark and invisible as a separate outline when only moon/ambient falls on them.
        cx,cz=1.08,9.18
        u=(x-cx)*cam.f[0]+(z-cz)*cam.f[2]
        v=(x-cx)*cam.r[0]+(z-cz)*cam.r[2]
        meander=.24*np.sin(u*1.25)+.10*np.sin(u*3.40+1.1)
        lake=np.exp(-((u/3.62)**2+((v+meander)/1.17)**2))
        self.film=sstep(.22,.84,lake*(.56+.52*n0+.38*n1))
        # Wet aggregates form small irregular groups: separate coarse pockets and dark fine pinholes.
        grain=sstep(.30,.72,.23*n0+.47*n1+.30*n2)
        self.grain=(.115+.885*grain)*(.59+.41*sstep(.26,.68,n2))
        self.rough=(.101+.103*(1-self.film)+.063*(1-n0)).astype(np.float32)
        # Millimetre asphalt relief: coherent static local mean slope plus low-curvature macro crown.
        self.nx=((n1-.5)*.162+(n2-.5)*.079-.064*self.film).astype(np.float32)
        self.nz=((n0-.5)*.132+(n2-.5)*.088-.023*self.film).astype(np.float32)
        self.fres=(.033+.72*(1-np.clip(self.v[:,1],0,1))**5).astype(np.float32)
        # Actual characters on a vertical housing; sample 2 groups along y and each side along z.
        self.samples=[]
        ox=(self.n[:,0],self.n[:,2])
        for y,w0 in ((4.58,.13),(4.90,.11),(5.10,.14),(5.65,.19),(5.99,.23),(6.22,.20)):
            for zp,w1 in ((.30,.27),(.58,.46),(.85,.27)):
                q=np.array([NEON_X-.012,y,zp],np.float32)
                L=q[None]-self.p
                len2=np.sum(L*L,axis=1)
                L=L/np.sqrt(len2[:,None])
                half=unit(L+self.v)
                cone_face=np.clip(L[:,0],0,1)*np.clip(L[:,1],0,1)
                idx=np.flatnonzero((self.film>.0001)&(cone_face>.005))
                seen=np.zeros_like(len2);seen[idx]=visibility(acc,self.p[idx],self.n[idx],q)
                e=seen*cone_face*(w0*w1)*(92/(len2+3.0))*np.exp(-.009*np.sqrt(len2))
                self.samples.append((half[:,0]-ox[0],half[:,2]-ox[1],e.astype(np.float32)))
        self.neon_energy=np.sum([s[2] for s in self.samples],axis=0)
        lit=WARM_SOURCE[None]-self.p
        ldist=np.linalg.norm(lit,axis=1)
        lit=lit/np.maximum(ldist[:,None],1.e-6);h=unit(lit+self.v)
        mask=(x>-6)&(x<5.3)&(z>2.25)&(z<10)&(h[:,1]>.6)
        src_vis=np.zeros(len(x),np.float32)
        src_vis[mask]=visibility(acc,self.p[mask],self.n[mask],WARM_SOURCE)
        broad=np.exp(-((h[:,0]-self.nx)**2+(h[:,2]-self.nz)**2)/.105)
        self.amber=(.020*src_vis*broad*(15/(ldist*ldist+5.5))*(.61+.39*n1)*self.cov*self.T).astype(np.float32)
        self.nrgb=np.asarray(srgb('#ff3d34'),np.float32)
        self.argb=np.asarray(srgb('#ffc384'),np.float32)
        self.vcool=np.asarray(srgb('#8ba0ba'),np.float32)
        out=2*(self.v*self.n).sum(1,keepdims=True)*self.n-self.v
        # The wet chips catch the subdued actual cool sky: tonal continuity between lit raindrop pores.
        self.sky_sheen=sc.sky(out)*((.86+.22*n1+.31*self.film)*self.fres*self.cov*self.T)[:,None]
        rng=np.random.default_rng(22062)
        drops=[]
        for j in range(583):
            if j<400:
                a=rng.uniform(-5.1,6.2);b=rng.uniform(5.1,12.4)
            else:
                a=rng.uniform(-8.8,14.2);b=rng.uniform(2.22,15.0)
            drops.append((rng.uniform(0,11),a,b,rng.uniform(.29,.72),rng.uniform(.150,.47)))
        self.impacts=RainImpacts(x,z,drops)
        nearfloor=(p['N'][...,1]>.75)&(p['P'][...,1]<.20)&(p['P'][...,0]>1.4)&(p['P'][...,0]<7.0)
        gx=p['P'][nearfloor][:,0]; gz=p['P'][nearfloor][:,2]
        self.splash_mask=nearfloor
        self.gutter=RainImpacts(gx,gz,[(a,x+.064,z+.037,.68,.86*w) for a,x,z,w in LIP])

    def evaluate(self,t,gain,wet_strength=1.):
        sx,sz,c=self.impacts.slope(t)
        dx=self.nx+sx
        dz=self.nz+sz
        lobe=np.zeros_like(dx)
        # Direction of full 3D view/source half vector changes at each road sample; no repeated row.
        rr=self.rough*self.rough
        for hx,hz,energy in self.samples:
            d=(hx-dx)**2+(hz-dz)**2
            lobe+=energy*np.exp(-d/rr)
        rain_coverage=np.clip(1.-.94*c,.40,1.)
        body=.135*lobe+.0045*self.neon_energy
        reflected=(self.cov*self.T*self.film*self.grain*self.fres*body*rain_coverage*wet_strength*gain).astype(np.float32)
        # Water bead tips refract the environment, not a luminous ring of unvarying red.
        amber=self.amber*np.clip(1-.65*c, .61,1.10)
        cool=c*.039*self.cov*self.T*(.37+.63*(1-self.film))
        return reflected,amber.astype(np.float32),cool.astype(np.float32)

    def draw(self,lin,t,gain,wet_strength=1.,eave=True):
        r,a,c=self.evaluate(t,gain,wet_strength)
        lin[self.flat]+=r[:,None]*self.nrgb+a[:,None]*self.argb+c[:,None]*self.vcool+self.sky_sheen
        if eave:
            sx,sz,p=self.gutter.slope(t)
            gl=np.clip(p*.22+.033*sx+.019*sz, -.015,.085)
            lin[self.splash_mask]+=gl[:,None]*np.asarray(srgb('#f4b074'),np.float32)
