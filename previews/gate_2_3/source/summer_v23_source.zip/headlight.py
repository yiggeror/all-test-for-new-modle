"""Movable shadowed light transport through a locked scene. No image translates."""
import numpy as np
from time import perf_counter
from engine.render import surface, fog_T
from engine.props import TAG_GROUND
from engine.noise import fbm2
from engine.world import MASK_NOSHADOW,srgb
from summer_motion import moving_light, cone_amount, unit
from shots import summer_world_gate15 as sc

H,W=180,320
BEAM_COLOR=np.asarray(srgb('#f6ca8f'),np.float32)
# Max physically plausible incident response of the ground receiving these distant low beams.
ROAD_LAMP_CAP_LINEAR=.026
BEAM_CONE=(.748,.956)

def lamps(t):
    p,d,g=moving_light(t)
    side=np.asarray([d[2],0.,-d[0]],np.float32)
    return [(p+side*(.56*i),d,g*(1.03 if i<0 else .91)) for i in (-1,1)]

class Headlights:
    """True current-frame 3D light field: BSDF plus visibility tested at each moving emitter."""
    def __init__(self,world,cam,acc,samples=2):
        self.s=samples
        g=world.finalize()
        o,ray=cam.rays(samples,np.random.default_rng(665))
        td,ci=acc.closest(o,ray)
        ii=np.flatnonzero(ci>=0)
        p=o[ii]+ray[ii]*td[ii,None]
        pick=(p[:,0]>-7.2)&(p[:,0]<17.7)&(p[:,1]<3.30)&(p[:,1]>.005-0.028)&(p[:,2]>-11.5)&(p[:,2]<16.3)
        ii=ii[pick]; self.p=p[pick]
        self.ray=ray[ii]
        sf=surface(world,g,ci[ii],self.p,self.ray,td[ii])
        sc.HOOK(sf,acc,None)
        self.n=sf['N'].astype(np.float32)
        self.v=-self.ray
        self.alb=sf['alb']
        self.fog=fog_T(sc.FOG,o[ii],self.p,td[ii])
        street=sf['tag']==TAG_GROUND
        self.street=street
        qx,qz=self.p[:,0],self.p[:,2]
        speckle=fbm2(qx*5.4,qz*5.9,607,3)
        self.spec_w=np.where(street,.092+.150*speckle,.36).astype(np.float32)
        self.f0=np.where(street,.043+.023*speckle,np.clip(sf['refl'],.025,.19))
        self.power=np.where(street,19.+13*speckle,np.where(sf['refl']>.07,37.,14.)).astype(np.float32)
        ww=W*samples
        self.pidx=(ii//ww//samples*W+(ii%ww)//samples).astype(np.int32)
        self.depth_idx=ii
        self.acc=acc
        self.solved=[]

    def shade(self,t):
        p,n,v=self.p,self.n,self.v
        pos=(p+n*.008).astype(np.float32)
        key=round(t*30)%330
        sources=lamps(t)
        trace={'frame':key,'seconds':float(t),'emitters_evaluated':0,'cast_shadow_rays':0,'unblocked_rays':0,
               'emitter_phase':[{ 'xyz_m':pos.tolist(),'axis':di.tolist(),'energy':float(g)}
                                for pos,di,g in sources]}
        began=perf_counter()
        if not any(e[2]>=1.e-6 for e in sources):
            self.solved.append(dict(trace,wall_s=perf_counter()-began))
            return np.zeros((H,W,3),np.float32)
        result=np.zeros((len(p),3),np.float32)
        for lamp,di,g in sources:
            if g<1.e-6:
                continue
            trace['emitters_evaluated']+=1
            L=lamp-pos
            d2=np.einsum('ij,ij->i',L,L)
            distance=np.sqrt(d2)
            L=L/np.maximum(distance[:,None],1.e-5)
            cos=np.clip(np.einsum('ij,ij->i',n,L),0.,1.)
            cone=cone_amount(-L,di,*BEAM_CONE)
            cone=cone+.133*cone_amount(-L,di,.35,.83)*(1-cone)
            # A low-beam projector is horizontally broad and rolls off softly above the hood line.
            lobe=np.exp(-.57*((-L[:,1]-di[1])/.170)**2)
            reach=np.clip((26-distance)/8.5,0.,1.)
            flux=9.2*g*cone*lobe*reach/(d2+2.45)
            h=unit(L+v)
            nh=np.clip(np.einsum('ij,ij->i',n,h),0.,1.)
            vh=np.clip(np.einsum('ij,ij->i',v,h),0.,1.)
            vr=self.f0+(1-self.f0)*.55*(1-vh)**5
            spec=(nh**self.power)*vr*self.spec_w
            act=np.flatnonzero((flux>.00009)&(cos>.0004))
            if not len(act):
                continue
            trace['cast_shadow_rays']+=int(len(act))
            blocked=self.acc.anyhit(pos[act],L[act].astype(np.float32),np.maximum(distance[act]-.032,.02).astype(np.float32),
                                    mask=MASK_NOSHADOW)
            hits=act[~blocked]
            trace['unblocked_rays']+=int(len(hits))
            if len(hits):
                i=hits
                diffuse=self.alb[i]*(cos[i]*np.where(self.street[i],.68,.92))[:,None]
                color=(diffuse+spec[i,None])*BEAM_COLOR[None]
                result[i]+= (color*flux[i,None]*self.fog[i,None]).astype(np.float32)
        # A low exposure shoulder on the road object only, not a mask on the finished image.
        # Neutral gray wash disappears; the real walls and car retain unconstrained warm transport.
        road=result[self.street]
        road /= 1+road[:,0,None]/ROAD_LAMP_CAP_LINEAR
        result[self.street]=road
        trace['peak_street_linear_green']=float(road[:,1].max(initial=0))
        trace['peak_nonstreet_linear_green']=float(result[~self.street,1].max(initial=0))
        rgb=np.zeros((H*W,3),np.float32)
        for ch in range(3):
            rgb[:,ch]=np.bincount(self.pidx,weights=result[:,ch],minlength=H*W)
        self.solved.append(dict(trace,wall_s=perf_counter()-began))
        return rgb.reshape(H,W,3)/(self.s**2)

