# 春 · 老巷暮色落花 | Gate 2.3

以 [Round 12](https://github.com/yiggeror/all-test-for-new-modle/blob/16951626d5db44eacf6ac0f9b52caf80cafd2a5b/REVIEW_LOG.md) 固定镜头为准。整棵树与远景一次光追后固定，不改动枝、干或树冠，灯锥里仅有局部世界空间落瓣。凉暮气氛和旧暖灯并存；灯泡及建筑亮度不做呼吸。定向花阵全用原生离散 1–2 px、世界风向、真实遮挡与路灯入射照度。每 2 帧更新一次见到的花瓣；平时撒得稀，5–7s 附近阵风经过灯锥。

右院米白与灰蓝两件布使用真实3D网面。每5帧采样一次物理姿势，顶部挂点固定，分别与横线、布夹对齐；两个暗色铁柱稳定，疏开摆幅，不做软化插帧。影面取自相同世界坐标及光线遮挡。无动物、树冠运动、二维扭曲、透视重定向或广域天气噪点。

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
export RAINROJI_SOURCE_ROOT=/absolute/path/to/pinned/all-test-for-new-modle
export NUMBA_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1
python -m unittest discover -s .
python spring23.py --out work/raw --span 0:330
python pack.py --src work/raw --out work/review --peak 195,180,15
python verify_exact.py spring work/review/spring_native.npy work/review/spring_loop.mp4 work/review/spring_decoded_qa.json
python evidence.py work/review/spring_native.npy work/review
```

外部源只需 pinned checkout 里的 `shots/spring_g15.py` 和 `prototype/film`。正本保留原生影像（原生320×180、6倍最近邻），H.264 QP0；mobile 下文件只是兼容送审。分卷按 MANIFEST 可校验组装。
