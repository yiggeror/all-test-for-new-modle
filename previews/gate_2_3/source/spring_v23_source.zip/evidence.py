"""Heat map and 30 fps adjacent strips from native delivery RGB, no spatial filtering."""
import argparse,json
from pathlib import Path
from PIL import Image, ImageDraw
import numpy as np
def main():
 p=argparse.ArgumentParser();p.add_argument('native',type=Path);p.add_argument('out',type=Path);a=p.parse_args()
 v=np.load(a.native,allow_pickle=False);r=a.out;r.mkdir(exist_ok=True,parents=True)
 match=np.any(v!=np.roll(v,1,axis=0),axis=-1)
 count=match.sum(0); lvl=np.minimum(np.log1p(count)/np.log(1+max(1,count.max())),1)
 heat=np.stack((np.minimum(1,2*lvl),np.maximum(0,2*lvl-1)*.74,.33*lvl),-1)
 Image.fromarray((heat*255).astype(np.uint8)).resize((1280,720),Image.Resampling.NEAREST).save(r/'spring_motion_heatmap.png')
 for name,box,start in [('cloth',(244,143,299,173),191),('petals',(107,78,166,121),175),('fixed_tree',(173,7,278,48),175)]:
  x0,y0,x1,y1=box; w,h=x1-x0,y1-y0; k=5
  im=Image.new('RGB',(w*k*5,(h*k+22)*2),'#222333'); dr=ImageDraw.Draw(im)
  for n in range(10):
   f=start+n;x=(n%5)*w*k;y=(n//5)*(h*k+22)
   im.paste(Image.fromarray(v[f,y0:y1,x0:x1]).resize((w*k,h*k),Image.Resampling.NEAREST),(x,y))
   dr.text((x+7,y+h*k+4),f'F{f:03d}',fill='#eeeeee')
  im.save(r/f'spring_adjacent_{name}.jpg',quality=95,subsampling=0)
 fixed=match[:,7:48,173:278]; trunk=match[:,115:153,208:220]
 cloth=match[:,142:172,244:299]
 event=np.flatnonzero(cloth.reshape(330,-1).any(1))
 doc={'frames':330,'fixed_crown_roi':[173,7,278,48],'fixed_crown_changed_frame_pixel_count':int(fixed.sum()),
      'fixed_trunk_roi':[208,115,220,153],'fixed_trunk_changed_frame_pixel_count':int(trunk.sum()),'cloth_roi':[244,142,299,172],'cloth_changed_at':event.tolist(),'cloth_changes_off_pose_boundaries':event[(event%5)!=0].tolist(),
      'loop_global_rgb_MAE':float(np.abs(v[0].astype(np.int16)-v[-1]).mean())}
 print(json.dumps(doc))
 assert fixed.sum()==0 and trunk.sum()==0,doc
 assert not (event%5).any(),doc
 (r/'spring_motion_evidence.json').write_text(json.dumps(doc,indent=2)+'\n')
if __name__=='__main__':main()
