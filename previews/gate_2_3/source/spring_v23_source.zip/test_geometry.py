import unittest
import numpy as np
from spring23 import cloth_points, shower_gain
class Geometry(unittest.TestCase):
 def test_five_frame_hold(self):
  for t in range(0,330,5):
   for j in (1,4):
    np.testing.assert_array_equal(cloth_points(0,t),cloth_points(0,t+j))
 def test_anchor_wrap_and_different_pose(self):
  a,b,c=(cloth_points(0,t) for t in (0,195,330))
  np.testing.assert_array_equal(a[0],b[0])
  np.testing.assert_array_equal(a,c)
  self.assertGreater(np.linalg.norm(a[-1]-b[-1],axis=1).max(),.12)
 def test_shower_has_calm_and_peak(self):
  self.assertEqual(shower_gain(15),0)
  self.assertGreater(shower_gain(180),.88)
