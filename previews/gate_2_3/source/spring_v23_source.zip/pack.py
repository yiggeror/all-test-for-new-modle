"""Quantize reviewed RGB renders once, export exact two cycles and peak full-raster stills."""
import argparse, hashlib, json, os, re, subprocess
from pathlib import Path
from PIL import Image
import numpy as np
import spring23 as s
from engine import pix

H,W,S=180,320,6

def encode(frames, path, strict, kbps=2840, work=Path('.')):
    dest=path.with_suffix('.tmp.mp4')
    filt=f'scale={W*S}:{H*S}:flags=neighbor:out_color_matrix=bt709,format=yuv420p'
    base=['ffmpeg','-v','error','-nostdin','-y','-filter_threads','1','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate','30','-i','-','-an','-vf',filt,'-c:v','libx264','-threads','3']
    mov=['-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-movflags','+faststart']
    if strict:
        passes=[base+['-preset','veryfast','-qp','0']+mov+[str(dest)]]
    else:
        common=base+['-preset','slow','-profile:v','high','-b:v',f'{kbps}k','-passlogfile',str(work/'s22_pass')]
        passes=[common+['-pass','1','-f','null',os.devnull], common+['-pass','2']+mov+[str(dest)]]
    for args in passes:
        with subprocess.Popen(args,stdin=subprocess.PIPE) as p:
            buf=memoryview(np.ascontiguousarray(frames)).cast('B')
            p.stdin.write(buf);p.stdin.write(buf);p.stdin.close()
            if p.wait()!=0: raise RuntimeError('ffmpeg encode')
    dest.replace(path)

def assemble(src):
    files=sorted(src.glob('spring_raw_[0-9][0-9][0-9]_[0-9][0-9][0-9].npy'))
    frames=np.empty((330,H,W,3),np.uint8);covered=np.zeros(330,bool)
    for path in files:
        a,b=map(int,re.search(r'(\d\d\d)_(\d\d\d)\.npy$',path.name).groups())
        v=np.load(path,mmap_mode='r',allow_pickle=False)
        assert not covered[a:b].any() and v.shape==(b-a,H,W,3) and v.dtype==np.uint8
        frames[a:b]=v;covered[a:b]=True
    assert covered.all(),np.where(~covered)[0]
    return frames

def rgb_key(rgb):
    rgb=rgb.astype(np.uint32)
    return (rgb[...,0]<<16)|(rgb[...,1]<<8)|rgb[...,2]
def quantize_clip(raw,pal,thr,strength):
    # Identity with original pix.quantize for uint8 source, amortizing nearest
    # palette and projected dither weights across repeated 24-bit colors.
    found=np.zeros(1<<24,bool)
    for frame in raw: found[rgb_key(frame)]=True
    keys=np.flatnonzero(found)
    l1=np.zeros(1<<24,np.uint8);l2=np.zeros(1<<24,np.uint8);cut=np.zeros(1<<24,np.float32)
    pl=pal['lab']*pix.LABW
    for aa in range(0,len(keys),32768):
        kk=keys[aa:aa+32768]
        rgb=(np.column_stack((kk>>16,kk>>8&255,kk&255)).astype(np.float32))/255
        lab=pix.oklab(rgb)*pix.LABW
        d=((lab[:,None]-pl[None])**2).sum(-1)
        i1=d.argmin(1);d[np.arange(len(kk)),i1]=1e9;i2=d.argmin(1)
        c1=pl[i1]; v=pl[i2]-c1
        t=((lab-c1)*v).sum(-1)/np.maximum((v*v).sum(-1),1e-9)
        l1[kk]=i1;l2[kk]=i2;cut[kk]=np.clip(t,0,1)*strength
    out=np.empty_like(raw)
    for j,frame in enumerate(raw):
        k=rgb_key(frame);out[j]=pal['rgb'][np.where(cut[k]>thr,l2[k],l1[k])]
    return out

def pack(src,dst,peak,skip):
    dst.mkdir(parents=True,exist_ok=True)
    raw=assemble(src)
    train=[raw[k].astype(np.float32)/255 for k in [0,29,60,90,120,153,171,185,200,230,251,276,311,329]]
    extra=[*s.shot.PAL['extra'],(.60,.48,.49),(.49,.50,.56),(.39,.42,.51)]
    pal=pix.fit_palette(train,k=60-len(extra),chroma_w=5.,extra=extra,iters=20,nsamp=50000,seed=31)
    thr=pix.threshold_map(H,W,'mix',seed=177)
    native=quantize_clip(raw,pal,thr,.22)
    np.save(dst/'spring_native.npy',native,allow_pickle=False)
    peak=tuple(map(int,peak.split(',')))
    for f,name in zip(peak,['washing_billow','blossom_shower','calm_no_cat']):
        Image.fromarray(native[f]).resize((1920,1080),Image.Resampling.NEAREST).save(dst/f'spring_peak_{f:03d}_{name}.png',optimize=True)
    data={'title':'春 · 老巷暮色落花 / Gate 2.3','native':[320,180],'fps':30,'cycle_frames':330,'cycle_seconds':11,'video_native_scale':6,'cycles':2,'peak_frames':dict(zip(['washing_billow','blossom_shower','calm_no_cat'],peak)), 'roi':{'washing':[247,145,300,174],'canopy':[155,10,270,138],'lamp_shower':[103,77,171,132]},'palette':pal['rgb'].tolist(), 'camera':{'pos':s.shot.camera().pos.tolist(),'forward':s.shot.camera().f.tolist()}, 'source_commit':'16951626d5db44eacf6ac0f9b52caf80cafd2a5b','github_source':['shots/spring_g15.py','prototype/film/scenes/spring.py'], 'parameters':{'camera_motion':False,'cat':False,'sparrow':False,'temporal_interpolation':False,'fixed_full_crown':True,'wet_cloth_hold_frames':5,'petal_fps':15,'raw_digest':hashlib.sha256(raw).hexdigest(),'native_digest':hashlib.sha256(native).hexdigest()}}
    (dst/'spring_provenance.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    if not skip:
        encode(native,dst/'spring_loop.mp4',True)
        mobile=dst/'mobile';mobile.mkdir(exist_ok=True)
        encode(native,mobile/'spring_loop.mp4',False,work=mobile)
        if (mobile/'spring_loop.mp4').stat().st_size>8450000:
            encode(native,mobile/'spring_loop.mp4',False,kbps=2600,work=mobile)
        assert (mobile/'spring_loop.mp4').stat().st_size<=8450000
        f=dst/'spring_loop.mp4'
        lossless=dst/'lossless_parts'
        partsdir=lossless/'spring';partsdir.mkdir(exist_ok=True,parents=True)
        whole=hashlib.sha256();parts=[]
        with f.open('rb') as inp:
            idx=0
            while b:=inp.read(8000000):
                part=partsdir/f'part-{idx:02d}.bin'
                part.write_bytes(b);whole.update(b)
                parts.append({'path':f'lossless_parts/spring/{part.name}','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
                idx+=1
        bundle={'spring':{'output':f.name,'bytes':f.stat().st_size,'sha256':whole.hexdigest(),'parts':parts}}
        (lossless/'MANIFEST.json').write_text(json.dumps(bundle,indent=2)+'\n')
        with f.open('rb') as inp:
            for rec in parts:
                b=(dst/rec['path']).read_bytes()
                assert inp.read(len(b))==b
            assert not inp.read(1)
    return data

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--src',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--peak',default='201,185,105');ap.add_argument('--skip-encode',action='store_true')
    a=ap.parse_args();print(json.dumps(pack(a.src,a.out,a.peak,a.skip_encode),ensure_ascii=False))
