import unittest
import numpy as np
import spring22 as s
class Geometry(unittest.TestCase):
 def test_clothes_anchors_continuous_fixed_and_billows(self):
  a,b,c = (s.cloth_points(0,t) for t in (.15,.58,1.15))
  np.testing.assert_allclose(a[0],b[0],atol=1e-10)
  np.testing.assert_allclose(a,c,atol=1e-10)
  self.assertGreater(np.max(np.abs(a[-1]-b[-1])),.16)
  self.assertLess(np.linalg.norm(a[-1]-a[0],axis=1).max(),1.65)
 def test_canopy_not_a_translation(self):
  p=np.array([[5.,.5,7.5],[5.,6.,7.5],[7.5,8.,7.]])
  a=s.wind(p,.30); b=s.wind(p,.63)
  np.testing.assert_allclose(a[0],p[0]); self.assertGreater(np.linalg.norm(a[1]-b[1]),.15)
  self.assertFalse(np.allclose(a[1]-p[1], a[2]-p[2]))
  np.testing.assert_allclose(a,s.wind(p,1.3),atol=1e-9)
 def test_shower_temporal_envelope(self):
  self.assertGreater(s.shower_gain(.56),.9)
  self.assertLess(s.shower_gain(.05),.04)
  self.assertAlmostEqual(s.shower_gain(.65),s.shower_gain(1.65))
