"""Spring Gate 2.2. Wind deforms frozen three-dimensional blossom geometry, not image pixels."""
import numpy as np
from pathlib import Path
import sys, os
here=Path(__file__).resolve()
choices=[Path(os.environ['RAINROJI_SOURCE_ROOT'])] if 'RAINROJI_SOURCE_ROOT' in os.environ else [*here.parents, *(p/'alltest_gate1_prod' for p in here.parents)]
ROOT=next((p for p in choices if (p/'shots/spring_g15.py').is_file() and (p/'prototype/film/engine/rt.py').is_file()),None)
if ROOT is None: raise SystemExit("Set RAINROJI_SOURCE_ROOT to the pinned all-test-for-new-modle checkout.")
for p in (ROOT/'shots', ROOT/'prototype/film'):
 sys.path.insert(0,str(p))
from engine.world import World, roty, _n, srgb, MASK_HIDDEN, MASK_NOSHADOW
from engine import render as ray, fx, pix, mats
from engine.rt import Accel
from scenes import spring as base
import spring_g15 as shot

RACK = np.array([10.,0.,13.]); RMAT = roty(.4)
CLOTH_TAG=81
TAU=2*np.pi
PHASE_FRAMES=330
def smooth(x):
 x=np.clip(x,0,1); return x*x*(3-2*x)
def shower_gain(p):
 p=np.asarray(p)%1
 return smooth((p-.41)/.105)*smooth((.78-p)/.15)
def wind(P,p):
 P=np.asarray(P); x,y,z=P.T; p=p%1
 h=smooth((y-.65)/8.4)
 w=TAU*(p-(x-5)*.040-(z-7.5)*.022)
 a=.25+.23*shower_gain(p)
 delta=np.column_stack((h*(a*np.sin(2*w+.45)+.21*np.sin(w-.15)),h*.074*np.sin(3*w+x*.26),h*(.16*np.sin(2*w-1.42)+.09*np.sin(w+z*.17))))
 return P+delta
def cloth_points(which,p):
 p=p%1
 u,v=np.meshgrid(np.linspace(0.,1.,25),np.linspace(0.,1.,19))
 # Two cloths from real rack coordinates; fixed clipped top leaves a short visual air gap.
 if which==0:
  start,width,length,z0=-2.18,1.29,1.18,-.55
 else:
  start,width,length,z0=-.67,.83,.72,0.
 x=start+width*u
 sag=.1*np.maximum(0.,1.-(2*x/5)**2)
 h=2-sag-.013
 w=TAU*(2*p - .53*u-.13*v) + which*.82
 level=.55+.45*shower_gain((p+.03)%1)
 billow=level*(.30+.27*np.sin(w)+.12*np.sin(w*1.5+TAU*p)) * v**1.48
 shift=v**1.53*(.21*np.sin(TAU*(p+.12))+.075*np.sin(w-.4))
 fold=.075*np.sin(TAU*(2.55*u-.22*v))+ .030*np.sin(TAU*(5.5*u+.15*v))
 hem=.036*np.sin(TAU*(2.3*u+p)) * v**3
 y=h-length*v+.23*billow**2+hem
 z=z0+fold*v**.8-billow
 return np.stack((x+shift,y,z),axis=-1)@RMAT.T+RACK

@mats.mat('gate22_washed')
def cloth_mat(s):
 # No emission; dye and seam both filter incident light.
 return s.col * (.925+.075*np.cos(s.seed*8.3))[:,None]

def add_cloth(w,p):
 # Keep both dye-dark, but resolve the load-bearing 3-D wire and attached clips
 # at native raster sampling, rather than air-gapping pale fabric from its rack.
 with w.at(RACK,yaw=.4):
  for z0 in (-.55,0.):
   base.pr.wire(w,(-2.5,2.,z0),(2.5,2.,z0),sag=.1,r=.018,n=24,col='#64524e')
 for i in range(2):
  q=cloth_points(i,p); r,c=np.indices((q.shape[0]-1,q.shape[1]-1))
  palette=[['#cab6ac','#b4abac','#ab8784'],['#98a6a4','#84949a','#a8aca6']][i]
  colors=np.broadcast_to(srgb(palette[0]),(*r.shape,3)).copy()
  colors[(r==q.shape[0]-2)|(c==0)|(c==q.shape[1]-2)]=srgb(palette[1])
  if i==0: colors[(r>=q.shape[0]-6)&(r<q.shape[0]-4)]=srgb(palette[2])
  else: colors[(c>=4)&(c<6)]=srgb(palette[2])
  w.quads(q[:-1,:-1].reshape(-1,3),q[:-1,1:].reshape(-1,3),q[1:,1:].reshape(-1,3),q[1:,:-1].reshape(-1,3),local=False,mat='gate22_washed',col=colors.reshape(-1,3),tag=CLOTH_TAG,seed=(r*.13+c*.11).ravel())
  for k in (3,21):
   x,y,z=q[0,k]
   w.box((x,y+.012,z),(.066,.11,.048),mat='plain',col='#aa8266')

class SplitAccel:
 def __init__(self,static,dynamic): self.static,self.dynamic=static,dynamic
 def anyhit(self,o,d,tmax,mask=0):
  return self.static.anyhit(o,d,tmax,mask)|self.dynamic.anyhit(o,d,tmax,mask)

def make_worlds():
 # Intercept controlled world-space source batches. Original seeds, geometry, framing, lights remain.
 source=base.blossom_tree; mark=[]
 def capture(w,x,z,h,rng,near=False):
  ta,fa=len(w.tris),w.nf
  source(w,x,z,h,rng,near)
  if near: mark.append((ta,len(w.tris),fa,w.nf))
 base.blossom_tree=capture
 try: w=base.build()
 finally: base.blossom_tree=source
 ta,tb,fa,fb=mark[0]
 tree=w.tris[ta:tb]
 # Moving source separated from static bowl, retaining face attributes for materials.
 g={}
 F={k:np.concatenate(v)[fa:fb].copy() for k,v in w.F.items()}
 for i,k in enumerate(('v0','v1','v2','tf','tm')):
  g[k]=np.concatenate([t[i] for t in tree]).astype(np.float32 if i<3 else np.int32 if i==3 else np.uint8)
 g['tf']-=fa; g['F']=F
 w.tris = w.tris[:ta]+w.tris[tb:]
 for L in w.lights:
  if L['grp']==base.G_LAMP and 'axis' in L:
   L['vol']*=.54; L['color']*=np.array([.94,.875,.78],np.float32); L['cone']=(-.16,.72)
 with w.at((-1.78,0,13.30),yaw=.21):
  t=-.095; M=np.array([[1,0,0],[0,np.cos(t),-np.sin(t)],[0,np.sin(t),np.cos(t)]])
  with w.at((0,0,0),M=M): shot._roadster(w)
 return w,g

def combine_geom(tree,w,p):
 c=w.finalize(); ft=tree['F']
 g={k:np.concatenate((wind(tree[k],p).astype(np.float32),c[k])) for k in ('v0','v1','v2')}
 g['tf']=np.concatenate((tree['tf'],c['tf']+len(ft['n'])))
 g['tm']=np.concatenate((tree['tm'],c['tm']))
 nf=len(ft['n'])
 # Re-evaluate transformed face normals in world space from finite offset.
 f={k:np.concatenate((ft[k],c['F'][k])) for k in ft}
 org=ft['org']; t=wind(org,p)
 u=_n(wind(org+ft['U']*.08,p)-t)
 v=_n(wind(org+ft['V']*.08,p)-t)
 f['org'][:nf]=t;f['U'][:nf]=u;f['V'][:nf]=v;f['n'][:nf]=_n(np.cross(u,v))
 g['F']=f
 return g

def make_petals(cam,plate):
 rng=np.random.default_rng(252)
 n=255
 # Release from the near tree's left lower curtain. Positions travel obliquely through the streetlamp.
 p=np.stack((rng.uniform(-.7,5.6,n),rng.uniform(4.75,7.2,n),rng.uniform(7.8,13.3,n)),axis=1)
 v=np.stack((rng.uniform(-1.27,-.63,n),rng.uniform(-1.02,-.53,n),rng.uniform(.16,.45,n)),axis=1)
 q=fx.custom_particles(cam,plate,p,v,11,2,.049,seed=371,phase=rng.uniform(-.36,.18,n)%1)
 q.tint=np.array([[1,.56,.66],[1,.70,.69],[1,.73,.79]],np.float32)[rng.integers(0,3,n)]
 q.sw_a=rng.uniform(.09,.48,n);q.sw_f=rng.integers(1,4,n);q.sw_p=rng.uniform(0,TAU,n)
 return q

def main():
 import argparse
 from PIL import Image
 import time
 ap=argparse.ArgumentParser()
 ap.add_argument('--out',type=Path,required=True)
 ap.add_argument('--frames',default='0,90,168,204')
 ap.add_argument('--samples',type=int,default=2)
 ap.add_argument('--span',type=str,help='start:end (native frame indices), for resumable lossless image data')
 ap.add_argument('--base-samples',type=int,default=3)
 args=ap.parse_args()
 args.out.mkdir(exist_ok=True,parents=True)
 print('building frozen Gate 1.5 scene',flush=True)
 from scipy.ndimage import gaussian_filter
 cam=shot.camera(); H,W=180,320; S=args.samples; N=H*W*S*S
 fx.SC=W/480
 w,tree=make_worlds(); print('dynamic source triangles:',len(tree['tf']),flush=True); gs=w.finalize(); st=Accel(gs['v0'],gs['v1'],gs['v2'],gs['tm'])
 wp=Path(args.out).parent/f'static_plate_q{args.base_samples}_v0.npz'
 if wp.is_file():
  with np.load(wp) as f: plate={k:f[k] for k in f.files}
 else:
  plate,_=ray.render(w,cam,shot.sky,S=args.base_samples,acc=st,**dict(shot.RENDER,hook=base.petal_hook))
  fx.denoise(plate,**shot.DENOISE)
  np.savez_compressed(wp,**plate)
 plate['lights']=w.lights;plate['chim']=w.chim
 ctx=shot.setup(plate,cam)
 # setup constructs prototype particle paths; production uses 11 seconds per cycle.
 for pp in [*ctx['pet'],ctx['shed']]:
  pp.life=11/pp.loops
 for ss in ctx['smoke']: ss.T=11
 q=make_petals(cam,plate)
 bg=plate['layers'].copy(); sky=plate['sky'].copy(); dep=plate['depth'].copy()
 o,d=cam.rays(S,np.random.default_rng(682)); stdepth,stid=st.closest(o,d,mask=MASK_HIDDEN)
 # Only ray-test pixels potentially hit by moving 3D geometry. Expand by two native pixels.
 ta=np.vstack([tree[k] for k in ('v0','v1','v2')])
 tbox=np.array(np.meshgrid(*zip(ta.min(0)-.6,ta.max(0)+.6))).reshape(3,-1).T
 cbox=np.vstack([cloth_points(j,t).reshape(-1,3) for j in range(2) for t in (0,.15,.30,.50,.65,.8)])
 X,Y,_,_=cam.project(np.r_[tbox,cbox]); xmin,ymin=np.maximum(0,np.floor([X.min()-3,Y.min()-3]).astype(int));xmax,ymax=np.minimum([W,H],np.ceil([X.max()+3,Y.max()+3]).astype(int))
 safe=np.zeros((H*S,W*S),bool);safe[ymin*S:ymax*S,xmin*S:xmax*S]=1
 ii=np.flatnonzero(safe.ravel()); oi,di,stdi=o[ii],d[ii],stdepth[ii]
 foliage0=shot.sky(np.array([[.21,.88,-.34],[-.48,.87,.30],[.30,.90,.33]])).mean(0)*.32
 amb=np.array([.105,.069,.084],np.float32)+foliage0
 grade=shot.GRADE; vig=fx.vignette(H,W,.15)
 pre=[]
 fs=list(range(330)) if args.frames=='all' else [int(x) for x in args.frames.split(',')]
 if args.span:
  aa,bb=map(int,args.span.split(':')); assert 0<=aa<bb<=330
  fs=list(range(aa,bb))
  mm=np.lib.format.open_memmap(args.out/f'spring_raw_{aa:03d}_{bb:03d}.part.npy','w+',dtype='uint8',shape=(bb-aa,H,W,3))
  metrics=[]
 centers=[dict(L,radius=0.,soft=0.) for L in w.lights]
 native_sky=fx.native_sky(base,cam,H,W)
 if args.span: print(f'processing ordered frames [{aa},{bb})',flush=True)
 for ix,j in enumerate(fs):
  tm=time.monotonic(); ph=j%330/330
  cloth=World(seed=6001);cloth.mats=w.mats.copy();cloth.pixang=2*cam.th/W
  add_cloth(cloth,ph)
  g=combine_geom(tree,cloth,ph)
  dy=Accel(g['v0'],g['v1'],g['v2'],g['tm'])
  dt,tr=dy.closest(oi,di,tmax=stdi,mask=MASK_HIDDEN)
  sel=np.flatnonzero(tr>=0); jj=ii[sel]; ts=dt[sel]; P=oi[sel]+di[sel]*ts[:,None]
  sf=ray.surface(cloth,g,tr[sel],P,di[sel],ts)
  cc=sf['tag']==CLOTH_TAG
  facing=np.clip(sf['N'][:,1],-.5,1.)
  E=ray.direct(centers,SplitAccel(st,dy),P,sf['N'],np.random.default_rng(93),base.K)
  height=P[:,1]
  side=np.clip((7.4-P[:,0])/4.8,.15,1.)
  E[0]+=amb[None]*(.55+.32*facing[:,None]+.26*side[:,None]) 
  E[0][cc]+=np.array([.17,.108,.085])[None]
  L=E*sf['alb'][None]
  for kg in range(base.K):
   m=sf['grp']==kg;L[kg,m]+=sf['emis'][m]*np.where(sf['tag'][m,None]==base.pr.TAG_FOLIAGE,.54+side[m,None]*.10,1.)
  T=ray.fog_T(shot.RENDER['fog'],oi[sel],P,ts)
  L*=T[None,:,None];L[0]+=shot.RENDER['fog']['color'](di[sel])*(1-T[:,None])
  # Recombine using true per-subpixel visible coverage from z-competing static and dynamic rays.
  def aggregate(a):
   a=np.ascontiguousarray(a)
   shape=a.shape[1:]
   return a.reshape(H,S,W,S,*shape).mean((1,3))
  m0=np.zeros(N,np.float32);m0[jj]=1
  coverage=aggregate(m0)
  frame_layers=bg*(1-coverage[None,:,:,None])
  for k in range(base.K):
   temp=np.zeros((N,3),np.float32);temp[jj]=L[k];frame_layers[k]+=aggregate(temp)
  d0=stdepth.copy();d0[stid<0]=1e9;d0[jj]=ts
  ds=d0.reshape(H,S,W,S).transpose(0,2,1,3).reshape(H,W,S*S)
  # Replace particles' depth by the same moving geometry samples every frame.
  plate['depth']=ds
  plate['layers']=frame_layers
  ctx['sky']=native_sky*sky[...,None]*(1-coverage[...,None])
  # Folded cloth shadows in its own warm courtyard-lamp contribution to the yard below.
  gx=plate['P'][...,0];gy=plate['P'][...,1];gz=plate['P'][...,2]
  ground=(gx>7.1)&(gx<12.7)&(gy>-.08)&(gy<.18)&(gz>9.1)&(gz<18.9)&(coverage<.5)
  ids=np.where(ground)
  if len(ids[0]):
   pa=plate['P'][ids].astype(np.float32); pa[:,1]+=.007
   source=np.array([8.6,2.7,6.2])
   dr=source[None]-pa;dd=np.linalg.norm(dr,axis=1)
   a=dy.anyhit(pa,dr/dd[:,None],dd-.03,mask=MASK_NOSHADOW)
   damp=np.zeros((H,W),np.float32);damp[ids]=a*.29
   damp=gaussian_filter(damp,.54)
   frame_layers[0]*=1-damp[...,None]
  g0=base.gains(ph);lin=ctx['sky']+frame_layers[0]+g0[base.G_LAMP]*frame_layers[base.G_LAMP]
  tv=.45+.9*fx.stepnoise(ph,36,11)*(.6+.4*fx.stepnoise(ph,9,12))
  tint=np.array([.8,.95,1.25])*(1-fx.stepnoise(ph,13,14)*.5)+np.array([1.2,1.,.7])*fx.stepnoise(ph,13,14)*.5
  lin+=frame_layers[base.G_TV]*(tv*tint)[None,None]
  # Native-depth particles with local lamp cone and atmospheric falloff; no warped canopy imagery.
  for smoke in ctx['smoke']: smoke.draw(lin,ph,ctx['amb']*.27)
  ls=[(l['pos'],l['color']*(g0[base.G_LAMP] if l['grp']==base.G_LAMP else 1.)*.45,.8,l['axis'],l['cone']) for l in ctx['lamps']]
  for p,a in zip([*ctx['pet'],ctx['shed']],[.20,.35,.29,.50]):
   p.draw(lin,ph,ctx['amb'],ls,alpha=a)
  q.draw(lin,ph,ctx['amb']*.92,ls,alpha=float(shower_gain(ph))*.92)
  for (x,y),l in zip(zip(*ctx['lamp_px'][:2]),ctx['lamps']):
   fx.glow(lin,x,y,l['color']*.010*(g0[base.G_LAMP] if l['grp']==base.G_LAMP else 1.),r0=2.4,power=1.3)
  lin=fx.bloom(lin,thresh=.5,sig=(1.2,4.5),gain=(.28,.2))
  a=pix.tonemap(lin*vig,**grade)
  if args.span:
   mm[ix]=np.round(a*255).clip(0,255).astype(np.uint8)
   metrics.append([j,int(len(jj)),int(cc.sum()),round(float(shower_gain(ph)),4)])
   if ix%12==0:
    mm.flush(); print(f'{j}/{bb} ({time.monotonic()-tm:.2f}s/frame)',flush=True)
  elif args.frames=='all':
   pre.append(np.round(a*255).clip(0,255).astype(np.uint8))
   if ix%15==0: print(f'{j}/330 ({time.monotonic()-tm:.2f}s/frame)',flush=True)
  else:
   Image.fromarray(np.round(a*255).clip(0,255).astype(np.uint8)).resize((1920,1080),resample=Image.Resampling.NEAREST).save(args.out/f'spring_{j:03d}.png')
   print(f'{j} rays {len(jj)} cloth {cc.sum()} time {time.monotonic()-tm:.2f}s',flush=True)
 if args.span:
  import json
  mm.flush(); del mm
  suffix=f'spring_raw_{aa:03d}_{bb:03d}'
  (args.out/f'{suffix}.part.npy').replace(args.out/f'{suffix}.npy')
  (args.out/f'{suffix}.json').write_text(json.dumps(metrics)+'\n')
 if pre: np.save(args.out/'spring_rgb24.npy',np.array(pre,np.uint8),allow_pickle=False)
if __name__=='__main__': main()
