# 春 · 老巷暮色落花 | Gate 2.2

## 输入与动作

源来自 `yiggeror/all-test-for-new-modle@4c06e29619b2efa6ed8c4f9b75888417d91a4bb7` 的 `shots/spring_g15.py` 与 `prototype/film`。保持 Gate 1.5 镜头：320×180、43°、原机位高度/视向。省去任何动物几何，使用画面内两项主动态：

- **晾布**：源场景固定晾衣架 (10, 0, 13)m。实际结构高 2m；两片布由连续三角形网面组成，宽度/垂长分别 1.29/1.18m 与 0.83/0.72m，顶部固定在绳及暖暗布夹。细绳、布夹、布、庭院/门楼共用深度，布面褶皱改变受光；灯位相同，投到庭院地面的弱影来自对灯遮挡射线。布不发光；小院真暖灯配合暮紫漫环境光。
- **花树**：取原树的 47,868 个三角面，随高度和枝团相位发生空间风变形，根保持锚定；更新 BVH、表面方向、受光及阴影后，与原场景几何分样本互遮，未使用屏幕抖动或整张画面重映射。灯下的 255 条风阵轨迹与常态花瓣通过真实深度与光锥分组，冷处片瓣黯淡。峰值花阵约 F170–207（5.67–6.90s），为一阵，不铺整场。

两项为同一阵风调制但有不同相位，330 个源相位每帧各算几何，不做光流插值。固定场景采用预先光线追踪及原色调；新几何每帧另行与固定世界深度比较。最终 60 色共享调色板。静帧文件均为原生帧的整倍放大，无标注烧入。

## 从锁定源重建

在 pinned repo 根目录或其外解包本源 ZIP，然后设 `RAINROJI_SOURCE_ROOT` 指到该 repo 根目录。渲染器允许读取该固定树，不需要已编码视频或仍图。

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
export RAINROJI_SOURCE_ROOT=/absolute/path/to/all-test-for-new-modle
# 独占或与其他季并行时，可按机器线程预算调整。
export NUMBA_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1
python -m unittest discover -s . -p 'test_*.py'
python spring22.py --out work/raw --span 0:330 --samples 3 --base-samples 3
python pack.py --src work/raw --out work/review --peak 203,186,105
python verify_exact.py spring work/review/spring_native.npy work/review/spring_loop.mp4 work/review/spring_decoded_qa.json
```

可把 `0:330` 替换成不重叠、合计覆盖 0..329 的若干 `--span`（同缓存、同参数）。先等一个分段启动并写完静场缓存，再启动其他并行分段，避免多余重复计算。每次渲染在单独工作目录。最终严格正本用 BT.709 限幅和 H.264 QP0；兼容审片版在 mobile/，不可替代正本。分卷是正本字节切分，8,000,000 B/最大，按 MANIFEST 串接复查。峰值 F203 晾布、F186 灯锥花阵、F105 原穿帮位置特查。具体媒体与源指纹另见 provenance 与 decoded_qa。
