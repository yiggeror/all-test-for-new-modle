"""Whole-amplitude and loop-neighborhood proof from actual rendered native frames."""
from pathlib import Path
import argparse,json
from PIL import Image,ImageDraw
import numpy as np

ROIS={'washing':[247,145,300,174], 'canopy':[155,10,270,138], 'lamp_shower':[103,77,171,132],
      'static_roofline':[19,16,93,36]}
def measure(v):
    fv=v.astype(np.int16)
    y= v.astype(np.float32) @ np.float32([.2126,.7152,.0722])
    out={}
    for k,(x0,y0,x1,y1) in ROIS.items():
        z=fv[:,y0:y1,x0:x1]; l=y[:,y0:y1,x0:x1]
        lag=np.abs(np.roll(z,15,axis=0)-z); avg=lag.mean((1,2,3))
        st=np.abs(np.roll(z,1,axis=0)-z).mean((1,2,3))
        out[k]={'roi_in_320x180':[x0,y0,x1,y1], 'halfsecond_motion_max_mean_rgb':float(avg.max()),
                'strong_pixels_diff_gt8_at_frame_203_vs_15':int(np.count_nonzero(np.max(np.abs(z[203]-z[15]),axis=2)>8)),
                'f329_to_f0_mean_rgb':float(st[0]), 'normal_single_frame_median':float(np.median(st)),
                'normal_single_frame_p95':float(np.quantile(st[1:],.95))}
    return out
def sheet(v, out):
    sz=480,270
    im=Image.new('RGB',(sz[0]*2,(sz[1]+21)*3),'#251b33')
    draw=ImageDraw.Draw(im)
    for k,(j,tag) in enumerate([(15,'Calm'),(105,'Previous cat timing; clear roof'),(168,'Petal front enters'),
                                (186,'Lamp cone petal peak'),(203,'Folds and cloth support'),(270,'Recovery')]):
        ix=(k%2)*sz[0];iy=(k//2)*(sz[1]+21)
        im.paste(Image.fromarray(v[j]).resize(sz,Image.Resampling.NEAREST),(ix,iy))
        draw.text((ix+6,iy+sz[1]+4),f'F{j:03d}  {j/30:.2f}s  {tag}',fill='#eadad7')
    im.save(out,quality=94,optimize=True)
if __name__=='__main__':
 p=argparse.ArgumentParser()
 p.add_argument('native',type=Path);p.add_argument('out',type=Path)
 a=p.parse_args();v=np.load(a.native,allow_pickle=False)
 assert v.shape==(330,180,320,3)
 a.out.mkdir(exist_ok=True,parents=True)
 (a.out/'spring_motion_stats.json').write_text(json.dumps(measure(v),indent=2)+'\n')
 sheet(v,a.out/'spring_contacts.jpg')
