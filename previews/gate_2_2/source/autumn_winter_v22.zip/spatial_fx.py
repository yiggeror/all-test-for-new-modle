"""Small physical decors on the frozen 3-D color plate: calibrated view, depth, fog, and subpixel coverage."""
from __future__ import annotations
import numpy as np
from scipy.ndimage import map_coordinates, distance_transform_edt,gaussian_filter
from math import pi,sin,cos
FPS=30
N=330
T=N/FPS
def sm(x):
    x=np.clip(x,0.,1.);return x*x*(3.-2.*x)
def pulse(t,a,b,c=.25,d=.43):
    u=(t-a)/(b-a)
    if not 0<u<1:return 0.
    return float(sm(u/c)*sm((1-u)/d))
def flow(t,salt=0):
    """One wind front: rising pressure, overshoot, then lower-frequency settling."""
    u=(t-3.12-salt)/5.62
    if not 0<u<1:return 0.
    return float(sm(u/.26)*sm((1-u)/.40)*(.82+.18*sin(2*pi*(u+.19))))
def depth_splat(cam, plate, P, radii, alpha, linear_colors, out=None, anis=None, maxalpha=.52, edge=None, additive=False):
    """Integrate projected Gaussian optical kernels, camera sample occlusion, and alpha-over.
    Positions/radii are 3-D metres, colors already lit; no rectangle or pre-drawn particle.
    """
    H,W=plate['sky'].shape
    x,y,dist,zf=cam.project(np.asarray(P))
    a=np.zeros((H,W),np.float32);rgb=np.zeros((H,W,3),np.float32);rads=np.asarray(radii)
    asp=np.broadcast_to(np.asarray(1. if anis is None else anis),(len(P),))
    for i in np.flatnonzero((zf>.8)&(alpha>1e-4)):
        radius=rads[i]*(W*.5/cam.th)/zf[i]
        if radius<.035:continue
        rx=max(.35,radius);ry=max(.34,radius*asp[i])
        x0,x1=max(0,int(x[i]-3*rx)),min(W,int(x[i]+3*rx)+1)
        y0,y1=max(0,int(y[i]-3*ry)),min(H,int(y[i]+3*ry)+1)
        if x1<=x0 or y1<=y0:continue
        yy,xx=np.ogrid[y0:y1,x0:x1]
        di=(plate['depth'][y0:y1,x0:x1]>dist[i]-.025).mean(axis=-1)
        if edge is not None:di*=edge[y0:y1,x0:x1]
        cov=alpha[i]*min(1.,(radius/.44)**1.5)*np.exp(-.5*(((xx+.5-x[i])/rx)**2+((yy+.5-y[i])/ry)**2))*di
        a[y0:y1,x0:x1]+=cov;rgb[y0:y1,x0:x1]+=cov[...,None]*linear_colors[i]
    if out is not None:
        sa=np.minimum(maxalpha,1-np.exp(-a))
        if not additive:out*=1-sa[...,None]
        out+=rgb*(sa/np.maximum(a,1e-8))[...,None]
    return a,rgb

def volume_plume(cam,plate,t,origin,mode,lin,wind_ref=0.):
    """Coupled optical density of several parcels from the same real point.
    Multi-lobed advection keeps the cap soft, no cone/profile artifact or hard white alpha.
    """
    tea=mode=='tea'; n=22 if tea else 18
    rng=np.random.default_rng(238 if tea else 397)
    shift=(np.arange(n)+rng.uniform(.09,.87,n))/n; phases=rng.uniform(0,2*pi,n)
    loops=2 if tea else 3
    age=(loops*(t%T)/T+shift)%1.
    work=rng.normal(size=(n,3))
    start=np.asarray(origin,float)
    wind=(.245 if tea else .49)+(.27 if tea else .63)*wind_ref
    rise=(1.45 if tea else 1.52)+(.11 if tea else .47)*wind_ref
    h=rise*(1+.10*work[:,1])*age
    # Slow push right through the knot followed by stretched out convection.
    bend=(wind*age**1.36+(.312 if tea else .22)*np.sin(2*pi*t/T*2.-8.4*age+.44)*age
          +(.11 if tea else .15)*work[:,0]*age)
    z=.12*work[:,2]*age+.07*np.cos(phases+age*8)*age
    P=start+cam.r[None]*bend[:,None]+cam.f[None]*z[:,None]
    P[:,1]+=h
    rad=((.041 if tea else .046)+(.228 if tea else .23)*age**.88)*(.90+.15*rng.random(n))
    bands=.69+.31*np.cos(4*pi*t/T-13.5*age+.45)
    density=(.141 if tea else .108)*sm(age/.084)*(1.-sm((age-.30)/.70))*(.58+.42*bands)*(.90+.10*np.cos(phases*.35+age*2.))
    # Tea takes its color from near tungsten; flue rapidly takes cool sky.
    c0=np.array([.302,.188,.098] if tea else [.141,.129,.128],np.float32)
    c1=np.array([.200,.153,.118] if tea else [.120,.127,.146],np.float32)
    colors=(1-age[...,None])*c0+age[...,None]*c1
    depth_splat(cam,plate,P,rad,density,colors,lin,anis=(.84+.48*age),maxalpha=.35 if tea else .28)
    return P

class Sway:
    """Depth-aware elastic reprojection in physical world space, with source-matched coverage.
    Cloth/tree depend on the same actual camera; there is no hand-layered canopy patch.
    """
    def __init__(self,plate,cam,kind):
        self.plate,self.cam,self.kind=plate,cam,kind
        P=plate['P'];y=P[...,1];self.depth=plate['depth'][...,4]
        self.yy,self.xx=np.mgrid[:y.shape[0],:y.shape[1]];self.inds=None
        trees=plate.get('tag5',np.zeros_like(y))
        foliage=plate.get('tag1',np.zeros_like(y))
        if kind=='autumn':
            m=np.minimum(1.,foliage+.60*trees)*sm((y-3.70)/3.1)
            # Bend decreases with depth; near plane crowns visibly ripple in sequence.
            h=sm((y-4.5)/6.7)
            fronts=.63+.37*np.cos(P[...,2]*.120+P[...,0]*.22)
            self.metres=(.48+.26*fronts)*h
            self.pitch=(.12+.08*np.cos(P[...,2]*.15+P[...,0]*.3))*h
        else:
            # Extreme foreground fine twigs: trees rooted lower down, late deep trunks remain locked.
            m=trees*sm((y-4.9)/2.6)*sm((30-self.depth)/14)*sm((99-self.xx)/41)
            h=sm((y-5.4)/3.7)
            fronts=.76+.24*np.cos(P[...,2]*.19+P[...,0]*.46)
            self.metres=.125*h*fronts
            self.pitch=.063*h
        self.mask=np.clip(m,0,1).astype(np.float32)
        self.P=P
        self.px,self.py,*_=cam.project(P.reshape(-1,3));self.px=self.px.reshape(y.shape);self.py=self.py.reshape(y.shape)
        # Masked interpolation cannot drag a nearby static pole/wire in the opposite depth.
        self.static_inds=distance_transform_edt(self.mask>.12,return_distances=False,return_indices=True)
        self.hull=gaussian_filter(self.mask,.78)
        self.aperture=(self.mask+plate['sky']>.88)&(plate['sky']>.01)
        self.air=(plate['sky']>.99)
        self.location=(P[...,2]*.145+P[...,0]*.19)
        obj=self.mask>.014
        self.near_indices=distance_transform_edt(~obj,return_distances=False,return_indices=True)
    def at(self,lin,t,sky_full):
        q=flow(t,.11 if self.kind=='winter' else 0)
        if self.kind=='autumn':
            h=q*(.78+.28*np.sin(1.75*t+self.location))+.062*np.sin(2*pi*t/T+self.location)
            v=q*(.43+.35*np.cos(1.43*t+self.location))+.10*np.sin(2*pi*t/T+self.location+.8)
        else:
            h=q*(.80+.40*np.sin(1.8*t+self.location)); v=q*(.58+.30*np.cos(2.05*t+self.location))
        # Analytic perspective of displacement; exact even close to camera.
        src=self.P.copy();src+=self.cam.r[None,None]*(self.metres*h)[...,None]
        src[...,1]+=self.pitch*v;src+=self.cam.f[None,None]*(.15*self.metres*h)[...,None]
        x,y,*_=self.cam.project(src.reshape((-1,3)))
        dx=(x.reshape(self.mask.shape)-self.px);dy=(y.reshape(self.mask.shape)-self.py)
        cap=7.8 if self.kind=='autumn' else 3.8
        dx=np.clip(np.nan_to_num(dx),-cap,cap)[tuple(self.near_indices)]
        dy=np.clip(np.nan_to_num(dy),-cap,cap)[tuple(self.near_indices)]
        # Never sample a repeated border when the camera crop does not reveal what lies beyond it.
        bx=sm(np.minimum(self.xx,self.xx.max()-self.xx)/11.5);by=sm(np.minimum(self.yy,self.yy.max()-self.yy)/7.2)
        dx*=bx;dy*=by
        loc=np.array([self.yy-dy,self.xx-dx])
        def warp(a):
            return map_coordinates(a,loc,order=1,mode='nearest',prefilter=False)
        m=self.mask
        wd=warp(m)
        edge=(np.maximum(wd,m)>.014)
        # Static underlay reconstructed only on newly covered/revealed mixed pixels.
        # At real sky edges use actual computed atmosphere, not a stretched image.
        bg=lin[tuple(self.static_inds)].copy()
        if self.kind=='autumn':
            nearair=self.air[tuple(self.static_inds)]|self.aperture
            bg[nearair]=sky_full[nearair]
        st=self.plate.get('tag6',0.)
        a=np.array(lin,dtype=np.float32,copy=True)
        fs=np.maximum(0.,lin-bg*(1-m[...,None]))
        # Saturated coverage is full actual leaf surface (not opacity graphic).
        for k in range(3):
            val=warp(fs[...,k])-fs[...,k]+(m-wd)*bg[...,k]
            val*=1-np.minimum(st,.95)
            a[...,k]+=np.where(edge,val,0.)
        np.maximum(a,0,out=a)
        return a,(wd-m),float(np.max(np.abs(dx[edge]))) if edge.any() else 0.

def world_snow(lin,cam,plate,P,scale,fade,lights,ambient,alpha=.72,flurry=0.):
    X,Y,D,Z=cam.project(P);f=cam.W*.5/cam.th
    good=(Z>2.)&(Y>=-.8)&(Y<180.8)&(X>=-.8)&(X<320.8)&(P[:,1]>.04)&(fade>.005)
    if not good.any():return
    P=P[good];r=scale[good]*f/Z[good];X=X[good]-.50;Y=Y[good]-.50;D=D[good]
    ix=np.floor(X).astype(int);iy=np.floor(Y).astype(int);wx=X-ix;wy=Y-iy
    cov=np.minimum(r,1.35)**1.11*fade[good]*alpha
    c=np.broadcast_to(np.asarray(ambient,np.float32),(len(P),3)).copy()
    for lp,lc,roll,axis,cones,stop in lights:
        V=P-lp;d2=np.sum(V*V,axis=1)
        wt=1./(roll**2+d2)
        if axis is not None: wt*=sm((V@axis/np.maximum(np.sqrt(d2),.01)-cones[0])/(cones[1]-cones[0]))
        if stop is not None: wt*=sm((stop-np.sqrt(d2))/(stop*.36))
        c+=lc[None]*wt[...,None]
    c=np.minimum(c,np.array([.62,.43,.32],np.float32))
    A=np.zeros((180,320),np.float32);C=np.zeros((180,320,3),np.float32)
    for ex,ey,u,v in [(0,0,1-wx,1-wy),(1,0,wx,1-wy),(0,1,1-wx,wy),(1,1,wx,wy)]:
        a=ix+ex;b=iy+ey;s=(a>=0)&(a<320)&(b>=0)&(b<180)
        a=a[s];b=b[s];k=cov[s]*u[s]*v[s]*((plate['depth'][b,a,:]>D[s,None]).mean(axis=-1))
        np.add.at(A,(b,a),k);np.add.at(C,(b,a),c[s]*k[:,None])
    opacity=np.minimum(.89,A)
    lin*=1-opacity[...,None]
    lin+=C*(opacity/np.maximum(A,1.e-8))[...,None]
