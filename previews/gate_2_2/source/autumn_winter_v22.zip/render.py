#!/usr/bin/env python3
"""Gate 2.2 autumn/winter reference build, no dependency on v2.1 images or private work paths."""
import argparse, hashlib, json, os, subprocess, sys, time, zipfile
from pathlib import Path
from collections import defaultdict
import numpy as np
from PIL import Image
N=330;FPS=30
BASIS={'autumn':('spring_autumn_source.zip','9c4e69ee6d6b1944cfc36a3030d24fe1db790ef74a83e9885d3abf6ca8354898','spring_autumn_gate2/src'),
       'winter':('gate2_summer_winter_source_qa.zip','758fd46755f7ad8259b9ee20e1ba6e6f6472c485b89e67db03110d4b6f1b99ce','.')}
# Draft stills list selected action moments. All full-frame PNG files come from final QP0 decoding.
PEAK={'autumn':[(122,'canopy'),(178,'gust'),(201,'leaves'),(222,'vendor')],
      'winter':[(95,'stairs'),(153,'warm_window'),(164,'page'),(214,'snow_gust')]}
AB={'autumn':{'canopy':(0,122,178,202),'leaves':(0,153,178,202,221),'steam':(85,120,198,224),'vendor':(0,198,211,222),'traffic':(0,80,112,134,162),'birds':(0,106,126,156,185)},
    'winter':{'page':(0,132,145,153,164,165,166,170,180,184,203,221),'smoke':(0,134,165,224),'branch':(0,134,157,191,214,224),'powder':(146,157,164,177,191,214,224,241),'window_snow':(0,112,145,155,164,167,170,184,214,221),'stairs':(0,52,95,135,178,214),'tv':(32,73,108,153,164,224,278),'gust':(0,130,153,164,173,209,214,224)}}
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as ff:
        for b in iter(lambda:ff.read(2<<20),b''):h.update(b)
    return h.hexdigest()
def basis(repo,work,scene):
    filename,hash,root=BASIS[scene]
    f=repo/'previews'/'gate_2'/'source'/filename
    if not f.is_file() or sha(f)!=hash:raise ValueError(f'Wrong frozen source: {f}')
    p=work/'base'/scene;p.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(f) as z:z.extractall(p)
    return p/root
def encode(a,out):
    pth=out.with_suffix('.pending.mp4')
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-nostdin','-y','-filter_threads','1','-f','rawvideo','-pixel_format','rgb24',
         '-video_size','320x180','-framerate','30','-i','-','-an','-vf','scale=1920:1080:flags=neighbor:out_color_matrix=bt709:out_range=tv,format=yuv420p',
         '-c:v','libx264','-preset','veryfast','-threads','2','-g','330','-keyint_min','330','-sc_threshold','0','-qp','0','-pix_fmt','yuv420p',
         '-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-color_range','tv','-movflags','+faststart',str(pth)]
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    for _ in range(2):p.stdin.write(memoryview(np.ascontiguousarray(a)).cast('B'))
    p.stdin.close()
    if p.wait():raise RuntimeError('QP0 encode failed')
    pth.replace(out)
def still(mp4,frame,out):
    expr=f'select=eq(n\\,{frame})'
    tmp=out.with_name(out.stem+'.pending.png')
    cmd=['ffmpeg','-v','error','-xerror','-y','-threads','2','-i',str(mp4),'-vf',expr,'-vsync','vfr','-frames:v','1','-threads','1',str(tmp)]
    subprocess.run(cmd,check=True)
    with Image.open(tmp) as im:
        if im.size!=(1920,1080):raise ValueError('Incorrect full-size peak still')
    tmp.replace(out)
def render(scene,repo,work,component,scout):
    sys.path.insert(0,str(basis(repo,work,scene).resolve()))
    if scene=='autumn':
        from autumn22 import Autumn
        s=Autumn()
    else:
        from winter22 import Winter
        s=Winter()
    print('PLATE',scene,s.info,flush=True)
    target=work/'out';target.mkdir(parents=True,exist_ok=True)
    qa=work/'qa';qa.mkdir(parents=True,exist_ok=True)
    atlas=qa/'layer_native';atlas.mkdir(parents=True,exist_ok=True)
    draft=work/'drafts';draft.mkdir(parents=True,exist_ok=True)
    if scout:
        fs=sorted(set([0,*[x for x,_ in PEAK[scene]],*[x for v in AB[scene].values() for x in v]]))
        base={}
        for i in fs:
            base[i]=s.frame(i/FPS)
            Image.fromarray(base[i]).save(draft/f'{scene}_{i:03d}.png')
        for layer,fr in AB[scene].items():
            for i in fr:Image.fromarray(s.frame(i/FPS,omit=(layer,))).save(draft/f'{scene}_{i:03d}_no_{layer}.png')
        (qa/(scene+'_scene.json')).write_text(json.dumps(s.info,indent=2)+'\n')
        return
    t0=time.monotonic()
    tmp=target/(f'.{scene}_native.pending')
    frames=np.lib.format.open_memmap(tmp,mode='w+',dtype=np.uint8,shape=(N,180,320,3))
    for j in range(N):
        frames[j]=s.frame(j/FPS)
        if j%55==0:print('FRAMES',scene,j,round(time.monotonic()-t0,2),flush=True)
    assert np.array_equal(frames[0],s.frame(N/FPS))
    frames.flush(); final=target/(scene+'_native.npy');tmp.replace(final)
    mp4=target/(scene+'_loop.mp4')
    print('NATIVE_READY',scene,sha(final),flush=True)
    encode(frames,mp4)
    print('MP4_READY',scene,sha(mp4),flush=True)
    for i,ename in PEAK[scene]:
        still(mp4,i,target/f'{scene}_{ename}_f{i:03d}_1080p.png')
    proof={}
    if component:
        for layer,indices in AB[scene].items():
            rows=[]
            for i in indices:
                off=s.frame(i/FPS,omit=(layer,))
                on=frames[i].copy()
                both=np.concatenate((on,off),axis=1)
                Image.fromarray(both).save(atlas/f'{scene}_{layer}_f{i:03d}_on-left_off-right.png')
                delta=np.abs(on.astype(np.int16)-off).max(2);y,x=np.where(delta>2)
                rows.append({'index':i,'pixels':int(len(x)),'bbox_xyxy':[int(x.min()),int(y.min()),int(x.max()+1),int(y.max()+1)] if len(x) else None,'max_rgb_delta':int(delta.max())})
            proof[layer]=rows
    (qa/(scene+'_scene.json')).write_text(json.dumps({'scene':scene,'movie':s.info,'fps':FPS,'period_frames':N,'full_peaks':PEAK[scene],
           'loop_mp4_sha256':sha(mp4),'native_npy_sha256':sha(final),'layers':proof},indent=2)+'\n')
    print('READY',scene,round(time.monotonic()-t0,2),flush=True)
def main():
    a=argparse.ArgumentParser();a.add_argument('scene',choices=['autumn','winter','both']);a.add_argument('--repo',type=Path,required=True);a.add_argument('--work',type=Path,required=True);a.add_argument('--scout',action='store_true');a.add_argument('--no-proof',action='store_true');args=a.parse_args()
    if args.scene=='both':
        for c in ('autumn','winter'):
            subprocess.run([sys.executable,str(Path(__file__).resolve()),c,*sys.argv[2:]],check=True)
    else:render(args.scene,args.repo.resolve(),args.work.resolve(),not args.no_proof,args.scout)
if __name__=='__main__':main()
