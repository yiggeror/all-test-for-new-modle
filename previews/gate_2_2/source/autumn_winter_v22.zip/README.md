# Gate 2.2｜秋、冬的原生动态

对应 [Round 9，4c06e296](https://github.com/yiggeror/all-test-for-new-modle/blob/4c06e29619b2efa6ed8c4f9b75888417d91a4bb7/REVIEW_LOG.md)。从 Gate 2 的冻结相机、场景和 60 色色板重新渲染，不继承 Gate 2.1 的动物像素图。不做总片或音频生产。

## 复现

所需环境：Python 3.12、FFmpeg/libx264、Noto CJK Serif/Sans 字体，具体 Python 库版本见 requirements.txt。模型从同一仓库已提交的 `previews/gate_2/source/` 读取：

- 秋：`spring_autumn_source.zip`，SHA-256 `9c4e69ee6d6b1944cfc36a3030d24fe1db790ef74a83e9885d3abf6ca8354898`
- 冬：`gate2_summer_winter_source_qa.zip`，SHA-256 `758fd46755f7ad8259b9ee20e1ba6e6f6472c485b89e67db03110d4b6f1b99ce`

仓库根目录执行：

```bash
repo="$PWD"
work="$repo/build/gate22_aw"
mkdir -p "$work/src"
unzip -q -o previews/gate_2_2/source/autumn_winter_v22.zip -d "$work/src"
python3.12 -m venv "$work/venv"
"$work/venv/bin/python" -m pip install -r "$work/src/requirements.txt"
export NUMBA_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1
"$work/venv/bin/python" "$work/src/render.py" both --repo "$repo" --work "$work"
for season in autumn winter; do
  "$work/venv/bin/python" "$work/src/verify.py" "$season" --repo "$repo" --output "$work/out" --json "$work/qa/${season}_verified.json"
done
```

`both` 可换成 `autumn` 或 `winter`；`--scout` 只生成少量原生 A/B 帧供试片。输出为 `out/{season}_native.npy`（uint8，330×180×320×3）、QP0 两周期 `out/{season}_loop.mp4`（22 秒，660帧，1920×1080/30fps/6×整像素放大，无声）以及 QP0 真解码出来的 1080p 整幅净帧。主要动作的逐层开关 A/B 在 `qa/layer_native/`。

## 秋 · 梧桐黄昏大道

- **无地面鸽子。** 阵风从 3.12 秒进入，约 4.5 秒达最大压力，几次回弹后在 8.74 秒收尾。树冠以原 3D 场景的逐像素世界坐标、采样覆盖和深度做挠曲重投影；树干根部、电线、灯壳固定，实际叶团遮挡的灯光层轻微明灭。
- **地面风通过物体表达。** 30 片 11.7–22.2 cm 量级的梧桐叶，在不同深度与街面高度翻滚。以真实世界坐标投影叶片两侧，接天地面法线、样本遮挡、附近几盏灯的主色与接触阴影。松散叶片在阵风前后衔接原场景的落叶，不按画面做平行条纹。
- 报刊亭侧：原汽源投影约 (75.5,135.4)。暖光体积散射包裹多缕对流汽，从底部偏暖到上部淡隐，不上不透明白色。柜台后人影是局部重追踪的肩、颈、头与手臂连体模型，约 5.95–8.75 秒稍俯身整理刊物。暖光朦罩轮廓。
- 暮雾中的远车灯通过距离平方与雾削弱，并由现场深度遮挡；高处仅留两只微小紫灰归鸟，淡于下方室外灯光。

## 冬 · 雪夜家属院

- **无雪人/石凳间的小鸟。** 左灯锥与原冷蓝院照保持。每轮同一场北风轻摇左上真实树枝，约 4.9 秒开始卷落枝头粉雪；近中远雪在对应三维灯锥沿不同轨迹斜行，疏落的细雪粉另作弱散射，不把静止雪地做成会动的纹理。
- **暖窗动作留原时相。** 4.30–6.90 秒仅翻一张纸，原声音提示 5.21/5.64/6.28 秒不挪。书页用三个真实曲面片逐帧弯转和受灯照，不使用发光页边，也不在灯罩上描线。近端纸运动包络约 1.466 m，灯罩左缘 1.635 m，两者原始光照隔开。前方雪使用窗外独立雪源与外墙暖灯，区域内逐样本以真实深度与窗框前后遮挡。
- 远处四层实际开孔由下往上逐层亮灯，保留近处枯枝遮挡；最右居民窗有独立亮度/色温变化的暖蓝电视间接光。值班室烟管重做多股上升与侧向拉伸的微弱半透明散射，不画固定锥体。

## 技术自查

`verify.py` 全量解码 660 帧并逐帧检查 Y 6×6 和 U/V 3×3 像素块，两周期 330 个对应帧字节一致；再用 Gate 2 冻结色板的 BT.709 反查逐像素核对原生 RGB。制作侧同时保留动作峰值的同帧原生 A/B，方便独立审片区分新成分，而非用裁剪放大图代替 1× 审片。
