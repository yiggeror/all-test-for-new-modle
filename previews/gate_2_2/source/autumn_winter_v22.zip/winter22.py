"""Winter, Gate 2.2: real lofted snow, warm window depth, curved matte page and a calibrated stove."""
import numpy as np
from math import sin,cos,pi
import winter_loop_scene as base
from timeline import reader_controls, wave,envelope
from framework import use_cjk,FixedColors
from engine import fx,props as pr
from engine.world import World,roty,srgb
from spatial_fx import *

def separate_reading_room(w,width,height):
    """Reuses the approved opening. Only book/desk and lamp move centimetres."""
    desk=base.sc.G_DESK
    light=dict(mat='emit',col='#e6a158',prm=(.56,0,0,0),tag=pr.TAG_NOSNOW,grp=desk)
    w.quads((-.25,-.16,-.64),(width+.22,-.16,-.64),(width+.22,height+.20,-.64),(-.25,height+.2,-.64),**light)
    w.quads((0,.01,-.61),(width,.01,-.61),(width,.25,-.61),(0,.25,-.61),mat='emit',col='#985e38',prm=(.47,0,0,0),tag=pr.TAG_NOSNOW,grp=desk)
    dl=dict(mat='plain',col='#453235',tag=pr.TAG_NOSNOW)
    w.sphere((.63,.39,-.27),.23,n=10,squash=1.45,**dl)
    w.tube((.69,.51,-.25),(.82,.76,-.23),.13,.10,sides=8,caps=True,**dl)
    w.sphere((.87,.83,-.21),.132,n=10,squash=1.03,**dl)
    w.sphere((.96,.79,-.22),.052,n=7,squash=.62,**dl)
    w.box((1.12,.26,-.18),(1.20,.105,.28),mat='wood',col='#714938',tag=pr.TAG_NOSNOW)
    for x in (1.065,1.241):
        w.box((x,.325,-.001),(.164,.025,.182),yaw=.13,mat='emit',col='#cab18b',prm=(.225,0,0,0),tag=pr.TAG_NOSNOW,grp=desk)
    # Narrow cloth shade, physically to the right of the entire book motion envelope.
    w.tube((1.815,.30,-.26),(1.805,.710,-.28),.021,sides=6,**dl)
    w.tube((1.805,.743,-.28),(1.805,.969,-.28),.17,.076,sides=10,caps=True,
           mat='emit',col='#ffd6a0',prm=(.76,0,0,0),tag=pr.TAG_NOSNOW,grp=desk)
    w.light('point',np.asarray(srgb('#ffd396'))*.68,pos=(1.755,.73,-.32),radius=.068,range=1.44,r0=.24,grp=desk)
    for x in (.025,width-.024):
        w.box((x,height/2,.02),(.09,height,.08),mat='wood',col='#483a37',tag=pr.TAG_NOSNOW)
    for y in (.029,height-.021):
        w.box((width/2,y,.02),(width,.072,.093),mat='wood',col='#483a37',tag=pr.TAG_NOSNOW)
    w.box((width/2,height-.19,.02),(width,.057,.068),mat='wood',col='#58423a',tag=pr.TAG_NOSNOW)

class Room(base.Winter):
    def arm(self,t):
        lift,turn,shown=reader_controls(t)
        breath=.010*wave(t,3,.10)
        start=(.73,.563+breath,-.123)
        ang=pi*(.04+.92*turn)
        hinge=np.array([1.161,.343,.030])
        leng=.247
        reach=cos(ang)*leng
        elbow=(.922+.045*lift,.357+.145*lift+breath,-.043+.051*lift)
        tip=(1.132+lift*(hinge[0]+reach*.90-1.17),.334+lift*(.039+(.196+sin(ang)*.107)*shown),.002+.068*lift)
        # During the lifted page fingertips follow the near paper edge, not the glass or lamp.
        m=World(seed=23)
        with m.at(base.sc.GUARD_POS,yaw=base.sc.GUARD_YAW):
            with m.at(self.xform):
                dark=dict(mat='plain',col='#4c3739',prm=(.28,0,0,0))
                m.tube(start,elbow,.076,.060,sides=8,caps=True,**dark)
                m.tube(elbow,tip,.059,.032,sides=8,caps=True,**dark)
                m.sphere(tip,.041,n=8,squash=.81,mat='plain',col='#96654e',prm=(.35,0,0,0))
                if shown>.012:
                    # Actual single bent paper. Nonemissive warm flax, deliberately narrower than lamp's body.
                    def p(a,z):
                        return hinge+np.array([reach*a+.058*z*a,
                            shown*(leng*sin(ang)*a+.127*sin(.64*pi*a)*sin(ang)),z*(.104+.018*a)+.048*a])
                    for k in range(3):
                        a,b=k/3,(k+1)/3
                        m.quads(p(a,-1),p(b,-1),p(b,1),p(a,1),mat='plain',
                                col=('#c5ad87','#dbc7a5','#e0c9a5')[k],prm=(.36+.43*sin(ang),0,0,0))
                    if shown>.22:
                        m.tube(p(1,-1),p(1,1),.016*shown,.012*shown,sides=6,caps=True,mat='plain',
                               col='#e5cca3',prm=(.81,0,0,0))
        return m

class Winter:
    def __init__(self):
        use_cjk()
        op=pr.pane;old=base.sc.reading_room_window
        front=np.array([14.,0.,-49.])
        self.landings=[front+roty(.42)@np.array([-20.05+.25+2.5*3.3,.7+2.9*f+1.675,5.05]) for f in range(4)]
        touched=[]
        def floor_panes(w,ow,oh,*a,**kw):
            center=w.xf((ow*.5,oh*.5,0)).reshape(3)
            for i,target in enumerate(self.landings):
                if np.linalg.norm(center-target)<.08:
                    touched.append(i);kw.update(lit=(.28,.31,.30,.25)[i],col='#ffd391',grp=base.sc.G_ST+i)
                    break
            return op(w,ow,oh,*a,**kw)
        pr.pane=floor_panes;base.sc.reading_room_window=separate_reading_room
        try:self.st=Room()
        finally:pr.pane=op;base.sc.reading_room_window=old
        if sorted(touched)!=[0,1,2,3]:raise RuntimeError('Lost stair group '+str(touched))
        self.st.lamp_pt=base.frozen.guard_world((self.st.xform[0]+1.755,self.st.xform[1]+.73,self.st.xform[2]-.32))
        self.b,self.cam=self.st.b,self.st.cam
        self.pa=FixedColors('winter',self.st.GRADE,self.st.VIGNETTE);self.palette=self.pa.rgb
        self.sway=Sway(self.b,self.cam,'winter')
        yy,xx=np.mgrid[:180,:320];self.sky_full=base.sc.sky(self.cam.dirs(xx.ravel()+.5,yy.ravel()+.5).astype(np.float32)).reshape(180,320,3)
        tree=self.b['tag5'];P=self.b['P'];dep=self.b['depth'][...,4]
        sel=(tree>.21)&(tree<.94)&(dep<27)&(xx>=32)&(xx<=72)&(yy>=11)&(yy<=44)&(P[...,1]>7.7)
        jj,ii=np.nonzero(sel)
        if not len(jj):raise RuntimeError('Expected physical branch not found')
        idx=np.argmin((ii-48)**2+((jj-29)*1.2)**2-.53*tree[jj,ii])
        self.branch=self.b['P'][jj[idx],ii[idx]].astype(float); self.branch_px=[int(ii[idx]),int(jj[idx])]
        self.L=self.st.c['lamp']
        self.ext=base.frozen.guard_world((-.65,1.48,base.sc.GUARD_SIZE[1]*.5+.22));self.ext=np.array(self.ext)
        self.ext_axis=roty(base.sc.GUARD_YAW)@np.array([0.,-.67,1.]);self.ext_axis/=np.linalg.norm(self.ext_axis)
        self.ext_col=np.asarray(srgb('#fbb36d'))*.32
        r=np.random.default_rng(519)
        self.wt0=r.uniform(0,1,85);self.winlocal=np.column_stack([r.uniform(-1.80,.68,85),r.uniform(.87,3.79,85),r.uniform(1.79,3.46,85)])
        self.winvel=np.column_stack([r.uniform(.32,.73,85),-r.uniform(.53,1.12,85),r.uniform(-.09,.03,85)])
        self.wsz=r.uniform(.009,.031,85)
        self.p0=np.column_stack([r.uniform(-.19,.33,52),r.uniform(-.18,.1,52),r.uniform(-.17,.21,52)])
        self.p_delay=4.90+r.uniform(0,.70,52); self.prad=r.uniform(.008,.028,52)
        self.p_life=r.uniform(1.83,3.46,52);self.eddy=r.uniform(0,6.28,52);self.p_dir=r.uniform(.3,1.25,52)
        self.lamp_local=r.uniform(0,1,195)
        self.lamp_p=np.column_stack([r.uniform(-2.85,1.80,195),r.uniform(-3.9,1.7,195),r.uniform(-2.1,4.6,195)])
        self.lamp_r=r.uniform(.014,.041,195);self.lamp_fall=r.uniform(.50,1.12,195)
        self.info={'branch_px':self.branch_px,'branch_m':list(self.branch),'stove_px':self.st.stats['flue_anchor'],
            'landing_px':[tuple(float(a) for a in self.cam.project(p)[:2]) for p in self.landings],
            'page_window_s':[4.3,6.90],'paper_cues_s':[5.21,5.64,6.28],
            'lamp_nearest_local_x':1.635,'page_farthest_local_x':1.466,
            'window_snow_clip':(245,100,272,117),'wind_s':[3.23,8.85]}
    def window_snow(self,out,t,lights,k):
        age=(t/T*4.+self.wt0)%1.;u=(age-.5)*3.1
        a=self.winlocal+self.winvel*u[:,None]
        a[:,0]+=k*.47*(.68+.32*np.cos(self.wt0*13.4+t*2))
        W=roty(base.sc.GUARD_YAW);p=np.asarray(base.sc.GUARD_POS)+a@W.T
        f=sm(age/.15)*sm((1-age)/.15)
        x,y,*_=self.cam.project(p)
        f*=sm((x-243)/4)*sm((276-x)/3)*sm((y-97)/4)*sm((122-y)/5)
        world_snow(out,self.cam,self.b,p,self.wsz,f,lights,self.st.c['amb']*.72,alpha=.83)
    def powder(self,out,t,lights,k):
        age=t-self.p_delay;u=age/self.p_life;fade=sm(u/.095)*sm((1-u)/.29)
        if not np.any(fade):return
        a=np.maximum(age,0.)
        p=self.branch+self.p0*np.minimum(1.,.31+a[:,None]*.8)
        p[:,0]+=-.31*a-.16*a*a+.22*a*np.sin(self.eddy+3.0*a)
        p[:,1]+=-self.p_dir*.18*a-.58*a*a+.08*a*np.cos(self.eddy+2.4*a)
        p[:,2]+=.20*a+.27*a*np.cos(self.eddy+2.6*a)
        world_snow(out,self.cam,self.b,p,self.prad,fade,lights,self.st.c['amb']*.83,alpha=.83)
        # Ten local parcels render the finest ice dust as weak forward-scattering powder, not extra bright dots.
        take=np.arange(1,len(a),5)
        pa=p[take]; ag=a[take]; alp=fade[take]*.044
        colors=np.tile(np.array([.148,.123,.113],np.float32),(len(take),1))
        depth_splat(self.cam,self.b,pa,.030+.061*ag,alp,colors,out,anis=1.04,maxalpha=.071)
    def cone_flow(self,out,t,lights,k):
        if k<.006:return
        age=(t/T*2+self.lamp_local)%1.;u=(age-.5)*5.5
        a=self.lamp_p.copy()
        ring=self.lamp_p[:,1]*.67-self.lamp_p[:,2]*.45-.97*t
        a[:,0]+=-.310*u+1.39*k*np.cos(ring)
        a[:,1]+=-self.lamp_fall*u+.31*k*np.sin(ring)
        a[:,2]+=.25*u+.61*k*np.sin(ring+.5)
        g=sm(age/.16)*sm((1-age)/.18)*k
        world_snow(out,self.cam,self.b,self.L['pos']+a,self.lamp_r,g,lights,self.st.c['amb']*.87,alpha=.68)
    def frame(self,t,omit=()):
        t=t%T;p=t/T;w=flow(t,.11);g=self.st.controls(t)
        for f in range(5):
            g[base.sc.G_ST+f]=.010+1.05*envelope(t,.8+f*1.35,2.91,.25,.37)
        if 'stairs' in omit:g[base.sc.G_ST:base.sc.G_ST+5]=.01
        g[base.sc.G_DESK]=1.+.022*wave(t,2,.40)+.013*wave(t,3,.21)
        gwin=g[base.sc.G_DESK]
        c=self.st.c
        tvbase=.80+.44*(fx.loopnoise(p,12,31)-.5)+.080*wave(t,7,.21)
        hue=.50+.5*fx.loopnoise(p,12,47)
        tc=tvbase*np.array([.80+.22*hue,.96,1.15+.17*(1.-hue)],np.float32)
        if 'tv' in omit:tc=np.array([.87,.87,.87],np.float32)
        out=c["sky"].copy()
        for i,v in enumerate(g):
            out+=self.b['layers'][i]*(tc[None,None] if i==base.sc.G_TV else v)
        if 'branch' not in omit:
            out,delta,_=self.sway.at(out,t,self.sky_full)
        if 'page' in omit:
            self.st.actor.composite(out,self.st.arm(0.),self.st.lamp_pt,float(gwin))
        else:
            self.st.actor.composite(out,self.st.arm(t),self.st.lamp_pt,float(gwin))
        if 'smoke' not in omit:volume_plume(self.cam,self.b,t,self.st.roof,'flue',out,w)
        lamp=self.L
        l=[(lamp['pos'],lamp['color']*.49*g[base.sc.G_LAMP],.83,lamp['axis'],lamp['cone'],7.5),
           (self.ext,self.ext_col*gwin,.47,self.ext_axis,(0.,.60),3.2)]
        for j,obj in enumerate(c['snow']):
            P,fade=obj.positions(p)
            incone=np.exp(-((P[:,2]-lamp['pos'][2])*.18)**2-((P[:,0]-lamp['pos'][0])*.22)**2)
            eddy=P[:,1]*.49-P[:,2]*.39+t*1.15
            P[:,0]-=w*(.74+.75*incone*(.57+.43*np.sin(eddy)))
            P[:,1]+=w*incone*(.38*np.sin(eddy+.93))
            world_snow(out,self.cam,self.b,P,obj.size,fade,l,c['amb']*(1.02 if j==2 else 1.),alpha=(.59,.67,.77)[j])
        if 'window_snow' not in omit:self.window_snow(out,t,l,w)
        if 'powder' not in omit:self.powder(out,t,l,w)
        if 'gust' not in omit:self.cone_flow(out,t,l,w)
        lamp_x,lamp_y,_,_=c['lamp_px']
        fx.glow(out,lamp_x[0],lamp_y[0],lamp['color']*.012*g[base.sc.G_LAMP],r0=2.2,power=1.3)
        return self.pa.quantize(fx.bloom(out,thresh=.55,sig=(1.0,3.5),gain=(.22,.14)))
