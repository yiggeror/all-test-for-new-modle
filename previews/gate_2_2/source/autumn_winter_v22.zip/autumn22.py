"""Autumn, Gate 2.2: physically located leaf rolls, lamplight filtered by a wind front, warm breathing haze."""
import numpy as np
from math import sin,cos,pi
from scipy.ndimage import gaussian_filter
from spatial_fx import *
import render_cycle as rc
import autumn_motion as prev
from engine import fx
from engine.world import World,roty,srgb,_n
from engine.rt import Accel

def convex(coords,x,y):
    q=(np.asarray(coords));e=np.roll(q,-1,axis=0)-q
    k=(q[:,0,None,None]-x)*e[:,1,None,None]-(q[:,1,None,None]-y)*e[:,0,None,None]
    return (k>=-1e-6).all(0)|(k<=1e-6).all(0)

def leaf_disc(lin,cam,plate,P,verts,col,fade=1.,shadow=False):
    q=np.asarray(P)+np.asarray(verts);x,y,d,z=cam.project(q)
    if min(z)<3:return
    x0,x1=max(0,int(np.floor(x.min()))),min(320,int(np.ceil(x.max()))+1)
    y0,y1=max(0,int(np.floor(y.min()))),min(180,int(np.ceil(y.max()))+1)
    if x1<=x0 or y1<=y0:return
    yy,xx=np.mgrid[y0:y1,x0:x1];coverage=np.zeros(yy.shape,np.float32)
    poly=np.stack([x,y],axis=1)
    for sy in range(3):
        for sx in range(3):coverage+=convex(poly,xx+(sx+.5)/3,yy+(sy+.5)/3)
    if not coverage.any():return
    if shadow:
        # Only actual upward-facing ground under the leaflet, not a road-sized matte or shadow on a post.
        front=plate['P'][y0:y1,x0:x1];dep=plate['depth'][y0:y1,x0:x1,4]
        m=(np.abs(dep-np.mean(d))<.49)&(plate['N'][y0:y1,x0:x1,1]>.60)&(np.abs(front[...,1]-P[1])<.23)
        lin[y0:y1,x0:x1]*=1-(coverage*fade/9*m)[...,None]*np.array([.68,.78,1.])
        return
    visible=(plate['depth'][y0:y1,x0:x1,:]>np.mean(d)-.027).mean(axis=-1)
    a=(coverage*visible*fade/9)[...,None]
    lin[y0:y1,x0:x1]+=(col-lin[y0:y1,x0:x1])*a

class RollingLeaves:
    def __init__(self,c):
        self.c=c;self.cam=c['cam'];self.b=c['plate'];r=np.random.default_rng(531)
        # Adult oriental plane leaves 10–20 cm; multiple files/depths, not ash or drifting graphics.
        self.n=30;N=self.n
        self.z=np.r_[r.uniform(2.2,6.8,16),r.uniform(6.6,11.9,8),r.uniform(-6.,2.,6)]
        self.x=r.uniform(-5.7,-2.8,N)
        self.start=r.uniform(3.28,4.67,N)+.105*np.abs(self.z-4.3)
        self.end=self.start+r.uniform(2.34,4.2,N)
        self.dist=r.uniform(4.7,9.1,N)
        self.pitch=r.uniform(-.20,1.20,N);self.theta=r.uniform(-pi,pi,N)
        self.lens=r.uniform(.117,.222,N);self.rise=r.uniform(.11,.47,N)
        self.zz=r.uniform(-1.9,.75,N);self.flutter=r.uniform(5.7,9.1,N)
        self.palette=np.stack([srgb(c) for c in ('#af6926','#ba7f37','#d59c48','#987136','#ae873d','#c58a2a')])
        self.which=r.integers(0,len(self.palette),N)
        self.shape=np.array([[-.62,0.,0.],[-.31,0.,-.26],[.08,0.,-.43],[.20,0.,-.32],[.43,0.,-.27],[.63,0.,0.],[.45,0.,.27],[.20,0.,.32],[.08,0.,.42],[-.30,0.,.23]])
    def draw(self,lin,t,gain):
        for i in np.flatnonzero((t>self.start)&(t<self.end)):
            u=(t-self.start[i])/(self.end[i]-self.start[i]); u2=.25*u+.75*sm(u)
            settle=float(sm(u/.13)*sm((1-u)/.20))
            xx=self.x[i]+self.dist[i]*u2;zz=self.z[i]+self.zz[i]*u2+.19*np.sin(12*u+self.theta[i])*settle
            ground=.153*float(sm((abs(xx)-4.53)/.25))
            h=self.rise[i]*settle*(.40+.60*max(0.,sin(2*pi*u*1.22+self.theta[i])**2))
            h+=.022
            p=np.array([xx,ground+h,zz])
            x,y,dep,z=self.cam.project(p)
            if not (10<x<315 and 124<y<181 and z>3):continue
            # Broad leaves roll end-over-side and take warmer direct light at matching world locations.
            alpha=settle
            turn=self.theta[i]+self.flutter[i]*u+1.06*sin(5*u+self.pitch[i]);roll=.25+sin(2*pi*u*1.75+self.theta[i])*1.34
            r=roty(turn)
            e=np.array([[1,0,0],[0,cos(roll),-sin(roll)],[0,sin(roll),cos(roll)]])
            face=self.shape*(self.lens[i]*np.array([1.04,1.,.93]))
            shape=(face@e.T)@r.T;norm=r@e[:,1]
            color=self.palette[self.which[i]]
            illumination=np.array([.077,.076,.088],np.float32)
            for j,l in enumerate(self.c['lamps'][:4]):
                L=l['pos']-p
                d=float(L@L)
                theta=float((-L/np.sqrt(d))@l['axis'])
                conc=float(sm((theta-l['cone'][0])/(l['cone'][1]-l['cone'][0])))
                illumination+=l['color']*(conc/(d+.66))*(.26+.74*abs(float(L@norm)/np.sqrt(d)))*(.78 if j>1 else 1.)*gain
            ambient=lin[min(179,int(y)),min(319,int(x))]
            col=color*illumination*.99+.10*ambient
            shadow=face@r.T;shadow[:,1]=0.;po=p.copy();po[1]=ground+.006;po[0]+=.15*h;po[2]-=.22*h
            leaf_disc(lin,self.cam,self.b,po,shadow,col,fade=.31*(1-.62*h)*alpha,shadow=True)
            leaf_disc(lin,self.cam,self.b,p,shape,col,fade=.94*alpha)
            # Two material-facing sides of the same wrinkled leaflet, sampled together at native resolution.
            # The vein softens into the base albedo whenever the leaf lies flat.
            if abs(sin(roll))>.35 and self.lens[i]>.143:
                side=face[[0,1,2,3,4,5]].copy();side[:,1]=np.abs(side[:,2])*.27
                leaf_side=(side@e.T)@r.T
                leaf_disc(lin,self.cam,self.b,p,leaf_side,col*(1.06+.25*abs(sin(roll))),fade=.45*alpha)

class Vendor:
    def __init__(self,c):
        self.c=c;self.cam=c['cam'];self.plate=c['plate'];self.M=roty(.76);self.origin=np.array([-8.65,.15,1.38])
        self.clip=(28,110,58,141);x0,y0,x1,y1=self.clip;self.S=4
        yy,xx=np.mgrid[:(y1-y0)*self.S,:(x1-x0)*self.S]
        self.rays=self.cam.dirs(x0+(xx+.5)/self.S,y0+(yy+.5)/self.S).reshape(-1,3).astype(np.float32)
        self.o=np.broadcast_to(self.cam.pos.astype(np.float32),self.rays.shape).copy()
        self.x=(xx.ravel()//self.S)+x0;self.y=(yy.ravel()//self.S)+y0
        self.light=self.origin+self.M@np.array([0.,1.91,1.50])
    def make(self,t):
        breath=.008*sin(2*pi*3*t/T); lift=pulse(t,5.95,8.75,.38,.40)
        m=World(seed=23);neck=np.array([-.42-lift*.125,1.71+lift*.163+breath,.970])
        shoulder=np.array([-.41-lift*.086,1.45+lift*.153+breath,.972])
        pinch=np.array([-.07-lift*.071,1.12+lift*.247,.985])
        with m.at(self.origin,yaw=.76):
            def lay(kind,color):return dict(mat='plain',col=color,prm=(kind,0,0,0))
            m.sphere(shoulder-np.array([0,.17,0]),.195,n=10,squash=1.44,**lay(.42,'#6b5041'))
            m.tube(shoulder,neck,.128,.080,sides=8,caps=True,**lay(.43,'#665040'))
            m.sphere(neck+np.array([-.011,.134,.004]),.103,n=10,squash=1.12,**lay(.51,'#80624f'))
            m.sphere(neck+np.array([-.030,.189,.003]),.095,n=10,squash=.56,**lay(.32,'#584438'))
            p0=shoulder+np.array([.086,.033,.016]);p1=(p0+pinch)*.5+np.array([-.04,-.11,.029])
            m.tube(p0,p1,.064,.046,sides=7,caps=True,**lay(.41,'#745343'));m.tube(p1,pinch,.049,.027,sides=7,caps=True,**lay(.43,'#795748'))
            m.sphere(pinch,.032,n=7,squash=.71,**lay(.56,'#a67855'))
            if lift>.06:
                m.quads(pinch+[-.12,-.02,.012],pinch+[.11,-.03,.012],pinch+[.09,.11,.031],pinch+[-.095,.11,.028],
                        **lay(.47,'#997b55'))
        return m.finalize()
    def draw(self,lin,t):
        g=self.make(t)
        acc=Accel(g['v0'],g['v1'],g['v2'],g['tm']);l,i=acc.closest(self.o,self.rays)
        ok=i>=0
        if not ok.any():return
        x=self.x[ok];y=self.y[ok];l=l[ok];sel=ok.copy();i=i[ok]
        v=(self.plate['depth'][y,x,:]>l[:,None]-.012).mean(1)*.82
        if not v.any(): return
        hits=self.o[sel]+self.rays[sel]*l[:,None];N=g['F']['n'][g['tf'][i]]
        src=self.light[None]-hits;D=_n(src)
        dot=np.maximum(np.sum(N*D,axis=-1),0)
        mat=g['F']['col'][g['tf'][i]]
        indirect=np.array([.112,.064,.038],np.float32)
        lit=mat*(indirect+(.11+.19*dot[:,None])*np.array([1.,.66,.37],np.float32))
        op=np.zeros((180,320),np.float32);buf=np.zeros((180,320,3),np.float32)
        np.add.at(op,(y,x),v/(self.S*self.S));np.add.at(buf,(y,x),lit*v[:,None]/(self.S*self.S))
        # A light transmission veil at the counter, softly reducing surgical contour contrast.
        for k in range(3):buf[...,k]=gaussian_filter(buf[...,k],.39)
        op=gaussian_filter(op,.39)
        # Preserve foreground shelf/trunk occlusion, as the complete clipped ray result did.
        lin*=1-op[...,None];lin+=buf

def sky_birds(lin,c,t):
    from dynamic_fx import line
    for i,(st,en,y0) in enumerate(((1.8,7.52,10.2),(3.12,8.85,16.1))):
        q=(t-st)/(en-st)
        if not 0<q<1:continue
        x=125+61*q+1.7*sin(2*pi*q);y=y0+1.70*sin(pi*q+i*.84)
        r=2*pi*(t*.99+i*.28)+.29*sin(2.8*t+i*.71)
        swing=.76*sin(r);h=(1.55,1.33)[i]
        pts=[(x-h,y-1.15*swing-.09),(x-.53,y-.39*swing),(x+.08,y+.24),
             (x+.65,y-.45*swing),(x+h,y-(.78*swing+.07))]
        # Like mountain shadows, warmed by the same violet scattering volume. Not black.
        line(lin,pts,.72,.56,np.array([.245,.153,.265],np.float32),c['bird_access'])

def traffic(lin,c,t):
    start,end=2.10,9.12;u=(t-start)/(end-start)
    if not 0<u<1:return
    roll=.22+.78*u; x=.84+1.59*u;z=-71.-132.*roll
    p=np.array([[x-.66,.68,z],[x+.66,.68,z],[x,.86,z-.13]])
    cam=c['cam'];D=np.linalg.norm(p-cam.pos,axis=1);tr=np.exp(-.0076*D)
    fade=sm(u/.16)*sm((1-u)/.39)
    soft=np.array([[.62,.188,.15],[.59,.182,.143],[.153,.083,.082]],np.float32)
    density=np.array([.62,.59,.18])*tr*fade
    depth_splat(cam,c['plate'],p,np.array([.195,.18,.51]),density,soft,lin,anis=np.array([.71,.73,.55]),maxalpha=.26,additive=True)

class Autumn:
    def __init__(self):
        rc.set_font_fallback()
        _,self.shot,self.c=rc.setup('autumn')
        self.pa=rc.Palette('autumn');self.palette=self.pa.rgb
        self.sway=Sway(self.c['plate'],self.c['cam'],'autumn')
        # Keep luminaire geometry stationary; its beam changes only where the leaves filter it.
        yyg,xxg=np.mgrid[:180,:320]
        self.lamp_core=np.zeros((180,320),np.float32)
        for xg,yg in [(124.7,46.4),(177.9,66.1)]:
            self.lamp_core=np.maximum(self.lamp_core,np.exp(-((xxg+.5-xg)**2+(yyg+.5-yg)**2)/(2*2.45**2))*.92)
        self.leaves=RollingLeaves(self.c);self.vendor=Vendor(self.c)
        yy,xx=np.mgrid[:180,:320];self.sky_full=self.shot.sky(self.c['cam'].dirs(xx.ravel()+.5,yy.ravel()+.5).astype(np.float32)).reshape(180,320,3)
        self.positions=[]
        for j in self.c['lv']:
            self.positions.append(j.positions)
            source=j.positions
            def move(p,source=source):
                P,f=source(p);t=(p%1.)*T
                k=flow(t)
                P[:,0]+=k*(.71+.31*np.sin(P[:,2]*.07+P[:,1]*.29))
                P[:,1]+=k*.095*np.sin(P[:,0]*.60+P[:,2]*.21-t)
                return P,f
            j.positions=move
        self.info={'tea_anchor':[float(x) for x in self.c['cam'].project(self.c['tea_at'])[:2]],'vendor_roi':self.vendor.clip,
                   'gust_window_s':[3.12,8.74],'leaf_roll_count':self.leaves.n,'bird_count':2,
                   'leaf_world_length_range_m':[float(self.leaves.lens.min()),float(self.leaves.lens.max())]}
    def frame(self,t,omit=()):
        t=t%T;p=t/T; c=self.c
        from dynamic_fx import finer_particles
        tv,kiosk,lamp=prev.lamps(p)
        wind=flow(t)
        b=c['plate']['layers']
        # Warm dapple's coefficient uses exactly the incident wind front and subtle aperture hysteresis.
        dapple=wind*.13*(.34+.66*sin(1.90*t+.9))
        l=lamp+dapple
        out=c['sky']+b[0]+l*b[self.shot.G_LAMP]+kiosk*b[self.shot.G_KIOSK]
        out+=b[self.shot.G_TV]*(tv*np.array([.9,1.,1.2],np.float32))[None,None]
        fl=gaussian_filter(out*c['cov'][...,None],(.93,.93,0))/c['denom']
        out+=(fl-out)*c['weights'][...,None]
        if 'canopy' not in omit:
            wind_look,delta,shift=self.sway.at(out,t,self.sky_full)
            out=wind_look+(out-wind_look)*self.lamp_core[...,None]
            # Leaves crossing the already positioned lamp aperture change the local halo, not the wall's color.
            aperture=gaussian_filter(delta,3.1)
            np.clip(aperture,-.19,.19,out=aperture)
            out-=aperture[...,None]*b[self.shot.G_LAMP]*.46
        if 'traffic' not in omit:traffic(out,c,t)
        if 'leaves' not in omit:self.leaves.draw(out,t,1.+dapple)
        if 'vendor' not in omit:self.vendor.draw(out,t)
        if 'steam' not in omit:volume_plume(c['cam'],c['plate'],t,c['tea_at'],'tea',out,wind)
        if 'birds' not in omit:sky_birds(out,c,t)
        lights=[(q['pos'],q['color']*(l if q['grp']==self.shot.G_LAMP else 1.0)*.4,.9,q['axis'],q['cone']) for q in c['lamps']]
        for j,a in enumerate((.64,.74,.75)):finer_particles(c['lv'][j],out,p,c['amb']*(1.04 if j==2 else 1),lights,a)
        x,y,_,_=c['lamp_px']
        for i,q in enumerate(c['lamps']):
            lamp_local=l if q['grp']==self.shot.G_LAMP else 1.+dapple*.59
            fx.glow(out,x[i],y[i],q['color']*.012*lamp_local,r0=2.4,power=1.3)
        return self.pa.map(fx.bloom(out,thresh=.5,sig=(1.2,4.5),gain=(.28,.2)),self.shot.GRADE)
