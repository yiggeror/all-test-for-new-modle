"""Physical summer cue schedule. Geometry in metres and time in seconds; one 11 s cycle."""
import math
import numpy as np

FPS=30
COUNT=330
PERIOD=11.0
CUTS=((192,197,.22),(204,209,.24),(216,220,.21),(229,234,.235))
# Exact warm impact anchors fit the original eave and preserve the approved dry/reverb timing.
LIP=((.77,3.06,2.116,.78),(2.53,4.90,2.133,1.0),(3.12,2.75,2.103,.69),
     (4.35,5.12,2.112,.96),(5.24,3.67,2.112,.51),(6.36,4.25,2.126,.61),
     (7.87,4.94,2.128,1.0),(9.13,3.22,2.105,.57),(10.42,5.24,2.128,.69))

def ease(x):
    z=np.clip(x,0.,1.)
    return z*z*z*(10+z*(6*z-15))

def unit(v):
    v=np.asarray(v)
    return v/np.maximum(np.linalg.norm(v,axis=-1,keepdims=True),1.e-7)

def neon_gain(frame_no):
    ii=int(frame_no)%COUNT
    for a,b,g in CUTS:
        if a<=ii<b:
            return g
    return 1.0

def moving_light(t):
    """A not-in-frame twin-lamp source. Forward approach then left turn; no vehicle mesh."""
    s=float(t)%PERIOD
    approach=min(s,2.76)
    angle=np.clip((s-2.76)*.835,0.,2.21)
    R=4.05
    x=7.60-R*(1-np.cos(angle))
    z=-7.18+3.40*approach+R*np.sin(angle)
    aim=unit(np.array([-np.sin(angle),-.087,np.cos(angle)],np.float32))
    # In/out intensity only fades the lens at the physically unseen start/exit, not successive tiles.
    weight=float(ease((s-.63)/.86)*ease((5.79-s)/.88))
    return np.array([x,.64,z],np.float32),aim,weight

def cone_amount(outward,axis,outer,inner):
    angular=np.sum(np.asarray(outward)*np.asarray(axis),axis=-1)
    u=np.clip((angular-outer)/(inner-outer),0.,1.)
    return u*u*(3-2*u)

def tube_light(t):
    # Only one single-voltage notch independent of the four red sign cuts.
    p=(float(t)-8.63)%PERIOD
    return 1.0-.225*float(ease(p/.021)*ease((.135-p)/.058))

def roof_drop(at,x,z,intensity,t):
    life=.693
    left=(at-t)%PERIOD
    q=np.clip((life-left)/life,0.,1.)
    p=np.asarray([x+.064*q,.153+2.337*(1-q*q),z+.037*q])
    tail=p+np.asarray([-.009,.026+.115*q*q,-.005])
    opacity=float(intensity*ease(q/.10)*ease((1-q)/.074)) if left<=life else 0.
    return tail,p,opacity


class RainImpacts:
    """Independent raindrop events in ground metres; propagating slope of finite damped capillary fronts."""
    def __init__(self,x,z,events):
        self.shape=x.shape
        self.rows=[]
        x=np.asarray(x,np.float32).ravel();z=np.asarray(z,np.float32).ravel()
        for at,ex,ez,life,strength in events:
            dx=x-ex;dz=z-ez
            idx=np.flatnonzero(dx*dx+dz*dz < (.60*life+.18)**2)
            if not len(idx):
                continue
            r=np.sqrt(dx[idx]**2+dz[idx]**2)
            inv=1/np.maximum(r,.02)
            self.rows.append((at,life,strength,idx,r,dx[idx]*inv,dz[idx]*inv))
    def slope(self,t):
        sx=np.zeros(np.prod(self.shape),np.float32)
        sz=np.zeros_like(sx);crest=np.zeros_like(sx)
        for at,life,strength,i,r,ux,uz in self.rows:
            a=(t-at)%PERIOD
            if a>=life:
                continue
            amp=strength*ease(a/.065)*ease((life-a)/(.54*life))*np.exp(-1.76*a)
            edge=(r-(.029+.58*a))/(.046+.027*a)
            h=np.exp(-.62*edge*edge)
            push=amp*np.sin(edge*1.9)*h
            sx[i]+=push*ux
            sz[i]+=push*uz
            crest[i]+=amp*h*np.maximum(.32+.68*np.cos(2.20*edge),0.)*.62
        return sx.reshape(self.shape),sz.reshape(self.shape),crest.reshape(self.shape)
