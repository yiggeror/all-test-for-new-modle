"""Movable shadowed light transport through a locked scene. No image translates."""
import numpy as np
from engine.render import surface, fog_T
from engine.props import TAG_GROUND
from engine.noise import fbm2
from engine.world import MASK_NOSHADOW,srgb
from summer_motion import moving_light, cone_amount, unit
from shots import summer_world_gate15 as sc

H,W=180,320
BEAM_COLOR=np.asarray(srgb('#fae0b8'),np.float32)
BEAM_CONE=(.748,.956)

def lamps(t):
    p,d,g=moving_light(t)
    side=np.asarray([d[2],0.,-d[0]],np.float32)
    return [(p+side*(.56*i),d,g*(1.03 if i<0 else .91)) for i in (-1,1)]

class Headlights:
    """Sample per-subpixel Bsdf, material color and cast shadow at 31 real 3D emitter locations."""
    def __init__(self,world,cam,acc,samples=2):
        self.s=samples
        g=world.finalize()
        o,ray=cam.rays(samples,np.random.default_rng(665))
        td,ci=acc.closest(o,ray)
        ii=np.flatnonzero(ci>=0)
        p=o[ii]+ray[ii]*td[ii,None]
        pick=(p[:,0]>-7.2)&(p[:,0]<17.7)&(p[:,1]<3.30)&(p[:,1]>.005-0.028)&(p[:,2]>-11.5)&(p[:,2]<16.3)
        ii=ii[pick]; self.p=p[pick]
        self.ray=ray[ii]
        sf=surface(world,g,ci[ii],self.p,self.ray,td[ii])
        sc.HOOK(sf,acc,None)
        self.n=sf['N'].astype(np.float32)
        self.v=-self.ray
        self.alb=sf['alb']
        self.fog=fog_T(sc.FOG,o[ii],self.p,td[ii])
        street=sf['tag']==TAG_GROUND
        self.street=street
        qx,qz=self.p[:,0],self.p[:,2]
        speckle=fbm2(qx*5.4,qz*5.9,607,3)
        self.spec_w=np.where(street,.21+.25*speckle,.36).astype(np.float32)
        self.f0=np.where(street,.043+.023*speckle,np.clip(sf['refl'],.025,.19))
        self.power=np.where(street,16.+11*speckle,np.where(sf['refl']>.07,37.,14.)).astype(np.float32)
        ww=W*samples
        self.pidx=(ii//ww//samples*W+(ii%ww)//samples).astype(np.int32)
        self.depth_idx=ii
        self.acc=acc

    def shade(self,t):
        p,n,v=self.p,self.n,self.v
        pos=(p+n*.008).astype(np.float32)
        result=np.zeros((len(p),3),np.float32)
        for lamp,di,g in lamps(t):
            if g<1.e-6:
                continue
            L=lamp-pos
            d2=np.einsum('ij,ij->i',L,L)
            distance=np.sqrt(d2)
            L=L/np.maximum(distance[:,None],1.e-5)
            cos=np.clip(np.einsum('ij,ij->i',n,L),0.,1.)
            cone=cone_amount(-L,di,*BEAM_CONE)
            cone=cone+.133*cone_amount(-L,di,.35,.83)*(1-cone)
            # A low-beam projector is horizontally broad and rolls off softly above the hood line.
            lobe=np.exp(-.57*((-L[:,1]-di[1])/.170)**2)
            reach=np.clip((26-distance)/8.5,0.,1.)
            flux=9.2*g*cone*lobe*reach/(d2+2.45)
            h=unit(L+v)
            nh=np.clip(np.einsum('ij,ij->i',n,h),0.,1.)
            vh=np.clip(np.einsum('ij,ij->i',v,h),0.,1.)
            vr=self.f0+(1-self.f0)*.55*(1-vh)**5
            spec=(nh**self.power)*vr*self.spec_w
            act=np.flatnonzero((flux>.00009)&(cos>.0004))
            if not len(act):
                continue
            blocked=self.acc.anyhit(pos[act],L[act].astype(np.float32),np.maximum(distance[act]-.032,.02).astype(np.float32),
                                    mask=MASK_NOSHADOW)
            hits=act[~blocked]
            if len(hits):
                i=hits
                diffuse=self.alb[i]*(cos[i]*np.where(self.street[i],1.23,.92))[:,None]
                color=(diffuse+spec[i,None])*BEAM_COLOR[None]
                result[i]+= (color*flux[i,None]*self.fog[i,None]).astype(np.float32)
        rgb=np.zeros((H*W,3),np.float32)
        for ch in range(3):
            rgb[:,ch]=np.bincount(self.pidx,weights=result[:,ch],minlength=H*W)
        return rgb.reshape(H,W,3)/(self.s**2)

    def bake(self):
        phase=np.linspace(.63,5.79,31)
        field=np.stack([self.shade(t) for t in phase])
        return phase,field


def lerp_field(t,cache):
    x,val=cache
    if t<=x[0] or t>=x[-1]:
        return np.zeros_like(val[0])
    j=np.searchsorted(x,t)-1
    u=float((t-x[j])/(x[j+1]-x[j]))
    return val[j]*(1-u)+val[j+1]*u
