# Gate 2.2 夏 · 从 3D 复现

这里是夏季独立源，重建不读取 v2.1 画面、旧缓存、网络资产或成片。开发基线为本仓库已评审 Gate 2 源包 `previews/gate_2/source/gate2_summer_winter_source_qa.zip`，Git blob `b31db69db3e740574521759935c581803ea4fc15`（见 Round 9 审批树 `4c06e29619b2efa6ed8c4f9b75888417d91a4bb7`）。真实 3D 引擎和街景源已随包。环境：Linux x86-64，Python 3.12.14，NumPy 2.3.5，SciPy 1.17.0，Pillow 13.0.0，Numba 0.65.1，FFmpeg 7.1.5 + libx264，Noto CJK。使用 `fonts-noto-cjk` 的 SC 字面，或原细明体/楷体字体。

在本源码包解压后的根目录：
```bash
python -m pip install -r requirements.txt
python -m unittest -v test_summer
NUMBA_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 python render_summer.py --out out
python encode.py --out out --threads 2
python split_parts.py out/summer_loop.mp4 staged
```

输出 330 原生 RGB 帧 `out/summer_native.npy`，两组完全相同的 11 秒原件 `out/summer_loop.mp4`、兼容审阅版 `out/mobile/summer_loop.mp4`、原件实解码峰值 PNG 与逐帧核查 JSON。原件是 320×180 精确 6× 放大后 H.264 QP0 / yuv420p / BT.709；第二周期不重复补上首尾帧。接缝先测原生 RGB 再测 660 帧同源 YUV 字节。审阅版仅用于手机播放。FFmpeg/x264 版本不同，封装 SHA 可以不同。

## 物理要点

- 固定审批机位、原小店、红车、天空色与接触阴影。没有猫、躲雨人或截取自旧片的区域；柜前能看到的形体是原货架、凳及 21 厘米真几何壶。壶盖蒸汽为深度遮挡的暖光半透明散射体积，不是白线。
- 一次画外双灯真实移动进深巷、转向道路再扫红车。以 31 个物理灯位传输位置，逐亚像素按场景表面法线、材质、距离、雾与 BVH 阴影分别求值，再在相邻时刻做光能插值，无全画面增亮或滑动像素片。
- 网吧反光对着实际灯牌的发光区域做湿路微面元半向量计算。路面凹湿与颗粒使用世界米制；局部落雨产生独立圆形阻尼波，只扰动在其传播半径内的沥青法线与高光，不产生重复长条。灯牌与砖墙真实光组、湿地镜面接收同一个帧增益，锁定 [192,197)、[204,209)、[216,220)、[229,234) 四段 22%/24%/21%/23.5%。
- 主街雨滴按远、中、近三个真实深度层、受可见灯与暗处遮挡；檐滴以同一世界坐标撞上 15cm 人行道，落点产生局部暖半环。保留三色理发灯实际柱面旋转、蓝电视和一次独立荧光微闪。
