# 梧桐黄昏 · Gate 2.6 秋景合包

- 少女肩背靠定原树干，脚下接地。暖边色由原报刊亭与街灯照出，脸不画亮五官；轻抬手做一次翻页，发丝体积与树冠、地面共用阵风周期。
- 秋冠仅从同深度真实叶片借一个整数像素，平面斜线权重降至极小，多个尺度的空间扰动打散前沿。原树干、停驻灯位、原暖光地面投影时序锁定。
- 人行道底板不再平移。独立世界坐标叶片沿真实步道着地、错拍翻面或短滑，接地投影另算。斑马线卷叶、88 枚天叶、茶汽、归鸟和灯光沿用已发布版。
- 原地貌与锁定层可逐帧复核；旧与新都关闭已改的三处动态后，渲染结果逐像素相同。

## 可复算

环境：Linux Python 3.12，pip install -r requirements.txt，FFmpeg / ffprobe，Noto CJK（报刊亭字体在固定旧 asset 中被调用）。仓库保留 previews/gate_2/source/spring_autumn_source.zip、previews/gate_2_3/source/autumn_winter_v23.zip、tools/gate3/native_fingerprints.json。校验器读取固定版本和逆色板映射，并拒绝不匹配的冻结源。人物资产无远程调用。

    export OPENBLAS_NUM_THREADS=1 NUMBA_NUM_THREADS=2
    python render25.py --repo /repo --work /tmp/autumn26 --phase picture
    python render25.py --repo /repo --work /tmp/autumn26 --phase reader-preview
    python render25.py --repo /repo --work /tmp/autumn26 --phase compat
    python proof_girl26.py --repo /repo --work /tmp/autumn26
    python proof_wind26.py --repo /repo --work /tmp/autumn26

风与路面校验器独立锁定 v2.5 的 330 帧公共底板 RGB 摘要（旧人物、影、旧树冠、旧地面积叶关闭）；如有原始复算对照，还可用 --common-reference 指向其 NPZ。场景原生 320×180、30fps；正本 6× 最近邻、BT.709 yuv420p、x264 无损 QP0/veryslow、两个 330 帧周期，总 22 秒。publish/autumn_parts.json 给出按顺序直接拼接的至多 8,000,000 字节分片与 SHA256。手机审片为独立兼容编码，不是无损复原源。
