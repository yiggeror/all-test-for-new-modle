"""Organic crown advection and independently projected pavement leaves."""
import numpy as np
from scipy.ndimage import binary_dilation
from engine.noise import fbm2
from autumn23 import FixedAutumn, fx, in_poly, paint_leaf, sm
from wind25 import CrownWind, N, STEPS, X, Y, peer


def gust(n):
    t=(int(n)%N)//5/STEPS
    def pulse(center,width):
        d=(t-center+.5)%1.-.5
        return np.exp(-.5*(d/width)**2)
    return float(.12+.79*pulse(.47,.092)+.40*pulse(.77,.060)+.25*pulse(.16,.052))


class OrganicCrown(CrownWind):
    """One integer tap at most, with spatially warped phases and loose gusts."""
    def __init__(self,b,lin,fixtures):
        super().__init__(b,lin,fixtures)
        # Dapple retains the exact v2.5 light clock; foliage uses its own new phase field.
        x=X.astype(float); y=Y.astype(float)
        u=fbm2(x/80+9,y/51-3,317,4,lac=1.92,gain=.50)-.5
        v=fbm2(x/55-2,y/80+2,761,4,lac=1.90,gain=.48)-.5
        eddy=fbm2((x+25*u)/43,(y+23*v)/39,2113,4,lac=1.92,gain=.42)-.5
        minor=fbm2(x/29-5,y/27+3,967,3,lac=1.87,gain=.41)-.5
        lag=.00120*x-.00065*y+2.05*eddy+1.16*u+.68*v+.36*minor
        phase=2*np.pi*(np.arange(STEPS)/STEPS)[:,None,None]
        q=np.sin(phase*3+2*np.pi*lag + .43*np.sin(phase*2+7*v)+.18*np.sin(phase*5+10*u))
        self.moves.fill(0)
        vertical=np.sin(phase+6*v+8*minor)>.59
        direction=np.zeros(q.shape,np.uint8)
        for front,h,vv in ((q>0,1,3),(q<0,2,4)):
            direction[front&self.donors[h]]=h
            direction[front&self.donors[vv]&(vertical|~self.donors[h])]=vv
        optical=fx.bloom(lin,thresh=.50,sig=(1.2,4.5),gain=(.28,.20))
        palette=FixedAutumn()
        neutral=palette.quantize(optical)
        # Calibrate each side by the ordered phase field at the fixed palette, not by
        # spraying arbitrary pixels until the curve reaches its count.
        changes=np.stack([np.zeros(X.shape,bool)]+[
            np.any(palette.quantize(optical+(peer(lin,j)-lin))!=neutral,axis=2)
            for j in range(1,5)])
        for k,field in enumerate(q):
            mag=np.abs(field)
            visible=np.take_along_axis(changes,direction[k][None],axis=0)[0]
            for side in self.rois:
                target=round(int(side.sum())*(.094+.052*gust(5*k)))
                possible=mag[side&visible&(direction[k]>0)]
                cut=np.partition(possible,-target)[-target]
                hits=side&(mag>=cut)
                self.moves[k,hits]=direction[k,hits]
        self.organic_pressure=q.astype(np.float32)


class GroundLeaves:
    """Only leaf geometry and soft contact shadows change; there is no pavement resampler."""
    palette=np.array([[.94,.61,.29],[.75,.37,.19],[.87,.52,.22],[.66,.28,.16]])
    def __init__(self,owner):
        self.a=owner
        b=owner.b
        pos=b['P']; xx,yy,zz=pos.transpose(2,0,1)
        al=b['alb']
        warm=(al[...,0]>.15)&(al[...,0]>1.16*al[...,1])&(al[...,1]>1.18*al[...,2])
        hard=binary_dilation((b['tag5']>.02)|(b.get('tag6',0.)>.02),iterations=1)
        walk=((b['N'][...,1]>.81)&(np.abs(yy-.15)<.028)&(np.abs(xx)>5.0)
              &(np.abs(xx)<11.5)&(Y>136)&(Y<176)&~hard&~((X>=43)&(X<=68)&(Y>=133)))
        self.bedding=walk&warm
        self.tracks=[]
        rng=np.random.default_rng(18829)
        spots=((15,166),(20,162),(26,151),(31,169),(36,156),(42,174),(74,151),(84,154),(88,170),(95,152),(110,174),
               (208,153),(218,143),(223,164),(232,151),(241,167),(252,153),(264,161),(277,155),(287,170),(299,154),(307,168))
        for j,(x,y) in enumerate(spots):
            d=(X-x)**2+1.55*(Y-y)**2
            free=self.bedding.copy(); side='left' if j<11 else 'right'
            free&=(X<160) if side=='left' else (X>=160)
            for q in self.tracks:
                sx,sy=q['seed_xy'];free&=(X-sx)**2+(Y-sy)**2>5**2
            pix=np.unravel_index(np.argmin(np.where(free,d,np.inf)),d.shape)
            if not free[pix]:raise ValueError('No visible leaf bedding')
            py,px=pix
            p=pos[pix].astype(float); p[1]=.153
            xa,ya,*_=owner.cam.project(p)
            scales=[]
            for axis in ([1,0,0],[0,0,1]):
                xb,yb,*_=owner.cam.project(p+.10*np.array(axis))
                scales.append(float(np.hypot(xb-xa,yb-ya))/.10)
            length=rng.uniform(1.70,1.98)/max(scales)
            dest=p.copy(); dist=0.
            if j%2==0 or j in (5,15):
                goal=float(rng.uniform(4.,10.1)); best=100.
                for equator in rng.permutation(16):
                    angle=float(equator/16*2*np.pi)
                    for f in (1.,1.23,.83,.66):
                        v=np.array([np.cos(angle),0.,np.sin(angle)])*goal*f/max(scales)
                        pp=p+v
                        pp[1]=p[1]
                        samples=np.array([p+k*v for k in (.22,.42,.66,.83,1.)])
                        ex,ey,*_=owner.cam.project(samples)
                        ix=np.floor(ex).astype(int);iy=np.floor(ey).astype(int)
                        if np.any((ix<1)|(ix>318)|(iy<136)|(iy>175)):continue
                        if not np.all(walk[iy,ix]):continue
                        reach=float(np.hypot(ex[-1]-xa,ey[-1]-ya))
                        if not 3.<=reach<=12.:continue
                        # Both sides follow the right-going gust, with different gutter deflections.
                        cost=(reach-goal)**2+1.6*(ex[-1]<xa)+.1*abs(ey[-1]-ya)
                        if cost<best:best=cost;dest=pp;dist=reach
            start=(95+((j*37+13)%105))//5*5
            duration=(25,35,40,45)[j%4]
            if j%4==1:start=max(30,start-55)
            if j%5==2:start=(185+((j*7)%24))//5*5
            ret=245+5*(j%7)
            self.tracks.append(dict(id=f'G{j+1:02}',side=side,seed_xy=(int(px),int(py)),source=p,
                end=dest,distance_px=dist,start_f=start,duration_f=duration,return_f=ret,length=float(length),
                yaw=float(rng.uniform(0.,2*np.pi)), flip=float(rng.uniform(.65,1.32)),
                height=float(rng.uniform(.047,.092)),color=j%len(self.palette)))

    def states(self,n):
        f=(int(n)%N)//5*5
        for r in self.tracks:
            u=(f-r['start_f'])/r['duration_f']
            v=(f-r['return_f'])/(30+5*(r['color']%3))
            a=float(sm((u-.08)/.80)); c=float(sm(v))
            path=a*(1-c)
            delta=r['end']-r['source']; pos=r['source']+path*delta
            # The weaker tail gust moves in reverse along a shallow return arc, never teleports.
            pos[2]+=.14*delta[0]*np.sin(np.pi*c)
            kick=(np.sin(np.pi*np.clip(u,0.,1.))**2)*(0.62+.38*gust(f))
            brake=.45*np.sin(np.pi*np.clip(v,0.,1.))**2 if r['distance_px'] else 0.
            pos[1]+=r['height']*(kick+brake)
            turn=r['flip']*(kick*np.cos(8*u)+brake)
            yaw=r['yaw']+.83*path+.55*kick*np.sin(7.2*u)
            yield r,pos,yaw,turn,kick+brake

    def draw_blade(self, out, p, blade, pigment, lift):
        cam,b=self.a.cam,self.a.b
        xs,ys,ds,zs=cam.project(np.vstack([p,p+blade]))
        if zs[0]<5:return
        # At the native lattice a projected blade is sampled at each pixel center,
        # as well as the four fractional rays used for its antialias coverage.
        x,y=xs[1:]-xs[0]+np.floor(xs[0])+.5,ys[1:]-ys[0]+np.floor(ys[0])+.5
        lo=max(0,int(np.floor(x.min())));hi=min(320,int(np.ceil(x.max()))+1)
        top=max(0,int(np.floor(y.min())));bottom=min(180,int(np.ceil(y.max()))+1)
        if hi<=lo or bottom<=top:return
        yy,xx=np.mgrid[top:bottom,lo:hi]
        silhouette=np.stack([x,y],1)
        center=in_poly(xx+.5,yy+.5,silhouette)
        frac=sum(in_poly(xx+u,yy+v,silhouette).astype(float)
                 for u,v in ((.26,.26),(.26,.74),(.74,.26),(.74,.74)))*.25
        # The world ray depth, not an overlaid sprite mask, determines whether it is visible.
        visible=(b['depth'][top:bottom,lo:hi]>ds[0]-.048).mean(2)
        coverage=np.maximum(.82*center,frac)*visible
        a=(coverage*(.86+.12*lift))[...,None]
        dst=out[top:bottom,lo:hi]
        dst+=(pigment-dst)*a

    def draw(self,out,n):
        cam,b=self.a.cam,self.a.b
        for r,p,yaw,flip,kick in self.states(n):
            cy,sy=np.cos(yaw),np.sin(yaw)
            cx,sx=np.cos(flip),np.sin(flip)
            g=np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]])@np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]])
            edge=(self.a.leaves.pattern*r['length'])@g.T
            xx,yy,*_=cam.project(p)
            x,y=np.clip(np.floor((xx,yy)).astype(int),(0,0),(319,179))
            base=out[y,x].copy()
            # Pigment follows nearby actual lighting, not a uniformly colored overlay.
            col=self.palette[r['color']]; lum=np.dot(base,[.52,.35,.13])
            pigment=col*lum/max(.15,np.dot(col,[.52,.35,.13]))
            # Backlit warm ochre catches on the lift; its underside reads rusty or brown.
            tone=(1.18,.79,.85,.72)[r['color']]+(.21,.51,.37,.32)[r['color']]*kick
            if r['distance_px']:
                tone*=1.11 if r['color'] in (0,2) else .93
            tint=(.30*base+.70*pigment)*tone
            contact=p.copy();contact[1]=.153
            paint_leaf(out,cam,b,contact,edge,tint,.15+.085*kick,True)
            self.draw_blade(out,p,edge,tint,kick)
