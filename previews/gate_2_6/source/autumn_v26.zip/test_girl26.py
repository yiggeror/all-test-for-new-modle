"""Gate 2.6 regressions: grounded tree lean, close shoes, original phase wind, visible folding."""
import sys, os, unittest
import numpy as np
if 'AUTUMN_FIXTURES' in os.environ:
    sys.path[:0]=os.environ['AUTUMN_FIXTURES'].split(os.pathsep)
from reader25 import make_girl,ankle_sites

class Geometry26(unittest.TestCase):
    def test_narrow_grounded_stance_and_soft_silhouette(self):
        for foot in ankle_sites():
            self.assertEqual(foot[1],0.)
        self.assertLess(np.linalg.norm(np.subtract(*ankle_sites())),.20)
        world,m=make_girl(0,np.array([-6.70,.15,5.39]),0.0)
        a=world.finalize();p=np.vstack((a['v0'],a['v1'],a['v2']))
        self.assertTrue(1.60<=p[:,1].max()-.15<=1.63)
        self.assertTrue(8.0<=m['back_lean_deg']<=12.0)
        self.assertLess(m['gaze_direction'][1],-.36)
    def test_fixed_roots_flexible_distal_only(self):
        base=np.array([-6.7,.15,5.39])
        W,A=make_girl(28,base,-.75); V,B=make_girl(28,base,.75)
        self.assertTrue(np.allclose(A['hair_roots'],B['hair_roots']))
        self.assertGreater(np.linalg.norm(np.asarray(A['hair_tips'])-np.asarray(B['hair_tips'])),.15)
        self.assertTrue(np.allclose(A['feet'],B['feet']))
    def test_single_continuous_inverse_kinematic_branch_and_bone_lengths(self):
        origin=np.array([-6.734,.15,5.39])
        g=[make_girl(k,origin,0)[1]['turn_arm'] for k in range(67)]
        c=np.asarray(g)
        self.assertTrue(np.allclose(np.linalg.norm(c[:,0]-c[:,1],axis=1),.244))
        self.assertTrue(np.allclose(np.linalg.norm(c[:,1]-c[:,2],axis=1),.248))
        self.assertLess(np.linalg.norm(c[:-1,1]-c[1:,1],axis=1).max(),.13)
        self.assertTrue(np.array_equal(c[0],c[-1]))
    def test_one_live_turn(self):
        p=np.array([-6.7,.15,5.39])
        events=[make_girl(k,p,0.)[1] for k in (0,24,27,29,31,33,36,40,66)]
        self.assertFalse(events[0]['paper_turn'])
        self.assertTrue(events[3]['paper_turn'])
        self.assertFalse(events[7]['paper_turn'])
        Y=[m['page_tip_world'][1] for m in events]
        self.assertGreater(max(Y)-Y[0],.07)
        self.assertEqual(events[0]['page_tip_world'],events[-1]['page_tip_world'])

if __name__=='__main__':unittest.main()
