"""Independent figure invariants, true control view, and complete v2.5 beat-regression."""
from pathlib import Path
import argparse,hashlib,json,sys,subprocess,tempfile,zipfile
import numpy as np
from PIL import Image,ImageDraw
from render25 import setup,sha,zip_source,still
N=330
OFF_SHA='f1e5117e6b01445289b5f501ef16ff40abbcd3bb2e991750a84150e90a556f67'
R19_ZIP='d9ce041832ef9fbc90b5776fb0e246b3de0f3b46c08f7e6ba00b9f1eb83cbfe7'

def jwrite(path,d):
    def convert(x):
        if isinstance(x,np.generic):
            return x.item()
        raise TypeError(type(x).__name__)
    path.write_text(json.dumps(d,ensure_ascii=False,allow_nan=False,indent=2,default=convert)+'\n')

def toe_offset(scene,v):
    start=v.copy();start[:,1]=.71
    d,h=scene.acc.closest(start,np.broadcast_to([0,-1.,0],v.shape))
    assert (h>=0).all()
    ground=start[:,1]-d
    return v[:,1]-ground

def nearest_tri(q,t):
    # Distance to the finite triangle: perpendicular projection if inside, three line segments otherwise.
    A,B,C=t
    ab=B-A;ac=C-A;ap=q-A
    z=np.cross(ab,ac)
    m=np.linalg.norm(z,axis=1);nz=m>1e-9
    z=z/np.maximum(m[:,None],1e-9)
    off=(ap*z).sum(1);flat=q-z*off[:,None]
    dot=lambda x,y:(x*y).sum(1)
    same=(dot(np.cross(ab,flat-A),z)>=-1e-8)&(dot(np.cross(C-B,flat-B),z)>=-1e-8)&(dot(np.cross(A-C,flat-C),z)>=-1e-8)&nz
    d=np.where(same,np.abs(off),np.inf)
    for a,b in ((A,B),(B,C),(C,A)):
        e=b-a;u=np.clip(dot(q-a,e)/np.maximum(dot(e,e),1e-9),0.,1.)
        d=np.minimum(d,np.linalg.norm(q-(a+e*u[:,None]),axis=1))
    return float(d.min())

def boxes(m,offset=(0,0)):
    j,i=np.where(m)
    return None if not len(i) else [int(i.min()+offset[0]),int(j.min()+offset[1]),int(i.max()+offset[0]),int(j.max()+offset[1])]

def image_grid(out,rows,crop=(41,127,66,164),cols=8):
    x,y,X,Y=crop;w=(X-x)*4;h=(Y-y)*4
    im=Image.new('RGB',(cols*(w+4),((-len(rows))//cols*-1)*(h+20)),(35,30,33))
    d=ImageDraw.Draw(im)
    for i,(a,caption) in enumerate(rows):
        x0=(i%cols)*(w+4);y0=(i//cols)*(h+20)
        q=Image.fromarray(a[y:Y,x:X]).resize((w,h),Image.Resampling.NEAREST)
        im.paste(q,(x0,y0))
        d.text((x0+2,y0+h+1),caption,fill='#eee2ca')
    im.save(out)

def prove(a,native,qa,out,baseline):
    from reader25 import make_girl,PARTS,PAPER_TAGS,HAIR_TIP,BOUNDS,BarkMount
    combined=hasattr(a.wind,"organic_pressure")
    if not combined and (baseline is None or sha(baseline)!=OFF_SHA):
        raise ValueError('Provide the actual original v2.5 330-frame reader/cast-off control')
    old=np.load(baseline,mmap_mode='r') if not combined else None
    if old is not None:assert old.shape==(N,180,320,3)
    # A true render bypass of body and all its direct and ground cast, not a crop/erase patch.
    diffs=[]
    h=hashlib.sha256()
    indices=(0,45,50,95,105,125,140,145,150,155,160,165,170,175,180,190,195,200,220,285,329)
    phases_off={}
    for n in range(N):
        q=a.frame(n,omit=('reader','reader_shadow'))
        h.update(q.tobytes())
        if old is not None:diffs.append(int(np.any(old[n]!=q,axis=2).sum()))
        if n in indices:phases_off[n]=q
    assert sum(diffs)==0
    jwrite(qa/'autumn_girl_actor_off_control.json',dict(old_control_npy_sha256=None if combined else OFF_SHA,
           old_source_release_zip_sha256=R19_ZIP,scope='reader + reader_shadow disabled in production entry',
           new_raw_rgb_sha256=h.hexdigest(),frames_verified=N,
           native_differing_pixels_by_frame=diffs,round22c_separate_common_control=combined))
    r=a.reader;x0,y0,x1,y1=BOUNDS
    m=r.mount
    samples=[];taglist=[];founds=[];casts=[];hoff=[];wind_diffs=[]
    snap={}
    hard_street=(a.b['tag28']>.5)
    leftmag=hard_street.copy();leftmag[:,44:]=False
    sign=np.zeros((180,320),bool)
    sign[111:121,27:57]=a.b['tag4'][111:121,27:57]>.17
    fixed_trunk=(a.b['tag5']>.05)
    bearing=m.contact_actor
    # Camera-space motion is measured from the same physical tips with wind set to zero at current head phase.
    def screen(p):
        x,y,*_=a.cam.project(np.asarray(p))
        return np.stack((x,y),axis=-1)
    for n in range(0,N,5):
        k=n//5
        v=r.get(n)
        w,meta=make_girl(k,r.origin,r.wind[k]);g=w.finalize()
        F=g['F']['tag'][g['tf']]
        tri=np.stack([g[t] for t in ('v0','v1','v2')])
        # Test original triangle vertices, midsides and interior; no reliance on author anchor.
        probe=np.concatenate((np.vstack(tri),(tri[0]+tri[1])*.5,(tri[1]+tri[2])*.5,(tri[2]+tri[0])*.5,tri.mean(0)))
        bx=BarkMount.bark_x(m.mesh,probe)
        clear=float(np.min(bx-probe[:,0]))
        assert clear>=-0.001,(n,clear)
        height=float(tri[...,1].max()-.15)
        assert 1.595<=height<=1.63,(n,height)
        feet=[]
        for code in (133,134):
            p=np.vstack(tri[:,F==code]);d=toe_offset(a,p)
            feet.append(dict(tag=code,distance_to_ground_m=float(d.min()),native_xy=screen(np.vstack(tri[:,F==code])).mean(0).tolist()))
            assert -.001<d.min()<.001
        xz=np.linalg.norm(np.asarray(meta['feet'][0])-meta['feet'][1])
        assert xz<.20
        offhair=a.frame(n,omit=('hair_tip',))
        hdelta=np.any(native[n]!=offhair,axis=2)
        # True on/off removal of the 3D distal curves acts under depth and composition.
        pp=np.isin(F,PAPER_TAGS)
        hand_hold=nearest_tri(np.array(meta['static_arm'][3]),tri[:,pp])
        hand_turn=nearest_tri(np.array(meta['turn_arm'][3]),tri[:,pp])
        assert hand_hold<.010 and (not meta['paper_turn'] or hand_turn<.010),(n,hand_hold,hand_turn)
        hit=v.coverage>.34
        book=np.isin(v.parts,PAPER_TAGS).mean(2)>.13
        bodybox=boxes(hit,(x0,y0));bookbox=boxes(book,(x0,y0))
        assert bodybox is not None and bookbox is not None
        blocked=int(np.count_nonzero(hit&(leftmag|sign)[y0:y1,x0:x1]))
        assert blocked==0,(n,blocked)
        footprofile=screen(meta['feet'])
        _,neutral=make_girl(k,r.origin,0.)
        hair_px=screen(meta['hair_tips'])
        hair_neutral=screen(neutral['hair_tips'])
        df=hair_px-hair_neutral
        phase=dict(frame=n,**v.meta,native_body_xy=bodybox,native_book_xy=bookbox,
            vertex_height_m=height,tree_penetration_check_min_clearance_m=clear,foot_contacts=feet,
            foot_center_offsets_px=(footprofile[1]-footprofile[0]).tolist(),
            hair_tip_xy=hair_px.tolist(),hair_motion_same_phase_neutral_dxdy=df.tolist(),
            projected_bark_contact_xy=screen(bearing).tolist(),mount_contact_real_m=float(m.clearance),
            paper_tip_xy=screen(meta['page_tip_world']).tolist(),
            nearest_hand_to_page_m=[hand_hold,hand_turn],hair_tip_ON_OFF_actual_rgb_pixels=int(hdelta.sum()),
            whole_rgb_cast_scope_px=int((v.lamp_shadow>.03).sum()),
            protected_left_shelf_and_sign_occlusion_native_pixels=blocked,
            visible_tag_ray_counts=v.part_counts)
        samples.append(phase);taglist.append(v.parts);founds.append(v.contact);casts.append(v.lamp_shadow);wind_diffs.append(hdelta)
        if n in (45,50,90,105,125,140,145,150,155,160,165,170,175,180,190,200,220,285):snap[n]=offhair
    assert np.array_equal(native[0],a.frame(330))
    max_x=max(abs(z[0]) for q in samples for z in q['hair_motion_same_phase_neutral_dxdy'])
    assert 0.90<=max_x<=2.2,max_x
    labels=np.stack(taglist)
    actor=labels.max(0)>0
    jwrite(qa/'autumn_girl_66_physical_poses.json',dict(
           native_px_to_real_scale=1,verified_pose_count=66,hold_frames=5,full_recurrence=True,
           mount_keep_clearance_min_m=min(p['tree_penetration_check_min_clearance_m'] for p in samples),
           projected_hair_tip_max_abs_x_px=max_x,
           true_moving_page_raster_poses=[p['frame'] for p in samples if p['visible_tag_ray_counts']['turning_page']>0],
           peak_hair_frame=max(samples,key=lambda q:max(abs(x[0]) for x in q['hair_motion_same_phase_neutral_dxdy']))['frame'],
           poses=samples))
    np.savez_compressed(qa/'autumn_girl_physical_masks.npz',
        raw_first_hit_tags_66=labels,
        seven_area_light_shadow_66=np.stack(casts),short_ao_66=np.stack(founds),
        hair_distal_only_true_onoff=np.stack(wind_diffs),bounds=BOUNDS,
        fixture_trunk_tag_a=fixed_trunk,shelf_physical_tag_a=hard_street)
    np.savez_compressed(qa/'autumn_girl_scope_ab.npz',samples=indices,
        raw_on=np.stack([native[n,120:169,34:76] for n in indices]),
        reader_and_shadow_off=np.stack([phases_off[n][120:169,34:76] for n in indices]),
        sample_full_native_off_raw_sha=h.hexdigest(),
        native_crop=(34,120,76,169),
        hair_samples=np.array(list(snap)),hair_distal_off=np.stack([snap[n][120:169,34:76] for n in snap]))
    image_grid(qa/'autumn_girl_turn_every_frame_4x.png',[(native[n],f'F{n:03d} {n/30:.2f}s') for n in range(125,200)],cols=10)
    peak=max(samples,key=lambda q:max(abs(x[0]) for x in q['hair_motion_same_phase_neutral_dxdy']))['frame']
    image_grid(qa/'autumn_girl_hair_contiguous_4x.png',[(native[n],f'F{n:03d} {n/30:.2f}s') for n in range(max(0,peak-14),min(N,peak+16))],(45,128,59,152),cols=10)
    pair=[]
    for f in (45,90,125,145,155,165,175,190):
        q=snap[f]
        pair.extend(((native[f],f'F{f} ON'),(q,f'F{f} tips OFF')))
    image_grid(qa/'autumn_girl_hair_A_B_4x.png',pair,(44,128,59,152),cols=8)
    still(out/'autumn_loop.mp4',peak,out/f'autumn_girl_hair_peak_f{peak:03}_1080p.png')
    print('Same-phase actor control rendered on',N,'frames; max hair displacement',max_x,'native px',flush=True)
    return samples

def main():
    x=argparse.ArgumentParser(description=__doc__)
    x.add_argument('--repo',type=Path,required=True);x.add_argument('--work',type=Path,required=True)
    lock=x.add_mutually_exclusive_group()
    lock.add_argument('--baseline-off',type=Path);lock.add_argument('--baseline-v25-zip',type=Path)
    x.add_argument('--candidate-cache',type=Path,default=None)
    z=x.parse_args();w=z.work.resolve();o=w/'out';q=w/'qa';q.mkdir(exist_ok=True,parents=True)
    setup(z.repo.resolve(),w)
    from autumn25 import AutumnV25
    s=AutumnV25(z.candidate_cache)
    a=np.load(o/'autumn_native.npy',mmap_mode='r')
    if z.baseline_off:
        prove(s,a,q,o,z.baseline_off.resolve())
    elif z.baseline_v25_zip:
        if sha(z.baseline_v25_zip)!=R19_ZIP:raise ValueError('Wrong v2.5 official autonomous final source')
        with tempfile.TemporaryDirectory(dir=w,prefix='proof_v25_') as t:
            work=Path(t);old=work/'src';old.mkdir()
            with zipfile.ZipFile(z.baseline_v25_zip) as zz:zz.extractall(old)
            out=work/'v25_off.npy'
            engine=w/'base/spring_autumn_gate2/src';portable=w/'basis_23'
            cmd="\n".join(("from pathlib import Path","import sys","sys.path[:0]=sys.argv[1:4]",
                   "from autumn25 import AutumnV25","from proof_reader19 import off_seq",
                   "off_seq(AutumnV25(),Path(sys.argv[4]))"))
            subprocess.run([sys.executable,'-c',cmd,str(old),str(engine),str(portable),str(out)],check=True)
            prove(s,a,q,o,out)
    else:
        prove(s,a,q,o,None)
    zip_source(o)

if __name__=='__main__':main()
