"""Gate 2.5 autumn, using the locked 3D street and fixed 60-color autumn palette."""
from pathlib import Path
from dataclasses import dataclass
import copy
import numpy as np
from scipy.ndimage import gaussian_filter
from autumn23 import FixedAutumn,Leaves,font,shot,ray,fx,sm,dusk_birds,tea_vapor,T
from wind25 import GroundDapple,N
from wind26 import OrganicCrown,GroundLeaves,gust
from reader25 import Reader
from foliage25 import build_air

GROUPS=('lamp','kiosk','tv','crown','dapple','pavement','rolling','reader','reader_shadow','air44','air_add','steam','birds')
EVENTS=((203,208,.201),(217,221,.168))

def fixture_gains(n):
    # Exactly the approved v2.4 autumn ballast/tube/CRT function.
    n=int(n)%N;p=n/N
    nominal=1.+.025*(2.*fx.loopnoise(p,23,5)-1.)
    edge=nominal
    for a,b,d in EVENTS:
        if a<=n<b:edge=nominal*(1.-d)
    kiosk=1.+.02*(2*fx.stepnoise(p,29,71)-1.)
    flick=1.+.086*(2*fx.loopnoise(p,19,17)-1.)
    hue=(2*fx.loopnoise(p,9,47)-1.)
    tv=flick*np.array([1.+.045*hue,1.,1.-.064*hue],np.float32)
    return dict(lamp=float(edge),nominal_lamp=float(nominal),kiosk=float(kiosk),tv=tv)

class AutumnV25:
    def __init__(self,plate_cache=None):
        font();fx.SC=320/480
        self.cam=shot.camera(320,180)
        self.world=world=shot.build(tea_offset=(.60,0.,.40))
        if plate_cache is not None and Path(plate_cache).is_file():
            with np.load(plate_cache,allow_pickle=False) as f:b=dict(f)
            g=world.finalize()
            acc=ray.Accel(g['v0'],g['v1'],g['v2'],g['tm'])
        else:
            b,acc=ray.render(world,self.cam,shot.sky,S=3,**shot.RENDER)
            if plate_cache is not None:np.savez_compressed(plate_cache,**b)
        fx.denoise(b,**shot.DENOISE)
        b['lights']=world.lights
        self.b=b;self.acc=acc;self.pa=FixedAutumn()
        self.tea=np.asarray(world.chim[0])+np.array([.027,.023,.065])
        self.lamps=sorted((v for v in b['lights'] if v.get('kind')=='point' and 'axis' in v),
                          key=lambda L:np.linalg.norm(L['pos']-self.cam.pos))[:6]
        self.leaves=Leaves(self.cam,b,self.lamps)
        self.air,self.air_info=build_air(self,world,acc)
        self.air44=copy.copy(self.air); self.add_air=copy.copy(self.air)
        self.air44.air=self.air.air[:44];self.add_air.air=self.air.air[44:]
        L=b['layers']
        lin=fx.native_sky(shot,self.cam,180,320)*b['sky'][...,None]+L[0]
        lamp=.99749*L[shot.G_LAMP]
        near=.98923*L[shot.G_KIOSK]
        tv=L[shot.G_TV]*(np.array([.9,1.,1.2],np.float32)*1.092835)
        # Match the original floating-point grouping exactly at palette decision boundaries.
        lin+=lamp+near
        lin+=tv
        cov=b['tag1'];den=gaussian_filter(cov,.78)
        def local_blend(layer,w):
            fc=gaussian_filter(layer*cov[...,None],(.78,.78,0))/np.maximum(den[...,None],1e-6)
            return layer+(fc-layer)*w[...,None]
        # Locked v2.3 static preparation and v2.4 grouped radiometry, no old wind animation.
        w=.52*sm((cov-.56)/.40)*sm((den-.37)/.41)
        lin=local_blend(lin,w)
        p=np.clip((cov-.56)/.40,0,1);g=np.clip((den-.37)/.41,0,1)
        wo=.52*p**2*(3-2*p);wo*=g*g*(3-2*g)
        self.lamp_r=local_blend(lamp,wo);self.tube_r=local_blend(near,wo);self.tv_r=local_blend(tv,wo)
        x,y,*_=self.cam.project(np.array([q['pos'] for q in self.lamps])+[0.,.15,0.])
        for i,q in enumerate(self.lamps):
            fx.glow(lin,x[i],y[i],q['color']*.012,r0=2.4,power=1.3)
            if q['grp']==shot.G_LAMP:
                fx.glow(self.lamp_r,x[i],y[i],q['color']*.012,r0=2.4,power=1.3)
        self.static=lin
        self.wind=OrganicCrown(b,lin,zip(x,y))
        self.dapple=GroundDapple(b,lin,self.lamps,self.wind)
        self.floor=GroundLeaves(self)
        self.reader=Reader(self.cam,world,acc,b,self.wind.organic_pressure,wind_envelope=np.array([gust(f) for f in range(0,N,5)]))

    def leaf_layer(self,layer,lin,t,plate,road=False):
        # Locked moving leaf runner with actual depth including the real foreground reader.
        if layer.b is plate:
            layer.draw(lin,t,road)
        else:
            q=copy.copy(layer);q.b=plate;q.draw(lin,t,road)

    def frame(self,n,*,omit=(),only=None,linear=False):
        n=int(n)%N;t=n/30.
        on=set(GROUPS if only is None else only).difference(omit)
        gs=fixture_gains(n)
        lin=self.static.copy()
        if 'lamp' in on:lin+=self.lamp_r*(gs['lamp']-1.)
        if 'kiosk' in on:lin+=self.tube_r*(gs['kiosk']-1.)
        if 'tv' in on:lin+=self.tv_r*(gs['tv']-1.)
        ray_base=lin.copy() if 'crown' in on else None
        if 'dapple' in on:self.dapple.draw(lin,n)
        if 'pavement' in on:self.floor.draw(lin,n)
        if 'rolling' in on:self.leaf_layer(self.leaves,lin,t,self.b,True)
        plate=self.b
        if on.intersection({'reader','reader_shadow'}):
            no_paper='paper' in omit; no_hair_tip='hair_tip' in omit
            self.reader.draw(lin,n,gs,self.tube_r,'reader_shadow' in on,'reader' in on,no_paper,no_hair_tip)
            if 'reader' in on and on.intersection({'air44','air_add'}):
                s=self.reader.get(n,no_paper,no_hair_tip);plate=dict(self.b);plate['depth']=dep=self.b['depth'].copy()
                r=dep[self.reader.ys,self.reader.xs];m=s.coverage>0
                r[m]=s.primary_depth[m]
        if 'air44' in on:self.leaf_layer(self.air44,lin,t,plate)
        if 'air_add' in on:self.leaf_layer(self.add_air,lin,t,plate)
        if 'steam' in on:tea_vapor(lin,self.cam,self.b,self.tea,t)
        if 'birds' in on:dusk_birds(lin,self.b,t)
        optical=fx.bloom(lin,thresh=.50,sig=(1.2,4.5),gain=(.28,.20))
        if ray_base is not None:
            # Subpixel optical bloom belongs to the real fixed fixtures. Do not let wind blur
            # or shift those lights, twigs or roof edges. A crossing 3D leaf occludes the crown.
            occluded=np.any(np.abs(lin-ray_base)>1e-7,axis=2)
            moved=self.wind.apply(ray_base,n);dh=moved-ray_base;dh[occluded]=0
            optical+=dh
        return optical if linear else self.pa.quantize(optical)
