"""Real triangle release sites and two leaf strata, with original road rolls untouched."""
import copy
import numpy as np
from engine import props
from engine.world import roty,srgb,MASK_HIDDEN
from autumn23 import paint_leaf,sm,T
from wind25 import Y,X

def legacy_extra(owner):
    # v2.4 deterministic sites recovered before snapping to exact centre-ray triangles.
    rng=np.random.default_rng(2423);b=owner.b
    pos,depth=b['P'],b['depth'][...,4];air0=owner.leaves.air;rows=[]
    for side in (-1,1):
        qty=22-sum(row[0]*side>0 for row in air0)
        belong=((X>17)&(X<150)) if side<0 else ((X>170)&(X<303))
        p=pos[...,0]*side
        m=belong&(b['tag1']>.9)&(b['tag5']<.05)&(pos[...,1]>6.15)&(pos[...,1]<9.85)
        m&=(p>2.25)&(p<8.8)&(depth>17.)&(depth<48.)&(Y>5)&(Y<84)
        choices=np.argwhere(m);rng.shuffle(choices);pick=[]
        for y,x in choices:
            if len(pick)>=qty:break
            if any((x-q)**2+(y-r)**2<69 for r,q in pick):continue
            pick.append((int(y),int(x)))
        if len(pick)!=qty:raise ValueError('Original airborne schedule could not be recovered')
        for i,(y,x) in enumerate(pick):
            p=pos[y,x].astype(float).copy();p[1]-=.013
            length=rng.uniform(.137,.218) if depth[y,x]<33 else rng.uniform(.158,.233)
            begin=(1.15+i*3.095+(2.01 if side>0 else 0.))%T
            life=rng.uniform(4.02,7.18);dx=rng.uniform(.58,1.78);dz=rng.uniform(-.71,1.06)
            dy=-np.clip(.67*p[1]+rng.uniform(.05,1.08),4.6,7.15)
            rows.append((p[0],p[2],p[1],length,begin,life,dx,dz,dy,0.,0.,
                         rng.uniform(0.,2*np.pi),rng.uniform(.65,1.50),rng.integers(0,len(owner.leaves.colors))))
    return rows

def escape(owner,p,delta):
    # Score whether this site reaches open air at several positions rather than dying behind its crown.
    u=np.array((.23,.38,.53,.71,.84))
    q=p[None]+u[:,None]*delta[None]
    x,y,d,_=owner.cam.project(q);xi=np.clip(np.floor(x).astype(int),0,319);yi=np.clip(np.floor(y).astype(int),0,179)
    v=(owner.b['depth'][yi,xi]>(d[:,None]-.04)).mean(1)
    return float(np.sum(v*(x>1)*(x<318)*(y>1)*(y<153)))

def build_air(owner,world,acc):
    cam=owner.cam;b=owner.b
    sel=(b['tag1']>=.79)&(b['tag5']<.06)&(Y>=6)&(Y<=91)&(X>9)&(X<310)
    ys,xs=np.where(sel)
    d=cam.dirs(xs+.5,ys+.5).astype(np.float32);o=np.broadcast_to(cam.pos.astype(np.float32),d.shape)
    dep,tri=acc.closest(o,d,mask=MASK_HIDDEN)
    g=world.finalize();tags=g['F']['tag'][g['tf'][np.maximum(tri,0)]]
    p=o+d*dep[:,None]
    ok=(tri>=0)&(tags==props.TAG_FOLIAGE)&(p[:,1]>5.7)&(p[:,1]<10.7)&(dep>18.)&(dep<76.)
    ok&=(np.abs(p[:,0])>1.95)&(np.abs(p[:,0])<10.0)
    ok&=((xs<155)&(p[:,0]<0))|((xs>164)&(p[:,0]>0))
    p,ys,xs,dep,tri=[q[ok] for q in (p,ys,xs,dep,tri)]
    rows=[];meta=[];used=set();rng=np.random.default_rng(6285)
    def register(j,r,desc):
        pp=p[j].astype(float)
        # Surface point verified against a single actual triangle, not the mixed native-pixel P.
        # The first infinitesimal bit of separating motion follows from gravity in Leaves.draw.
        delta=np.array([r[6],r[8],r[7]])
        rows.append((float(pp[0]),float(pp[2]),float(pp[1]),*r[3:]))
        depth=float(dep[j]);side='left' if pp[0]<0 else 'right'
        code='near' if depth<25.5 else 'mid' if depth<39. else 'far'
        meta.append(dict(id=f'A{len(rows)-1:02d}',side=side,tag=int(props.TAG_FOLIAGE),stratum=code,
                         seed_world_xyz=pp.tolist(),seed_native_xy=[int(xs[j]),int(ys[j])],
                         mesh_triangle=int(tri[j]),distance_m=depth,release_s=float(r[4]),
                         duration_s=float(r[5]),physical_length_m=float(r[3]),source_history=desc,
                         sample_clear_line_escape=escape(owner,pp,delta)))
        used.add(j)
    prior=owner.leaves.air+legacy_extra(owner)
    for uid,r in enumerate(prior):
        source=np.array([r[0],r[2],r[1]])
        distances=np.linalg.norm((p-source)*[1.13,1.4,.79],axis=1)
        distances[p[:,0]*source[0]<=0]=1e6
        for j in used:distances[j]=1e6
        candidates=np.argsort(distances)[:160 if uid<24 else 30]
        delta=np.array([r[6],r[8],r[7]])
        # The v2.4 strict projected anchors remain essentially fixed; allow v2.3 approximate
        # origins to retarget off a deep bough when the original path was hidden.
        best=min(candidates,key=lambda j: float(distances[j])+(2.10 if uid<24 else .12)*(4.4-escape(owner,p[j],delta)))
        register(int(best),r,'v2.3 path/clock/leaf retained; source snapped to true leaf' if uid<24 else
                 'v2.4 path/clock/leaf retained; exact ray on its release surface')
        meta[-1]['pre_snap_world_xyz']=source.tolist()
    for side in (-1,1):
        q=0
        for group,qty in enumerate((8,8,6)):
            strat=((dep<25.5) if group==0 else ((dep>=25.5)&(dep<39.)) if group==1 else (dep>=39.))
            pool=np.where((p[:,0]*side>0)&strat)[0]
            rng.shuffle(pool)
            made=0
            for j in pool:
                d=float(dep[j]);p0=p[j].astype(float)
                if j in used or any((xs[j]-xs[k])**2+(ys[j]-ys[k])**2<24 for k in used):continue
                fall=-np.clip((p0[1]-(2.35 if group==0 else 1.60))*rng.uniform(.79,1.11),3.5,7.6)
                drift=rng.uniform(.75,2.26);toward=rng.uniform(-.68,.97)
                # Both rows respond to the same crosswind with a sideways wobble, not mirrored paths.
                if side>0 and abs(p0[0])>6.6:drift*=-.71
                if escape(owner,p0,np.array([drift,fall,toward]))<(2.20 if group<2 else 2.65):continue
                L=rng.uniform(*((.135,.211),(.164,.236),(.181,.255))[group])
                age=(1.41+q*2.713+(1.23 if side>0 else .00)+rng.uniform(-.29,.29))%T
                life=rng.uniform(4.95,7.56)-group*.15
                r=(0.,0.,0.,L,age,life,drift,toward,fall,0.,0.,rng.uniform(0,2*np.pi),
                   rng.uniform(.65,1.53),rng.integers(0,len(owner.leaves.colors)))
                register(int(j),r,'new Gate 2.5 true 3D detachable leaf')
                made+=1;q+=1
                if made==qty:break
            if made!=qty:raise ValueError(f'Not enough clear physical anchors: side {side}, stratum {group}: {made}/{qty}')
    assert len(rows)==88 and sum(m['side']=='right' for m in meta)==44
    v=copy.copy(owner.leaves);v.air=rows;v.road=[]
    return v,meta

class PavementLeaves:
    def __init__(self,owner,bed):
        self.a=owner;self.tracks=[]
        rng=np.random.default_rng(12884);self.colors=np.stack([srgb(a) for a in ('#bd7c31','#e3a946','#d8a749','#ca8438')])
        P=owner.b['P'];pool=bed.bedding;nx=np.array([.0,1.,.0])
        # Distinct locations and trigger phases; kept on the two raised pavements.
        spots=((27,155,69),(35,163,152),(78,151,162),(92,158,233),
               (223,150,74),(247,155,148),(277,158,160),(292,167,240))
        for j,(x,y,t0) in enumerate(spots):
            d=((X-x)**2+(Y-y)**2*2.4).astype(float)
            d[~pool]=1e6
            for r in self.tracks:
                sx,sy=r['seed_xy'];d[(X-sx)**2+(Y-sy)**2<8**2]=1e6
            y1,x1=np.unravel_index(np.argmin(d),d.shape)
            if d[y1,x1]>=1e6:raise ValueError(f'No physical leaf bedding near {x,y}')
            pp=P[y1,x1].astype(float);pp[1]=.1505
            # Travel projects one, two or three full pixels; at rest lies again in the same leaf carpet.
            move=np.array([rng.uniform(.094,.163),0.,rng.uniform(-.17,.075)])
            if j in (1,3,4,7):move[0]*=-1.
            p1=pp+move;p1[1]=pp[1]
            xa,ya,*_=owner.cam.project(pp);xb,yb,*_=owner.cam.project(p1)
            distance=float(np.hypot(xb-xa,yb-ya))
            if distance>2.85:
                p1=pp+move*(2.85/distance);xb,yb,*_=owner.cam.project(p1)
            self.tracks.append(dict(id=f'G{j+1}',side='left' if j<4 else 'right',source=pp,end=p1,
                                    seed_xy=[int(x1),int(y1)],distance_px=float(np.hypot(xb-xa,yb-ya)),
                                    start_f=int(t0//5*5),duration_f=(45,55,60,50)[j%4],
                                    length=float(rng.uniform(.105,.160)),height=float(rng.uniform(.027,.059)),
                                    rotation=float(rng.uniform(.0,2*np.pi)),color=j%len(self.colors)))
    def states(self,n):
        for r in self.tracks:
            age=((int(n)%330)//5)*5-r['start_f'];life=r['duration_f'];u=age/life
            # Both ends hold on the exact physical plane. Humps are brief shallow flips.
            path=float(sm((u-.10)/.58))
            v=r['source']+(r['end']-r['source'])*path
            active=float(sm(u/.20)*sm((1-u)/.23))
            if 0.<u<.73:
                jumps=max(0.,np.sin(np.pi*sm((u-.04)/.66)))*(.71+.29*np.sin(9*u+r['rotation'])**2)
                v[1]+=r['height']*jumps
            spin=r['rotation']+np.pi*1.2*path
            flip=.82*np.sin(12.*u+r['rotation'])*active if 0<u<1 else 0.
            sx,sy,d,_=self.a.cam.project(v)
            yield r,v,active,spin,flip,(float(sx),float(sy),float(d))
    def draw(self,out,n):
        for r,v,a,yaw,flip,screen in self.states(n):
            if a<=.015:continue
            cam,b=self.a.cam,self.a.b
            g=roty(yaw);A=np.array([[1,0,0],[0,np.cos(flip),-np.sin(flip)],[0,np.sin(flip),np.cos(flip)]])
            edge=(self.a.leaves.pattern*r['length'])@(g@A).T
            x,y=np.clip(np.floor(screen[:2]).astype(int),(0,0),(319,179))
            col=self.colors[r['color']]
            lt=np.array([.217,.129,.076],np.float32)
            for light in self.a.lamps[:3]:
                vv=light['pos']-v;d=float(vv@vv);d1=np.sqrt(d)
                ca=float((-vv/d1)@light['axis'])
                lt+=light['color']*sm((ca-light['cone'][0])/(light['cone'][1]-light['cone'][0]))/(d+.65)*.68
            natural=col*lt*(.86+.25*np.cos(flip))
            tint=natural*.57+out[y,x]*.43
            p=v.copy();p[1]=.153
            paint_leaf(out,cam,b,p,edge,tint,a*.21,True)
            paint_leaf(out,cam,b,v,edge,tint,a*.83)
