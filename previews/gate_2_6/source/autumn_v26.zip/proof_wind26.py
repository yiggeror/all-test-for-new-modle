"""Prove rendered crown coverage, stable underlying plate, and sparse ground scope."""
import argparse, hashlib, json
from pathlib import Path
import numpy as np
from PIL import Image
from render25 import setup, sha

BASE='de935c2a35442b7fa665ddee0c2cffaa157d91c6593d370476c6695d58754ed3'
COMMON=('reader','reader_shadow','crown','pavement')

def region(masks,area):
    v=(masks&area).sum((1,2));d=int(area.sum());u=int((masks.any(0)&area).sum())
    assert min(v)>=.08*d and max(v)<=.16*d and u>=.70*d,(min(v),max(v),u,d)
    return dict(denominator=d,min_pixels=int(min(v)),max_pixels=int(max(v)),mean_pixels=float(v.mean()),union_pixels=u,
        min_percent=round(100*min(v)/d,5),max_percent=round(100*max(v)/d,5),
        union_percent=round(100*u/d,5),by_frame=v.tolist())

def prove(a,native,out,old=None):
    d=[];ground=[];h=hashlib.sha256();changes=[];gscope=[]
    for f in range(330):
        no=a.frame(f,omit=('crown',))
        gr=a.frame(f,omit=('pavement',))
        shelf=a.frame(f,omit=COMMON)
        dm=np.any(native[f]!=no,axis=2);gm=np.any(native[f]!=gr,axis=2)
        d.append(dm);ground.append(gm)
        h.update(shelf.tobytes())
        if old is not None: changes.append(int(np.any(old[f]!=shelf,axis=2).sum()))
        # High-spread connected movement is incompatible with these isolated physical leaves.
        gscope.append(int(gm.sum()))
        if f%55==0:print(f'Scope/wind F{f:03d}',flush=True)
    d=np.stack(d);ground=np.stack(ground)
    assert h.hexdigest()==BASE and not any(changes)
    assert not np.any(d[:,a.wind.protected])
    assert not np.any(ground[:,:134])
    roi=a.wind.rois
    stat={k:region(d,m) for k,m in [('left',roi[0]),('right',roi[1]),('both',a.wind.physical)]}
    rows=[]
    for q in a.floor.tracks:
        z={k:(v.tolist() if isinstance(v,np.ndarray) else v) for k,v in q.items()}
        z['poses']=[]
        rows.append(z)
    for f in range(0,330,5):
        for (q,pos,yaw,flip,lift), r in zip(a.floor.states(f),rows):
            x,y,*_=a.cam.project(pos)
            r['poses'].append(dict(frame=f,x=float(x),y=float(y),world=pos.tolist(),yaw=float(yaw),flip=float(flip),lift=float(lift)))
    moved=[q['distance_px'] for q in rows if q['distance_px']>0.]
    assert 18<=len(rows)<=24 and min(moved)>=3 and max(moved)<=12
    out.mkdir(exist_ok=True,parents=True)
    (out/'autumn_scope_wind_ground_330.json').write_text(json.dumps(dict(
        controls=COMMON,unchanged_underlying_scene_rgb24_sha256=BASE,common_different_pixels=sum(changes),
        physical_crown_rois=stat,protected_crown_pixels=int(a.wind.protected.sum()),
        protected_crown_changed_pixels=int(d[:,a.wind.protected].sum()),
        ground_pixels_per_frame_range=[min(gscope),max(gscope)],
        mature_ground_leaves=len(rows),translating_ground_leaves=len(moved),tracks=rows),indent=2)+'\n')
    np.savez_compressed(out/'autumn_wind_ground_native_masks.npz',crowns=np.packbits(d,axis=-1),ground=np.packbits(ground,axis=-1),
                        left_roi=roi[0],right_roi=roi[1],protected=a.wind.protected)
    mid=native[155].copy()//3
    heat=d.sum(0);active=heat>0
    mid[active,0]=np.minimum(255,60+6*heat[active])
    mid[active,1]=np.minimum(255,40+4*heat[active])
    mid[active,2]=28
    Image.fromarray(mid).resize((1280,720),Image.Resampling.NEAREST).save(out/'autumn_crown_330_heatmap.png')
    print('Crown',[(k,v['min_percent'],v['max_percent'],v['union_percent']) for k,v in stat.items()],
          'moving ground',len(moved),'stable base',BASE,flush=True)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,required=True);p.add_argument('--work',type=Path,required=True)
    p.add_argument('--candidate-cache',type=Path);p.add_argument('--common-reference',type=Path)
    z=p.parse_args()
    setup(z.repo.resolve(),z.work.resolve())
    from autumn25 import AutumnV25
    q=AutumnV25(z.candidate_cache)
    native=np.load(z.work/'out/autumn_native.npy',mmap_mode='r')
    old=np.load(z.common_reference)['frames'] if z.common_reference else None
    prove(q,native,z.work/'qa',old)

if __name__=='__main__':main()
