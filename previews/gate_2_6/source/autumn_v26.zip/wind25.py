"""Continuous periodic FBM phase over physically tagged foliage; discrete integer donors."""
import numpy as np
from scipy.ndimage import binary_dilation
from engine.noise import fbm2
from autumn23 import sm

N=330
STEPS=N//5
Y,X=np.mgrid[:180,:320]
SHIFTS=((0,0),(0,1),(0,-1),(1,0),(-1,0))

def peer(a,j):
    dy,dx=SHIFTS[j];return np.roll(a,(-dy,-dx),axis=(0,1))

class CrownWind:
    def __init__(self,b,lin,fixtures):
        dep=b['depth'][...,4]
        wood=b['tag5']>.027
        wire=b.get('tag6',np.zeros(X.shape))>.027
        anchors=wood|wire
        for x,y in fixtures:
            anchors|=(X+.5-x)**2+(Y+.5-y)**2<=5.65**2
        self.protected=binary_dilation(anchors,iterations=1)
        # Denominator is all dense visible foliage in the physical crowns, not chosen donors.
        territory=(b['tag1']>=.665)&(b['sky']<.224)&(Y<104)&(X>1)&(X<318)
        self.physical=territory
        self.rois=(territory&(X<160),territory&(X>=160))
        # Source and destination remain inside an existing leaf region and off fixed hard lines.
        inner=(b['tag1']>=.552)&(b['sky']<.155)&(X>0)&(X<319)&(Y>0)&(Y<178)&~self.protected
        domain=territory&inner
        radius=.95+.069*np.minimum(dep,55.)
        self.donors=np.stack([np.zeros(X.shape,bool)]+[
            domain&peer(inner,j)&(np.abs(dep-peer(dep,j))<radius)
            &(np.max(np.abs(lin-peer(lin,j)),axis=2)<.18) for j in range(1,5)])
        self.domain=self.donors.any(0)
        Xf=X.astype(float);Yf=Y.astype(float)
        # A smoothly advected gust front; low-frequency FBM only, no per-pixel RNG/chessboard.
        lag=.0176*Xf-.0106*Yf+.54*(fbm2(Xf/63.,Yf/53.,1258,4,lac=1.82,gain=.39)-.5)
        cross=.61*(fbm2(Xf/79.+4,Yf/57.-6,1263,3,lac=1.9,gain=.41)-.45)
        phase=2*np.pi*(np.arange(STEPS)/STEPS)[:,None,None]
        # Dominant eddies sweep from side to side, with a quarter-period recovery front.
        wave=phase*3+lag[None]*2*np.pi + .19*np.sin(phase*5+cross[None]*6)
        q=np.sin(wave)
        # Direction only. Each site sees both wave directions; one native color tap per active pose.
        threshold=.949
        choose_pos=(q>threshold);choose_neg=(q<-threshold)
        moves=np.zeros(q.shape,np.uint8)
        for front,h,v in ((choose_pos,1,3),(choose_neg,2,4)):
            moves[front&self.donors[h]]=h
            moves[front&~self.donors[h]&self.donors[v]]=v
        self.moves=moves
        self.pressure=q.astype(np.float32)
    def sample(self,n):
        return self.moves[(n%N)//5]
    def apply(self,source,n):
        d=self.sample(n);dst=source.copy()
        for j in range(1,len(SHIFTS)):
            m=d==j;dst[m]=peer(source,j)[m]
        return dst

class GroundDapple:
    """The original four physically lit paving pockets; read the broad local field above them."""
    def __init__(self,b,lin,lamps,wind):
        P=b['P'];xx,yy,zz=P.transpose(2,0,1);Nn=b['N']
        up=(Nn[...,1]>.65)&(yy>-.09)&(yy<.23)&(Y>=112)&(Y<=176)&(b['tag5']<.07)
        sodium=[q for q in lamps if q['color'][0]>q['color'][1]*1.3 and q['grp'] in (0,1)]
        mottle=.42+.58*sm((fbm2(xx*2.55+zz*.41,zz*1.84,445,3)-.32)/.61)
        self.parts=[];self.data=[];self.series=[]
        for j,(cx,cy,wx,wy,canopy) in enumerate(((61,152,15.,7.7,(45,33)),(86,145,12.,7.6,(101,48)),
                                                (232,150,14.,8.4,(215,44)),(250,156,15.,7.5,(264,27)))):
            q=.86*(X-cx)+(Y-cy)*.30;r=(Y-cy)-.23*(X-cx)
            geom=sm((1.-(q/wx)**2-(r/wy)**2)*1.5)
            same=(xx<-4.65)&(xx>-8.6) if j<2 else (xx>4.65)&(xx<8.6)
            mask=geom*same*up*mottle
            lum=np.zeros_like(lin)
            for light in sodium:
                v=light['pos'][None,None]-P;D=np.maximum(.1,(v*v).sum(2));r0=np.sqrt(D);aim=(-v*light['axis']).sum(2)/r0
                cone=sm((aim-light['cone'][0])/(light['cone'][1]-light['cone'][0]))
                lambert=np.maximum(0,(v*Nn).sum(2)/r0)
                loc=(1-sm((r0-11.)/9.))*lambert*cone/(D+.7)
                lum+=b['alb']*light['color']*loc[...,None]
            lum=np.minimum(lum,np.maximum(lin,0.)*np.array([.62,.56,.51],np.float32))
            area=lum*mask[...,None]*(.075+.013*(j%2))
            rx,ry=canopy
            l=(X-rx)**2+(Y-ry)**2<13.**2
            amp=np.clip(wind.pressure[:,l].mean(1)*(1.05 if j%2==0 else -.65),-1,1)
            self.parts.append(area.astype(np.float32));self.series.append(amp)
            self.data.append(dict(paving_xy=[cx,cy],field_xy=list(canopy)))
        self.support=np.any(np.sum(np.abs(self.parts),axis=0)>1e-8,axis=2)
    def draw(self,out,n):
        for patch,signal in zip(self.parts,self.series):
            out+=patch*signal[(n%N)//5]
