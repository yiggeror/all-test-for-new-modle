"""Gate 2.6: girl leaning on surveyed bark, true book, and the locked canopy wind."""
from dataclasses import dataclass
from functools import lru_cache
import numpy as np
from engine import render as rt
from engine.world import World,roty,srgb,_n,MASK_HIDDEN
from engine.rt import Accel

PARTS={131:'coat',132:'skirt',133:'support_boot',134:'relaxed_boot',135:'face_and_neck',
       136:'hair_cap',137:'hair_tips',138:'support_hand',139:'turning_hand',140:'book',
       141:'turning_page',142:'fixed_hair_roots',143:'sleeves',144:'legs',145:'collar'}
PAPER_TAGS=(140,141)
HAIR_TIP=137
HEIGHT=1.616
BOUNDS=(41,122,72,168)
YAW=-1.42
ORIGIN=np.array([-6.716,.15,5.39])
V=np.array([.983,0,.153])
C=np.array([.018,1.192,-.175])
H=np.array([-.002,.873,-.120])
COAT='#9a6e5d'
FOLD='#ac7d64'
SLEEVE='#96695d'
SKIRT='#584955'
HAIR='#533633'
HAIRMID='#77483d'
HAIRLIT='#925c44'
SKIN='#ac806a'

def sigma(u):
    s=np.clip(u,0.,1.);return s*s*(3.-2.*s)

def ankle_sites():
    return [np.array([-.057,0.,.078]),np.array([.047,0.,.208])]

def ball(w,c,r,tag,col,n=12,rot=None):
    M=np.diag(r) if rot is None else rot@np.diag(r)
    with w.at(c,M=M):
        w.sphere((0.,0.,0.),1.,n=n,mat='plain',col=col,tag=tag)

def tube(w,a,b,ra,rb,tag,col,n=8):
    w.tube(a,b,ra,rb,sides=n,mat='plain',col=col,tag=tag,caps=True)

def cloth(w,rings,tag,colors,N=18):
    # Actual 3D cloth shell. Geometric side folds, not painted strips on a flat silhouette.
    t=np.arange(N)*2*np.pi/N
    seq=[]
    for j,(y,cx,cz,rx,rz,cr) in enumerate(rings):
        flex=1.+cr*np.cos(5*t+(.16 if j<2 else .35))
        yy=y+(.013*np.cos(t+.9) if j==0 else 0.)
        seq.append(np.column_stack((cx+rx*flex*np.cos(t),np.broadcast_to(yy,t.shape),cz+rz*flex*np.sin(t))))
    col=([colors[0]]*(N) if len(colors)<2 else [colors[1] if i in (0,1,2,15,16,17) else colors[0] for i in range(N)])
    col=np.stack([srgb(k) for k in col])
    for a,b in zip(seq[:-1],seq[1:]):
        w.quads(a,np.roll(a,-1,axis=0),np.roll(b,-1,axis=0),b,mat='plain',col=col,tag=tag)
    w.poly(seq[0][::-1],mat='plain',col=colors[0],tag=tag)
    w.poly(seq[-1],mat='plain',col=colors[0],tag=tag)

def book_panel(origin,spine,across,width,flex=0.):
    normal=_n(np.cross(across,spine))
    def pos(u,v):
        return origin+across*(width*u)+spine*v+normal*(.007*np.sin(np.pi*u))+[0,flex*u*v,0]
    return pos

def draw_book(w,pos,tag,col,edge=True):
    t=(0.,.11,.39,.72,1.)
    for j,(u,U) in enumerate(zip(t[:-1],t[1:])):
        for v,B in ((0.,.51),(.51,1.)):
            w.quads(pos(u,v),pos(U,v),pos(U,B),pos(u,B),mat='plain',
                    col=col*(.77 if j==0 else (.92 if j==3 and edge else 1.)),tag=tag)

def hair_shape(w,head,q,mat):
    # Sculpted stable head roots and three tapering world-space tresses. Only the distal
    # knots receive the existing 66-pose wind; a physical front strand separates from bark.
    roots=[];tips=[]
    local_sweep=roty(YAW).T@np.array([-.127*q,.062*max(0.,q)+.025*max(0.,-q),.026*q])
    for j,(rx,rz,drop,base,spread) in enumerate(((.095,-.048,.390,.045,1.),
                        (.128,-.072,.310,.030,.83),(.125,.001,.220,.023,1.13),
                        (-.072,-.080,.295,.037,.48))):
        root=head+np.array([rx,.031 if j<2 else -.028,rz])
        fixed=root+np.array([.012*np.sign(rx),-.104 if j!=2 else -.075,.025 if j!=3 else .033])
        mid=root+np.array([-.021 if j<2 else .021,-.67*drop,.070 if j!=2 else .091])+local_sweep*.30*spread
        tip=root+np.array([-.033 if j<2 else .017,-drop,.104 if j!=3 else .101])+local_sweep*spread
        tube(w,root,fixed,base,base*.95,142,mat if j>0 else HAIR,8)
        tube(w,fixed,mid,base*.96,base*.72,HAIR_TIP,mat,8)
        tube(w,mid,tip,base*.74,max(.005,base*.11),HAIR_TIP,HAIRLIT if j in (1,2) else mat,8)
        ball(w,mid,(base*.71,base*.74,base*.72),HAIR_TIP,mat,8)
        roots.append(w.xf(root).tolist());tips.append(w.xf(tip).tolist())
    return roots,tips

def joint_targets(k):
    k=int(k)%66;f=k*5
    nt=np.interp(f,[0,130,138,145,155,163,174,181,329],[0,0,.11,.28,.58,.80,.96,1,1])
    roll=np.pi*sigma(nt);lift=float(np.sin(roll)**1.05)
    follow=np.interp(f,[0,125,140,153,162,177,196,329],[0,0,.16,.58,.93,.52,0,0])
    cm=np.array([.118,.959,.075])+[0,.011*follow,.010*follow]
    spine=np.array([-.013,.170,-.043])
    hr=_n(np.array([.39,.033,.920]));hl=_n(np.array([.010,-.026,-.999]))
    lw,rw=.146,.150
    L=book_panel(cm,spine,hl,lw);R=book_panel(cm,spine,hr,rw)
    axis=_n(spine);normal=_n(np.cross(axis,hr))
    arc=_n(hr*np.cos(roll)+normal*np.sin(roll)+(hl+hr)*((1.-np.cos(roll))*.5))
    P=book_panel(cm+normal*.003*lift,spine,arc,rw,.119*lift)
    active=.015<roll<np.pi-.015
    out=[]
    for side in (-1,1):
        shoulder=np.array([side*.131+.020,1.208,-.165+.012*follow])
        guide=np.array([side*.151+.028,.966,-.060])
        if side<0:
            grip=L(.50,.16)
        elif roll<=.015:
            grip=R(.94,.20+.27*sigma((f-119)/18))
        elif active:
            grip=P(.88,.61+.26*lift)
        else:
            g=sigma((f-176)/22)
            grip=L(.88,.57)*(1.-g)+R(.94,.20)*g
        palm=grip+V*(.068 if side<0 else .042)+[0,-.026,-.010]
        out.append((shoulder,palm,grip,guide))
    return roll,follow,cm,spine,L,R,P,active,out

def arm_circle(shoulder,palm,guide):
    upper=.244; lower=.248
    d=palm-shoulder;dist=float(np.linalg.norm(d))
    if not abs(upper-lower)<dist<upper+lower:
        raise ValueError(f'Unreachable natural arm target: {dist:.5f}')
    u=d/dist;s=(upper**2-lower**2+dist**2)/(2*dist)
    v=_n(guide-shoulder-u*((guide-shoulder)@u))
    tangent=np.cross(u,v);r=np.sqrt(max(0.,upper**2-s**2))
    z=np.arange(144)*2*np.pi/144
    pts=shoulder+s*u+(np.cos(z)[:,None]*v+np.sin(z)[:,None]*tangent)*r
    x=(pts@roty(YAW).T)[:,0]
    admissible=(x<.212)&(pts[:,1]>.889)&(pts[:,1]<1.214)
    if not admissible.any():admissible=x<.212
    if not admissible.any():raise RuntimeError('Arm cannot clear the bearing tree')
    cost=(.34*(np.square(pts-guide).sum(1))+
          .14*np.square(np.maximum(pts[:,1]-1.135,0.)))
    cost[~admissible]=np.inf
    return pts,cost

@lru_cache(maxsize=1)
def linked_elbow_poses():
    # Solve the two-bone mechanism over the whole closed five-frame score.
    # Keeping a linked elbow branch avoids in/out flips in the middle of a subtle hand arc.
    scene=[joint_targets(n)[-1] for n in range(67)]
    tracks=[]
    for side in (0,1):
        opts=[]
        for lu in scene:
            shoulder,palm,grip,guide=lu[side]
            opts.append(arm_circle(shoulder,palm,guide))
        start=int(np.argmin(opts[0][1]))
        weight=np.full(144,np.inf);weight[start]=0.
        back=[]
        for k,((prev,_),(new,prefer)) in enumerate(zip(opts[:-1],opts[1:]),1):
            D=np.square(prev[:,None]-new[None]).sum(2)
            MM=weight[:,None]+8.6*D+prefer[None]
            ii=np.argmin(MM,axis=0)
            weight=MM[ii,np.arange(144)]
            if k<23 or k>=40:
                keep=weight[start];weight[:]=np.inf;weight[start]=keep
            back.append(ii)
        if not np.isfinite(weight[start]):
            raise RuntimeError('No cyclic constant-length arm trajectory')
        idx=[start]
        for link in reversed(back):
            idx.append(int(link[idx[-1]]))
        idx=idx[::-1]
        tracks.append(np.stack([p[j] for (p,_),j in zip(opts,idx)])[:66])
    return np.stack(tracks,axis=1)

def make_girl(k,origin,wind):
    k=int(k)%66; f=k*5
    roll,following,cm,spine,L,R,P,active,grips=joint_targets(k)
    elbows=linked_elbow_poses()[k]
    w=World(seed=419)
    shoes=ankle_sites()
    result={}
    with w.at(origin,yaw=YAW):
        # Asymmetric weight, close feet, a relaxed toe a little forward. Both rest on actual paving.
        for i,t0 in enumerate(shoes):
            tag=133+i
            shoe='#423439' if i==0 else '#594042'
            ankle=t0+[0,.091 if i==0 else .124,-.036 if i==0 else -.031]
            knee=np.array((-.043 if i==0 else .040,.428,-.004 if i==0 else .116))
            pelvis=H+np.array((-.063 if i==0 else .062,-.070,.003))
            tube(w,ankle,knee,.041,.057,144,'#574153' if i else '#46364a')
            tube(w,knee,pelvis,.057,.070,144,'#4c3d4e')
            ball(w,knee,(.055,.068,.060),144,'#51404d',10)
            # Flat base, gently rounded matching instep, genuine heel-toe silhouette.
            if i==0:
                w.box(t0+[0.,.015,.012],(.082,.030,.142),yaw=-.10,mat='plain',col=shoe,tag=tag)
                ball(w,t0+[0.,.042,.041],(.045,.034,.072),tag,shoe)
                ball(w,t0+[0.,.079,-.024],(.046,.067,.054),tag,shoe)
            else:
                w.box(t0+[0.,.015,.039],(.081,.030,.097),yaw=.07,mat='plain',col=shoe,tag=tag)
                ball(w,t0+[0.,.049,.035],(.044,.041,.066),tag,shoe)
                ball(w,t0+[0.,.085,-.020],(.045,.054,.060),tag,shoe)
                # This heel, distinct from the toe's flat grounded sole, remains above paving.
                w.box(t0+[0.,.053,-.036],(.075,.044,.077),yaw=.07,mat='plain',col=shoe,tag=tag)
        cloth(w,((.485,-.007,-.020,.130,.092,.050),(.557,-.010,-.049,.134,.104,.039),
                 (.692,-.007,-.080,.141,.112,.035),(.826,-.004,-.112,.132,.105,.017),
                 (.901,.002,-.125,.127,.098,.012)),132,[SKIRT,'#55434e'])
        # One fixed whole back through the book gesture maintains the bearing contact.
        # Right scapular ridge at local +X gets within ~2 mm of measured bark.
        cloth(w,((.671,-.024,-.076,.157,.110,.033),(.772,-.012,-.107,.151,.113,.040),
                 (.890,.002,-.122,.133,.106,.018),(.991,.011,-.143,.122,.103,.020),
                 (1.075,.016,-.154,.143,.111,.017),(1.170,.022,-.175,.154,.119,.014),
                 (1.239,.014,-.171,.146,.102,.009),(1.292,.012,-.160,.099,.079,.0),
                 (1.329,.015,-.155,.060,.057,0.)),131,[COAT,FOLD])
        # Unobtrusive warm lapel and dark shirt, no screen-line decoration.
        ow=np.array([.005,1.235,-.070])
        for s in (-1.,1.):
            w.poly([ow+(s*.021,.048,-.016),ow+(s*.077,-.014,.012),
                     ow+(s*.043,-.144,.039),ow+(s*.016,-.052,.041)],
                    mat='plain',col='#77584f' if s==-1 else '#694b48',tag=145)
        # A small loose dark-camel knit roll under the hair naturally divides head and coat.
        ball(w,(.044,1.310,-.091),(.079,.036,.063),145,'#906952',12)
        # An open little book, not an oversize glare block. The bindings and narrow cream pages
        # are physical facets, with no faux print or disconnected light spots.
        paper=srgb('#e4d2b0')
        # A dark rust cover, just the real binding silhouette.
        for pos0 in (L,R):
            dz=np.array([.002,-.010,-.003])
            w.quads(pos0(0,0)+dz,pos0(1,0)+dz,pos0(1,1)+dz,pos0(0,1)+dz,
                    mat='plain',col='#7c4b3e',tag=140)
        draw_book(w,L,140,paper*.955);draw_book(w,R,140,paper)
        if active:draw_book(w,P,141,paper*1.025)
        target=(L(.32,.63)+R(.32,.63))*.5
        target=target*(1.-.51*following)+.51*following*P(.72,.68)
        head=np.array([.012,1.492-.010*following,-.112+.014*following])
        look=_n(target-head)
        right=_n(np.cross([0,1.,0.],look));up=np.cross(look,right)
        ball(w,(head+[0,-.087,-.002]),(.057,.073,.056),135,SKIN,12)
        with w.at(head,M=np.column_stack((right,up,look))):
            # Matte face tucked within the hair silhouette. Intentionally no nose, ears, eyes, or
            # high-colour skin accents. Very small difference between shadowed jaw and collar.
            ball(w,(0.,-.008,.014),(.089,.108,.090),135,SKIN,16)
            ball(w,(-.004,.034,-.016),(.107,.098,.092),136,HAIR,16)
            ball(w,(-.060,.017,-.023),(.063,.088,.069),136,HAIR,12)
            ball(w,(.055,.025,-.022),(.065,.088,.078),136,HAIRMID,12)
        roots,tips=hair_shape(w,head,float(wind),HAIRMID)
        for j,s in enumerate((-1,1)):
            shoulder,palm,grip,guide=grips[j]
            el=elbows[j]
            wrist=palm*.82+el*.18
            tube(w,shoulder,el,.066,.054,143,COAT if s<0 else SLEEVE,10)
            ball(w,el,(.055,.062,.055),143,SLEEVE,10)
            tube(w,el,wrist,.054,.039,143,SLEEVE if s<0 else FOLD,10)
            tube(w,wrist,palm,.040,.027,143,'#ae8265' if s>0 else COAT,8)
            tag=138 if s<0 else 139
            ball(w,palm,(.037,.035,.032),tag,SKIN)
            kn=(palm+grip)/2+[0,.005,.005]
            tube(w,palm,kn,.020,.017,tag,SKIN,8)
            tube(w,kn,grip,.017,.010,tag,SKIN,8)
            lbl='static' if s<0 else 'turn'
            result[lbl+'_arm']=[w.xf(q).tolist() for q in (shoulder,el,palm,grip)]
        v=roty(YAW)@(C-H)
        lean=float(np.rad2deg(np.arctan2(np.linalg.norm(v[[0,2]]),v[1])))
        result.update(feet=[w.xf(z).tolist() for z in shoes],
                      back_lean_deg=lean,
                      gaze_direction=w.xd(look).tolist(),head=w.xf(head).tolist(),gaze_target=w.xf(target).tolist(),
                      book_hinge_world=[w.xf(cm).tolist(),w.xf(cm+spine).tolist()],
                      paper_turn=active,turn_angle=float(roll),page_tip_world=w.xf(P(1.,1.)).tolist(),
                      hair_roots=roots,hair_tips=tips,wind=float(wind))
    return w,result

@dataclass
class BarkMount:
    origin: np.ndarray
    mesh: object
    contact_actor: np.ndarray
    contact_bark: np.ndarray
    clearance: float

    @classmethod
    def survey(cls,scene):
        d=scene.finalize()
        tri=np.flatnonzero(d['F']['tag'][d['tf']]==5)
        v=np.stack([d[q][tri] for q in ('v0','v1','v2')])
        c=v.mean(0)
        t=(c[:,0]>-7.1)&(c[:,0]<-4.8)&(c[:,2]>4.)&(c[:,2]<6.85)&(np.max(v[:,:,1],0)>.29)&(np.min(v[:,:,1],0)<1.90)
        if len(np.flatnonzero(t))<6:raise RuntimeError('Second actual tagged plane-tree trunk not found')
        acc=Accel(*v[:,t],d['tm'][tri[t]])
        g,_=make_girl(0,ORIGIN,0.)
        gg=g.finalize()
        tag=gg['F']['tag'][gg['tf']]
        v=np.concatenate([gg[z][tag==131] for z in ('v0','v1','v2')])
        v=v[(v[:,1]>.98)&(v[:,1]<1.46)]
        b=cls.bark_x(acc,v)
        ix=np.where(np.isfinite(b))[0]
        if len(ix)==0:raise RuntimeError('No backed torso vertices on second physical trunk')
        j=int(ix[np.argmin(b[ix]-v[ix,0])])
        delta=float(b[j]-v[j,0])-.0018
        base=ORIGIN.copy();base[0]+=delta
        p=v[j]+[delta,0,0]
        q=p.copy();q[0]=b[j]
        if np.linalg.norm(q-p)>.006:raise RuntimeError('Unseated torso')
        return cls(base,acc,p,q,float(q[0]-p[0]))

    @staticmethod
    def bark_x(acc,v):
        o=v.copy();o[:,0]=-8.2
        dp=np.broadcast_to([1.,0.,0.],v.shape)
        t,j=acc.closest(o,dp)
        return np.where(j>=0,(o[:,0]+t),np.inf)

class Together:
    def __init__(self,a,b):self.a,self.b=a,b
    def anyhit(self,o,d,tmax,mask=0):
        # Both physical acceleration structures participate in direct light visibility.
        s=self.a.anyhit(o,d,tmax,mask)
        if not s.all():
            ii=np.nonzero(~s)[0]
            tm=tmax if np.isscalar(tmax) else tmax[ii]
            s[ii]=self.b.anyhit(o[ii],d[ii],tm,mask)
        return s

@dataclass
class ReaderSample:
    coverage:np.ndarray
    contact:np.ndarray
    incoming:np.ndarray
    lamp_shadow:np.ndarray
    primary_depth:np.ndarray
    parts:np.ndarray
    part_counts:dict
    ground_y:float
    upper_y:float
    meta:dict

class Reader:
    def __init__(self,cam,world,acc,b,pressure,wind_envelope=None):
        self.cam,self.world,self.acc,self.b=cam,world,acc,b
        self.mount=BarkMount.survey(world)
        self.origin=self.mount.origin
        # Same signed FBM actually driving the locked crown, averaged around this tree's bough;
        # the accepted bedding's macro wind envelope weights the exact same 5-frame phase.
        p=np.mean(pressure[:,34:48,49:69],axis=(1,2))
        if wind_envelope is None:
            gg=.5+.5*np.sin(2*np.pi*(np.arange(66)/66*3-.23))
        else:
            gg=np.asarray(wind_envelope,dtype=np.float64)
            if gg.shape==(330,):gg=gg[::5]
            if gg.shape!=(66,) or not np.all(np.isfinite(gg)) or not np.all((gg>=0.)&(gg<=1.)):
                raise ValueError('Expected one shared normalized gust envelope at the 66 held phases')
        self.wind_bough=p
        self.wind_envelope=gg
        self.wind=np.clip(.61*p+.49*p*gg,-1.,1.)
        self.wind[np.abs(self.wind)<.12]*=.63
        x0,y0,x1,y1=BOUNDS;self.ys=slice(y0,y1);self.xs=slice(x0,x1)
        self.shape=(y1-y0,x1-x0)
        yy,xx=np.mgrid[y0:y1,x0:x1]
        # Four-by-four fixed subpixel rays per native cell. Pose holds remain exact.
        oy,ox=np.mgrid[0:4,0:4].reshape(2,-1)
        dv=cam.dirs((xx[...,None]+(.5+ox)/4).ravel(),(yy[...,None]+(.5+oy)/4).ravel()).astype(np.float32)
        self.d=dv;self.o=np.broadcast_to(cam.pos.astype(np.float32),dv.shape).copy()
        self.dist,ti=acc.closest(self.o,dv,mask=MASK_HIDDEN)
        safe=np.maximum(ti,0);g=world.finalize();ntag=g['F']['tag'][g['tf'][safe]]
        nn=g['F']['n'][g['tf'][safe]];self.P=self.o+dv*np.minimum(self.dist,1e3)[:,None]
        # Check existing kiosk sign (upper sign + left mag stand) and actual contact paving.
        self.structure=ntag.reshape(*self.shape,16)
        self.floor=(ti>=0)&(np.abs(nn[:,1])>.82)&(np.abs(self.P[:,1]-.15)<.011)
        self.kiosk=next(q for q in world.lights if q['grp']==3 and 'axis' not in q)
        self.near=[q for q in world.lights if q['kind']=='point' and np.linalg.norm(q['pos']-self.origin)<22.]
        # Integrate diffuse reflected/transmitted light from the actual nearby bright shelf.
        # These are surveyed positions and radiance of the fixed light group, not invented LEDs.
        hit=(b['tag28']>.96)&(np.indices(b['tag28'].shape)[1]<55)
        sc=np.argwhere(hit)
        if len(sc)>=12:
            sc=sc[np.linspace(0,len(sc)-1,12).astype(int)]
        self.panel_pos=b['P'][sc[:,0],sc[:,1]]
        self.panel_irr=b['layers'][3,sc[:,0],sc[:,1]]
        self.samples=np.array(((0,0,0),(.67,0,0),(-.67,0,0),(0,.62,0),(0,-.62,0),(0,0,.61),(0,0,-.61)),np.float32)
        self.fidx=np.where(self.floor&(np.linalg.norm(self.P[:,[0,2]]-self.origin[[0,2]],axis=1)<1.95))[0]
        pp=self.P[self.fidx].copy();pp[:,1]+=.003
        v=self.kiosk['pos'][None,None]+self.kiosk['radius']*self.samples[None]-pp[:,None]
        self.sd=np.linalg.norm(v,axis=2);self.sdir=(v/self.sd[...,None]).reshape(-1,3)
        self.so=np.repeat(pp,len(self.samples),axis=0)
        basevis=~acc.anyhit(self.so,self.sdir,self.sd.ravel()-.005,mask=1)
        self.basevis=basevis.reshape(self.sd.shape)
        self.shadow_weight=np.maximum(self.sdir[:,1],0).reshape(self.sd.shape)/(self.sd**2+.36)
        self.floor_check={}
        for p in make_girl(0,self.origin,self.wind[0])[1]['feet']:
            pp=np.asarray(p,np.float32);o=pp+[0,.045,0];down=np.array([[0.,-1.,0.]])
            floor_t,idx=acc.closest(o[None],down,tmax=.075)
            self.floor_check[str(p)]=float(floor_t[0]-.045) if idx[0]>=0 else None
        # Stable set of hemisphere directions for contact ambient visibility.
        a=np.arange(13)*2.399963;xz=np.sqrt((np.arange(13)+.5)/13)
        self.updirs=np.stack((np.cos(a)*xz,np.sqrt(1-xz*xz),np.sin(a)*xz),axis=1).astype(np.float32)

    def get(self,n,omit_paper=False,omit_hair=False):
        return self._get((int(n)%330)//5,bool(omit_paper),bool(omit_hair))

    @lru_cache(maxsize=132)
    def _get(self,k,omit_paper=False,omit_hair=False):
        w,meta=make_girl(k,self.origin,self.wind[k])
        meta.update(bark_contact_actor=self.mount.contact_actor.tolist(),bark_contact_tree=self.mount.contact_bark.tolist(),
                    mount_clearance_m=self.mount.clearance,mount_origin=self.origin.tolist(),
                    same_bough_fbm_phase=float(self.wind_bough[k]),same_bedding_gust_envelope=float(self.wind_envelope[k]))
        w.pixang=2*self.cam.th/320
        g=w.finalize(); points=np.concatenate((g['v0'],g['v1'],g['v2']))
        meta['mesh_vertices_aabb_m']=[points.min(0).tolist(),points.max(0).tolist()]
        triangle_mask=g['tm'].copy()
        if omit_paper:triangle_mask[np.isin(g['F']['tag'][g['tf']],PAPER_TAGS)]|=MASK_HIDDEN|1
        if omit_hair:triangle_mask[g['F']['tag'][g['tf']]==HAIR_TIP]|=MASK_HIDDEN|1
        acc=Accel(g['v0'],g['v1'],g['v2'],triangle_mask)
        dist,tri=acc.closest(self.o,self.d,tmax=self.dist-.002,mask=MASK_HIDDEN)
        ii=np.where(tri>=0)[0]
        P=self.o[ii]+self.d[ii]*dist[ii,None]
        sf=rt.surface(w,g,tri[ii],P,self.d[ii],dist[ii])
        N=sf['N'];A=sf['alb'];tg=sf['tag'];accpair=Together(self.acc,acc)
        rng=np.random.default_rng(813)
        # Non-emissive material. Sample actual fog, directional sky, same global fixture groups,
        # direct shadow rays from real lamps. Paper reflects from either hemisphere when bent.
        full=rt.direct(self.near,accpair,P,N,rng,4)
        for q in range(3):
            full+=rt.direct(self.near,accpair,P,N,rng,4)
        full*=.25
        ksrc=self.kiosk['pos']-P;dn=np.linalg.norm(ksrc,axis=1)
        ld=ksrc/dn[:,None];face=np.abs((N*ld).sum(1))
        one=accpair.anyhit(P+ld*.004,ld,dn-.006,mask=1)
        pap=np.isin(tg,PAPER_TAGS)
        # Paper thin diffuse transmission restores a little of the kiosk light on the back.
        full[3,pap]+=(~one[pap]*.34*(.14+.86*face[pap])/(dn[pap]**2+.36))[:,None]*self.kiosk['color']
        up=floor_ambient(N)
        full[0]+=up+np.array([.019,.012,.006],np.float32)
        # Low, local diffuse floor reflection only, just separates soft hair from dark coat.
        strand=np.isin(tg,(136,137,142))
        full[0,strand]+=np.array([.029,.016,.011],np.float32)
        # Broad skylight reflected by the lighter paper fibres, never an emissive term.
        full[0,pap]+=np.array([.019,.029,.041],np.float32)
        full*=A[None]
        T=rt.fog_T(__import__('autumn_g15').FOG,self.o[ii],P,dist[ii])
        full*=T[None,:,None]
        full[0]+=(1.-T)[:,None]*__import__('autumn_g15').FOG['color'](self.d[ii])
        sh=np.zeros(len(self.o),np.float32)
        occ=acc.anyhit(self.so,self.sdir,self.sd.ravel()-.005,mask=1).reshape(self.sd.shape)
        wg=self.shadow_weight*self.basevis
        sh[self.fidx]=(wg*occ).sum(1)/np.maximum(wg.sum(1),.001)
        sh[ii]=0.
        pp=self.P[self.fidx].copy();pp[:,1]+=.003
        shadowdir=np.tile(self.updirs,(len(pp),1))
        corn=acc.anyhit(np.repeat(pp,13,axis=0),shadowdir,.41,mask=1).reshape(-1,13)
        cont=np.zeros(len(self.o),np.float32);cont[self.fidx]=corn.mean(1)*.9;cont[ii]=0.
        incoming=np.zeros((4,len(self.o),3),np.float32);incoming[:,ii]=full
        tags=np.zeros(len(self.o),np.uint8);tags[ii]=tg
        # Part tags retain all subpixel labels (no arbitrary display pad or flattening).
        tags=tags.reshape(*self.shape,16)
        vis=np.where(tri>=0,dist,self.dist).reshape(*self.shape,16)
        dep=np.sort(vis,axis=2)[...,np.rint(np.linspace(.5,14.5,9)).astype(int)]
        return ReaderSample((tags>0).mean(2).astype(np.float32),cont.reshape(*self.shape,16).mean(2),
                            incoming.reshape(4,*self.shape,16,3).mean(3),
                            sh.reshape(*self.shape,16).mean(2),dep,tags,
                            {s:int((tags==tag).sum()) for tag,s in PARTS.items()},
                            float(self.origin[1]),float(self.origin[1])+HEIGHT,meta)

    def draw(self,lin,n,gains,near_lit,with_shadows=True,with_body=True,omit_paper=False,omit_hair=False):
        v=self.get(n,omit_paper,omit_hair);sl=lin[self.ys,self.xs]
        if with_shadows:
            sl-=near_lit[self.ys,self.xs]*v.lamp_shadow[...,None]*gains['kiosk']*.84
            sl*=1.-v.contact[...,None]*.34
        if with_body:
            incoming=v.incoming[0]+v.incoming[1]*gains['lamp']+v.incoming[2]*gains['tv']+v.incoming[3]*gains['kiosk']
            sl*=1.-v.coverage[...,None]
            sl+=incoming

def floor_ambient(N):
    # Reflected ochre pavement also reaches underside of dark clothing.
    z=np.clip(N[:,1],-1,1);up=.045+.025*z
    return up[:,None]*np.array((.73,.82,1.03),np.float32)+(.044-.020*z)[:,None]*np.array((1.,.56,.28),np.float32)
