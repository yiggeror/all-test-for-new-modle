from pathlib import Path
import os,argparse,time
os.environ.setdefault('RAINROJI_SOURCE_ROOT',str(Path(__file__).resolve().parent/'basis'))
from spring_scene29 import Scene,palette,pix,H,W,np
from pack import quantize_clip
from PIL import Image
def main():
    a=argparse.ArgumentParser();a.add_argument('--out',type=Path,default=Path('render'))
    a.add_argument('--scout',type=int);a=a.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    s=Scene(); fs=range(331) if a.scout is None else [a.scout];start=time.time();frames=[];old=[]
    for j in fs:
        frames.append(s.render(j)[0]);old.append(s.render(j,exclude='fixture')[0])
        if j%60==0:print('phase',j, 'elapsed',round(time.time()-start,1),flush=True)
    pal=palette();th=pix.threshold_map(H,W,'mix',seed=177)
    for name,seq in [('new',frames),('old',old)]:
        v=quantize_clip(np.asarray(seq),pal,th,.22)
        if len(v)>1:
            assert np.array_equal(v[0],v[-1]); np.save(a.out/(name+'.npy'),v[:-1])
        Image.fromarray(v[0]).save(a.out/(name+'.png'))
    np.save(a.out/'physical_mask.npy',s.fixtures.mask)
if __name__=='__main__':main()
