"""Gate 2.5 spring: frozen yard, continuously visible physical cat loop and whole-crown wind."""
from pathlib import Path
import argparse
import hashlib
import json
import sys

import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter

from spring23 import World, shot, base, ray, fx, pix, make_world, add_cloth, SplitAccel, Accel, MASK_HIDDEN, MASK_NOSHADOW, _n
from preserved24 import FlowerShower, gains, TV_TINT, moth_glints
from wind25 import WindField
from cat25 import mesh, route, PATH_LEN, HOLD, CAT_BODY, CAT_HEAD, CAT_FOOT, CAT_TAIL, CAT_EAR

W,H=320,180
CLOTH_RECT=(241,320,141,180)
TAGS=(CAT_HEAD,CAT_BODY,CAT_FOOT,CAT_TAIL)
APPROVED_CACHE='56eaac84fc312ce2aae7d7980ac0c57cf9ca20c2aca189b669bd40352e3cae85'
CONTROL_PHASES=(0,25,50,75,100,105,115,120,125,130,137,138,141,143,144,145,150,165,175,180,195,225,250,275,305,315,325,329)


def acc(x):
    return Accel(x['v0'],x['v1'],x['v2'],x['tm'])


def stage_world():
    near=[]
    original=base.blossom_tree
    def remember(w,x,z,h,rng,near_tree=False,**kw):
        hero=kw.get('near',near_tree)
        lo=w.nf
        original(w,x,z,h,rng,near=hero)
        if hero:near.extend([lo,w.nf])
    try:
        base.blossom_tree=remember
        w=make_world()
    finally:
        base.blossom_tree=original
    if len(near)!=2:raise RuntimeError('unique main blossom face geometry was not collected')
    return w,tuple(near)


class ClothPass:
    """The Gate2.3 coat-dye, exact 5f meshes and lighting/cast shadow are unchanged."""
    def __init__(self,st,w,pl,cam):
        self.st=st;self.cam=cam;self.pl=pl
        self.centers=[dict(v,radius=0.,soft=0.) for v in w.lights]
        self.lamp=self.centers[0]
        x0,x1,y0,y1=CLOTH_RECT
        s=3
        o,d=cam.rays(s,np.random.default_rng(682))
        select=np.zeros((H*s,W*s),bool);select[y0*s:y1*s,x0*s:x1*s]=True
        i=np.flatnonzero(select.ravel()); self.o,self.d=o[i],d[i]
        self.td,ids=st.closest(self.o,self.d,mask=MASK_HIDDEN);self.td[ids<0]=1e9
        p=pl['P'];gx,gy,gz=p.transpose(2,0,1)
        gr=np.where((gx>7.1)&(gx<12.7)&(gy>-.08)&(gy<.18)&(gz>9.1)&(gz<18.9))
        pa=p[gr].astype(np.float32);pa[:,1]+=.007
        vd=np.array([8.6,2.7,6.2])-pa; dd=np.linalg.norm(vd,axis=1);vd/=dd[:,None]
        self.gr,self.pa,self.vd,self.dd=gr,pa,vd,dd

    def step(self,key):
        o,d,td=self.o,self.d,self.td
        x0,x1,y0,y1=CLOTH_RECT
        c=World(seed=6001);c.pixang=2*self.cam.th/W
        add_cloth(c,key)
        gg=c.finalize();da=acc(gg)
        t,tr=da.closest(o,d,tmax=td,mask=MASK_HIDDEN)
        sel=np.where(tr>=0)[0];q=o[sel]+d[sel]*t[sel,None]
        sf=ray.surface(c,gg,tr[sel],q,d[sel],t[sel])
        E=ray.direct(self.centers,SplitAccel(self.st,da),q,sf['N'],np.random.default_rng(93),base.K)
        E[0]+=np.array([.225,.150,.164])[None]*(.78+.25*np.abs(sf['N'][:,1,None]))
        L=E.sum(0)*sf['alb']
        T=ray.fog_T(shot.RENDER['fog'],o[sel],q,t[sel])
        L=L*T[:,None]+shot.RENDER['fog']['color'](d[sel])*(1-T[:,None])
        def agg(p):
            return p.reshape(y1-y0,3,x1-x0,3,*p.shape[1:]).mean((1,3))
        m=np.zeros(len(td),np.float32);m[sel]=1
        rgb=np.zeros((len(td),3),np.float32);rgb[sel]=L
        shadow=np.zeros((H,W),np.float32)
        shadow[self.gr]=da.anyhit(self.pa,self.vd,self.dd-.03,mask=MASK_NOSHADOW)*.24
        dn=td.copy();dn[sel]=t[sel]
        dep=self.pl['depth'].copy()
        dep[y0:y1,x0:x1]=dn.reshape(y1-y0,3,x1-x0,3).transpose(0,2,1,3).reshape(y1-y0,x1-x0,9)
        parts=np.zeros_like(m);parts[sel]=(sf['tag']==81).astype(np.float32)
        return dict(da=da,cover=agg(m),radiance=agg(rgb),shadow=gaussian_filter(shadow,.42),
                    tal=agg(parts),depth=dep,visible_cloth=int(np.count_nonzero(sf['tag']==81)))


def agg_mask(x,shape):
    return x.reshape(*shape).mean(-1)


def bounds(mask,x0,y0):
    yy,xx=np.where(mask)
    if not len(yy):return None
    return [int(xx.min()+x0),int(yy.min()+y0),int(xx.max()+x0),int(yy.max()+y0)]


class CatPass:
    def __init__(self,w,g,st,cam):
        self.st=st;self.g=g;self.w=w;self.cam=cam
        o,d=cam.rays(4,np.random.default_rng(165216))
        def res(q):
            return q.reshape(H,4,W,4,3).transpose(0,2,1,3,4).reshape(H,W,16,3)
        self.o=res(o);self.d=res(d)
        td,tri=st.closest(o,d,mask=MASK_HIDDEN)
        f=tri>=0
        tags=np.full(tri.shape,-1,int);tags[f]=g['F']['tag'][g['tf'][tri[f]]]
        self.t=td.reshape(H,4,W,4).transpose(0,2,1,3).reshape(H,W,16)
        self.tri=tri.reshape(H,4,W,4).transpose(0,2,1,3).reshape(H,W,16)
        self.tags=tags.reshape(H,4,W,4).transpose(0,2,1,3).reshape(H,W,16)
        self.centers=[dict(v,radius=0.,soft=0.) for v in w.lights]
        self.lamp=next(L for L in self.centers if L['grp']==base.G_LAMP and 'axis' in L)
        self.mat_rev={i:k for k,i in w.mats.items()}

    def check_edges(self,g,off=0.0004):
        # Triangle-spanning edge segments, not just center/point collision probes.
        v=[g[x] for x in ('v0','v1','v2')]
        A=np.concatenate(v)
        B=np.concatenate(v[1:]+v[:1])
        V=B-A
        n=np.linalg.norm(V,axis=1); keep=n>off*4
        D=V[keep]/n[keep,None]
        t,f=self.st.closest(A[keep]+D*off,D,tmax=n[keep]-off*2,mask=MASK_HIDDEN)
        f=f[f>=0]
        return int(np.count_nonzero(self.g['F']['tag'][self.g['tf'][f]]!=base.pr.TAG_GROUND))

    def step(self,key,cloth):
        w,info=mesh(key);w.pixang=2*self.cam.th/W
        g=w.finalize();ca=acc(g)
        v=np.concatenate([g['v0'],g['v1'],g['v2']])
        xx,yy,_,_=self.cam.project(v)
        x0=max(0,int(np.floor(xx.min()))-9); x1=min(W,int(np.ceil(xx.max()))+11)
        y0=max(0,int(np.floor(yy.min()))-5); y1=min(H,int(np.ceil(yy.max()))+11)
        p=(y1-y0,x1-x0,16)
        if not (p[0]>0 and p[1]>0):raise ValueError(('cat completely beyond camera bounds',key,info))
        st=self.t[y0:y1,x0:x1].reshape(-1)
        tri=self.tri[y0:y1,x0:x1].reshape(-1)
        o=self.o[y0:y1,x0:x1].reshape(-1,3)
        d=self.d[y0:y1,x0:x1].reshape(-1,3)
        tc,ic=cloth.closest(o,d,tmax=st,mask=MASK_HIDDEN)
        td=np.minimum(st,tc)
        cat,ci=ca.closest(o,d,mask=MASK_HIDDEN)
        ray_body=ci>=0
        show=ray_body&(cat<td-.0003)
        showidx=np.flatnonzero(show)
        under=np.where(show,cat,td).reshape(p)
        cover=agg_mask(show,p).astype(np.float32)
        a=np.zeros((len(o),3),np.float32)
        b=a.copy()
        ct=np.zeros((4,len(o)),np.float32)
        ears=np.zeros(len(o),np.uint8)
        if len(showidx):
            hit=o[showidx]+cat[showidx,None]*d[showidx]
            sf=ray.surface(w,g,ci[showidx],hit,d[showidx],cat[showidx])
            allacc=SplitAccel(self.st,SplitAccel(cloth,ca))
            E=ray.direct(self.centers,allacc,hit,sf['N'],np.random.default_rng(279),base.K)
            # Diffuse sky facing right: muted dusk, not an emissive outline or palette swap.
            side=.5+.5*sf['N'][:,0]
            wrap=np.stack((.248-.045*side,.169-.004*side,.159+.038*side),1)
            normals=sf['N']
            # Amber diffuse return from lamp-facing upper curves only. Retain quiet
            # fur underneath. Neither an outline nor source emission is added.
            up=np.clip((normals[:,1]-.30)/.70,0,1)
            toward=np.clip(.55-.45*normals[:,0],0,1)
            wrap+= (up*toward)[:,None]*np.array([.052,.030,.010],np.float32)[None]
            E[0]+=wrap*(.59+.52*np.clip(normals[:,1,None]*.5+.5,0,1))
            T=ray.fog_T(shot.RENDER['fog'],o[showidx],hit,cat[showidx])
            a[showidx]=(E[0]+E[base.G_TV])*sf['alb']*T[:,None]+shot.RENDER['fog']['color'](d[showidx])*(1-T[:,None])
            b[showidx]=E[base.G_LAMP]*sf['alb']*T[:,None]
            for c,tag in enumerate(TAGS):ct[c,showidx]=(sf['tag']==tag)
            ear_hits=(sf['tag']==CAT_EAR)
            ears[showidx]=ear_hits
            ct[0,showidx]+=ear_hits  # identical head silhouette/alpha, optional ear subset proof only
        a=a.reshape(*p,3).mean(2);b=b.reshape(*p,3).mean(2)
        c=ct.reshape((4,*p)).sum(-1).astype(np.uint8)
        n_raw=ray_body.reshape(p).sum(-1)
        n_seen=show.reshape(p).sum(-1)
        # Tiny optical silhouettes need clean pixel contours: only firm, already
        # unoccluded geometry gets a stronger per-pixel resolve. Partial wall
        # or cloth occlusion is NEVER overridden, including emergence/exit.
        all_clear=(n_raw==n_seen)&(n_seen>0)
        alpha=cover.copy()
        main_s=c[:3].sum(0)
        alpha[all_clear & (main_s>=5)] = np.maximum(cover[all_clear & (main_s>=5)], .73)
        alpha[all_clear & (c[3]>=3)] = np.maximum(alpha[all_clear & (c[3]>=3)], .58)
        sig=alpha/np.maximum(cover,1e-5)
        a*=sig[...,None]; b*=sig[...,None]
        shadow_direct=np.zeros(len(o),np.float32)
        shadow_contact=np.zeros_like(shadow_direct)
        visible_ground=(self.tags[y0:y1,x0:x1].reshape(-1)==base.pr.TAG_GROUND)&(ic<0)
        gid=np.flatnonzero(visible_ground)
        if len(gid):
            spt=o[gid]+st[gid,None]*d[gid]
            spt[:,1]+=.004
            # Visible true geometric ground only; integrate light over the original emitter area.
            for off in ((-.13,0,-.08),(.13,0,-.08),(-.09,0,.105),(.10,0,.105)):
                vv=self.lamp['pos']+np.array(off)-spt
                dd=np.linalg.norm(vv,axis=1)
                L=vv/dd[:,None]
                cat_shadow=ca.anyhit(spt,L,dd-.03,mask=MASK_NOSHADOW)
                hits=np.flatnonzero(cat_shadow)
                if len(hits):
                    lit=~self.st.anyhit(spt[hits],L[hits],dd[hits]-.03,mask=MASK_NOSHADOW)
                    shadow_direct[gid[hits[lit]]]+=.25
            # True local hemispheric-blockage: tight beneath four feet and solid belly.
            for v in ((-.37,.92,0.),(.37,.92,0.),(0,.93,-.36),(0,.93,.36),(0,1,0)):
                L=np.broadcast_to(np.asarray(v,np.float32),spt.shape)
                shadow_contact[gid]+=ca.anyhit(spt,L,np.full(len(spt),.36),mask=MASK_NOSHADOW)*.20
        s1=gaussian_filter(agg_mask(shadow_direct,p),.32)
        s2=gaussian_filter(agg_mask(shadow_contact,p),.31)
        hidden=(ray_body & ~show)
        blocking=tri[hidden]
        matids=self.g['F']['mat'][self.g['tf'][blocking[blocking>=0]]]
        mat_counts={self.mat_rev[int(k)]:int(n) for k,n in zip(*np.unique(matids,return_counts=True))}
        main=c[:3].sum(0)
        silhouette=bounds(main>=3,x0,y0)
        full=bounds(c.sum(0)>=3,x0,y0)
        ear_pixels=ears.reshape(p).sum(-1).astype(np.uint8)
        info.update({'visible_ear_ray_hits':int(ears.sum()),'projected_root':[float(q) for q in self.cam.project(info['root'])[:2]],
                     'ray_hits_before_world_depth':int(ray_body.sum()),'ray_hits_after_world_and_cloth_depth':int(show.sum()),
                     'occluded_samples':int(hidden.sum()),'first_static_blocker_materials':mat_counts,
                     'body_box_native_without_tail':silhouette,'full_box_native_with_tail':full,
                     'edge_static_collision_count':self.check_edges(g),
                     'visible_shadow_pixels_over_.10':int(np.count_nonzero((s1>.10)|(s2>.10)))})
        return {'box':(x0,x1,y0,y1),'cover':alpha, 'ray_hits_raw':n_raw.astype(np.uint8), 'ray_blocked':(n_raw-n_seen).astype(np.uint8),'a':a,'b':b,'c':c,'ear_pixels':ear_pixels,'shadow_direct':s1,'shadow_contact':s2,
                'depth':under,'info':info}


def palette():
    p=json.loads(Path(__file__).with_name('palette24.json').read_bytes())
    rgb=np.asarray(p['palette_rgb'],np.uint8)
    if rgb.shape!=(60,3):raise ValueError('the audited Gate2.3 spring palette is required')
    return dict(rgb=rgb,lab=pix.oklab(rgb/255.0))


class Scene:
    def __init__(self,cache=None,scout_only=False):
        self.cam=cam=shot.camera()
        fx.SC=W/480.
        self.w,near=stage_world()
        self.g=self.w.finalize();self.st=acc(self.g)
        if cache is not None:
            with Path(cache).open('rb') as f:dig=hashlib.file_digest(f,'sha256').hexdigest()
            if dig!=APPROVED_CACHE:raise ValueError('draft plate cache must be exact frozen Gate2.3 plate')
            with np.load(cache) as data:pl={k:data[k] for k in data.files}
        else:
            print('Ray tracing the unchanged Gate2.3 world/held canopy.',flush=True)
            pl,_=ray.render(self.w,cam,shot.sky,S=3,acc=self.st,**dict(shot.RENDER,hook=base.petal_hook))
            fx.denoise(pl,**shot.DENOISE)
        self.pl=pl;self.center=pl['depth'][:,:,4]
        self.lamps=[l for l in self.w.lights if l['kind']=='point' and 'axis' in l]
        self.lamp=next(L for L in self.lamps if L['grp']==base.G_LAMP)
        self.base_lit=fx.native_sky(base,cam,H,W)*pl['sky'][...,None]+pl['layers'][0]
        self.main=pl['layers'][base.G_LAMP].copy()
        for L in self.lamps:
            x,y,*_=cam.project(L['pos']+np.array([0,.15,0]))
            fx.glow(self.main if L['grp']==base.G_LAMP else self.base_lit,x,y,L['color']*.010,r0=2.4,power=1.3)
        # Whole real projection, including mixed silhouette pixels; no world or
        # screen subwindow can reduce the independent review denominator.
        foliage=(pl['tag1']>=.5)
        # Part labels come from the real, supersampled static camera intersections.
        self.wood_wires=(pl['tag5']>0)|(pl['tag6']>0)
        self.lamp_surfaces=(pl['tag4']>0)
        self.architecture=(pl['tag1']==0)&(pl['tag2']==0)&(pl['sky']<.001)&~self.wood_wires
        self.fixed_block=self.wood_wires|self.lamp_surfaces|self.architecture
        self.leaf=WindField(foliage,self.center,protected=self.fixed_block,leaf_fraction=pl['tag1'])
        if int(self.leaf.mask.sum())!=11122:
            raise ValueError('fixed meaningful whole-crown denominator changed')
        self.petal=FlowerShower(self.g,near)
        self.cloth=ClothPass(self.st,self.w,pl,cam)
        self.cat=CatPass(self.w,self.g,self.st,cam)
        self.vig=fx.vignette(H,W,.15)
        self.key=-1
        self.flock=None
        try:
            from flock24 import SpringFlock
        except ModuleNotFoundError:
            if not scout_only:raise
        else:self.flock=SpringFlock(cam,pl['depth'])
        from lamp_fixtures import FixtureLayer
        self.fixtures=FixtureLayer(self)
        self.tones={}
        print(f'main leaf mask={int(foliage.sum())}; anchors={len(self.petal.s)} true tree triangles; BVH tris={len(self.g["v0"])}',flush=True)

    def wind_reference(self,j=None):
        # Unchanged visible preset, frozen illumination. No petals/actors make
        # adjacent held-pose difference an exact wind-only measurement.
        lin=fx.bloom(self.base_lit+self.main+TV_TINT[None,None]*self.pl['layers'][base.G_TV],
                     thresh=.5,sig=(1.2,4.5),gain=(.24,.17))
        if j is not None:
            y,x,a,b=self.leaf.taps(j)
            lin[y,x]=lin[a,b]
        return np.round(pix.tonemap(np.maximum(lin,0)*self.vig,**shot.GRADE)*255).clip(0,255).astype(np.uint8)

    def prepare(self,j):
        key=(j%330)//5*5
        if self.key!=key:
            self.key=key
            self.c=self.cloth.step(key)
            self.k=self.cat.step(key,self.c['da'])
        return self.c,self.k

    def render(self,j,exclude='',metadata=False):
        c,k=self.prepare(j)
        lamp,tv=gains(j)
        if exclude=='lamp':
            lamp=1.
        if exclude=='lamp_drop':
            lamp=gains(j,False)[0]
        if exclude=='tv':
            tv=TV_TINT
        lampcon=self.main*lamp
        lin=self.base_lit+lampcon+self.pl['layers'][base.G_TV]*tv[None,None]
        lit_before_bloom=lin
        lin=fx.bloom(lin,thresh=.5,sig=(1.2,4.5),gain=(.24,.17))
        veil=lin-lit_before_bloom
        birds=[]
        if self.flock is not None and exclude!='bird':
            birds=self.flock.draw(lin,j)
        leaf_idxs=self.leaf.taps(j)
        if exclude!='leaf':
            y,x,z,u=leaf_idxs
            lin[y,x]=lin[z,u]
        if exclude!='fixture':
            self.fixtures.resolve(lin,lamp,veil)
        seen_depth=c['depth'] if exclude=='fixture' else np.minimum(c['depth'],self.fixtures.depth)
        x0,x1,y0,y1=CLOTH_RECT
        lin*=1-c['shadow'][...,None]
        lin[y0:y1,x0:x1]=(1-c['cover'][...,None])*lin[y0:y1,x0:x1]+c['radiance']
        x0,x1,y0,y1=k['box']
        if exclude not in ('cat','cat_shadow'):
            lin[y0:y1,x0:x1]*=(1-k['shadow_contact'][...,None]*.31)
            lin[y0:y1,x0:x1]-=lampcon[y0:y1,x0:x1]*k['shadow_direct'][...,None]*.56
        if exclude not in ('cat','cat_body'):
            lin[y0:y1,x0:x1]=(1-k['cover'][...,None])*lin[y0:y1,x0:x1]+k['a']+lamp*k['b']
            catdepth=(x0,y0,k['depth'])
        else:catdepth=None
        visible=[]
        if exclude!='petal':
            if exclude=='fixture':
                visible,dots=self.petal.draw(lin,seen_depth,self.cam,j,self.lamp,lamp,catdepth)
            else:
                # A two-pixel petal can straddle a narrow arm. Apply new depth
                # only at the occupied native sites; its free half stays visible.
                under=lin.copy()
                visible,dots=self.petal.draw(lin,c['depth'],self.cam,j,self.lamp,lamp,catdepth)
                self.petal.draw(under,seen_depth,self.cam,j,self.lamp,lamp,catdepth)
                idx=self.fixtures.idx
                lin[idx]=under[idx]
        else:dots=np.empty((0,2),np.int16)
        moth=[]
        if exclude!='moth':
            moth=moth_glints(lin,seen_depth,self.cam,j,self.lamp,lamp)
        a=np.round(pix.tonemap(np.maximum(lin,0)*self.vig,**shot.GRADE)*255).clip(0,255).astype(np.uint8)
        return a,dict(lamp_gain=lamp,tv_tint=tv.tolist(),visible_cat=k['info'],petal_meta=visible,birds=birds,moths=moth),leaf_idxs,dots


def main():
    from pack import quantize_clip
    ap=argparse.ArgumentParser()
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--span',default='0:330')
    ap.add_argument('--frames',help='comma-separated still scout phases; unlike full renders can omit flock while it is being developed')
    ap.add_argument('--draft-approved-cache',type=Path,help='optional exact precomputed v2.3 plate for scouting; cannot be used for full final export')
    ap.add_argument('--no-controls',action='store_true')
    a=ap.parse_args()
    if a.draft_approved_cache and not a.frames: ap.error('cached v2.3 scout plates are not allowed for the final producer render')
    a.out.mkdir(parents=True,exist_ok=True)
    s=Scene(a.draft_approved_cache,scout_only=bool(a.frames))
    s0,s1=map(int,a.span.split(':'))
    fs=list(map(int,a.frames.split(','))) if a.frames else list(range(s0,s1))
    meta=[]; frames=[]; variant=[]; labels=[]
    ct=[];cd=[];cs=[];lc=[]; pc=[]; ce=[]
    cloth_a=[];cloth_rgb=[];cloth_sh=[]; cloth_pose=[]
    for j in fs:
        f,info,leaf,dots=s.render(j,metadata=True)
        frames.append(f)
        if j%5==0 or not meta:
            c=s.c
            cloth_a.append(c['tal']);cloth_rgb.append(c['radiance']);cloth_sh.append(c['shadow'])
            cloth_pose.append(int(s.key))
        meta.append(dict(frame=j,**info))
        c,k=s.prepare(j)
        x0,x1,y0,y1=k['box']
        cat=np.zeros((4,H,W),np.uint8);cat[:,y0:y1,x0:x1]=k['c'];ct.append(cat)
        ear=np.zeros((H,W),np.uint8);ear[y0:y1,x0:x1]=k['ear_pixels'];ce.append(ear)
        shadow=np.zeros((2,H,W),np.uint8)
        shadow[0,y0:y1,x0:x1]=np.rint(255*k['shadow_direct']).astype(np.uint8)
        shadow[1,y0:y1,x0:x1]=np.rint(255*k['shadow_contact']).astype(np.uint8)
        cs.append(shadow)
        block=np.zeros((2,H,W),np.uint8)
        block[0,y0:y1,x0:x1]=k['ray_hits_raw']
        block[1,y0:y1,x0:x1]=k['ray_blocked']
        cd.append(block)
        src=np.zeros((2,H,W),np.int8)
        y,x,z,u=leaf
        src[0,y,x]=z-y;src[1,y,x]=u-x;lc.append(src)
        p=np.zeros((H,W),bool)
        if len(dots):p[tuple(dots.T)]=True
        pc.append(p)
        if not a.no_controls and (a.frames or j in CONTROL_PHASES):
            items=('cat','cat_shadow','leaf','petal','lamp','bird') if a.frames else ('petal','lamp','lamp_drop','tv','bird','moth')
            # Fixed isolated controls, same time and actual color quantizer, never proxy frames.
            for key in items:
                vr,_,_,_=s.render(j,exclude=key)
                variant.append(vr); labels.append((j,key))
        if not a.frames and not a.no_controls:
            for key in ('leaf','cat','cat_shadow'):
                vr,_,_,_=s.render(j,exclude=key)
                variant.append(vr); labels.append((j,key))
        if len(meta)%15==1:
            vv=k['info']
            print('frame',j,'lamp',round(info['lamp_gain'],4),'cat:',vv['body_box_native_without_tail'],
                  vv['ray_hits_after_world_and_cloth_depth'],'collisions',vv['edge_static_collision_count'],
                  'petals',len(info['petal_meta']),'bird',len(info['birds']),flush=True)
    real_probe=(not a.frames and fs==list(range(330)))
    if real_probe:
        if s.key!=325:raise ValueError('proof must physically rewind from the final real 6fps pose')
        # Recalculate pose zero from after 330 sequential phases. Do not fill from frame 0.
        f330,info,leaf330,dots330=s.render(330,metadata=True)
        if not np.array_equal(f330,frames[0]):raise ValueError('physical F330 rerender differs from F0')
        meta.append(dict(frame=330,**info))
        if not (int(s.key)==0 and np.allclose(info['visible_cat']['projected_root'],meta[0]['visible_cat']['projected_root'])):
            raise ValueError('pose not recalculated at actual closure')
    raw=np.asarray(frames,np.uint8)
    fixed=np.array([s.wind_reference(None),*(s.wind_reference(k) for k in range(0,330,5))])
    blocks=(raw,np.asarray(variant,np.uint8),fixed) if len(variant) else (raw,fixed)
    if real_probe:blocks=(*blocks,f330[None])
    all_video=quantize_clip(np.concatenate(blocks),palette(),pix.threshold_map(H,W,'mix',seed=177),.22)
    native=all_video[:len(raw)];controls=all_video[len(raw):len(raw)+len(variant)]
    fixed=all_video[len(raw)+len(variant):len(raw)+len(variant)+67]
    if real_probe and not np.array_equal(all_video[-1],native[0]):
        raise ValueError('actual post-palette F330 rerender differs from F0')
    np.save(a.out/'spring_native.npy',native,allow_pickle=False)
    ctrl_frames=np.array([x[0] for x in labels],np.int16)
    ctrl_names=np.array([x[1] for x in labels],dtype='U12')
    long=['leaf','cat','cat_shadow']
    layer={'frame_ids':fs,'cat_samples':np.asfortranarray(ct),
                'cat_ear_real_ray_samples':np.asfortranarray(ce),
                'cat_shadow':np.asfortranarray(cs),'cat_candidate_and_blocked':np.asfortranarray(cd),
                'leaf_offset':np.asfortranarray(lc),'petal_visible':np.asfortranarray(pc),
                'protected_geometry':s.fixed_block,'static_branch_and_wire':s.wood_wires,
                'light_fixture_surfaces':s.lamp_surfaces,'architecture':s.architecture,'eligible_leaf':s.leaf.mask,
                'native_median_depth':s.center,'leaf_primary_ray_fraction':s.pl['tag1'],'reference_wind_only_off':fixed[0],
                'reference_wind_only_66_all':np.asfortranarray(fixed[1:])}
    keep=np.ones(len(labels),bool)
    if real_probe and not a.no_controls:
        for key in long:
            mask=ctrl_names==key
            if not np.array_equal(ctrl_frames[mask],np.arange(330)):raise ValueError('incomplete causal A/B: '+key)
            np.savez_compressed(a.out/f'spring_control_{key}_all330.npz',frame_ids=fs,
                                rgb_off=np.asfortranarray(controls[mask]))
            keep&=~mask
    layer.update(control_frame=ctrl_frames[keep],control_name=ctrl_names[keep],rgb_control=np.asfortranarray(controls[keep]))
    if real_probe:
        layer.update(raw_frame_0=raw[0],raw_new_trace_frame_330=f330,native_actual_frame_330=all_video[-1])
    np.savez_compressed(a.out/'spring_layer_proof.npz',**layer)
    np.savez_compressed(a.out/'spring_cloth_pose_proof.npz',pose_frames=cloth_pose,
                cover=np.asfortranarray(cloth_a),radiance=np.asfortranarray(cloth_rgb),
                shadow=np.asfortranarray(cloth_sh))
    (a.out/'spring_physical.json').write_text(json.dumps(meta,ensure_ascii=False,separators=(',',':'),default=lambda x:x.item())+'\n')
    (a.out/'spring_petal_origins.json').write_text(json.dumps(s.petal.export(),ensure_ascii=False,separators=(',',':'))+'\n')
    (a.out/'spring_scene_bounds.json').write_text(json.dumps({
        'source_camera':{'pos':s.cam.pos.tolist(),'forward':s.cam.f.tolist(),'vertical_shift':s.cam.shift,'raster':[W,H]},
        'gate15_reference_camera_unchanged':True,'base_unchanged':True,'lens_static':True,
        'cat_y_world':0,'cat_route_length_m':PATH_LEN,'cat_stopped_phase_inclusive':HOLD,
        'cat_real_331_trace_count':len(meta),'phase330_raw_recomputed_exact':real_probe,
        'fixed_cloth_same_module_and_ray_seed_as_v24':True,'palette_source':'approved Gate 2.3 60-color RGB lock, preserved in Gate 2.4',
        'near_tree_foliage_pixels':int(s.leaf.mask.sum()),
        'visible_crown_pixels_with_protected_nonleaf_samples_still_in_denominator':int(np.count_nonzero(s.leaf.mask&s.fixed_block)),
        'tree_wires_never_tapped':all(not np.any(s.fixed_block[y,x]|s.fixed_block[z,u])
            for y,x,z,u in (s.leaf.taps(j) for j in fs))
    },ensure_ascii=False,indent=2)+'\n')
    if a.frames:
        x=(143,146,320,180)
        cards=[]
        for j,n in zip(fs,native):
            im=Image.fromarray(n)
            im.resize((1920,1080),Image.Resampling.NEAREST).save(a.out/f'full_{j:03d}.png')
            cr=im.crop(x).resize(((x[2]-x[0])*4,(x[3]-x[1])*4),Image.Resampling.NEAREST)
            cards.append((j,cr))
        board=Image.new('RGB',(cards[0][1].width*2,((len(cards)+1)//2)*(cards[0][1].height+19)), '#251f2b')
        from PIL import ImageDraw
        d=ImageDraw.Draw(board)
        for n,(j,p) in enumerate(cards):
            x0=(n%2)*p.width;y0=(n//2)*(p.height+19);board.paste(p,(x0,y0))
            d.text((x0+5,y0+p.height+2),f'{j:03d} / {j/30:.2f}s',fill='#ead5c8')
        board.save(a.out/'actual_cat_strip4x.png')


if __name__=='__main__':main()
