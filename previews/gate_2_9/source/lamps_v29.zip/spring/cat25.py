"""One continuous torso–neck–head loft, independently planted 3-D paws, a continuously visible closed ground route."""
import numpy as np
from scipy.interpolate import PchipInterpolator, CubicSpline, CubicHermiteSpline
from spring23 import World,mats,srgb,roty

CAT_HEAD,CAT_BODY,CAT_FOOT,CAT_TAIL,CAT_EAR=91,92,93,94,95
CAT_BODY_M=.466
# Physical world samples (metres at y=0) measured by rays through the warm
# ground strip of the locked camera. The two courses are not time reversals.
HOLD=(105,128)
NODES=np.array([[6.34731,12.66076],[6.07185,12.60800],[5.74212,12.50100],
                [5.26769,11.79320],[4.65239,11.64613],[4.30781,11.74099],
                [4.32985,12.17197],[4.57967,12.62574],[4.94612,12.72366],
                [5.50501,12.92293],[5.97466,12.94550],[6.32393,12.88475],
                [6.41590,12.88950],[6.45563,12.81399],[6.42157,12.69003],[6.34731,12.66076]],np.float64)
U=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(NODES,axis=0),axis=1))]
U/=U[-1]
WORLD_PATH=CubicSpline(U,NODES,axis=0,bc_type='periodic')
PATH_SPEED=WORLD_PATH.derivative()
ARC_PARAM=np.linspace(0,1,4097)
ARC_POINTS=WORLD_PATH(ARC_PARAM)
ARC_LENGTH=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(ARC_POINTS,axis=0),axis=1))]
PATH_LEN=float(ARC_LENGTH[-1])
ANCHOR_NODE=(0,1,2,3,4,5,5,6,7,8,9,10,11,12,13,14,15)
KEY=np.array([0,18,40,65,88,*HOLD,150,170,187,218,249,276,302,313,325,330.])
TARGET=np.interp(U[list(ANCHOR_NODE)],ARC_PARAM,ARC_LENGTH)
vel=PchipInterpolator(KEY,TARGET).derivative()(KEY)
vel[0]=vel[-1]=.5*(vel[0]+vel[-1])
PACE=CubicHermiteSpline(KEY,TARGET,vel)
STRIDE=PATH_LEN/12.
# Root trajectory is distinct from the articulated body orientation: the cat
# slows and shifts weight onto its paws while neck/shoulders initiate each turn.
# The two real 3-D pivots pass the narrow end-on angle between held poses.
FACE_KEYS=np.array([0,15,35,65,85,95,105,125,130,135,140,145,150,155,160,
                    173,190,206,225,248,267,283,297,305,310,315,320,325,330.])
FACE_DEG=np.array([174,161,153,158,174,192,204,204,213,225,235,243,312,320,325,
                   339,340,340,349,367,375,365,366,380,402,418,486,520,534.])
# Equal angular velocity on the seam is important: an unseen yaw correction
# here would reveal the reset even though ground position is perfectly closed.
face_vel=PchipInterpolator(FACE_KEYS,FACE_DEG).derivative()(FACE_KEYS)
face_vel[0]=face_vel[-1]=0.
FACE=CubicHermiteSpline(FACE_KEYS,np.deg2rad(FACE_DEG),np.deg2rad(face_vel))
STRIDE_FRAME=np.arange(3301)*.1
STRIDE_ARC=PACE(STRIDE_FRAME)
ARC_LOOKUP,ARC_FRAMES=np.unique(STRIDE_ARC,return_index=True)


def yaw_at_phase(f):
    v=FACE(float(f)%330.)
    return float((v+np.pi)%(2*np.pi)-np.pi)


def world_at_arc(s):
    arc=float(s)%PATH_LEN
    u=float(np.interp(arc,ARC_LENGTH,ARC_PARAM))
    x,z=WORLD_PATH(u)
    f=np.interp(arc,ARC_LOOKUP,STRIDE_FRAME[ARC_FRAMES])
    return np.array([x,0.,z]),yaw_at_phase(f)

@mats.mat('spring24_fur')
def fur(s):
    # Broad, low contrast coat markings. All response is reflected incident light.
    return s.col*(.93+.07*np.cos(s.seed*7.4))[:,None]


def route(j):
    # Exclusive ring of 330 display frames; evaluating 330 recomputes frame zero.
    f=float(j)%330.
    arc=float(PACE(f))
    root,_=world_at_arc(arc)
    return root,yaw_at_phase(f),arc


def sm(x):
    x=np.clip(x,0.,1.)
    return x*x*(3-2*x)


def muscle(f,s):
    rest=float(sm((f-99)/6)*(1-sm((f-HOLD[1])/11)))
    look=float(sm((f-103)/13)*(1.-sm((f-119)/13)))
    bob=float(.005*np.sin(4*np.pi*s/STRIDE)*(1-rest))
    return rest,look,bob


def mesh(frame):
    j=float(frame)%330.
    root,yaw,s=route(j)
    stop,look,bob=muscle(j,s)
    bend=sm((j-130)/12)*(1-sm((j-151)/16))-sm((j-302)/11)*(1-sm((j-319)/11))
    head_turn=.085*bend+.022*look
    prof=np.array([
        [-.230,.172,.005,.012],[-.219,.175,.048,.049],[-.179,.173,.076,.066],
        [-.113,.166,.076,.065],[-.025,.168,.075,.058],[.046,.180,.073,.056],
        [.102,.191,.058,.045],[.145,.225,.060,.047],
        [.181,.236,.058,.048],[.211,.220,.040,.041],[.236,.208,.016,.027],
    ],float)
    # A single watertight, connected loft; look changes the vertex heights of
    # the last rings continuously through the shoulder transition.
    cross=sm((prof[:,0]-.048)/.17)
    prof[:,1]+=bob+.025*look*cross
    w=World(seed=2415)
    with w.at(root,yaw=yaw):
        a=np.linspace(0,2*np.pi,13)[:-1]
        c=np.cos(a); d=np.sin(a)
        rings=np.stack([np.broadcast_to(prof[:,0,None],(len(prof),len(a))),
          prof[:,1,None]+prof[:,2,None]*c,prof[:,3,None]*d+head_turn*cross[:,None]],axis=-1)
        rr=np.roll(rings,-1,axis=1)
        shade=np.clip((c*.29+.78),.54,1.)
        F=srgb('#e8d7bb')
        H=srgb('#f6e7ca')
        D=srgb('#c3ab92')
        col=np.array([D if k==0 else H if k>6 else F for k in range(len(prof)-1)])
        w.quads(rings[:-1].reshape(-1,3),rr[:-1].reshape(-1,3),rr[1:].reshape(-1,3),rings[1:].reshape(-1,3),
                mat='spring24_fur',col=(col[:,None]*shade[None,:,None]).reshape(-1,3),
                seed=(.24+prof[:-1,0,None]*.6+c[None,:]*.09).ravel(),
                tag=np.repeat(np.where(prof[:-1,0]>.13,CAT_HEAD,CAT_BODY),len(a)))
        w.poly(rings[0][::-1],mat='spring24_fur',col=F,tag=CAT_BODY)
        w.poly(rings[-1],mat='spring24_fur',col='#fff1d6',tag=CAT_HEAD)
        # The ears grow through the skull crown; no independently drawn head or edges.
        for k,side in enumerate((-1,1)):
            z=side*.027+head_turn*.63
            by=.269+.020*look+bob
            xe=.149+.038*k
            ear=np.array([[xe-.023,by,z+side*.005],[xe+.017,by-.006,z+side*.012],
                          [xe-.004,min(.333,.324+.010*look+bob),z+side*.006],
                          [xe-.010,by-.007,z-side*.015]])
            for u,v,r in ((0,1,2),(1,3,2),(3,0,2),(0,3,1)):
                w.poly(ear[[u,v,r]],mat='spring24_fur',col='#bfa286' if v!=3 else '#75584d',tag=CAT_EAR)
        # Four feet, stance coordinates fixed in arclength until real swing.
        planted=[]
        feet=[]
        for q,(hx,hz,phase) in enumerate(((.095,.041,.06),(-.155,-.044,.29),(.095,-.041,.58),(-.155,.044,.79))):
            # In stance the same world target is anchored until its next swing.
            stride=STRIDE;dt=.55
            p=s/stride+phase
            cycle=np.floor(p);t=p-cycle
            ref=(cycle+dt*.5-phase)*stride
            w0,y0=world_at_arc(ref)
            w0+=roty(y0)@np.array([hx,0.,hz])
            foot=w0;ylift=0.
            if t>=dt:
                u=(t-dt)/(1-dt)
                w1,y1=world_at_arc(ref+stride)
                w1+=roty(y1)@np.array([hx,0.,hz])
                foot=w0+(w1-w0)*sm(u)
                ylift=.050*np.sin(np.pi*u)
            local=(foot-root)@roty(yaw)
            xloc=(1-stop)*float(np.clip(local[0]-hx,-.148,.148))
            side=(1-stop)*float(np.clip(local[2]-hz,-.052,.052))
            ylift*=1-stop
            hz=hz+side
            ank=(hx+xloc,.027+ylift,hz)
            kn=(hx+.25*xloc+(.018 if hx>0 else -.014),.119+.34*ylift+bob,hz)
            hip=(hx,.183+bob,hz*.86)
            w.tube(hip,kn,.031,.021,sides=7,mat='spring24_fur',col='#be9b7d',tag=CAT_FOOT)
            w.tube(kn,ank,.021,.014,sides=7,mat='spring24_fur',col='#715141',tag=CAT_FOOT)
            # Its world-space mesh shares the cat's body transform, not a floaty decal.
            w.box((ank[0]+.010,.009+ylift,ank[2]),(.053,.018,.031),
                    mat='spring24_fur',col='#bb987b',tag=CAT_FOOT)
            planted.append(bool(ylift<=.001))
            feet.append(w.xf((ank[0]+.010,ylift,ank[2])).tolist())
        phase=2*np.pi*(7*s/PATH_LEN+2*j/330.)
        curl=stop*sm((j-106)/13)*(1-sm((j-121)/18))
        t=np.array([[-.192,.170,.006],[-.263,.165,.022],[-.328,.191,.048],[-.380,.241,.062],
                    [-.407+.022*curl,.266+.037*curl,.060],[-.430+.055*curl,.290+.058*curl,.059+.040*curl]])
        t[1:,2]+=np.sin(phase+np.arange(1,6)*.63)*np.linspace(.003,.028,5)
        t[1:,2]-=bend*np.array([.015,.034,.074,.108,.144])
        t[:,1]+=bob
        rr=[.033,.029,.025,.023,.018,.013]
        for i in range(len(t)-1):
            w.tube(t[i],t[i+1],rr[i],rr[i+1],sides=7,mat='spring24_fur',col='#ac8a72' if i<3 else '#876b62',tag=CAT_TAIL)
        w.sphere(t[-1],.013,n=5,mat='spring24_fur',col='#927262',tag=CAT_TAIL)
    return w,{'frame_pose':j,'root':root.tolist(),'yaw_radians':yaw,'arc_m':s,'pause_weight':stop,'head_look_weight':look,
              'feet_planted':planted,'soles_world':feet,'body_length_m':CAT_BODY_M,'shoulder_height_m':.261,
              'head_and_ears_max_m':float(ear[:,1].max()),'tail_curl_weight':float(curl)}
