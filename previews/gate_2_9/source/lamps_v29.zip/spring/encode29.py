"""Encode the 11 s viewing loop and its exact two-cycle QP0 source."""
import argparse,hashlib,json,subprocess
from pathlib import Path
import os
os.environ.setdefault('RAINROJI_SOURCE_ROOT',str(Path(__file__).resolve().parent/'basis'))
import numpy as np
from PIL import Image
from pack import encode
from verify_exact import exact_master
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def boxes(m):
    y,x=np.where(m)
    return ([int(x.min()),int(y.min()),int(x.max()),int(y.max())] if len(x) else None)
def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=Path('render'));a=p.parse_args();d=a.out
    v=np.load(d/'new.npy',mmap_mode='r');old=np.load(d/'old.npy',mmap_mode='r')
    frozen=d/'lossless_parts/spring/part-00.bin';frozen.parent.mkdir(exist_ok=True,parents=True)
    loss=d/'double.mp4';preview=d/'spring_loop.mp4'
    encode(v,loss,True)
    assert loss.stat().st_size<=8_000_000,loss.stat().st_size
    frozen.write_bytes(loss.read_bytes())
    qa=exact_master('spring',d/'new.npy',loss)
    cmd=['ffmpeg','-y','-v','error','-xerror','-nostdin','-threads','2','-i',str(loss),'-frames:v','330','-an','-c:v','libx264','-threads','3','-preset','slow','-crf','12','-pix_fmt','yuv420p','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-movflags','+faststart',str(preview)]
    subprocess.run(cmd,check=True)
    mask=np.load(d/'physical_mask.npy')>0
    diff=np.any(v!=old,axis=-1);outside=np.sum(diff&~mask);arr=np.any(diff,axis=0)
    assert outside==0, (outside,boxes(np.any(diff&~mask,axis=0)))
    assert np.all(diff.any((1,2)))
    # Save true native phase crop pairs as individual images; no graphic substitution.
    for j in (0,117,141,287):
        for k,(x0,y0,x1,y1) in {'street':(127,77,172,104),'yard':(247,100,282,128)}.items():
            for name,seq in [('v28',old),('v29',v)]:
                im=Image.fromarray(seq[j,y0:y1,x0:x1]);im.resize((8*im.width,8*im.height),Image.Resampling.NEAREST).save(d/f'{k}_{name}_f{j:03}.png')
    probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(preview)]))['streams'][0]
    assert (int(probe['nb_frames']),float(probe['duration']),probe['width'],probe['height'],probe['profile'])==(330,11.,1920,1080,'High')
    diag={'lossless':{'output':'spring_loop.mp4','bytes':loss.stat().st_size,'sha256':sha(loss),'parts':[{'path':'lossless_parts/spring/part-00.bin','bytes':loss.stat().st_size,'sha256':sha(loss)}]},
          'preview':{'bytes':preview.stat().st_size,'sha256':sha(preview),'frames':330,'seconds':11},'qp0_validation':qa,'max_phase_changed':int(diff.sum((1,2)).max()),'min_phase_changed':int(diff.sum((1,2)).min()),'total_changed_outside_visible_hardware_mask':int(outside),'changed_bbox_native_inclusive':[boxes(arr&(np.indices(arr.shape)[1]<200)),boxes(arr&(np.indices(arr.shape)[1]>=200))],'native_new_sha256':sha(d/'new.npy'),'native_original_sha256':sha(d/'old.npy')}
    (d/'spring_evidence.json').write_text(json.dumps(diag,indent=2,ensure_ascii=False)+'\n')
if __name__=='__main__':main()
