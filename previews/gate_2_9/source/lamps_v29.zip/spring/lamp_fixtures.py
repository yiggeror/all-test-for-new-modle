"""Two mounted spring lamps, in metres in the approved street and court geometry."""
import numpy as np
from spring23 import World, Accel, MASK_NOSHADOW, MASK_HIDDEN, ray, base, shot, _n
from engine.world import MASK_NOBOUNCE

def fixtures():
    w=World(seed=29023)
    steel,band,outer,lip,pale='#29272c','#61555c','#201e25','#3e343d','#766156'
    def pipe(points,r,col=steel):
        p=np.asarray(points,float)
        for a,b in zip(p[:-1],p[1:]):
            w.tube(a,b,r,sides=10,mat='plain',col=col,caps=True)
    def lathe(x,z,rings,colors):
        ang=np.arange(17)*np.pi/8; circum=np.stack((np.cos(ang),0*ang,np.sin(ang)),axis=1)
        rings=[circum*r+np.array((x,y,z)) for y,r in rings]
        for a,b,col in zip(rings,rings[1:],colors):
            w.quads(a[:-1],a[1:],b[1:],b[:-1],mat='plain',col=col)
    with w.flag(MASK_NOSHADOW|MASK_NOBOUNCE):
        # Old concrete pole and existing bulb, not surrogate screen-space endpoints.
        px,pz=1.75,10.6
        dx,dz=_n(np.asarray((-1.,.15)))
        def P(along,y,upstage=0.):return [px+along*dx,y,pz+along*dz+upstage]
        for y in (4.51,5.00):
            w.tube((px,y-.044,pz),(px,y+.044,pz),.161,sides=12,
                   mat='plain',col=band,caps=True)
        # Galvanised tapered upper arm, lower compression strut and short turned socket.
        p=[P(.075,5.00,.075),P(.48,5.17,.050),P(1.05,5.47,.018),
           P(1.31,5.55,.008),P(1.43,5.55),P(1.50,5.49),P(1.50,5.43)]
        pipe(p,.048)
        pipe([P(.08,4.51,.079),P(.30,4.63,.060),P(.83,5.07,.033),P(1.06,5.46,.017)],.037,'#25242a')
        hx,_,hz=P(1.50,5.30)
        lathe(hx,hz,[(5.450,.052),(5.440,.112),(5.390,.190),(5.325,.295),(5.304,.310),(5.278,.310),
                     (5.288,.18),(5.26,.10)],[outer,outer,outer,outer,lip,pale,pale])
        # A real X-directed camera-space-independent probe of the facade gives x=9.83.
        # Fix the back of the iron shoe flush inside that existing brick face.
        x0,z0=9.83,6.20
        w.box((x0-.055,2.53,z0),(.14,.28,.30),mat='plain',col=band)
        pipe([(9.76,2.55,z0),(9.64,2.62,z0),(9.49,2.86,z0),(9.36,3.04,z0),(9.19,3.18,z0),
              (8.91,3.23,z0),(8.73,3.22,z0),(8.63,3.15,z0),(8.60,3.05,z0)],.047,'#2c272e')
        lathe(8.60,z0,[(3.072,.036),(3.052,.066),(3.015,.105),(2.96,.166),
                         (2.943,.207),(2.922,.211),(2.917,.18),(2.94,.075)],
                        [outer,outer,outer,outer,lip,pale,pale])
    return w

class FixtureLayer:
    def __init__(self,scene):
        cam=scene.cam; w=fixtures();g=w.finalize();w.pixang=2*cam.th/320
        self.mask=np.zeros((180,320),np.float32);self.diff0=np.zeros((180,320,3),np.float32)
        self.diff1=self.diff0.copy();self.depth=np.full((180,320,9),np.inf,np.float32)
        ac=Accel(g['v0'],g['v1'],g['v2'],g['tm'])
        for xlo,xhi,ylo,yhi in [(131,167,78,103),(250,284,100,126)]:
            ny,nx=yhi-ylo,xhi-xlo;S=8
            ys,xs=np.mgrid[ylo*S:yhi*S,xlo*S:xhi*S]
            dv=cam.dirs((xs.ravel()+.5)/S,(ys.ravel()+.5)/S).astype('f4')
            o=np.broadcast_to(cam.pos.astype('f4'),dv.shape).copy()
            st,old=scene.st.closest(o,dv,mask=MASK_HIDDEN)
            st[old<0]=1e8
            t,tr=ac.closest(o,dv,tmax=st+.0001,mask=MASK_HIDDEN)
            sel=np.flatnonzero(tr>=0)
            if len(sel)==0:raise RuntimeError('no visible fixture')
            pt=o[sel]+dv[sel]*t[sel,None]
            sf=ray.surface(w,g,tr[sel],pt,dv[sel],t[sel])
            ctr=[dict(v,radius=0.,soft=0.) for v in scene.w.lights]
            E=ray.direct(ctr,scene.st,pt,sf['N'],np.random.default_rng(210),base.K)
            hemi=np.clip(.51+.49*sf['N'][:,1],0,1)
            sky=np.array([.27,.206,.31])[None,:]*(.52+.62*hemi[:,None])
            T=ray.fog_T(shot.RENDER['fog'],o[sel],pt,t[sel])
            a=(E[0]+E[base.G_TV]+sky)*sf['alb']*T[:,None]+shot.RENDER['fog']['color'](dv[sel])*(1-T[:,None])
            b=E[base.G_LAMP]*sf['alb']*T[:,None]
            def mean(z):return z.reshape(ny,S,nx,S,*z.shape[1:]).mean((1,3))
            hit=np.zeros(len(o),np.float32);hit[sel]=1
            cov=mean(hit);sel2=cov>0
            # Coverage-resolve small solid hardware to the native grid, keeping a
            # narrow silhouette and corners tied to actual visible 8×8 ray samples.
            opacity=np.clip((cov-.0625)/.48,0,1)
            self.mask[ylo:yhi,xlo:xhi]=opacity
            for arr,shaded in [(self.diff0,a),(self.diff1,b)]:
                rad=np.zeros((len(o),3),np.float32);rad[sel]=shaded
                gmean=mean(rad)
                gmean[sel2]/=cov[sel2,None]
                arr[ylo:yhi,xlo:xhi]=gmean
            center=np.stack(np.meshgrid(np.arange(xlo,xhi)+.5,np.arange(ylo,yhi)+.5),axis=-1)
            # Nine angular bins compatible with the scene's native particle depth masks.
            for si in range(9):
                px=center[...,0]+((si%3)-1)/3;py=center[...,1]+((si//3)-1)/3
                d=cam.dirs(px.ravel(),py.ravel()).astype('f4');o3=np.broadcast_to(cam.pos.astype('f4'),d.shape).copy()
                t3,ii=ac.closest(o3,d,mask=MASK_HIDDEN);t3[ii<0]=1e8
                self.depth[ylo:yhi,xlo:xhi,si]=t3.reshape(ny,nx)
        self.depth[self.mask==0]=np.inf
        self.idx=np.where(self.mask>0)
    def resolve(self,lin,lamp,veil):
        i=self.idx; a=self.mask[i][:,None]
        metal=self.diff0[i]+lamp*self.diff1[i]+veil[i]*.065
        lin[i]=lin[i]*(1-a)+a*metal
