# 春：旧街挑臂与院檐壁灯

在本目录运行，以 FFmpeg（含 libx264）、Python 3.12 和 requirements.txt 中的包重建。

    export OPENBLAS_NUM_THREADS=1 NUMBA_NUM_THREADS=3
    python render29.py --out render
    python encode29.py --out render

其中 spring_loop.mp4 是 11 秒样片；lossless_parts/spring/part-00.bin 是两个完整相位循环的 22 秒 QP0 正本。render29.py 不从历史图像、旧视频或缓存取色，old.npy 是同相关闭两盏新增支撑的真实重渲对照。

spring_scene29.py 保留签收的布、猫、树风、落瓣、暮燕、小蛾、灯压降与画面调色。lamp_fixtures.py 在原坐标建立世界空间铸铁灯座、斜挑臂、斜撑、弯管与分段旋转面搪瓷罩；街灯双箍扣在 (1.75, 0, 10.6) 水泥杆上，院灯压板固定在 x=9.83 的真实砖面。两盏灯沿用原灯泡与光源，不新增灯，也不移动或遮蔽原来地面、花树和院墙的受光。支撑是无投影的实心相机可见网格；8×8 子像素真实射线与原场景比较深度，9 个独立方向补入前后景深度，沿用原生 60 色量化。只有支撑覆盖的像素改变。
