"""Audit visible (post-quantization) eight-connected paths from the hood to both pole collars."""
import argparse,hashlib,json
from pathlib import Path
import numpy as np
from scipy.ndimage import label

def check(base,candidate,mask):
    structure=np.ones((3,3),bool);xs=slice(45,87);ys=slice(37,62)
    g=mask[ys,xs]
    xy=(42,31,92,66)
    def bbox(a,b,c,d):
        return np.s_[b-37:d-37,a-45:c-45]
    boxes=[bbox(48,43,57,46),bbox(80,51,86,55),bbox(80,57,86,60)]
    outcomes={}
    for cutoff in (1,8,12,15,20,25,30):
        acc=[0,0];worst=[]
        for i in range(len(base)):
            d=np.linalg.norm(candidate[i,ys,xs].astype('f4')-base[i,ys,xs],axis=2)
            labels,_=label((d>=cutoff)&g,structure)
            sets=[set(labels[box].ravel())-{0} for box in boxes]
            ok=[bool(sets[0]&sets[j]) for j in (1,2)]
            acc[0]+=ok[0];acc[1]+=ok[1]
            if not all(ok):worst.append(i)
        outcomes[str(cutoff)]=dict(hood_to_upper_collar_frames=acc[0],hood_to_lower_collar_frames=acc[1],missing=worst)
    assert outcomes['12']['missing']==[]
    assert np.array_equal(base[:,62:,:,:],candidate[:,62:,:,:])
    assert np.array_equal(base[:,46:48,51:55],candidate[:,46:48,51:55]), 'bulb core'
    return dict(rgb_distance_metric='Euclidean 8-bit RGB after fixed palette quantization, within coverage mask; 8-connected component must intersect head AND clamped pole end',neighborhood_xyxy=[45,37,87,62],hood_upper_lower_boxes_xyxy=[[48,43,57,46],[80,51,86,55],[80,57,86,60]],path_results=outcomes,original_bulb_core_4x2_all_330_identical=True,entire_frame_y_gte_62_all_330_identical=True)
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('baseline',type=Path);a.add_argument('work',type=Path);q=a.parse_args()
    r=check(np.load(q.baseline,mmap_mode='r'),np.load(q.work/'winter_native.npy',mmap_mode='r'),np.load(q.work/'geometry_support.npy'));print(json.dumps(r,indent=2))
