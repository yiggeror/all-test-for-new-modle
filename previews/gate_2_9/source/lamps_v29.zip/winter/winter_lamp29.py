"""Pole-mounted sodium streetlight. Dimensions are metres in the signed camera's world."""
from __future__ import annotations
import numpy as np
from engine.world import World, MASK_NOSHADOW, MASK_NOBOUNCE
from engine.rt import Accel
from engine import props

# Concrete pole and socket are inherited from shots/winter_world_gate15.py.
POLE=np.array([-7.75,0.,5.50]); ARM=np.array([-1.,0.,.1]);ARM/=np.linalg.norm(ARM)
UP=np.array([0.,1.,0.]); LENGTH=1.70
def loc(s,h):return POLE+ARM*s+UP*h

def steelwork():
    m=World(seed=29)
    def shape(col,tag):return dict(mat='metal',col=col,tag=tag,mask=MASK_NOSHADOW|MASK_NOBOUNCE)
    steel=shape('#69737a',1);brace=shape('#404c56',2);band=shape('#7b8586',3)
    outer=shape('#303d40',4);rolle=shape('#292d32',5);inside=shape('#846747',6)
    def bent(coords,r,metal):
        # Overlapping mitered joints and short tangent segments make one watertight silhouette.
        for a,b in zip(coords,coords[1:]):
            m.tube(loc(*a),loc(*b),r,sides=16,caps=True,**metal)
        for a in coords[1:-1]:m.sphere(loc(*a),r,n=10,**metal)
    # Hooped collars seat the top arm and triangulated lower strut against the post.
    for h in (6.85,6.52):
        m.tube(loc(0,h-.043),loc(0,h+.043),.150,.150,sides=20,caps=True,**band)
        m.box(loc(.125,h),(.104,.115,.156),**steel)
    bent([(.09,6.85),(.43,7.006),(.76,7.18),(1.09,7.37),(1.31,7.486),
          (1.46,7.543),(1.58,7.552),(1.65,7.525),(1.695,7.47),(1.70,7.401)],
         .054,steel)
    bent([(.11,6.52),(.38,6.715),(.68,6.959),(.90,7.164),(1.00,7.317)],.037,brace)
    # Spun enamel crown, flared skirt and rolled outer rim; the old emitter is retained below.
    def ring(h0,h1,r0,r1,material):
        m.tube(loc(LENGTH,h0),loc(LENGTH,h1),r0,r1,sides=24,caps=False,**material)
    ring(7.410,7.482,.058,.056,steel)
    ring(7.412,7.463,.095,.065,outer)
    ring(7.365,7.416,.153,.093,outer)
    ring(7.321,7.369,.235,.150,outer)
    ring(7.297,7.325,.286,.233,outer)
    ring(7.250,7.301,.294,.284,rolle)
    ring(7.247,7.282,.290,.238,inside)
    return m

def prepare(scene):
    m=steelwork().finalize(); cam=scene.cam
    V=np.concatenate((m['v0'],m['v1'],m['v2']));u,v,*_=cam.project(V)
    x0,y0,x1,y1=int(np.floor(u.min()))-1,int(np.floor(v.min()))-1,int(np.ceil(u.max()))+1,int(np.ceil(v.max()))+1
    cut=np.s_[y0:y1,x0:x1];h,w=y1-y0,x1-x0
    ss=15; yy,xx=np.mgrid[:h*ss,:w*ss]
    dirs=cam.dirs(x0+(xx+.5)/ss,y0+(yy+.5)/ss).reshape(-1,3).astype('float32')
    orig=np.broadcast_to(cam.pos.astype('f4'),dirs.shape).copy()
    rt=Accel(m['v0'],m['v1'],m['v2'],m['tm'])
    dist,tri=rt.closest(orig,dirs)
    k=np.flatnonzero(tri>=0); face=m['tf'][tri[k]]
    F=m['F'];n=F['n'][face].copy();n*=np.where((n*(-dirs[k])).sum(1,keepdims=True)<0,-1,1)
    po=orig[k]+dirs[k]*dist[k,None];col=F['col'][face]
    tag=F['tag'][face]
    # Diffuse indirect sky, frost on the upper side of the pipe, and warm return from
    # the original emitter at its original position. No replacement/screen-space light.
    up=np.clip(n[:,1],0,1);pane=np.clip(n@np.array([-.42,.76,.48]),0,1)
    amb=(.045+.26*up+.13*pane)[:,None]*np.array([.66,.84,1.11])[None]
    lin=col*amb
    frost=(np.clip((n[:,1]-.47)/.47,0,1)**1.6) * np.where(tag==2,.16,np.where(tag<4,.63,.085))
    lin+=frost[:,None]*np.array([.084,.11,.15])
    orig_light=scene.st.c['lamp'];bulb=orig_light['pos']+np.array([0,.16,0]);to=bulb-po;d2=(to*to).sum(1)
    incidence=np.maximum(0,(n*to).sum(1)/np.sqrt(np.maximum(.0001,d2)))
    warm=col*np.array([1,.51,.22])[None]*(.128*incidence/(.13+d2))[:,None]
    # Preserve the depth ordering of the underlying branch/pole. The source stores
    # nine sorted subpixel distances per native pixel; evaluate new rays against them.
    iy=(yy.ravel()[k]//ss);ix=(xx.ravel()[k]//ss)
    depth=scene.b['depth'][cut].copy()
    # The signed plate contains the former 0.34 m sheet-metal shell. It sits
    # inside this new housing: it is not a second foreground occluder at the rim.
    # Do not give the same tolerance to the post, tree, or any distant structure.
    housing=(tag>=4)&(np.linalg.norm((po-loc(LENGTH,7.32))[:,[0,2]],axis=1)<.32)
    tol=np.where(housing,.28,.005).astype('f4')
    vis=(depth[iy,ix]>dist[k,None]-tol[:,None]).mean(1).astype('f4')
    cov=np.zeros((h,w),'f4');sky=np.zeros((h,w,3),'f4');inc=np.zeros_like(sky)
    np.add.at(cov,(iy,ix),vis/ss**2)
    np.add.at(sky,(iy,ix),lin*vis[:,None]/ss**2)
    np.add.at(inc,(iy,ix),warm*vis[:,None]/ss**2)
    cov=np.minimum(cov,1.)
    # Merge old/new depth order statistics for snow (front flakes remain in front;
    # rear flakes cannot leak through the head or rod).
    H=yy.size;hits=np.full(H,np.inf,'f4');hits[k]=dist[k]
    hits=hits.reshape(h,ss,w,ss).transpose(0,2,1,3).reshape(h,w,ss*ss)
    old=np.repeat(depth,ss*ss//9,axis=2)
    depths=np.minimum(np.sort(hits,axis=2),old[:,:,::-1]);new=np.sort(depths,axis=2)[:,:,12::25]
    scene.static[cut]=scene.static[cut]*(1-cov[...,None])+sky+inc
    scene.lamp_radiance[cut]=scene.lamp_radiance[cut]*(1-cov[...,None])+inc
    scene.b['depth'][cut]=new
    # The flame's bloom is behind the porcelain/steel housing; only a small lens veil
    # remains across it. The camera still sees the entire original glow outside the mesh.
    # Dark occupancy is derived from the same supersampled, visibility-tested 3D surface.
    shade=np.where(tag>=4,.985,np.where(tag==2,.60,.78))
    stop=np.zeros((h,w),'f4');np.add.at(stop,(iy,ix),shade*vis/ss**2)
    scene.lamp29_glare=(cut,np.clip(stop,0,.99)[...,None])
    return cut,cov
