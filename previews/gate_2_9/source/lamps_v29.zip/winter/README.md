# 冬 · 雪夜街灯
在原水泥杆左侧，用两道镀锌抱箍固定弯挑臂和较短的下斜撑。上臂的末端弯向下方，从短颈接入深色搪瓷灯罩。屋内贴桌翻页与屋外雪地光池沿用 v2.8。

`winter_lamp29.py` 以米为单位产生抱箍、圆管与搪瓷罩的回转面。金属只参与相机可见性，不投下新的阴影。15×15 子像素采样与原场景深度相交，金属朝向决定其天光、薄霜和灯泡的反光；新的深度供落雪使用。雪与烟气仍在原来的渲染顺序里。罩面和挑臂仅在与之相交的相机光线上遮住光源后方的辉光，保留少量镜前散光。最后使用原色板量化。

## 重现
Python 3.12、`requirements.txt` 和 FFmpeg 7.1（libx264）。依赖与中文字体见 `README_v28.md`。在本目录执行：

```sh
export OPENBLAS_NUM_THREADS=1 NUMBA_NUM_THREADS=2
python render29.py --work work --out out
python check_escrow.py work out
```

完整入口包含原场景和 v2.8 翻书重建，并校验此前的完整 330 帧原生 RGB。若已有同一份已核验的 v2.8 原生数组，可加 `--baseline-native /path/to/winter28.npy` 省去重建旧版的时间；输入数组哈希不匹配时程序中止。输出为 1× 原速、1920×1080、330 帧的 `winter_loop.mp4`；无损母版为两次相同循环，660 帧 / 22 秒，分为六卷。 `winter_parts.json` 记录六卷字节数及 SHA-256，`winter_v29_audit.json` 记录逐帧变更范围及窗内检验。 `before_crop_f165.png`、`after_crop_f165.png` 是同一相机的八倍整像素裁切。
