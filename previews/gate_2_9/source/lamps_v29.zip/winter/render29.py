#!/usr/bin/env python3
"""Rebuild the winter native frames, 11-second review, and two-cycle lossless volume set."""
from pathlib import Path
import argparse,hashlib,json
import numpy as np
from PIL import Image
from render28 import movie,sha,write_native
from winter24 import WinterV24
from winter_lamp29 import prepare

N=330;BASE='da3d59cbde68abfe593813cb114ccbe9018af1458e944b05138557228a27de1e'
def digest(a):return hashlib.sha256(np.ascontiguousarray(a).data).hexdigest()

def run(work,out,base_native=None):
    work.mkdir(parents=True,exist_ok=True);out.mkdir(parents=True,exist_ok=True)
    if base_native is not None:
        old=np.load(base_native,mmap_mode='r')
    else:
        # The previous full source is included; the first run independently rebuilds
        # its earlier static scene and physical reading-room revision.
        oldwork=work/'v28';oldwork.mkdir(exist_ok=True);old,_=write_native(oldwork,None)
    assert old.shape==(N,180,320,3) and digest(old)==BASE
    scene=WinterV24(); cut,cov=prepare(scene)
    support=np.zeros((180,320),bool);support[cut]=cov>0
    np.save(work/'geometry_support.npy',support)
    ary=np.lib.format.open_memmap(work/'winter_native.npy',mode='w+',dtype=np.uint8,shape=old.shape)
    raw_extra=[];perframe=[]
    for i in range(N):
        frm=scene.frame(i/30);q=np.any(frm!=old[i],axis=2)
        q[105:116,250:264]=False
        raw_extra.append(int(np.count_nonzero(q&~support)))
        # The captured hood has no shadow rays: keep the exact prior atmospheric glow
        # and ground light on rays that did not hit any new steelwork.
        ary[i]=old[i];ary[i,support]=frm[support];perframe.append(int(np.count_nonzero(q&support)))
        if i%66==0:print('winter',i,flush=True)
    ary.flush();assert min(perframe)>0
    assert np.array_equal(ary[:,~support],old[:,~support])
    assert np.array_equal(ary[:,98:122,242:274],old[:,98:122,242:274])
    assert np.array_equal(ary[0,support],scene.frame(11)[support])
    xy=(42,31,92,66)
    for i in (0,165,205,225):
        for label,s in [('before',old),('after',ary)]:
            im=Image.fromarray(s[i]);im.save(work/f'{label}_f{i:03d}.png')
            im.crop(xy).resize((400,280),Image.Resampling.NEAREST).save(work/f'{label}_crop_f{i:03d}.png')
    movie(ary,out/'winter_loop.mp4',review=True)
    master=work/'winter_lossless_660.mp4';movie(ary,master,twice=True)
    vol=out/'lossless_parts/winter';vol.mkdir(parents=True,exist_ok=True)
    parts=[]
    with master.open('rb') as src:
        for i,buf in enumerate(iter(lambda:src.read(8_000_000),b'')):
            target=vol/f'part-{i:02d}.bin';target.write_bytes(buf);parts.append({'path':str(target.relative_to(out)),'bytes':len(buf),'sha256':sha(target)})
    assert len(parts)==6
    (work/'winter_parts.json').write_text(json.dumps({'output':'winter_loop.mp4','bytes':master.stat().st_size,'sha256':sha(master),'parts':parts},indent=2)+'\n')
    y,x=np.where(support);active=np.any(ary!=old,axis=(0,3));rr,cc=np.where(active)
    audit=dict(baseline='v2.8',baseline_native_sha256=BASE,native_sha256=digest(ary),actual_edit_union_pixels=int(active.sum()),geometry_xyxy=[int(x.min()),int(y.min()),int(x.max()+1),int(y.max()+1)],actual_edit_xyxy=[int(cc.min()),int(rr.min()),int(cc.max()+1),int(rr.max()+1)],geometry_projection_pixels=int(support.sum()),raw_off_support_except_old_reader_per_frame=raw_extra,final_off_support_differences_all_330=0,reading_room_whole_window_rgb_sha256=digest(ary[:,98:122,242:274]),changed_pixels_per_frame=perframe,review_bytes=(out/'winter_loop.mp4').stat().st_size,review_sha256=sha(out/'winter_loop.mp4'),phase_330_matches_zero=True,frame_165_crop_xyxy=xy)
    (work/'winter_v29_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    print('winter final',audit['native_sha256'],audit['actual_edit_union_pixels'],flush=True)
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--work',type=Path,default=Path('work_v29'));a.add_argument('--out',type=Path,default=Path('out_v29'));a.add_argument('--baseline-native',type=Path);k=a.parse_args();run(k.work,k.out,k.baseline_native)
