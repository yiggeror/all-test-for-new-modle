# 夏 · 雨夜路灯（Gate 2.9）
在有 FFmpeg/libx264、Noto CJK 和 requirements.txt 中 Python 包的环境运行：

```sh
NUMBA_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 python build_summer_v29.py --out build
```

运行后，`build/summer_loop.mp4` 是 11 秒、330 帧的独立审片循环。
`build/render/summer_native.npy` 为 320×180 原生 RGB，`build/summer_double_lossless.mp4` 是 6× 最近邻、BT.709 限幅的无损编码双循环；
`build/lossless_parts/summer/` 含 8 份连续的原件字节。输出目录应与已有结果分开。

`summer_fixture.py` 定义了装在实际水泥杆上的两道环箍、耳片、向上回弯的钢挑管、焊接斜撑及有翻边的搪瓷铁罩。以锁定机位的 8×8 子像素射线与原场景作深度测试，在原有辉光与量化链上呈现湿铁的背光轮廓。原灯泡、色温、向下光锥、地面光池和发光组保持原值，真实受遮挡的雨点按灯具深度合成。夏景上一个批准版本的光照、湿路面、车灯、招牌与动态代码随源保留；不依赖旧成片、素材截图或外部资产。
