"""重建夏季 330 帧原生循环、1080p 审片文件、无损双循环及 8 分卷。"""
import argparse
from pathlib import Path
import subprocess,sys
import numpy as np
from encode import exact

HERE=Path(__file__).resolve().parent
def preview(master,proxy):
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-nostdin','-y','-threads','2','-i',str(master),
                    '-map','0:v:0','-frames:v','330','-an','-c:v','libx264','-preset','medium',
                    '-tune','animation','-crf','15','-maxrate','5100k','-bufsize','7000k',
                    '-x264-params','threads=1:lookahead-threads=1:sync-lookahead=0:aq-mode=3:aq-strength=.78:scenecut=0:open-gop=0',
                    '-g','330','-threads','1','-pix_fmt','yuv420p','-profile:v','high','-level:v','4.0',
                    '-colorspace','bt709','-color_range','tv','-color_primaries','bt709','-color_trc','bt709',
                    '-movflags','+faststart',str(proxy)],check=True)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--out',type=Path,default=Path('out_v29'))
    p.add_argument('--from-native',type=Path,help='仅打包已渲染的原生序列')
    a=p.parse_args()
    out=a.out.resolve(); out.mkdir(exist_ok=True,parents=True)
    if a.from_native is None:
        render=out/'render'
        subprocess.run([sys.executable,str(HERE/'render_summer.py'),'--out',str(render)],check=True)
        a.from_native=render/'summer_native.npy'
    rgb=np.load(a.from_native,mmap_mode='r')
    assert (rgb.shape,rgb.dtype)==((330,180,320,3),np.uint8)
    master=out/'summer_double_lossless.mp4'
    exact(rgb,master,2)
    # 首个完整循环单独导出，QP 0 的双循环保持原分卷接口。
    proxy=out/'summer_loop.mp4'
    preview(master,proxy)
    subprocess.run([sys.executable,str(HERE/'split_parts.py'),str(master),str(out)],check=True)
    subprocess.run([sys.executable,str(HERE/'verify_master.py'),'summer',str(a.from_native),str(master),
                    str(out/'summer_verified.json')],check=True)
if __name__=='__main__': main()
