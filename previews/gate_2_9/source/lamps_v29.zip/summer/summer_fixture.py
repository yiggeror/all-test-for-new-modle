"""夏夜老街灯：套在既有近景水泥杆上的钢件。独立的三维可见性通道不重抽街景间接光。"""
import numpy as np
from engine.rt import Accel
from engine.world import World, MASK_NOSHADOW, MASK_NOBOUNCE, MASK_HIDDEN

STEEL, STAY, BANDS, SHADE, LIP, POST = range(1,7)
X,Z = -6.,1.20
LAMP = np.array([-6.,6.00,2.95])   # 已有钠灯的光源位置，不新加灯

def fixture():
    w=World(seed=29)
    def tube(a,b,r,r1=None,sides=12,tag=STEEL,caps=False):
        w.tube(a,b,r,r1,sides=sides,tag=tag,seed=.3,caps=caps,
               mask=MASK_NOSHADOW | MASK_NOBOUNCE)
    # 抱箍扣在原混凝土圆杆上，墙角来的间接光掠过杆面湿边。
    # POST 的薄表层与原 8 边水泥杆同轴同锥度，只计算此处潮湿表面的受光。
    def concrete_radius(y): return .16-.06*((y-.15)/8.)
    tube((X,4.80,Z),(X,7.38,Z),concrete_radius(4.80)+.003,concrete_radius(7.38)+.003,
         sides=8,tag=POST)
    for y, r in ((5.43,.150),(5.96,.153)):
        tube((X,y-.037,Z),(X,y+.037,Z),r,sides=12,tag=BANDS,caps=True)
    # 靠杆竖耳片与两根箍相接。管根穿入耳片，避免管端与抱箍之间悬空。
    w.box((X,5.70,Z+.134),(.112,.595,.066),seed=.3,tag=STAY,
          mask=MASK_NOSHADOW | MASK_NOBOUNCE)
    # 上挑管略拱起，在灯头之前回弯落入螺纹灯颈；下撑与它在悬臂中段焊接。
    p=np.array([[X,5.95,Z+.110],[X,6.035,Z+.32],[X,6.235,Z+.76],
                [X,6.435,Z+1.23],[X,6.48,Z+1.49],[X,6.47,Z+1.62],
                [X,6.434,Z+1.70],[X,6.391,Z+1.745],[X,6.340,Z+1.75]])
    p[:,1]+=np.array([0.,0.,.015,.012,.007,0,0,0,0])
    tube(p[:-1],p[1:],.047,tag=STEEL)
    q=np.array([[X,5.43,Z+.11],[X,5.50,Z+.27],[X,5.82,Z+.65],
                [X,6.15,Z+1.03],[X,6.464,Z+1.43]])
    tube(q[:-1],q[1:],.038,tag=STAY)
    hz=Z+1.75
    # 旋压铁皮扁帽：收窄灯颈、圆锥顶盖、外卷边。旧玻璃和原发光面从下方露出。
    tube((X,6.405,hz),(X,6.333,hz),.071,.075,tag=BANDS,caps=True)
    tube((X,6.398,hz),(X,6.369,hz),.090,.124,tag=SHADE)
    tube((X,6.371,hz),(X,6.282,hz),.120,.263,tag=SHADE)
    tube((X,6.284,hz),(X,6.230,hz),.262,.290,tag=LIP)
    return w

def norm(x):
    return x/np.maximum(np.linalg.norm(x,axis=-1,keepdims=True),1e-12)

def appearance(tag,n,p,eye):
    # 限于这组湿金属的材质响应：软天光刻出外沿，临近灯罩的一面带局部暖色。
    # 这里不写回照明列表，也不向雨幕、地面或店面投射光。
    vs=norm(eye-p)
    sky=norm(np.array([-.66,.34,.69]))
    h=norm(sky+vs)
    ndl=np.maximum(0,n@sky)
    satin=(np.maximum(0,(n*h).sum(1))**8)
    L=norm(LAMP-p)
    dist=np.linalg.norm(LAMP-p,axis=1)
    rim=np.clip((-.4+n[:,1]*.0+np.maximum(0,(n*L).sum(1)))/.60,0,1)/(1+2*dist**2)
    base=np.array([[0,0,0],[.0120,.0157,.0190],[.0105,.0140,.0160],
                   [.0120,.0140,.0150],[.0055,.010,.0128],[.010,.014,.015],
                   [.0080,.0100,.0113]],np.float32)[tag]
    response=base*(.67+.65*ndl+.24*satin)[:,None]
    response+=rim[:,None]*np.array([.016,.0068,.0022])
    # 灯罩为深色搪瓷，上缘受冷雨光，翻边下缘映暖，不出现第二个发光块。
    factor=np.array([1.,2.00,2.05,2.16,.73,.85,1.50])
    response*=factor[tag,None]
    iron=(tag==STEEL)|(tag==STAY)|(tag==BANDS)
    response[iron]*=np.array([1.10,.81,.81])
    # 非发光铁件上，雨膜只在上沿捕光。避免钢管整段读成荧绿色。
    response[iron]+=np.maximum(n[iron,1],0)[:,None]**2*np.array([.010,.009,.010])
    # 冷天空在湿钢顶面留一线连续反光，抱箍及右上方挑臂与暗墙分层。
    post=(tag==POST)
    response[post]+=np.maximum(0,n[post] @ norm(np.array([-.84,.0,.54])))[:,None]**6*np.array([.001,.0025,.0042])
    fade=np.ones(len(p))
    pole=(tag==POST)
    fade[pole]=.72*np.clip((p[pole,1]-4.8)/.5,0,1)*np.clip((7.38-p[pole,1])/1.06,0,1)
    return response,fade

class FixturePass:
    def __init__(self,world,cam,acc,plate):
        f=fixture(); g=f.finalize()
        sub=Accel(g['v0'],g['v1'],g['v2'],g['tm'])
        self.bbox=None
        xyz=np.concatenate((g['v0'],g['v1'],g['v2']))
        px,py,_,_=cam.project(xyz)
        x0=max(0,int(np.floor(px.min()))-1); x1=min(cam.W,int(px.max()+2))
        y0=max(0,int(np.floor(py.min()))-1); y1=min(cam.H,int(py.max()+2))
        self.ys,self.xs=slice(y0,y1),slice(x0,x1)
        S=8; ny,nx=y1-y0,x1-x0
        y,x=np.mgrid[:ny*S,:nx*S]
        d=cam.dirs(x0+(x.ravel()+.5)/S,y0+(y.ravel()+.5)/S).astype(np.float32)
        o=np.broadcast_to(cam.pos.astype(np.float32),d.shape)
        t,tri=sub.closest(o,d); tb,base=acc.closest(o,d,mask=MASK_HIDDEN)
        wi=np.flatnonzero((tri>=0)&(t<tb+.0008)); faces=g['tf'][tri[wi]]
        tag=g['F']['tag'][faces]; normal=g['F']['n'][faces]
        normal=np.where((normal*d[wi]).sum(1,keepdims=True)>0,-normal,normal)
        p=o[wi]+d[wi]*t[wi,None]
        rgb,weight=appearance(tag,normal,p,cam.pos)
        a=np.zeros(len(t),np.float32); rgbbuf=np.zeros((len(t),3),np.float32)
        a[wi]=weight; rgbbuf[wi]=rgb*weight[:,None]
        self.alpha=a.reshape(ny,S,nx,S).mean((1,3))[...,None]
        self.reflect=rgbbuf.reshape(ny,S,nx,S,3).mean((1,3))
        # 与玻璃灯泡共占一个原生像素时保留原发光通道，避免平均后重新遮一次灯芯。
        b0=world.finalize(); mids=np.full(len(base),-1)
        ih=base>=0; mids[ih]=b0['F']['mat'][b0['tf'][base[ih]]]
        emitter=(mids==world.mats['emit']).reshape(ny,S,nx,S).any((1,3))
        self.alpha[emitter]=0; self.reflect[emitter]=0
        # 灯罩隔开灯泡和罩后空气；只保留少量镜内眩光。罩外的光晕与路面光池照旧。
        holdout=np.zeros(len(t),np.float32)
        holdout[wi]=np.choose(tag,[0,.18,.09,.18,.93,.89,0])
        self.hood_cut=holdout.reshape(ny,S,nx,S).mean((1,3))[...,None]
        self.hood_cut[emitter]=0
        # 雨点仍按相机到灯具的真实距离作前后遮挡。
        dd=np.minimum(t,tb).reshape(ny,S,nx,S).transpose(0,2,1,3).reshape(ny,nx,S*S)
        depth=plate['depth'][self.ys,self.xs]
        updated=np.sort(dd,axis=2)[:,:,((np.arange(depth.shape[-1])+.5)/depth.shape[-1]*S*S).astype(int)]
        mask=(self.alpha[...,0]>.01)
        depth[mask]=updated[mask]

    def apply(self,lin):
        target=lin[self.ys,self.xs]
        target*=1-self.alpha
        target+=self.reflect

    def shaded_halo(self,lin,bloomed):
        loc=(self.ys,self.xs)
        bloomed[loc]-=(bloomed[loc]-lin[loc])*self.hood_cut
        return bloomed
