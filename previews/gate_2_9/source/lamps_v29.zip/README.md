# Rainroji · Gate 2.9 四处灯具

按 Round 32 加固春景街灯与院灯、夏景街灯、冬景街灯。三个目录各自是该场景使用的完整可运行源码，不读取历史视频作为画面输入。各目录的 README 和 requirements 说明运行入口。秋景沿用已验收的原分卷，未改动，也不加入本次重渲。

- 春：`cd spring; python render29.py --out render; python encode29.py --out render`
- 夏：`cd summer; python build_summer_v29.py --out build`
- 冬：见 `winter/README.md`。

需要 Python 3.12、NumPy、Numba 和带 libx264 的 FFmpeg；逐景按 requirements 安装。渲染为 320×180 原生像素，再以 6 倍整数近邻扩到 1920×1080。每景独立审片为 330 帧（11 秒），分卷则由两期完全相同的 330 帧组成（总 22 秒）。
