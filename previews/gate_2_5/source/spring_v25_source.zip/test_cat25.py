from collections import Counter
import unittest
import numpy as np
from cat25 import route,mesh,CAT_TAIL,CAT_BODY_M,HOLD,PATH_LEN

class CourtGeometry(unittest.TestCase):
    def test_exact_world_closure_and_true_path_separation(self):
        F=[route(fr) for fr in range(331)]
        self.assertTrue(np.array_equal(F[0][0],F[330][0]))
        self.assertEqual(F[0][1],F[330][1])
        a=np.array([p[0] for p in F])
        self.assertTrue((a[:,1]==0).all())
        def nearest_r(i,j):
            k=i+int(np.argmin(abs(a[i:j,0]-4.25))); return a[k,2]
        self.assertGreater(abs(nearest_r(8,95)-nearest_r(185,250)),1.0)
        self.assertGreater(PATH_LEN,4.6)
        p=a[HOLD[0]]
        self.assertTrue(all(np.array_equal(q,p) for q in a[HOLD[0]:HOLD[1]+1]))

    def test_same_cat_watertight_equal_at_actual_wrap(self):
        a=mesh(0)[0].finalize(); z=mesh(330)[0].finalize()
        for k in ('v0','v1','v2','tf','tm'):np.testing.assert_array_equal(a[k],z[k])

    def test_planted_feet_never_sink_or_resize_head(self):
        self.assertTrue(.42<=CAT_BODY_M<=.48)
        for f in range(0,330,5):
            w,i=mesh(f);g=w.finalize()
            t=g['F']['tag'][g['tf']]
            v=np.concatenate([g[k] for k in ('v0','v1','v2')])
            u=np.concatenate([g[k][t!=CAT_TAIL] for k in ('v0','v1','v2')])
            self.assertGreaterEqual(v[:,1].min(),-1e-5)
            self.assertLessEqual(u[:,1].max(),.341)
            self.assertTrue(any(i['feet_planted']))

if __name__=='__main__':unittest.main()
