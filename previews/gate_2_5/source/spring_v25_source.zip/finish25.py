"""Encode the true Gate 2.5 render, then prepare readback stills/strips and physical controls."""
import argparse
import csv
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy.ndimage import label,maximum_filter
from pack import encode, rgb_key
from scene25 import gains, palette, CLOTH_RECT
from cat25 import HOLD, PATH_LEN, route
from spring23 import shot, roty
from verify_exact import exact_master

W,H,S=320,180,6
HERE=Path(__file__).resolve().parent

def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def wr(path,x):
    path.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def font(size):
    p=Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
    return ImageFont.truetype(str(p) if p.is_file() else 'DejaVuSans.ttf',size,index=2 if p.is_file() else 0)

def contiguous_pts(media):
    p=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_streams','-show_packets',
                                          '-show_entries','stream=time_base,nb_frames,avg_frame_rate:packet=pts,duration',
                                          '-of','json',str(media)]))
    v,=p['streams']; t=Fraction(v['time_base'])
    frames=[int(x['pts'])*t for x in p['packets']]
    durations={int(x['duration'])*t for x in p['packets']}
    assert sorted(frames)==[Fraction(i,30) for i in range(660)]
    assert durations=={Fraction(1,30)} and v['nb_frames']=='660' and v['avg_frame_rate']=='30/1'
    return {'pts_count_checked':len(frames),'packet_time_base':str(t),'step_frame_seconds':'1/30',
            'min_pts':'0','max_pts':'659/30','identical_timestamps':0,'missing_timestamps':0}

def principal_wheel_px():
    cam=shot.camera()
    t=-.095
    M=roty(.21)@np.array([[1.,0,0],[0,np.cos(t),-np.sin(t)],[0,np.sin(t),np.cos(t)]])
    a=np.linspace(0,np.pi*2,181)
    roots=np.array([-1.78,0,13.30])
    vals=[]
    for x in [-.54,.54]:
        pos=np.column_stack((x+.398*np.cos(a),.40+.398*np.sin(a),np.zeros_like(a)))
        xx,yy,_,_=cam.project(pos@M.T+roots)
        vals.append({'approx_roadster_tire_world_diameter_m':.796,'height_approx_native_px':float(np.ptp(yy)),
                     'pixel_bounds':[float(v) for v in (min(xx),min(yy),max(xx),max(yy))]})
    return vals

def components(m):
    feat,n=label(m,np.ones((3,3),int))
    return feat,n

def split(out,f):
    whole=hashlib.sha256(); rows=[]
    p=out/'lossless_parts/spring';p.mkdir(parents=True,exist_ok=True)
    with f.open('rb') as fp:
        i=0
        while b:=fp.read(8_000_000):
            n=p/f'part-{i:02d}.bin';n.write_bytes(b)
            whole.update(b)
            rows.append({'path':str(n.relative_to(out)),'bytes':len(b),'sha256':sha(n)})
            i+=1
    doc={'output':f.name,'bytes':f.stat().st_size,'sha256':whole.hexdigest(),'parts':rows}
    with f.open('rb') as fp:
        assert all((out/r['path']).read_bytes()==fp.read(r['bytes']) for r in rows)
        assert not fp.read(1)
    assert sha(f)==doc['sha256']
    wr(out/'lossless_parts/MANIFEST.json',{'spring':doc})
    return doc

def thumbnail(plate,rect,up=4):
    x0,y0,x1,y1=rect
    return Image.fromarray(plate).crop(rect).resize(((x1-x0)*up,(y1-y0)*up),Image.Resampling.NEAREST)

def contact(name,text,rows,path,cols=7):
    pw,ph=rows[0][1].size
    nrows=(len(rows)+cols-1)//cols
    r=Image.new('RGB',(24+(pw+6)*cols,max(79+nrows*(ph+20),98)),'#261f2c')
    d=ImageDraw.Draw(r)
    d.text((12,5),name,fill='#ffead5',font=font(21))
    d.text((12,35),text,fill='#d0b8c5',font=font(14))
    for i,(cap,im) in enumerate(rows):
        yy=61+(i//cols)*(ph+20);xx=12+(i%cols)*(pw+6)
        r.paste(im,(xx,yy));d.text((xx,yy+ph+1),cap,fill='#f3dfc8',font=font(12))
    r.save(path,quality=96,subsampling=0) if path.suffix=='.jpg' else r.save(path,optimize=True)

def same(a,b):return np.array_equal(a,b)

def percentage(n,d):return float(n)/int(d)*100

def metrics(per_frame,mask,selected):
    rows=per_frame & mask[None]
    numer=rows.sum((1,2));den=int(mask.sum())
    used=rows[selected].any(0)
    cnt=int(used.sum())
    return {
        'denominator_full_native_pixels':den,
        'selected_samples':int(len(selected)),
        'same_scope_min_numerator':int(numer[selected].min()),
        'same_scope_max_numerator':int(numer[selected].max()),
        'same_scope_mean_numerator':float(numer[selected].mean()),
        'min_percent':percentage(numer[selected].min(),den),
        'max_percent':percentage(numer[selected].max(),den),
        'mean_percent':percentage(numer[selected].mean(),den),
        'union_numerator':cnt,'union_percent':percentage(cnt,den),
        'count_by_zero_based_frame_index':numer.tolist()
    }

def art_proof(out,native,baseline=None):
    q=np.load(out/'spring_layer_proof.npz',allow_pickle=False)
    frames=q['frame_ids']
    assert frames.tolist()==list(range(330)) and native.shape==(330,H,W,3)
    def load(name):
        r=np.load(out/f'spring_control_{name}_all330.npz',allow_pickle=False)
        assert same(r['frame_ids'],frames)
        return r['rgb_off']
    no_wind,no_cat,no_shadow=[load(s) for s in ('leaf','cat','cat_shadow')]
    t=json.loads((out/'spring_physical.json').read_bytes())
    assert [p['frame'] for p in t]==list(range(331))
    seam0=q['raw_frame_0'];seam330=q['raw_new_trace_frame_330'];quant330=q['native_actual_frame_330']
    assert same(seam0,seam330) and same(native[0],quant330)
    assert t[330]['visible_cat']==t[0]['visible_cat'] and t[330]['visible_cat']['ray_hits_after_world_and_cloth_depth']>0
    assert not same(native[-1],native[0]),'physical closure is 330==0, not a duplicate final held frame'
    permitted=set(map(int,rgb_key(palette()['rgb'])))
    used={int(k) for frame in native for k in np.unique(rgb_key(frame))}
    assert used.issubset(permitted) and len(used)<=60
    # Do not infer the ROI from what moved. Mine the entire original supersampled leaf projection.
    eligible=q['eligible_leaf'];frac=q['leaf_primary_ray_fraction'];full=frac>=.5;pure=frac>=.999
    lock=q['protected_geometry'];depth=q['native_median_depth'];dy=q['leaf_offset'][:,0];dx=q['leaf_offset'][:,1]
    assert same(full,eligible) and int(full.sum())==11122 and int(pure.sum())==8681
    assert same(lock,q['static_branch_and_wire']|q['light_fixture_surfaces']|q['architecture'])
    wy,wx=np.mgrid[:H,:W]
    wave=(np.abs(dx)+np.abs(dy))!=0
    assert max(np.max(np.abs(dx)),np.max(np.abs(dy)))<=1
    assert np.all((np.abs(dx)+np.abs(dy))<=1)
    assert not np.any(wave&lock)
    assert not np.any(wave&~pure)
    dcmax=0.
    for j in range(330):
        to=wave[j]; a=(wy+dy[j])[to]; b=(wx+dx[j])[to]
        assert len(a)>0 and np.all(a>=0) and np.all(b>=0) and np.all(a<H) and np.all(b<W)
        assert np.all(pure[a,b]&~lock[a,b])
        diff=abs(depth[to]-depth[a,b])
        dcmax=max(dcmax,float(diff.max()))
        assert float(diff.max())<=1.501
        if j%5:assert same(dy[j],dy[j-1]) and same(dx[j],dx[j-1])
    vis_w=np.any(native!=no_wind,axis=3)
    assert not np.any(vis_w & (~pure|lock)) and not np.any(vis_w&~wave)
    not_dip=np.r_[:138,144:330]
    both=metrics(vis_w,full,not_dip)
    all_frames=metrics(vis_w,full,np.arange(330))
    by_pure=metrics(vis_w,pure,not_dip)
    # Frozen-light wind-only images were independently toned and palette-quantized
    # inside the clean renderer; this is not an estimate using coordinate changes.
    fixed=q['reference_wind_only_66_all'];initial=q['reference_wind_only_off']
    frozen_motion=np.any(fixed!=initial[None],axis=3)
    frozen_step=np.any(fixed!=np.roll(fixed,1,axis=0),axis=3)
    assert len(fixed)==66 and not np.any((frozen_motion|frozen_step)&(~pure|lock))
    ref_ab=metrics(frozen_motion,full,np.arange(66))
    ref_step=metrics(frozen_step,full,np.arange(66))
    ref_pure_step=metrics(frozen_step,pure,np.arange(66))
    repeat=np.repeat(fixed,5,axis=0)
    held=np.any(repeat!=np.roll(repeat,1,axis=0),axis=3)
    held_stats=metrics(held,full,np.arange(330))
    assert not np.any(held[np.arange(330)%5!=0])
    for r in (both,ref_ab,ref_step):
        assert 8<=r['min_percent'] and r['max_percent']<=18, r['min_percent']
    assert min(all_frames['union_percent'],both['union_percent'],ref_ab['union_percent'],ref_step['union_percent'])>=70
    # Exact native cats from the 3D BVH and same-phase actor/no-actor images.
    body=q['cat_samples'];blocked=q['cat_candidate_and_blocked'];shadow=q['cat_shadow']
    assert np.array_equal(blocked[:,0]-blocked[:,1],body.sum(1))
    actor=t[0]['visible_cat']
    assert .42<=actor['body_length_m']<=.48 and .24<=actor['shoulder_height_m']<=.28
    assert max(p['visible_cat']['head_and_ears_max_m'] for p in t)<=.34
    assert all(p['visible_cat']['edge_static_collision_count']==0 for p in t)
    assert all(any(p['visible_cat']['feet_planted']) for p in t)
    cat_visible=body[:,:3].sum(1)>=3
    weak_cat_samples=(np.any(np.abs(native.astype(np.int16)-no_cat.astype(np.int16))>=8,axis=3)&cat_visible).sum((1,2))
    alpha_diff=(np.any(native!=no_cat,axis=3)&cat_visible).sum((1,2))
    true_shadow=(shadow.max(1)>25)
    raw_shadow=(np.any(native!=no_shadow,axis=3)&true_shadow)
    assert np.min(weak_cat_samples)>=6 and int((alpha_diff>0).sum())==330
    assert int(np.count_nonzero(raw_shadow.any((1,2))))>=320
    root_points=np.array([p['visible_cat']['root'] for p in t],float)
    yaw=np.array([p['visible_cat']['yaw_radians'] for p in t])
    screen=np.array([p['visible_cat']['projected_root'] for p in t])
    world_render_visible=[p['visible_cat']['ray_hits_after_world_and_cloth_depth'] for p in t]
    assert min(world_render_visible)>0 and np.all(root_points[:,1]==0)
    assert same(root_points[330],root_points[0]) and yaw[330]==yaw[0]
    # During each held 5-frame tooth, the actor geometry and camera projection are fixed.
    assert all(np.array_equal(body[j],body[j-j%5]) and np.array_equal(root_points[j],root_points[j-j%5]) for j in range(330))
    path_geometry=np.array([route(j)[0] for j in range(331)])
    assert same(path_geometry[0],path_geometry[-1])
    def crossing(a,b):
        i=a+int(np.argmin(np.abs(screen[a:b,0]-211.5)))
        return {'frame':i,'x':float(path_geometry[i,0]),'z':float(path_geometry[i,2]),
                'screen_x':float(screen[i,0]),'screen_y':float(screen[i,1])}
    outbound=crossing(5,100);back=crossing(173,260)
    assert abs(outbound['z']-back['z'])>.65
    assert abs(outbound['screen_y']-back['screen_y'])>3.4
    assert same(root_points[HOLD[0]],root_points[HOLD[1]])
    assert all(same(r,root_points[HOLD[0]]) for r in root_points[HOLD[0]:HOLD[1]+1])
    spaced=np.r_[np.arange(0,330,5),330]
    max_step=float(np.max(np.linalg.norm(np.diff(root_points[spaced],axis=0),axis=1)))
    yaw_step=np.abs(np.diff(np.unwrap(yaw[spaced])))
    max_yaw_step_degrees=float(np.max(yaw_step)*180/np.pi)
    assert max_step<.38 and max_yaw_step_degrees<80.
    head_checks=[];partial=[]
    for j in range(330):
        h,torso=body[j,0]>=3,body[j,1]>=3
        f,n=components(h|torso)
        ch=set(int(x) for x in f[h])-{0}
        ct=set(int(x) for x in f[torso])-{0}
        if not(ch and ct):partial.append(j)
        else:head_checks.append(bool(ch&ct))
    assert all(head_checks)
    shadows_by_phase=raw_shadow.sum((1,2))
    Y=np.array([.2126,.7152,.0722])
    ldiff=np.abs((native.astype(np.int16)-no_cat.astype(np.int16))@Y)
    vals=(ldiff*cat_visible).sum((1,2))/cat_visible.sum((1,2))
    cfa=[q['cat_samples'][j,3]>2 for j in (105,120,130,145)]
    assert any(not same(cfa[0],x) for x in cfa[1:])
    legs=[]
    for j,p in enumerate(t):
        feet=p['visible_cat']['feet_planted'];soles=np.array(p['visible_cat']['soles_world'])
        assert all(np.isclose(soles[i,1],0.,atol=.001) for i,s in enumerate(feet) if s)
        legs.append(sum(feet))
    protected={
        'branch_wire_pixels_stable_for_entire_wind_comparison':int(q['static_branch_and_wire'].sum()),
        'fixture_pixels_stable_for_entire_wind_comparison':int(q['light_fixture_surfaces'].sum()),
        'fixed_nonfoliage_architecture_pixels_stable':int(q['architecture'].sum()),
        'moving_protected_pixels':int((vis_w&lock).any(0).sum()),
        'moving_outside_11122_roi':int((vis_w&~full).any(0).sum()),
        'raw_depth_delta_highest_between_real_neighbors_m':dcmax,
    }
    keep={}
    if baseline:
        last=json.loads((baseline/'spring_physical.json').read_bytes())
        assert len(last)==330
        cols=('lamp_gain','tv_tint','birds','moths')
        agree={k:all(t[j][k]==last[j][k] for j in range(330)) for k in cols}
        assert all(agree.values())
        assert (out/'spring_petal_origins.json').read_bytes()==(baseline/'spring_petal_origins.json').read_bytes()
        A=np.load(out/'spring_cloth_pose_proof.npz',allow_pickle=False)
        B=np.load(baseline/'spring_cloth_pose_proof.npz',allow_pickle=False)
        clo={k:same(A[k],B[k]) for k in A.files}
        assert all(clo.values())
        a,b,c,d=CLOTH_RECT
        pc=A['cover'][np.arange(330)//5]>.999
        old=np.load(baseline/'spring_native.npy',mmap_mode='r',allow_pickle=False)
        identical=np.all(native[:,c:d,a:b]==old[:,c:d,a:b],axis=3)
        keep={'exact_old_blossom_source_195_routes':True,'unchanged_action_trace_all_330':agree,
              'exact_frozen_attachment_mesh_lighting_cover_for_all_66_cloth_poses':clo,
              'fully_covered_cloth_pixels_old_new_compared':int(pc.sum()),
              'their_pixel_differences':int((pc&~identical).sum())}
        assert keep['their_pixel_differences']==0
    gain=np.array([p['lamp_gain'] for p in t[:330]])
    nominal=np.array([gains(i,False)[0] for i in range(330)])
    assert np.array_equal(np.flatnonzero(gain/nominal<.9),np.arange(138,144))
    assert np.allclose(gain[138:144]/nominal[138:144],.82)
    live_movie=np.any(native!=np.roll(native,1,axis=0),axis=3)&full
    live_30=metrics(live_movie,full,not_dip)
    shot_stats={'wind_6fps_actor_region_holds_each_5_frames':True,
        'raw_layer_max_donor_distance_manhattan_px':1,
        'full_mask_formula':'tag1 >= 0.5 from exactly nine true primary rays at fixed approved camera',
        'only_pure_mask_formula':'tag1 >= 0.999 from the same nine true rays; all borrow and destination sites inside',
        'composited_same_phase_wind_off_entire_330_actual_full':all_frames,
        'composited_same_phase_wind_off_324_nondip_actual_full':both,
        'excluded_from_nonlamp_comparison_half_open_frames':[138,144],
        'composited_actual_same_phase_ab_alternative_pure_denominator':by_pure,
        'fixed_lighting_66_pose_ab_full':ref_ab,
        'fixed_lighting_actual_66_adjacent_6fps_full':ref_step,
        'fixed_lighting_actual_66_adjacent_6fps_pure':ref_pure_step,
        'fixed_lighting_330_adjacent_with_legitimate_holds':held_stats,
        'native_composited_playback_330_adjacent_other_fx_included':live_30,
        'protected':protected}
    cat_stats={'primary_unoccluded_or_partial_frames_num_denom':[int(np.count_nonzero(np.array(world_render_visible[:330])>0)),330],
               'primary_unoccluded_or_partial_percent':100.,
               'body_rgb_diff_at_least_8_min_over_330':int(min(weak_cat_samples)),
               'body_support_pixels_min_over_330':int(cat_visible.sum((1,2)).min()),
               'raw_real_body_hits_min':int(min(world_render_visible)),
               'body_nonzero_ab_count_all_frames':alpha_diff.tolist(),
               'body_Luma_mean_abs_difference_min_median':[float(np.min(vals)),float(np.median(vals))],
               'ground_contact_shadow_threshold_counts_all_frames':shadows_by_phase.tolist(),
               'sample_render_mesh_stance_soless_grounded_all_331':legs,
               'c0_c330_exact_new_raw_pixel_sha256':hashlib.sha256(seam0).hexdigest(),
               'c0_c330_exact_new_quantized_pixel_sha256':hashlib.sha256(native[0]).hexdigest(),
               'hold_root_frames_inclusive':list(HOLD),'normal_body_length_m':actor['body_length_m'],
               'wheel_reference':principal_wheel_px(),
               'route_length_m':float(PATH_LEN),'farther_outbound_and_return_same_x':[outbound,back],
               'max_6fps_world_step_m':max_step,'max_6fps_heading_step_deg':max_yaw_step_degrees,
               'head_torso_rendered_contiguous_when_both_tags_sampled':[int(sum(head_checks)),int(len(head_checks))],
               'foreshortened_partial_head_torso_pixel_samples_frames':partial,
               'geometry_collision_with_static_all_66_active_meshes':0}
    summary={'scope':'330 paired exact native controls generated in the same actual render; not a test tile',
             'native_palette_unique_colors':len(used),
             'wind':shot_stats,'cat':cat_stats,'retained_from_24':keep,
             'lamp_notch_half_open_f':[138,144],'lamp_radiance_ratio':.82}
    return summary,t,vis_w,frozen_step,no_cat,full

def round19_scope(out,native,trace,no_cat,baseline):
    q=np.load(out/'spring_layer_proof.npz',allow_pickle=False)
    root=np.array([k['visible_cat']['projected_root'] for k in trace[:330]])
    actor=q['cat_samples']
    ears=q['cat_ear_real_ray_samples']
    occluded=q['cat_candidate_and_blocked'][:,1]
    shadow=q['cat_shadow'].max(1)>0
    body=actor.sum(1)>0
    assert np.all(ears<=actor[:,0])  # ears are already included in head coverage
    assert np.array_equal(ears.sum((1,2)),np.array([t['visible_cat']['visible_ear_ray_hits'] for t in trace[:330]]))
    c=np.any(native!=no_cat,axis=3)
    allowed=body|maximum_filter(shadow,size=(1,3,3))
    assert not np.any(c&~allowed),'non-actor change outside true body + shadow response support'
    warmth=[]; luma=[]
    for j,(x,y) in enumerate(root):
        iy=int(y);ix=int(x)
        sample=no_cat[j,max(0,iy-1):min(180,iy+2),ix-2:ix+3].astype(np.int16)
        warmth.append(float(np.median(sample[...,0]-sample[...,2])))
        vv=actor[j,:3].sum(0)>=3
        b=native[j].astype(np.int16)-no_cat[j].astype(np.int16)
        luma.append(float(np.mean(np.abs(b[vv].astype(np.float64)@np.array([.2126,.7152,.0722])))))
    b=np.array([k['visible_cat']['body_box_native_without_tail'] for k in trace[:330]])
    whole=np.array([k['visible_cat']['full_box_native_with_tail'] for k in trace[:330]])
    w=b[:,2]-b[:,0]+1;h=b[:,3]-b[:,1]+1
    assert root[:,0].min()>=194 and root[:,0].max()<=238 and np.ptp(root[:,0])>=30
    assert min(w)>=5 and min(w[250:311])>=6
    assert min(warmth)>=35
    assert min(luma)>=8
    assert np.all(whole[:,0]>=187)&np.all(whole[:,2]<245)&np.all(whole[:,3]<180)
    result={'round19_readback_same_native_colors_without_tonal_enhancement':True,
         'actor_x_span_px':[float(root[:,0].min()),float(root[:,0].max())],
         'actor_center_y_span_px':[float(root[:,1].min()),float(root[:,1].max())],
         'min_width_core_all_330':int(w.min()),'max_width_core_all_330':int(w.max()),
         'min_width_core_review_f250_310':int(w[250:311].min()),'height_core_range':[int(h.min()),int(h.max())],
         'warm_ground_center_patch_median_R_minus_B_min_over_330':min(warmth),'warm_ground_center_patch_R_minus_B_by_frame':warmth,
         'body_luma_contrast_abs_8bit_by_frame':luma,'body_luma_contrast_abs_8bit_min':min(luma),
         'ear_primary_sample_min_over_330':int(ears.sum((1,2)).min()),
         'cat_actor_off_only_native_changed_pixels_by_frame':c.sum((1,2)).tolist(),
         'changed_pixels_outside_actor_or_one_px_shadow_kernel_count':0}
    if baseline is not None:
        old=np.load(baseline/'spring_native.npy',mmap_mode='r',allow_pickle=False)
        old_off=np.load(baseline/'spring_control_cat_all330.npz',allow_pickle=False)['rgb_off']
        assert same(old_off,no_cat),'noncat scene changed'
        # Full native cat-off proves all other actors, illumination and timing
        # together, rather than relying on a scene-script prose promise.
        old_actor=np.any(old!=old_off,axis=3)
        new_vs_old=np.any(old!=native,axis=3)
        assert not np.any(new_vs_old&~(old_actor|c))
        before=np.load(baseline/'spring_layer_proof.npz',allow_pickle=False)
        names=('eligible_leaf','leaf_primary_ray_fraction','protected_geometry','native_median_depth',
               'leaf_offset','reference_wind_only_off','reference_wind_only_66_all')
        wind={k:same(q[k],before[k]) for k in names}
        assert all(wind.values())
        last=json.loads((baseline/'spring_physical.json').read_bytes())
        tags=('lamp_gain','tv_tint','petal_meta','birds','moths')
        motion={name:all(row[name]==a[name] for row,a in zip(trace,last,strict=True)) for name in tags}
        assert all(motion.values())
        result.update(r18_entire_cat_off_AB_RGB_exact_all_frames=True,
             r18_exact_cat_off_rgb_bytes=int(old_off.nbytes),
             r18_exact_background_frame_samples=330,
             r18_cat_off_sha256=hashlib.sha256(np.ascontiguousarray(old_off)).hexdigest(),
             r18_frozen_whole_crown_artifacts_exact=wind,
             r18_noncats_dynamic_phase_traces_exact=motion,
             new_vs_r18_changes_outside_old_new_cat_and_shadow_causal_union=0)
    return result


def native_heat(out,native,vis_w,phase_masks,full,summary):
    c=vis_w.sum(0)
    freq=np.minimum(1,np.sqrt(c/max(1,c.max())))
    u=np.clip(np.stack([.20+.70*freq,.33+.61*freq,.44+.50*freq],-1),0,1)*255
    src=native[125].copy().astype(np.float32)
    heat=src*.32
    heat[full]=src[full]*.38+[36,25,24]
    heat[c>0]=src[c>0]*.36+u[c>0]*.64
    natural=thumbnail(native[125],(0,0,W,H),3)
    hue=thumbnail(heat.astype(np.uint8),(0,0,W,H),3)
    R=summary['wind']['composited_same_phase_wind_off_entire_330_actual_full']
    title='真实 330 · 樱花整冠风场'
    text=f"有风／同相关风原生对比，累计 {R['union_numerator']}/{R['denominator_full_native_pixels']}={R['union_percent']:.2f}%。"
    contact(title,text,[('F125 actual native',natural),('330 phase-linked A/B heat overlay',hue)],out/'spring_wind_heatmap_330.jpg',cols=2)
    # Phase fronts are real changed pixels, not the mask used to validate them.
    rt=(106,0,320,156); frames=list(range(50,80,5))
    panels=[]
    for j in frames:
        mask=phase_masks[j//5]
        N=np.uint8(native[j]*.38)
        N[mask]=(77,200,230)
        panels.append((f'F{j:03d} · {int(mask.sum())}/11122',thumbnail(N,rt,2)))
    contact('风脉实像素 · 6fps相邻姿态','蓝色为固定光下本实际姿态与上一姿态的量化 RGB 差。整冠连贯迁移。',panels,out/'spring_wind_phase_fronts.jpg',cols=3)

def evidence(out,master,native,trace,without_cat):
    peaks={
        0:'cat_present_initial',65:'cat_toward_warm_left',
        120:'swallows_and_ground_cat',125:'cat_scent_pause',
        141:'locked_lamp_notch',150:'warm_ground_look_and_turn',
        175:'cat_rounds_turn',225:'bilateral_petals_and_return_path',
        265:'cat_on_offset_return',315:'right_pivot_no_vertical_blob',330:'seam_cat_same_frame_again'}
    sheets={'outbound':range(53,75),'pause_and_look':range(104,132),
            'turn':range(133,167),'return':range(250,281),'seam':range(305,340)}
    ids=sorted(set([*peaks,*[j for row in sheets.values() for j in row]]))
    spans=[]
    for i in ids:
        if spans and i==spans[-1][-1]+1:spans[-1][1]=i
        else:spans.append([i,i])
    sel='+'.join(f'eq(n,{a})' if a==b else f'between(n,{a},{b})' for a,b in spans)
    filt=f"select='{sel}',scale=in_color_matrix=bt709:in_range=tv:out_range=pc,format=rgb24"
    cmd=['ffmpeg','-v','error','-xerror','-nostdin','-threads','4','-filter_threads','1','-i',str(master),'-an',
         '-vf',filt,'-fps_mode','passthrough','-frames:v',str(len(ids)),'-threads','1','-pix_fmt','rgb24','-f','rawvideo','pipe:1']
    decoded={}
    manifest={}
    with subprocess.Popen(cmd,stdout=subprocess.PIPE) as p:
        for n in ids:
            b=p.stdout.read(1920*1080*3)
            if len(b)!=1920*1080*3:raise ValueError(('bad real decode frame',n,len(b)))
            im=np.frombuffer(b,np.uint8).reshape(1080,1920,3)
            decoded[n]=im[3::6,3::6].copy()
            if n in peaks:
                file=out/f'spring_peak_{n:03d}_{peaks[n]}.png'
                Image.fromarray(im).save(file,optimize=True)
                manifest[file.name]={'frame':n,'bytes':file.stat().st_size,'sha256':sha(file),'size':[1920,1080]}
        assert not p.stdout.read(1) and p.wait()==0
    assert same(decoded[330],decoded[0])
    catbox=(185,154,245,180)
    for kind,rr in sheets.items():
        row=[(f'F{j:03d} / {j/30:.2f}s',thumbnail(decoded[j],catbox,4)) for j in rr]
        contact('院落小猫 · 连续实解原生4×','固定裁窗，不放大实际猫体；相邻帧未抽跳。',row,out/f'spring_cat_4x_{kind}.png',cols=5)
    overlay=thumbnail(native[0],catbox,8);rail=ImageDraw.Draw(overlay)
    pts=np.array([p['visible_cat']['projected_root'] for p in trace])
    uv=np.rint((pts-catbox[:2])*8).astype(int)
    for k in range(0,330,5):
        cl='#efb778' if k<150 else '#b8e2e4'
        rail.line((tuple(uv[k]),tuple(uv[k+5])),fill=cl,width=2)
        if k%25==0:
            rail.ellipse((uv[k,0]-2,uv[k,1]-2,uv[k,0]+2,uv[k,1]+2),fill=cl)
            rail.text((uv[k,0]+3,uv[k,1]+1),str(k),font=font(12),fill=cl,stroke_width=1,stroke_fill='#2c2535')
    contact('一只猫 · 原机位闭合轨迹','暖色前半去程，蓝色后半归程；叠线只存在于证据，不加入成片。', [('F0 = F330',overlay)],out/'spring_cat_path_checked.png',cols=1)
    for j in (125,150,175,225,265,315):
        rows=[('real master',thumbnail(decoded[j],catbox,5)),('causal same-phase cat off',thumbnail(without_cat[j],catbox,5))]
        contact('猫影与真实遮挡','实际媒体与同一原生相位关猫；阴影区域来自画面同一真实地面。',rows,out/f'spring_cat_causal_F{j:03d}.png',cols=2)
    # One real fixed-crop 4x playback of both entire cycles, independent of the strips.
    x0,y0,x1,y1=catbox
    vw,vh=(x1-x0)*4,(y1-y0)*4
    f=out/'spring_cat_two_cycles_4x.mp4'
    sample_filter=f'crop={(x1-x0)*6}:{(y1-y0)*6}:{x0*6}:{y0*6},scale={vw}:{vh}:flags=neighbor'
    subprocess.run(['ffmpeg','-v','error','-nostdin','-y','-i',str(master),'-an','-vf',sample_filter,
                    '-c:v','libx264','-profile:v','high','-crf','13','-preset','medium','-pix_fmt','yuv420p',
                    '-movflags','+faststart',str(f)],check=True)
    contiguous_pts(f)
    wr(out/'spring_decoded_evidence_manifest.json',manifest)

def package(out):
    names=['README.md','base_bindings.json','requirements.txt','spring23.py','cat25.py','flock24.py','preserved24.py',
           'scene25.py','wind25.py','palette24.json','pack.py','verify_exact.py','finish25.py',
           'test_cat25.py','test_cat19_pose.py','test_flock24.py','test_wind25.py']
    with zipfile.ZipFile(out/'spring_v25_source.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as f:
        for n in names:
            item=zipfile.ZipInfo(n,date_time=(2026,11,25,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED
            f.writestr(item,(HERE/n).read_bytes())
    assert zipfile.ZipFile(out/'spring_v25_source.zip').testzip() is None

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--baseline-audit-only',type=Path)
    ap.add_argument('--use-rendered-mp4',action='store_true')
    ap.add_argument('--round18-scope-audit',type=Path,
                    help='optional finish-only rejected-source review guard; never picture input')
    a=ap.parse_args();out=a.out
    v=np.load(out/'spring_native.npy',mmap_mode='r',allow_pickle=False)
    summary,trace,vis_w,phase_masks,without_cat,full=art_proof(out,v,a.baseline_audit_only)
    wr(out/'spring_gate25_art_proof.json',summary)
    scope=round19_scope(out,v,trace,without_cat,a.round18_scope_audit)
    wr(out/'spring_round19_causal_scope.json',scope)
    with (out/'spring_cat_world_visibility_0_through_330.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.writer(f)
        w.writerow(['frame','pose_6fps','x_m','y_m','z_m','projected_x_px','projected_y_px','yaw_rad','body_sample_hits','camera_visible_hits','shadow_pixels_causal','grounded_soles','physical_edge_collision','ear_primary_rays_visible'])
        shadow_rows=summary['cat']['ground_contact_shadow_threshold_counts_all_frames']
        for row in trace:
            c=row['visible_cat'];j=int(row['frame'])
            w.writerow([j,int(c['frame_pose']),*c['root'],*c['projected_root'],c['yaw_radians'],
                        c['ray_hits_before_world_depth'],c['ray_hits_after_world_and_cloth_depth'],
                        shadow_rows[j%330],sum(c['feet_planted']),c['edge_static_collision_count'],c['visible_ear_ray_hits']])
    nw=summary['wind']['composited_same_phase_wind_off_324_nondip_actual_full']
    all_w=summary['wind']['composited_same_phase_wind_off_entire_330_actual_full']
    print('WIND FULL',nw['same_scope_min_numerator'],nw['same_scope_max_numerator'],nw['denominator_full_native_pixels'],
          'non-dip 324 union',nw['union_numerator'],nw['union_percent'],
          'all 330 union',all_w['union_numerator'],all_w['union_percent'],flush=True)
    ca=summary['cat']; print('CAT',ca['primary_unoccluded_or_partial_frames_num_denom'],
          ca['body_rgb_diff_at_least_8_min_over_330'],ca['raw_real_body_hits_min'],
          ca['head_torso_rendered_contiguous_when_both_tags_sampled'],flush=True)
    print('PRESERVED',summary['retained_from_24'],flush=True)
    native_heat(out,v,vis_w,phase_masks,full,summary)
    master=out/'spring_loop.mp4'
    mobile=out/'mobile';mobile.mkdir(exist_ok=True)
    proxy=mobile/'spring_loop.mp4'
    if not a.use_rendered_mp4:
        if master.exists():raise ValueError('existing QP0 media, run --use-rendered-mp4 to check without changing')
        encode(v,master,True)
    if not proxy.exists():
        encode(v,proxy,False,work=mobile)
        if proxy.stat().st_size>8_450_000:encode(v,proxy,False,2600,work=mobile)
    assert proxy.stat().st_size<=8_450_000
    qa=exact_master('spring',out/'spring_native.npy',master)
    qa['lossless_pts']=contiguous_pts(master)
    p=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=profile,codec_name,width,height','-of','json',str(proxy)]))['streams'][0]
    assert (p['codec_name'],p['profile'],p['width'],p['height'])==('h264','High',1920,1080)
    qa['browser_proxy']={'bytes':proxy.stat().st_size,'sha256':sha(proxy),'pts':contiguous_pts(proxy),'profile':'High'}
    wr(out/'spring_decoded_qa.json',qa)
    recap=split(out,master)
    wr(out/'spring_gate25_provenance.json',{
        'review_commit':'d4cde25ec35477c8585cd0d6b17d4c742c17c982',
        'round18_background_commit':'3826dec8fdcbc07b0ad22ea96747b0444ed5e811',
        'approved_base_commit':'ffd3b67dc2d7a7bf84e9cb58d866ae3b0d0d8d0a',
        'source_base_zip_git_blob':'171898e7d4254d66da856fd138adf264e0369418',
        'clean_actual_render_not_from_old_RGB_or_plate_cache':True,
        'lossless':recap,'native_npy_sha256':qa['npy_sha256'],'proxy_sha256':qa['browser_proxy']['sha256']})
    evidence(out,master,v,trace,without_cat)
    package(out)
    print('FROZEN SPRING',recap['bytes'],recap['sha256'],'parts',len(recap['parts']),
          proxy.stat().st_size,sha(proxy),'native',qa['npy_sha256'],flush=True)
if __name__=='__main__':main()
