"""Gate 2.5 spring: frozen geometry, coherent 6 fps integer leaf exchange."""
from functools import lru_cache
import numpy as np

_PERIOD_POSES = 66
# Single axial pixel, never diagonal, interpolation, or repeated within a pose.
_DY = np.array([0,1,0,-1],np.int16)
_DX = np.array([1,0,-1,0],np.int16)

def _fade(v):
    return v*v*v*(v*(v*6.-15.)+10.)

def _value_noise(x,y,period,rng):
    # Interpolate only the procedural field, never the rendered picture.
    ix=np.floor(x/period).astype(np.int16);iy=np.floor(y/period).astype(np.int16)
    xx=_fade(x/period-ix);yy=_fade(y/period-iy)
    g=rng.uniform(-1,1,(int(iy.max())+2,int(ix.max())+2))
    return (g[iy,ix]*(1-xx)+g[iy,ix+1]*xx)*(1-yy)+(g[iy+1,ix]*(1-xx)+g[iy+1,ix+1]*xx)*yy

def _fbm(x,y,rng):
    return sum(a*_value_noise(x,y,p,rng) for a,p in ((.58,38.),(.28,19.),(.14,9.5)))

class WindField:
    """Mask is the full physical crown denominator, not the subset with safe donors."""
    threshold=.94
    travel_cycles=3
    depth_cut=1.50
    def __init__(self,mask,depth,seed=741,protected=None,leaf_fraction=None):
        self.mask=np.array(mask,dtype=bool,copy=True)
        self.mask.setflags(write=False)
        z=np.asarray(depth)
        if z.ndim==3:z=z[:,:,z.shape[2]//2]
        if z.shape!=self.mask.shape:raise ValueError('crown/depth resolution mismatch')
        # Only full 9/9 leaf coverage may be touched, never a mixed silhouette sample.
        # Keep the projected coverage mask unedited for scoring, including mixed-edge pixels.
        coverage=self.mask.copy()
        if leaf_fraction is not None:
            lv=np.asarray(leaf_fraction)
            if lv.shape!=coverage.shape:raise ValueError('leaf-fraction resolution mismatch')
            coverage&=(lv>=.999)
        if protected is not None:
            pv=np.asarray(protected,dtype=bool)
            if pv.shape!=coverage.shape:raise ValueError('protection resolution mismatch')
            coverage&=~pv
        h,w=coverage.shape
        y,x=np.where(coverage)
        yy=np.clip(y[:,None]+_DY,0,h-1);xx=np.clip(x[:,None]+_DX,0,w-1)
        local=z[y,x,None]
        ok=coverage[yy,xx]&((np.abs(yy-y[:,None])+np.abs(xx-x[:,None]))==1)&np.isfinite(local)&np.isfinite(z[yy,xx])&(np.abs(local-z[yy,xx])<=self.depth_cut)
        eligible=ok.any(1)
        self._x=x[eligible];self._y=y[eligible]
        self._yy=yy[eligible];self._xx=xx[eligible];self._valid=ok[eligible]
        x=self._x;y=self._y
        if not len(x):
            self._phase=self._direction=self._mottle=np.empty(0);self._max=0
            return
        rng=np.random.default_rng(seed)
        self._phase=.115*(x-160)+.061*(y-8)+1.72*_fbm(x,y,rng)
        self._direction=.78+.61*_fbm(x,y,rng)+.012*(y-58)
        self._mottle=_fbm(x,y,rng)
        self._max=0 if not len(x) else int(np.count_nonzero(eligible))
    @lru_cache(maxsize=66)
    def _pose(self,i):
        phi=i*(2*np.pi/_PERIOD_POSES)
        s=np.sin(self._phase-self.travel_cycles*phi+.17*np.sin(phi+self._mottle))
        # Smooth directional drifts, change only integer donor selection when a front advances.
        az=self._direction+1.13*np.sin(self._phase*.38-phi)+np.pi*(s<0)
        heading=np.stack((np.cos(az),np.sin(az),-np.cos(az),-np.sin(az)),axis=1)
        heading=np.where(self._valid,heading,-3.)
        k=np.argmax(heading,axis=1)
        active=(np.abs(s)>self.threshold)
        jj=np.flatnonzero(active)
        return self._y[jj],self._x[jj],self._yy[jj,k[jj]],self._xx[jj,k[jj]]
    def taps(self,frame):
        return self._pose((int(frame)%330)//5)
