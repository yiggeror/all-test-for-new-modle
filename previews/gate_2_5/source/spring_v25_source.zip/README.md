# 春 · 老巷暮色 / Gate 2.5

画面基线为审批 ffd3b67。固定机位、世界主体、60 色、花瓣、灰紫暮燕、两件晾衣、暖灯小蛾与灯微压降沿用 v2.4。春更新两层：

1. 一条周期性连续 FBM 相位波穿过樱花整冠。整个相机可见投影分母为 11,122，不用旧局部取样区。只有真实全是叶片的 9/9 射线像素才可作为动效落点和取色源；邻域最多只取上下左右一格，保护木、线、灯核、混合边缘和硬结构。每 5 帧采样一个新的相位，不加中间帧。证据同时给合成同相 AB、6fps 真的相邻姿态与30fps含持帧三种口径。
2. 一只实际 y=0 的小巷猫，维持0.466m身体、0.261m肩高与≤0.34m头耳高。头颈躯干一体，真实四足着地与真实投影。去回沿不同弧线，暖斑处停驻抬头卷尾，然后从另一侧走回，采样整个11秒都保留在同一院落。源代码实际重新计算原始及量化 F330；它和 F0 完全相同，F329不是人为复制为 F0。

在所审批项目源工作区运行，或指定其本地路径。Python3.12、NumPy、SciPy、Pillow、Numba和带 libx264 的FFmpeg：

    export RAINROJI_SOURCE_ROOT=/absolute/path/to/approved/all-test-for-new-modle
    export OPENBLAS_NUM_THREADS=1 NUMBA_NUM_THREADS=3
    python -m pip install -r requirements.txt
    python -m unittest discover -s . -v
    python scene25.py --out render --span 0:330
    python finish25.py --out render

完整运行使用真实光追路径，不借用旧 RGB 或缓存。可选在 finish25.py 用 --baseline-audit-only 指向 Gate2.4 的既有出件目录，只用于可重现范围核对。交付为正本两周22秒1080p30、整6倍最近邻、逐帧实解复核、High兼容播放样片、无损分卷及实拍证据。近照裁条只用于审片。
