# 春 · 老巷暮色 / Gate 2.5

画面基线为审批 ffd3b67。固定机位、世界主体、60 色、花瓣、灰紫暮燕、两件晾衣、暖灯小蛾与灯微压降沿用 v2.4。春更新两层：

1. Round 18 已通过的周期性 FBM 相位波原样保持，完整冠面 11,122，保护非叶硬结构与原整数借色。
2. Round 19 只重做小猫：活动带从冷紫墙影改到暖色地面，真实坐标双横弧错开，从矮混凝土凳近侧经过，完整回到开始。F105–128 暂停抬头卷尾，两个短转体动作自头颈脊背至实步跟随；不改相机。体长 0.466m，肩高 0.261m，暖灰奶油色漫反射和深尾端均为实际物理毛材质，不施发光或描边。真正另渲的 F330 与 F0 逐像素一致，F329 未被复制。
3. 以同相只去猫（身体、遮挡、投影同时移除）的 330 帧原生 RGB 对照比对 Round 18，在整个画面中严格相同。只有在新/旧猫与实际投影影响范围内，完成正本才与上轮不同。

在所审批项目源工作区运行，或指定其本地路径。Python3.12、NumPy、SciPy、Pillow、Numba和带 libx264 的FFmpeg：

    export RAINROJI_SOURCE_ROOT=/absolute/path/to/approved/all-test-for-new-modle
    export OPENBLAS_NUM_THREADS=1 NUMBA_NUM_THREADS=3
    python -m pip install -r requirements.txt
    python -m unittest discover -s . -v
    python scene25.py --out render --span 0:330
    python finish25.py --out render

完整运行使用真实光追路径，不借用旧 RGB 或缓存。可选在 finish25.py 用 --baseline-audit-only 指向 Gate2.4 的既有出件目录，及 --round18-scope-audit 指向旧 Gate2.5 出件；两个只用于证据核对，不提供渲染输入。交付为正本两周22秒1080p30、整6倍最近邻、逐帧实解复核、High兼容播放样片、无损分卷及实拍证据。近照裁条只用于审片。
