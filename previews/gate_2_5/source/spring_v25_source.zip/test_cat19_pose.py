"""Round-19 red tests: actual physical projected root, span and full-scale pose."""
import unittest
import numpy as np
from spring23 import shot
from cat25 import CAT_BODY,CAT_HEAD,CAT_TAIL,mesh,route

class WarmCourt(unittest.TestCase):
    def test_wider_physical_path_stays_in_lit_landing(self):
        c=shot.camera()
        pts=np.array([route(f)[0] for f in range(331)])
        x,y,_,_=c.project(pts)
        self.assertGreaterEqual(x.min(),194)
        self.assertLessEqual(x.max(),238)
        self.assertGreaterEqual(np.ptp(x),30)
        self.assertGreaterEqual(y.min(),169)
        self.assertLessEqual(y.max(),179)
        past=np.argmin(abs(x[10:95]-213))+10
        good=np.argmin(abs(x[165:260]-213))+165
        self.assertGreater(abs(y[good]-y[past]),3.4)

    def test_no_foreshortened_vertical_rear_trip(self):
        c=shot.camera()
        for f in range(250,311,5):
            g=mesh(f)[0].finalize()
            tags=g['F']['tag'][g['tf']]
            face=np.isin(tags,[CAT_HEAD,CAT_BODY])
            vertices=np.concatenate([g[k][face] for k in ('v0','v1','v2')])
            x,y,*_=c.project(vertices)
            with self.subTest(frame=f):
                self.assertGreaterEqual(np.ptp(x),5.)

    def test_natural_retained_physical_scale_and_tail_presence(self):
        c=shot.camera()
        for f in range(0,330,5):
            w,i=mesh(f);g=w.finalize()
            t=g['F']['tag'][g['tf']]
            u=np.concatenate([g[k][t==CAT_TAIL] for k in ('v0','v1','v2')])
            self.assertGreater(np.ptp(c.project(u)[0]),1.15,f)
            self.assertTrue(any(i['feet_planted']),f)
            self.assertLessEqual(i['head_and_ears_max_m'],.34,f)
