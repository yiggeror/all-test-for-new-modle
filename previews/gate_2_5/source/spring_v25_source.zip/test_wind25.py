import unittest
import numpy as np
from wind25 import WindField
class Wind(unittest.TestCase):
 def test_mask_edges_and_depth_stay_locked(self):
  m=np.ones((35,51),bool);m[[0,-1],:]=0;m[:,[0,-1]]=0;m[9:12,19]=0
  d=np.full(m.shape,27.,np.float32);d[:,:25]=22.
  f=WindField(m,d)
  np.testing.assert_array_equal(m,f.mask)
  found=0
  for i in range(0,330,5):
   y,x,yy,xx=f.taps(i)
   self.assertTrue(np.all(m[y,x]&m[yy,xx]))
   self.assertTrue(np.all(np.abs(y-yy)+np.abs(x-xx)==1))
   self.assertTrue(np.allclose(d[y,x],d[yy,xx]))
   self.assertEqual(len(y),len(np.unique(y*m.shape[1]+x)))
   found+=len(y)
  self.assertGreater(found,0)
 def test_5f_holds_and_exact_repeat(self):
  m=np.ones((30,41),bool);d=np.full(m.shape,17.)
  f=WindField(m,d)
  for i in range(0,330,5):
   a=f.taps(i)
   for j in (i+4,i-330,i+330):
    for u,v in zip(a,f.taps(j)):np.testing.assert_array_equal(u,v)
  self.assertFalse(np.array_equal(f.taps(0)[1],f.taps(5)[1]))
 def test_empty_mask(self):
  f=WindField(np.zeros((30,40),bool),np.ones((30,40)))
  self.assertEqual(tuple(map(len,f.taps(50))),(0,0,0,0))
 def test_public_denominator_includes_mixed_and_protected_without_tapping_them(self):
  m=np.ones((25,40),bool);p=np.zeros_like(m);p[:,19]=True
  d=np.full(m.shape,20.)
  f=m.astype(float);f[3:9,4:12]=.67
  obj=WindField(m,d,protected=p,leaf_fraction=f)
  self.assertEqual(int(obj.mask.sum()),1000)
  used=0
  for i in range(0,330,5):
   y,x,yy,xx=obj.taps(i)
   self.assertFalse(np.any(p[y,x]|p[yy,xx]))
   self.assertTrue(np.all((f[y,x]==1)&(f[yy,xx]==1)))
   used+=len(y)
  self.assertGreater(used,0)
