"""One continuous torso–neck–head loft, independently planted 3-D paws, a continuously visible closed ground route."""
import numpy as np
from scipy.interpolate import PchipInterpolator, CubicSpline, CubicHermiteSpline
from spring23 import World,mats,srgb,roty

CAT_HEAD,CAT_BODY,CAT_FOOT,CAT_TAIL=91,92,93,94
CAT_BODY_M=.466
# From start near the cherry tree, take the nearer leftward curve,
# watch the petals, then return along a back arc. Every point is inside the yard.
HOLD=(105,146)
NODES=np.array([[4.92,12.10],[4.53,12.26],[4.20,12.37],[3.90,12.36],
                [3.33,12.03],[3.18,11.63],[3.28,11.10],[3.53,10.71],
                [4.03,10.55],[4.63,10.63],[5.02,10.95],[5.12,11.39],
                [5.04,11.90],[4.92,12.10]],np.float64)
U=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(NODES,axis=0),axis=1))]
U/=U[-1]
WORLD_PATH=CubicSpline(U,NODES,axis=0,bc_type='periodic')
PATH_SPEED=WORLD_PATH.derivative()
ARC_PARAM=np.linspace(0,1,4097)
ARC_POINTS=WORLD_PATH(ARC_PARAM)
ARC_LENGTH=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(ARC_POINTS,axis=0),axis=1))]
PATH_LEN=float(ARC_LENGTH[-1])
# Use arc anchors from the actual world path, not desired pixel sections.
ANCHOR_NODE=(0,1,2,3,3,4,6,8,9,11,12,13)
KEY=np.array([0,23,57,105,146,163,193,226,250,283,309,330.])
TARGET=np.interp(U[list(ANCHOR_NODE)],ARC_PARAM,ARC_LENGTH)
vel=PchipInterpolator(KEY,TARGET).derivative()(KEY)
vel[0]=vel[-1]=.5*(vel[0]+vel[-1])
PACE=CubicHermiteSpline(KEY,TARGET,vel)
STRIDE=PATH_LEN/12.

def world_at_arc(s):
    arc=float(s)%PATH_LEN
    u=float(np.interp(arc,ARC_LENGTH,ARC_PARAM))
    x,z=WORLD_PATH(u)
    vx,vz=PATH_SPEED(u)
    yaw=-np.arctan2(vz,vx)
    return np.array([x,0.,z]),float(yaw)

@mats.mat('spring24_fur')
def fur(s):
    # Broad, low contrast coat markings. All response is reflected incident light.
    return s.col*(.93+.07*np.cos(s.seed*7.4))[:,None]


def route(j):
    # Exclusive ring of 330 display frames; evaluating 330 recomputes frame zero.
    f=float(j)%330.
    arc=float(PACE(f))
    root,yaw=world_at_arc(arc)
    return root,yaw,arc


def sm(x):
    x=np.clip(x,0.,1.)
    return x*x*(3-2*x)


def muscle(f,s):
    rest=float(sm((f-96)/9)*sm((156-f)/10))
    look=float(sm((f-109)/13)*(1.-sm((f-132)/15)))
    bob=float(.005*np.sin(4*np.pi*s/STRIDE)*(1-rest))
    return rest,look,bob


def mesh(frame):
    j=float(frame)%330.
    root,yaw,s=route(j)
    stop,look,bob=muscle(j,s)
    prof=np.array([
        [-.230,.172,.005,.012],[-.219,.175,.048,.049],[-.179,.173,.076,.066],
        [-.113,.166,.076,.065],[-.025,.168,.075,.058],[.046,.180,.073,.056],
        [.102,.193,.068,.050],[.145,.229,.050,.047],
        [.181,.237,.053,.047],[.211,.220,.034,.040],[.236,.213,.012,.024],
    ],float)
    # A single watertight, connected loft; look changes the vertex heights of
    # the last rings continuously through the shoulder transition.
    cross=sm((prof[:,0]-.048)/.17)
    prof[:,1]+=bob+.025*look*cross
    w=World(seed=2415)
    with w.at(root,yaw=yaw):
        a=np.linspace(0,2*np.pi,13)[:-1]
        c=np.cos(a); d=np.sin(a)
        rings=np.stack([np.broadcast_to(prof[:,0,None],(len(prof),len(a))),
          prof[:,1,None]+prof[:,2,None]*c,prof[:,3,None]*d],axis=-1)
        rr=np.roll(rings,-1,axis=1)
        shade=np.clip((c*.16+.84),.72,1.)
        F=srgb('#795642')
        H=srgb('#965f3e')
        D=srgb('#775248')
        col=np.array([D if k==0 else H if k>6 else F for k in range(len(prof)-1)])
        w.quads(rings[:-1].reshape(-1,3),rr[:-1].reshape(-1,3),rr[1:].reshape(-1,3),rings[1:].reshape(-1,3),
                mat='spring24_fur',col=(col[:,None]*shade[None,:,None]).reshape(-1,3),
                seed=(.24+prof[:-1,0,None]*.6+c[None,:]*.09).ravel(),
                tag=np.repeat(np.where(prof[:-1,0]>.13,CAT_HEAD,CAT_BODY),len(a)))
        w.poly(rings[0][::-1],mat='spring24_fur',col=F,tag=CAT_BODY)
        w.poly(rings[-1],mat='spring24_fur',col=H,tag=CAT_HEAD)
        # The ears grow through the skull crown; no independently drawn head or edges.
        for k,side in enumerate((-1,1)):
            z=side*.028
            by=.269+.020*look+bob
            ear=np.array([[.132,by,z+side*.005],[.179,by-.006,z+side*.012],
                          [.159+k*.008,min(.333,.320+.013*look+bob),z+side*.006],
                          [.146,by-.007,z-side*.015]])
            for u,v,r in ((0,1,2),(1,3,2),(3,0,2),(0,3,1)):
                w.poly(ear[[u,v,r]],mat='spring24_fur',col='#a26945' if v!=3 else '#724943',tag=CAT_HEAD)
        # Four feet, stance coordinates fixed in arclength until real swing.
        planted=[]
        feet=[]
        for q,(hx,hz,phase) in enumerate(((.095,.041,.06),(-.155,-.044,.29),(.095,-.041,.58),(-.155,.044,.79))):
            # In stance the same world target is anchored until its next swing.
            stride=STRIDE;dt=.55
            p=s/stride+phase
            cycle=np.floor(p);t=p-cycle
            ref=(cycle+dt*.5-phase)*stride
            w0,y0=world_at_arc(ref)
            w0+=roty(y0)@np.array([hx,0.,hz])
            foot=w0;ylift=0.
            if t>=dt:
                u=(t-dt)/(1-dt)
                w1,y1=world_at_arc(ref+stride)
                w1+=roty(y1)@np.array([hx,0.,hz])
                foot=w0+(w1-w0)*sm(u)
                ylift=.050*np.sin(np.pi*u)
            local=(foot-root)@roty(yaw)
            xloc=(1-stop)*float(np.clip(local[0]-hx,-.148,.148))
            side=(1-stop)*float(np.clip(local[2]-hz,-.052,.052))
            ylift*=1-stop
            hz=hz+side
            ank=(hx+xloc,.027+ylift,hz)
            kn=(hx+.25*xloc+(.018 if hx>0 else -.014),.119+.34*ylift+bob,hz)
            hip=(hx,.183+bob,hz*.86)
            w.tube(hip,kn,.031,.021,sides=7,mat='spring24_fur',col='#886049',tag=CAT_FOOT)
            w.tube(kn,ank,.021,.014,sides=7,mat='spring24_fur',col='#694d43',tag=CAT_FOOT)
            # Its world-space mesh shares the cat's body transform, not a floaty decal.
            w.box((ank[0]+.010,.009+ylift,ank[2]),(.053,.018,.031),
                    mat='spring24_fur',col='#815946',tag=CAT_FOOT)
            planted.append(bool(ylift<=.001))
            feet.append(w.xf((ank[0]+.010,ylift,ank[2])).tolist())
        phase=2*np.pi*(7*s/PATH_LEN+2*j/330.)
        curl=stop*sm((j-108)/16)*(1-sm((j-131)/20))
        t=np.array([[-.192,.170,.006],[-.263,.165,.022],[-.328,.191,.048],[-.380,.241,.062],
                    [-.407+.022*curl,.266+.037*curl,.060],[-.430+.055*curl,.290+.058*curl,.059+.040*curl]])
        t[1:,2]+=np.sin(phase+np.arange(1,6)*.63)*np.linspace(.003,.025,5)
        t[:,1]+=bob
        rr=[.033,.029,.025,.023,.018,.013]
        for i in range(len(t)-1):
            w.tube(t[i],t[i+1],rr[i],rr[i+1],sides=7,mat='spring24_fur',col='#81583f',tag=CAT_TAIL)
        w.sphere(t[-1],.013,n=5,mat='spring24_fur',col='#825949',tag=CAT_TAIL)
    return w,{'frame_pose':j,'root':root.tolist(),'yaw_radians':yaw,'arc_m':s,'pause_weight':stop,'head_look_weight':look,
              'feet_planted':planted,'soles_world':feet,'body_length_m':CAT_BODY_M,'shoulder_height_m':.261,
              'head_and_ears_max_m':float(ear[:,1].max()),'tail_curl_weight':float(curl)}
