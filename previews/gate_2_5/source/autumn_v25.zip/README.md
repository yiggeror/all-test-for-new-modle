# Gate 2.5 秋 · 梧桐黄昏

Round 18 审稿锚点：`347e47c41b5c5ee19cbf0a289e1d96aac57d9fba`。本包仅秋景，夏冬不在包内。锁定原机位、路与亭的 3D 骨架、60 色原生调色资产、320×180×30 fps、每周期 330 帧；无损双循环为 1920×1080 QP0，由原生 RGB 经 6× 最近邻和固定 BT.709 映射导出。

- `reader25.py`：亭外原地站读的成人网格，衣、双鞋、双手和翻动纸面各有三角面与材质；原场景加速结构做遮挡，柜台灯为自身及真实地面投影提供软阴影。光经原物理灯组，纸不自发光。鞋底与台阶铺装同高。每 5 帧锁同一个完整三维姿态。只有一页从一手翻到另一侧，姿态从放下报纸的小动作回归安静观看而不倒放。
- `wind25.py`：拼贴式树叶代码完全移除出这条生产入口。两侧整冠工作区取真实 foliage 标签（至少 6/9 固定原生采样），不按变化结果画遮罩；一小波四向邻像素整数借色、匹配该处已有叶面深度，主干、线、灯核、固定亮晕不位移。周期 FBM 相位驱动，一姿态 5 帧，严禁插值。运动覆盖用同帧色差；实际相邻帧仅在五帧边界改变的结果另外报告。现场暖光斑仍走原铺装照度和范围，从实际冠上风场取能量。
- `foliage25.py`：88 条，包括 44 条原有释放节奏，全部用相机射线吸附真实 3D 叶源，风向、三层纵深与遮挡保留；地面 8 片在实际暖积叶路牙上掀起短滑且落回同地面，原 19 路面卷叶、三只归鸟、暖茶汽与两次灯降沿用旧实现。
- 完整输出脚本逐帧复验原生到 1080p 三个平面、周期完全相同、原色调映射。真 A/B 控制均走同一现场入口。支持的原井盖/斑马线/窗台位置未改；证据另有全幅与 4× 顺帧条带。

## 复现

兼容：Linux / Python 3.12 / FFmpeg (libx264) + ffprobe；Noto CJK Sans/Serif 在 `/usr/share/fonts/opentype/noto/`（用于原始 3D 亭招牌）。`pip install -r requirements.txt`。仓库树要保留：

- `previews/gate_2/source/spring_autumn_source.zip`：原 3D 秋街、色板。
- `previews/gate_2_3/source/autumn_winter_v23.zip`：锁定静态定色、真实光影、旧路面卷叶、热茶汽、归鸟。
- `previews/gate_2_4/source/autumn_winter_v24.zip`：可选，仅用于对旧已通过动态逐帧回归，不被生产渲染器导入。
- `tools/gate3/native_fingerprints.json`：原调色 BT.709 无损逆查表。

```sh
OPENBLAS_NUM_THREADS=1 NUMBA_NUM_THREADS=2 python render25.py --repo /repo --work /tmp/autumn25
OPENBLAS_NUM_THREADS=1 NUMBA_NUM_THREADS=2 python render25.py --repo /repo --work /tmp/autumn25 --phase compat
OPENBLAS_NUM_THREADS=1 NUMBA_NUM_THREADS=2 python render25.py --repo /repo --work /tmp/autumn25 --phase reader-preview
```

`--phase picture` 只交实际图像无损正本；`--phase proof` 从同目录原生序列重生成完整证据。可选 `--baseline-native /path/autumn_native.npy` 须为原 v2.4 发布样片（明确校验摘要），用来生成精确同帧前后图。兼容版独立于 QP0 正本，不进入复核或总合片。不依赖插值、遮挡层换位、资产授权之外的生成媒体。

## Round 19：只替换报刊亭读者

依据 `d4cde25ec35477c8585cd0d6b17d4c742c17c982`。Round 18 已认可的风、街景、灯、落叶及地面层使用同一份 `autumn25.py`、`wind25.py`、`foliage25.py`。本轮出片时用 `--phase picture`，另用 `proof_reader19.py` 独立装载上轮冻源（ZIP SHA256 `2f5be01022e6217eeb4e962f6ecd3ca826a1da9aa3ba79fbfd4db7465247dfea`；对应评审对象 `3826dec`），将两版的人体与投影在生产入口同时禁用，逐帧比较其余画面，保证已认可层如旧。此外提交连续正常速与4×局部、独立真遮挡 ray 标签、读者 ON / 纸 OFF / 读者及影 OFF 对照与全 331 姿证据。

```sh
export OPENBLAS_NUM_THREADS=1 NUMBA_NUM_THREADS=2
python render25.py --repo /repo --work /tmp/autumn25-r19 --phase picture
python render25.py --repo /repo --work /tmp/autumn25-r19 --phase reader-preview
python render25.py --repo /repo --work /tmp/autumn25-r19 --phase compat
python proof_reader19.py --repo /repo --work /tmp/autumn25-r19 --r18-source /frozen/autumn_v25_r18.zip
```
