"""Articulated triangle-mesh reader, primary intersections and real area-light occlusion."""
from dataclasses import dataclass
from functools import lru_cache
import numpy as np
from engine import render as rt
from engine.world import World, roty, srgb, _n, MASK_HIDDEN
from engine.rt import Accel

PARTS={101:'coat',102:'trousers',103:'shoes',104:'collar',105:'head',
       106:'left_hand',107:'right_hand',108:'paper',109:'left_sleeve',110:'right_sleeve',113:'turning_newsprint'}
PAPER=108
ORIGIN=np.array([-6.993,.150,4.698],float)
HEIGHT=1.69
# Merely a ray work tile. No screen-domain body, material or shadow geometry.
BOUNDS=(35,119,60,165)
YAW=-1.745
P0=np.array([.247,1.055,.033])
VIEW=np.array([.985,0.,-.173])
PAPER_TURN=113
PAPER_TAGS=(PAPER,PAPER_TURN)

def sigma(u):
    u=np.clip(u,0.,1.);return u*u*(3.-2.*u)

def controls(k):
    f=(k%66)*5
    phase=np.interp(f,[0,128,136,144,156,166,178,329],[0,0,.08,.28,.59,.85,1,1])
    turn=np.pi*sigma(phase)
    lift=float(np.sin(turn)**1.05)
    follow=float(np.interp(f,[0,127,140,151,161,173,184,198,329],[0,0,.28,.69,1.,.76,.21,0.,0.]))
    rest=.045*np.sin(2*np.pi*(f/330+.12))
    weight=.012*np.sin(2*np.pi*f/330)
    return float(turn),lift,follow,rest,weight

def ell(w,p,r,tag,col,tilt=0.,n=12):
    s=np.sin(tilt);c=np.cos(tilt)
    with w.at(p,M=np.array([[1,0,0],[0,c,s],[0,-s,c]])@np.diag(r)):
        w.sphere((0,0,0),1.,n=n,mat='plain',col=col,tag=tag)

def lobe(w,a,b,r0,r1,col,tag):
    w.tube(a,b,r0,r1,sides=9,mat='plain',col=col,tag=tag,caps=True)

def pane(origin,spine,across,width,curl=0.):
    n=_n(np.cross(across,spine))
    def p(u,v):
        return origin+across*(width*u)+spine*v+n*(.013*np.sin(np.pi*u)) + np.array([0.,1.,0.])*curl*u*v
    return p,n

def print_sheet(w,p,n,tag,col,print_full=True):
    # Print is attached to the curved paper, so it follows the fold, never a floating decal.
    # Real bound edge and two faceted blocks of ink read as one open spread at 5–7 native pixels.
    c=(0.,.088,.31,.57,.79,1.)
    for j,(u,U) in enumerate(zip(c[:-1],c[1:])):
        for v,V in ((0.,.55),(.55,1.)):
            tone=col*(.73 if j==0 else (.93 if j==1 else (.74 if j==4 else 1.)))
            w.quads(p(u,v),p(U,v),p(U,V),p(u,V),mat='plain',col=tone,tag=tag)
    ind=np.array((.49,.72,.81,.68,.76))
    for j,(v,d) in enumerate(((.18,.071),(.36,.063),(.54,.063),(.71,.072),(.855,.084))):
        if j<3 and not print_full:continue
        for u,U in zip(c[:-1],c[1:]):
            u=max(.195,u);U=min(ind[j],U)
            if U<=u:continue
            tone=col*np.array([.43,.49,.53],np.float32)*(1 if j==4 else 1.19)
            for sign in (-1.,1.):
                patch=np.stack([p(u,v),p(U,v),p(U,v+d),p(u,v+d)])+n*(sign*.0026)
                w.quads(*patch,mat='plain',col=tone,tag=tag)

def model(k):
    turn,lift,follow,breath,weight=controls(k);f=(k%66)*5
    w=World(seed=401)
    main_coat='#51515d';front_coat='#5c5663';sleeve='#514a57';seam='#695b63'
    far_pant='#473641';near_pant='#574855';shoe='#3b2c36';skin='#c99b82';hair='#413640'
    neck_color='#9c735f'; scarf='#78665f';newsprint=srgb('#eeeae0')
    # Diagonal natural stance. Both real shoe soles are exactly on the pavement;
    # the feet and knees separate in the fixed camera as well as in world space.
    feet=((-0.135,0.,-.105),(.143,0.,.108))
    packet={}
    with w.at(ORIGIN,yaw=YAW):
        pelvis=np.array([weight,.864,-.022])
        rib=np.array([weight+.009,1.205,-.010+.019*follow])
        for j,(ax,_,az) in enumerate(feet):
            side=-1+2*j
            k0=np.array((ax+side*.010,.465,az+.016))
            sh=np.array((ax,.099,az-.022))
            tail=pelvis+np.array((side*.102,-.060,-.007))
            clr=near_pant if j==1 else far_pant
            lobe(w,sh,k0,.067,.081,clr,102)
            lobe(w,k0,tail,.080,.107,clr,102)
            ell(w,k0,(.084,.094,.083),102,clr,n=10)
            # Compact toe cap and a real flat sole; no long floating silhouette.
            loc=(ax,.032,az+.008)
            w.box(loc,(.123,.064,.224),yaw=side*.13,mat='plain',col=shoe,tag=103)
            ell(w,(ax,.065,az+.033),(.075,.056,.130),103,shoe)
            packet['near_shoe_center' if j else 'far_shoe_center']=w.xf(loc).tolist()
        # Wide torso with designed taper instead of cylinders; hips + hem + rib cage make one coat.
        ell(w,pelvis+[0.,.019,-.012],(.195,.116,.146),101,main_coat,tilt=.08)
        ell(w,(pelvis+rib)/2+[0.,.062,.001],(.218,.226,.179),101,main_coat,tilt=.10)
        ell(w,rib+[0.,.042,.0],(.238,.119,.169),101,front_coat,tilt=.074)
        # A very short neck rising out of the scarf collar. The collar follows the actual shoulder shape.
        neck=np.array([weight+.018,1.391,.022+.017*follow])
        ell(w,neck,(.076,.060,.074),104,neck_color,tilt=.25)
        ell(w,neck+[0.,-.024,-.008],(.116,.072,.088),104,scarf,tilt=.23)
        for s in (-1,1):
            a=rib+np.array([s*.048,.178,.077]);b=rib+np.array([s*.129,.122,.117])
            d=rib+np.array([s*.041,.016,.172]);e=rib+np.array([s*.024,.104,.164])
            w.poly((a,b,d,e),mat='plain',col=scarf,tag=104)
        # The hands hold a real open sheet at chest height. Both of its folds remain physically spread
        # while a third, flexible leaf connected to the centre seam turns once, above both rest planes.
        c=P0+np.array([weight*.29,.013*follow,.010*follow])
        spine=np.array([-.027,.230,-.025-.006*follow])
        hr=_n(np.array([.51,.019,.859]))
        hl=_n(np.array([.048,-.018,-.998]))
        widthL=.222;widthR=.231
        L,Ln=pane(c,spine,hl,widthL)
        R,Rn=pane(c,spine,hr,widthR)
        haxis=_n(spine)
        # Rotate the rest right leaf round the live central hinge; flex its outer top edge upward.
        N=_n(np.cross(haxis,hr))
        angleFix=hl+hr
        hlive=_n(hr*np.cos(turn)+N*np.sin(turn)+angleFix*((1.-np.cos(turn))*.5))
        upper_curl=.188*lift
        # The narrow .004 m leaf separation is physical and does not shift the main spine.
        P,Np=pane(c+Rn*.003*lift,spine,hlive,widthR,upper_curl)
        print_sheet(w,L,Ln,108,newsprint*.915)
        print_sheet(w,R,Rn,108,newsprint*.985)
        if .020<turn<np.pi-.020:
            print_sheet(w,P,Np,PAPER_TURN,newsprint*.966,False)
        # Eyes and cheek turn with the very same page, then settle back on the centre spread.
        base_target=c+spine*.63+(L(.34,.65)+R(.29,.65)-2*(c+spine*.65))*.21
        gaze_target=base_target*(1-.58*follow)+P(.79,.84)*(.58*follow)
        head=np.array([weight+.013,1.540-.018*follow,.054+.024*follow+.008*breath])
        look=_n(gaze_target-head)
        right=_n(np.cross([0.,1.,0.],look));up=np.cross(look,right)
        with w.at(head,M=np.column_stack((right,up,look))):
            ell(w,(0.,.002,-.003),(.121,.112,.122),105,skin,n=14)
            ell(w,(0.,.045,-.026),(.125,.093,.113),105,hair,n=14)
            ell(w,(.002,-.037,.062),(.085,.063,.067),105,skin,n=12)
            ell(w,(.007,-.005,.100),(.035,.031,.039),105,skin,n=10)
            for s in (-1,1):
                ell(w,(s*.102,-.011,.013),(.023,.037,.028),105,skin,n=10)
        # Tucked bent elbows under the lower ribs. Real palms and two joined thumb surfaces
        # wrap the newsprint. Far hand supports one half throughout; near hand physically turns the other.
        for s in (-1,1):
            shoulder=rib+np.array([s*.194,.065,.001])
            elbow=np.array([weight+s*(.024 if s<0 else .211),(1.050 if s<0 else 1.018)+.058*lift,
                            (.053 if s<0 else .142)+.033*follow])
            if s<0:
                grip=L(.66,.188+.110*follow)
            elif turn<.02:
                anticipation=sigma((f-119)/19)
                grip=R(.90,.26+.39*anticipation)
            elif turn<np.pi-.02:
                grip=P(.89,.64+.18*lift)
            else:
                move=sigma((f-174)/22)
                grip=L(.94,.63)*(1.-move)+R(.90,.26)*move
            palm=grip+VIEW*(.037 if s<0 else .045)+np.array([0.,-.035,-.013])
            wrist=palm*.80+elbow*.20
            arm=109 if s<0 else 110;tag=106 if s<0 else 107
            lobe(w,shoulder,elbow,.087,.073,sleeve if s<0 else main_coat,arm)
            ell(w,elbow,(.072,.075,.071),arm,sleeve if s<0 else main_coat,n=10)
            lobe(w,elbow,wrist,.074,.052,main_coat if s<0 else front_coat,arm)
            lobe(w,wrist,palm,.054,.037,seam,arm)
            ell(w,palm,(.044,.050,.043),tag,skin,tilt=.20,n=12)
            thumb=.47*palm+.53*grip+np.array([.0,.010,.009])
            lobe(w,palm,thumb,.027,.023,skin,tag)
            lobe(w,thumb,grip,.024,.014,skin,tag)
            key='left' if s<0 else 'right'
            packet[key+'_hand']=w.xf(palm).tolist();packet[key+'_grip']=w.xf(grip).tolist()
            packet[key+'_elbow']=w.xf(elbow).tolist();packet[key+'_shoulder']=w.xf(shoulder).tolist()
        packet.update(feet=[w.xf(j).tolist() for j in feet],spine_top=w.xf(c+spine).tolist(),spine_bottom=w.xf(c).tolist(),
                      head=w.xf(head).tolist(),gaze_target=w.xf(gaze_target).tolist(),gaze_direction=w.xd(look).tolist(),
                      paper_free_top=w.xf(P(1.,1.)).tolist(),live_page_free_top=w.xf(P(1.,1.)).tolist(),
                      rest_left_outer_top=w.xf(L(1.,1.)).tolist(),rest_right_outer_top=w.xf(R(1.,1.)).tolist(),
                      page_angle=float(turn),body_weight=float(weight),nod=float(follow),
                      active_turn_mesh=.020<turn<np.pi-.020)
    return w,packet

class Together:
    def __init__(self,a,b):self.a,self.b=a,b
    def anyhit(self,o,d,tmax,mask=0):
        # Both physical acceleration structures participate in direct light visibility.
        s=self.a.anyhit(o,d,tmax,mask)
        if not s.all():
            ii=np.nonzero(~s)[0]
            tm=tmax if np.isscalar(tmax) else tmax[ii]
            s[ii]=self.b.anyhit(o[ii],d[ii],tm,mask)
        return s

@dataclass
class ReaderSample:
    coverage:np.ndarray
    contact:np.ndarray
    incoming:np.ndarray
    lamp_shadow:np.ndarray
    primary_depth:np.ndarray
    parts:np.ndarray
    part_counts:dict
    ground_y:float
    upper_y:float
    meta:dict

class Reader:
    def __init__(self,cam,world,acc,b):
        self.cam,self.world,self.acc,self.b=cam,world,acc,b
        x0,y0,x1,y1=BOUNDS;self.ys=slice(y0,y1);self.xs=slice(x0,x1)
        self.shape=(y1-y0,x1-x0)
        yy,xx=np.mgrid[y0:y1,x0:x1]
        # Four-by-four fixed subpixel rays per native cell. Pose holds remain exact.
        oy,ox=np.mgrid[0:4,0:4].reshape(2,-1)
        dv=cam.dirs((xx[...,None]+(.5+ox)/4).ravel(),(yy[...,None]+(.5+oy)/4).ravel()).astype(np.float32)
        self.d=dv;self.o=np.broadcast_to(cam.pos.astype(np.float32),dv.shape).copy()
        self.dist,ti=acc.closest(self.o,dv,mask=MASK_HIDDEN)
        safe=np.maximum(ti,0);g=world.finalize();ntag=g['F']['tag'][g['tf'][safe]]
        nn=g['F']['n'][g['tf'][safe]];self.P=self.o+dv*np.minimum(self.dist,1e3)[:,None]
        # Check existing kiosk sign (upper sign + left mag stand) and actual contact paving.
        self.structure=ntag.reshape(*self.shape,16)
        self.floor=(ti>=0)&(np.abs(nn[:,1])>.82)&(np.abs(self.P[:,1]-.15)<.011)
        self.kiosk=next(q for q in world.lights if q['grp']==3 and 'axis' not in q)
        self.near=[q for q in world.lights if q['kind']=='point' and np.linalg.norm(q['pos']-ORIGIN)<22.]
        # Integrate diffuse reflected/transmitted light from the actual nearby bright shelf.
        # These are surveyed positions and radiance of the fixed light group, not invented LEDs.
        hit=(b['tag28']>.96)&(np.indices(b['tag28'].shape)[1]<55)
        sc=np.argwhere(hit)
        if len(sc)>=12:
            sc=sc[np.linspace(0,len(sc)-1,12).astype(int)]
        self.panel_pos=b['P'][sc[:,0],sc[:,1]]
        self.panel_irr=b['layers'][3,sc[:,0],sc[:,1]]
        self.samples=np.array(((0,0,0),(.67,0,0),(-.67,0,0),(0,.62,0),(0,-.62,0),(0,0,.61),(0,0,-.61)),np.float32)
        self.fidx=np.where(self.floor&(np.linalg.norm(self.P[:,[0,2]]-ORIGIN[[0,2]],axis=1)<1.95))[0]
        pp=self.P[self.fidx].copy();pp[:,1]+=.003
        v=self.kiosk['pos'][None,None]+self.kiosk['radius']*self.samples[None]-pp[:,None]
        self.sd=np.linalg.norm(v,axis=2);self.sdir=(v/self.sd[...,None]).reshape(-1,3)
        self.so=np.repeat(pp,len(self.samples),axis=0)
        basevis=~acc.anyhit(self.so,self.sdir,self.sd.ravel()-.005,mask=1)
        self.basevis=basevis.reshape(self.sd.shape)
        self.shadow_weight=np.maximum(self.sdir[:,1],0).reshape(self.sd.shape)/(self.sd**2+.36)
        self.floor_check={}
        for p in model(0)[1]['feet']:
            pp=np.asarray(p,np.float32);o=pp+[0,.045,0];down=np.array([[0.,-1.,0.]])
            floor_t,idx=acc.closest(o[None],down,tmax=.075)
            self.floor_check[str(p)]=float(floor_t[0]-.045) if idx[0]>=0 else None
        # Stable set of hemisphere directions for contact ambient visibility.
        a=np.arange(13)*2.399963;xz=np.sqrt((np.arange(13)+.5)/13)
        self.updirs=np.stack((np.cos(a)*xz,np.sqrt(1-xz*xz),np.sin(a)*xz),axis=1).astype(np.float32)

    def get(self,n,omit_paper=False):
        return self._get((int(n)%330)//5,bool(omit_paper))

    @lru_cache(maxsize=132)
    def _get(self,k,omit_paper=False):
        w,meta=model(k)
        w.pixang=2*self.cam.th/320
        g=w.finalize(); points=np.concatenate((g['v0'],g['v1'],g['v2']))
        meta['mesh_vertices_aabb_m']=[points.min(0).tolist(),points.max(0).tolist()]
        triangle_mask=g['tm'].copy()
        if omit_paper:triangle_mask[np.isin(g['F']['tag'][g['tf']],PAPER_TAGS)]|=MASK_HIDDEN|1
        acc=Accel(g['v0'],g['v1'],g['v2'],triangle_mask)
        dist,tri=acc.closest(self.o,self.d,tmax=self.dist-.002,mask=MASK_HIDDEN)
        ii=np.where(tri>=0)[0]
        P=self.o[ii]+self.d[ii]*dist[ii,None]
        sf=rt.surface(w,g,tri[ii],P,self.d[ii],dist[ii])
        N=sf['N'];A=sf['alb'];tg=sf['tag'];accpair=Together(self.acc,acc)
        rng=np.random.default_rng(813)
        # Non-emissive material. Sample actual fog, directional sky, same global fixture groups,
        # direct shadow rays from real lamps. Paper reflects from either hemisphere when bent.
        full=rt.direct(self.near,accpair,P,N,rng,4)
        for q in range(3):
            full+=rt.direct(self.near,accpair,P,N,rng,4)
        full*=.25
        ksrc=self.kiosk['pos']-P;dn=np.linalg.norm(ksrc,axis=1)
        ld=ksrc/dn[:,None];face=np.abs((N*ld).sum(1))
        one=accpair.anyhit(P+ld*.004,ld,dn-.006,mask=1)
        pap=np.isin(tg,PAPER_TAGS)
        # Paper thin diffuse transmission restores a little of the kiosk light on the back.
        full[3,pap]+=(~one[pap]*.34*(.14+.86*face[pap])/(dn[pap]**2+.36))[:,None]*self.kiosk['color']
        up=floor_ambient(N)
        full[0]+=up+np.array([.018,.011,.006],np.float32)
        # Broad skylight reflected by the lighter paper fibres, never an emissive term.
        full[0,pap]+=np.array([.019,.029,.041],np.float32)
        full*=A[None]
        T=rt.fog_T(__import__('autumn_g15').FOG,self.o[ii],P,dist[ii])
        full*=T[None,:,None]
        full[0]+=(1.-T)[:,None]*__import__('autumn_g15').FOG['color'](self.d[ii])
        sh=np.zeros(len(self.o),np.float32)
        occ=acc.anyhit(self.so,self.sdir,self.sd.ravel()-.005,mask=1).reshape(self.sd.shape)
        wg=self.shadow_weight*self.basevis
        sh[self.fidx]=(wg*occ).sum(1)/np.maximum(wg.sum(1),.001)
        sh[ii]=0.
        pp=self.P[self.fidx].copy();pp[:,1]+=.003
        shadowdir=np.tile(self.updirs,(len(pp),1))
        corn=acc.anyhit(np.repeat(pp,13,axis=0),shadowdir,.41,mask=1).reshape(-1,13)
        cont=np.zeros(len(self.o),np.float32);cont[self.fidx]=corn.mean(1)*.9;cont[ii]=0.
        incoming=np.zeros((4,len(self.o),3),np.float32);incoming[:,ii]=full
        tags=np.zeros(len(self.o),np.uint8);tags[ii]=tg
        # Part tags retain all subpixel labels (no arbitrary display pad or flattening).
        tags=tags.reshape(*self.shape,16)
        vis=np.where(tri>=0,dist,self.dist).reshape(*self.shape,16)
        dep=np.sort(vis,axis=2)[...,np.rint(np.linspace(.5,14.5,9)).astype(int)]
        return ReaderSample((tags>0).mean(2).astype(np.float32),cont.reshape(*self.shape,16).mean(2),
                            incoming.reshape(4,*self.shape,16,3).mean(3),
                            sh.reshape(*self.shape,16).mean(2),dep,tags,
                            {s:int((tags==tag).sum()) for tag,s in PARTS.items()},
                            float(ORIGIN[1]),float(ORIGIN[1])+HEIGHT,meta)

    def draw(self,lin,n,gains,near_lit,with_shadows=True,with_body=True,omit_paper=False):
        v=self.get(n,omit_paper);sl=lin[self.ys,self.xs]
        if with_shadows:
            sl-=near_lit[self.ys,self.xs]*v.lamp_shadow[...,None]*gains['kiosk']*.84
            sl*=1.-v.contact[...,None]*.34
        if with_body:
            incoming=v.incoming[0]+v.incoming[1]*gains['lamp']+v.incoming[2]*gains['tv']+v.incoming[3]*gains['kiosk']
            sl*=1.-v.coverage[...,None]
            sl+=incoming

def floor_ambient(N):
    # Reflected ochre pavement also reaches underside of dark clothing.
    z=np.clip(N[:,1],-1,1);up=.045+.025*z
    return up[:,None]*np.array((.73,.82,1.03),np.float32)+(.044-.020*z)[:,None]*np.array((1.,.56,.28),np.float32)
