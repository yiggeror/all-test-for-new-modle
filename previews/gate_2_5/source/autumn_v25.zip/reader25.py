"""Articulated triangle-mesh reader, primary intersections and real area-light occlusion."""
from dataclasses import dataclass
from functools import lru_cache
import numpy as np
from engine import render as rt
from engine.world import World, roty, srgb, _n, MASK_HIDDEN
from engine.rt import Accel

PARTS={101:'coat',102:'trousers',103:'shoes',104:'collar',105:'head',
       106:'left_hand',107:'right_hand',108:'paper',109:'left_sleeve',110:'right_sleeve'}
PAPER=108
ORIGIN=np.array([-7.431,.150,3.104],float)
HEIGHT=1.69
# Merely a ray work tile. No screen-domain body, material or shadow geometry.
BOUNDS=(35,119,60,165)
YAW=-2.115
P0=np.array([.104,.670,.348])
VIEW=np.array([.856,0.,-.518])

def sigma(u):
    u=np.clip(u,0.,1.);return u*u*(3.-2.*u)

def controls(k):
    f=(k%66)*5
    lift=np.interp(f,[0,125,140,150,160,170,185,200,329],[0,0,.68,1,.95,.54,.19,0,0])
    # One leaf of the physical newspaper goes right-to-left and settles atop the other half.
    angle=np.pi*sigma(np.interp(f,[0,137,146,154,162,171,181,329],[0,0,.12,.38,.64,.87,1,1]))
    nod=.128*lift+.055*np.sin(2*np.pi*(f/330+.14))-.043
    weight=.028*np.sin(2*np.pi*f/330)*(.85+.15*np.cos(2*np.pi*f/330))
    return float(lift),float(angle),float(nod),float(weight)

def ell(w,p,r,tag,col,tilt=0.,n=10):
    # Geometric ellipsoid (not a sprite). Faces and their normals rotate together.
    s=np.sin(tilt);c=np.cos(tilt)
    with w.at(p,M=np.array([[1,0,0],[0,c,s],[0,-s,c]]) @ np.diag(r)):
        w.sphere((0,0,0),1.,n=n,mat='plain',col=col,tag=tag)

def lobe(w,a,b,r0,r1,col,tag):
    w.tube(a,b,r0,r1,sides=8,mat='plain',col=col,tag=tag,caps=True)

def sheet(w,start,spine,horiz,width,tag,col,ink_count=6):
    a=np.array(start);d=spine;h=horiz
    # Bowed newsprint with a real narrow crease, muted grey columns and a wider headline.
    # In the native 5x4 footprint these facets read as coarse light/dark print, not synthetic letters.
    faceN=_n(np.cross(h,d))
    cuts=(0.,.074,.33,.66,1.)
    def p(u,v):return a+h*(u*width)+d*v+faceN*(.019*np.sin(np.pi*u))
    for i,(u0,u1) in enumerate(zip(cuts[:-1],cuts[1:])):
        tone=col*(np.array([.66,.72,.77],np.float32) if i==0 else 1.)
        w.quads(p(u0,0),p(u1,0),p(u1,1),p(u0,1),mat='plain',col=tone,tag=tag)
    words=np.array([.59,.76,.68,.83,.69,.72])
    for m in range(ink_count):
        v=.20+.111*m
        pen=col*np.array((.51,.59,.65),np.float32)
        thickness=.073 if m==5 else .038
        for k,l in zip(cuts[:-1],cuts[1:]):
            u0=max(.14,k);u1=min(words[m],l)
            if u1<=u0:continue
            quad=np.stack((p(u0,v),p(u1,v),p(u1,v+thickness),p(u0,v+thickness)))
            for off in (-.002,.002):
                w.quads(*(quad+faceN*off),mat='plain',col=pen,tag=tag)

def model(k):
    lift,angle,nod,weight=controls(k)
    f=(k%66)*5
    w=World(seed=401)
    coat='#565467';shade='#49495a';seam='#67605b';lapel='#6e604f'
    trousers='#4c3b46';shoe='#36292b';skin='#c89a78';hair='#514247'
    paper=srgb('#efe1c9')
    contacts=((-0.137,0.,.085),(.145,0.,-.025))
    packet={}
    with w.at(ORIGIN,yaw=YAW):
        hips=np.array((weight,.836,-.024))
        chest=np.array((weight*.85,1.178,.016+.033*lift))
        # Two finite feet and bendable knees. Sole has a face at exactly y=0 of the local pavement.
        for i,(ax,_,az) in enumerate(contacts):
            a=np.array((ax,.082,az));s=-1+2*i
            toe=az+.065
            # Closed boot ellipsoid, lowest vertex exactly at y=0.
            ell(w,(ax,.060,toe),(.068,.060,.135),103,shoe,n=10)
            w.box((ax,.029,toe+.012),(.113,.058,.178),mat='plain',col=shoe,tag=103)
            knee=np.array((ax+.015*s,.455,az+.021))
            hip=hips+[s*.086,-.032,0.]
            lobe(w,a,knee,.069,.083,trousers,102)
            lobe(w,knee,hip,.085,.105,trousers,102)
            ell(w,knee,(.085,.109,.087),102,trousers,n=8)
        ell(w,hips,(.178,.125,.117),101,shade)
        ell(w,(hips+chest)/2+[0.,.040,0.],(.201,.265,.137),101,coat,tilt=.10+lift*.095)
        ell(w,chest,(.211,.128,.133),101,coat,tilt=.08)
        ell(w,(weight*.91,1.377,.038+lift*.048),(.088,.090,.091),104,lapel)
        ell(w,(weight*.94,1.402,.056+lift*.045),(.056,.091,.058),105,skin,n=8)
        # Sloped collar and side seam, carrying the warm rim rather than a grey outline.
        for s in (-1,1):
            w.poly([chest+(s*.035,.19,.078),chest+(s*.122,.132,.102),
                    chest+(s*.053,-.045,.129),chest+(s*.015,.071,.128)],
                   mat='plain',col=lapel,tag=104)
            w.poly([chest+(s*.18,.032,.056),chest+(s*.161,-.176,.070),
                    chest+(s*.161,-.162,.092),chest+(s*.191,.012,.072)],
                   mat='plain',col=seam,tag=101)
        # Leaning face with a neck, brow, crown and nose silhouette.
        hd=np.array((weight*1.01,1.526-.028*lift,.095+nod*.242))
        ell(w,hd,(.103,.130,.107),105,skin,tilt=.17+nod,n=12)
        ell(w,hd+(0.,.055,-.025),(.110,.109+.028*lift,.102),105,hair,tilt=.21+nod,n=12)
        ell(w,hd+(.004,-.027,.103),(.033,.034,.040),105,skin,tilt=.24+nod,n=8)
        for s in (-1,1):
            ell(w,hd+(s*.096,-.018,.005),(.023,.036,.027),105,skin,n=8)
        # Twist the newspaper slightly toward the viewer while its user faces the kiosk.
        # Two cream, non-emissive spreads and a physically hinged turning leaf.
        c=P0+np.array((weight*.5,.033*lift,.013*lift))
        h=_n(np.array([.685,.033,.727]))
        spine=np.array([-.027,.260,-.082-.019*lift])
        normal=_n(np.cross(h,spine))
        rotate=h*np.cos(angle)+normal*np.sin(angle)
        # Light the exposed physical front using the actual kiosk through a two-sided BRDF.
        h_left=_n(-h+VIEW*.39)
        sheet(w,c,spine,h_left,.218,108,paper)
        sheet(w,c,spine,h,.223,108,paper*.95)
        # Initially/at the end the animated leaf is just one of the physical resting sheets.
        if .015<angle<np.pi-.015:
            bent=_n(rotate+.075*normal+np.array([0.,.25*np.sin(angle),0.]))
            sheet(w,c+normal*.006,spine,bent,.222,108,paper*.996)
        else:
            bent=rotate
        for s in (-1,1):
            shoulder=chest+[s*.187,.055,.014]
            elbow=np.array((s*.218+weight*.89,.969+.03*lift,.184+.035*lift))
            if s<0:
                reach=h_left;u=.202;v=.38
            else:
                if angle<=.015:
                    reach=h
                elif angle<np.pi-.015:
                    reach=bent
                else:
                    undo=sigma((f-181)/22)
                    reach=_n(h_left*(1-undo)+h*undo+VIEW*.10*np.sin(np.pi*undo))
                u=.196;v=.32+.39*lift
            face=_n(np.cross(reach,spine))
            grip=c+reach*u+spine*v+face*(.019*np.sin(np.pi*u/(.218 if s<0 else .223)))
            # Palm and a connected curled thumb grip the physical edge; no screen-only hand.
            hand=grip+VIEW*(.057 if s<0 else .073)+np.array((0.,-.021,0.))
            # Shoulder, elbow sleeve, wrist cuff and hand overlap in actual space.
            arm=109 if s<0 else 110;tag=106 if s<0 else 107
            lobe(w,shoulder,elbow,.090,.073,shade,arm)
            ell(w,elbow,(.075,.075,.069),arm,shade,n=9)
            wrist=hand*.88+elbow*.12
            lobe(w,elbow,wrist,.071,.043,coat,arm)
            lobe(w,wrist,hand,.045,.039,seam,arm)
            ell(w,hand,(.051,.049,.049),tag,skin,tilt=.24,n=10)
            fingers=(hand+grip)*.5+np.array((0.,.018,0.))
            lobe(w,hand,fingers,.030,.026,skin,tag)
            lobe(w,fingers,grip,.026,.014,skin,tag)
            ell(w,fingers,(.031,.033,.029),tag,skin,tilt=.42,n=8)
            packet['left_hand' if s<0 else 'right_hand']=w.xf(hand).tolist()
        packet.update(feet=[w.xf(j).tolist() for j in contacts],spine_top=w.xf(c+spine).tolist(),
                      spine_bottom=w.xf(c).tolist(),paper_free_top=w.xf(c+spine+bent*.222).tolist(),
                      head=w.xf(hd).tolist(),page_angle=float(angle),body_weight=float(weight),nod=float(nod))
    return w,packet

class Together:
    def __init__(self,a,b):self.a,self.b=a,b
    def anyhit(self,o,d,tmax,mask=0):
        # Both physical acceleration structures participate in direct light visibility.
        s=self.a.anyhit(o,d,tmax,mask)
        if not s.all():
            ii=np.nonzero(~s)[0]
            tm=tmax if np.isscalar(tmax) else tmax[ii]
            s[ii]=self.b.anyhit(o[ii],d[ii],tm,mask)
        return s

@dataclass
class ReaderSample:
    coverage:np.ndarray
    contact:np.ndarray
    incoming:np.ndarray
    lamp_shadow:np.ndarray
    primary_depth:np.ndarray
    parts:np.ndarray
    part_counts:dict
    ground_y:float
    upper_y:float
    meta:dict

class Reader:
    def __init__(self,cam,world,acc,b):
        self.cam,self.world,self.acc,self.b=cam,world,acc,b
        x0,y0,x1,y1=BOUNDS;self.ys=slice(y0,y1);self.xs=slice(x0,x1)
        self.shape=(y1-y0,x1-x0)
        yy,xx=np.mgrid[y0:y1,x0:x1]
        # Four-by-four fixed subpixel rays per native cell. Pose holds remain exact.
        oy,ox=np.mgrid[0:4,0:4].reshape(2,-1)
        dv=cam.dirs((xx[...,None]+(.5+ox)/4).ravel(),(yy[...,None]+(.5+oy)/4).ravel()).astype(np.float32)
        self.d=dv;self.o=np.broadcast_to(cam.pos.astype(np.float32),dv.shape).copy()
        self.dist,ti=acc.closest(self.o,dv,mask=MASK_HIDDEN)
        safe=np.maximum(ti,0);g=world.finalize();ntag=g['F']['tag'][g['tf'][safe]]
        nn=g['F']['n'][g['tf'][safe]];self.P=self.o+dv*np.minimum(self.dist,1e3)[:,None]
        # Check existing kiosk sign (upper sign + left mag stand) and actual contact paving.
        self.structure=ntag.reshape(*self.shape,16)
        self.floor=(ti>=0)&(np.abs(nn[:,1])>.82)&(np.abs(self.P[:,1]-.15)<.011)
        self.kiosk=next(q for q in world.lights if q['grp']==3 and 'axis' not in q)
        self.near=[q for q in world.lights if q['kind']=='point' and np.linalg.norm(q['pos']-ORIGIN)<22.]
        self.samples=np.array(((0,0,0),(.67,0,0),(-.67,0,0),(0,.62,0),(0,-.62,0),(0,0,.61),(0,0,-.61)),np.float32)
        self.fidx=np.where(self.floor&(np.linalg.norm(self.P[:,[0,2]]-ORIGIN[[0,2]],axis=1)<1.95))[0]
        pp=self.P[self.fidx].copy();pp[:,1]+=.003
        v=self.kiosk['pos'][None,None]+self.kiosk['radius']*self.samples[None]-pp[:,None]
        self.sd=np.linalg.norm(v,axis=2);self.sdir=(v/self.sd[...,None]).reshape(-1,3)
        self.so=np.repeat(pp,len(self.samples),axis=0)
        basevis=~acc.anyhit(self.so,self.sdir,self.sd.ravel()-.005,mask=1)
        self.basevis=basevis.reshape(self.sd.shape)
        self.shadow_weight=np.maximum(self.sdir[:,1],0).reshape(self.sd.shape)/(self.sd**2+.36)
        self.floor_check={}
        for p in model(0)[1]['feet']:
            pp=np.asarray(p,np.float32);o=pp+[0,.045,0];down=np.array([[0.,-1.,0.]])
            floor_t,idx=acc.closest(o[None],down,tmax=.075)
            self.floor_check[str(p)]=float(floor_t[0]-.045) if idx[0]>=0 else None
        # Stable set of hemisphere directions for contact ambient visibility.
        a=np.arange(13)*2.399963;xz=np.sqrt((np.arange(13)+.5)/13)
        self.updirs=np.stack((np.cos(a)*xz,np.sqrt(1-xz*xz),np.sin(a)*xz),axis=1).astype(np.float32)

    def get(self,n,omit_paper=False):
        return self._get((int(n)%330)//5,bool(omit_paper))

    @lru_cache(maxsize=132)
    def _get(self,k,omit_paper=False):
        w,meta=model(k)
        w.pixang=2*self.cam.th/320
        g=w.finalize(); points=np.concatenate((g['v0'],g['v1'],g['v2']))
        meta['mesh_vertices_aabb_m']=[points.min(0).tolist(),points.max(0).tolist()]
        triangle_mask=g['tm'].copy()
        if omit_paper:triangle_mask[g['F']['tag'][g['tf']]==PAPER]|=MASK_HIDDEN|1
        acc=Accel(g['v0'],g['v1'],g['v2'],triangle_mask)
        dist,tri=acc.closest(self.o,self.d,tmax=self.dist-.002,mask=MASK_HIDDEN)
        ii=np.where(tri>=0)[0]
        P=self.o[ii]+self.d[ii]*dist[ii,None]
        sf=rt.surface(w,g,tri[ii],P,self.d[ii],dist[ii])
        N=sf['N'];A=sf['alb'];tg=sf['tag'];accpair=Together(self.acc,acc)
        rng=np.random.default_rng(813)
        # Non-emissive material. Sample actual fog, directional sky, same global fixture groups,
        # direct shadow rays from real lamps. Paper reflects from either hemisphere when bent.
        full=rt.direct(self.near,accpair,P,N,rng,4)
        for q in range(3):
            full+=rt.direct(self.near,accpair,P,N,rng,4)
        full*=.25
        ksrc=self.kiosk['pos']-P;dn=np.linalg.norm(ksrc,axis=1)
        ld=ksrc/dn[:,None];face=np.abs((N*ld).sum(1))
        one=accpair.anyhit(P+ld*.004,ld,dn-.006,mask=1)
        pap=(tg==108)
        # Paper thin diffuse transmission restores a little of the kiosk light on the back.
        full[3,pap]+=(~one[pap]*.50*(.14+.86*face[pap])/(dn[pap]**2+.36))[:,None]*self.kiosk['color']
        up=floor_ambient(N)
        full[0]+=up+np.array([.018,.011,.006],np.float32)
        # Broad skylight reflected by the lighter paper fibres, never an emissive term.
        full[0,pap]+=np.array([.019,.029,.041],np.float32)
        full*=A[None]
        T=rt.fog_T(__import__('autumn_g15').FOG,self.o[ii],P,dist[ii])
        full*=T[None,:,None]
        full[0]+=(1.-T)[:,None]*__import__('autumn_g15').FOG['color'](self.d[ii])
        sh=np.zeros(len(self.o),np.float32)
        occ=acc.anyhit(self.so,self.sdir,self.sd.ravel()-.005,mask=1).reshape(self.sd.shape)
        wg=self.shadow_weight*self.basevis
        sh[self.fidx]=(wg*occ).sum(1)/np.maximum(wg.sum(1),.001)
        sh[ii]=0.
        pp=self.P[self.fidx].copy();pp[:,1]+=.003
        shadowdir=np.tile(self.updirs,(len(pp),1))
        corn=acc.anyhit(np.repeat(pp,13,axis=0),shadowdir,.41,mask=1).reshape(-1,13)
        cont=np.zeros(len(self.o),np.float32);cont[self.fidx]=corn.mean(1)*.9;cont[ii]=0.
        incoming=np.zeros((4,len(self.o),3),np.float32);incoming[:,ii]=full
        tags=np.zeros(len(self.o),np.uint8);tags[ii]=tg
        # Part tags retain all subpixel labels (no arbitrary display pad or flattening).
        tags=tags.reshape(*self.shape,16)
        vis=np.where(tri>=0,dist,self.dist).reshape(*self.shape,16)
        dep=np.sort(vis,axis=2)[...,np.rint(np.linspace(.5,14.5,9)).astype(int)]
        return ReaderSample((tags>0).mean(2).astype(np.float32),cont.reshape(*self.shape,16).mean(2),
                            incoming.reshape(4,*self.shape,16,3).mean(3),
                            sh.reshape(*self.shape,16).mean(2),dep,tags,
                            {s:int((tags==tag).sum()) for tag,s in PARTS.items()},
                            float(ORIGIN[1]),float(ORIGIN[1])+HEIGHT,meta)

    def draw(self,lin,n,gains,near_lit,with_shadows=True,with_body=True,omit_paper=False):
        v=self.get(n,omit_paper);sl=lin[self.ys,self.xs]
        if with_shadows:
            sl-=near_lit[self.ys,self.xs]*v.lamp_shadow[...,None]*gains['kiosk']*.84
            sl*=1.-v.contact[...,None]*.34
        if with_body:
            incoming=v.incoming[0]+v.incoming[1]*gains['lamp']+v.incoming[2]*gains['tv']+v.incoming[3]*gains['kiosk']
            sl*=1.-v.coverage[...,None]
            sl+=incoming

def floor_ambient(N):
    # Reflected ochre pavement also reaches underside of dark clothing.
    z=np.clip(N[:,1],-1,1);up=.045+.025*z
    return up[:,None]*np.array((.73,.82,1.03),np.float32)+(.044-.020*z)[:,None]*np.array((1.,.56,.28),np.float32)
