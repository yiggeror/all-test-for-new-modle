"""Gate 2.5 exact provenance: matched production frames, native geometry masks, and motion traces."""
from __future__ import annotations
from pathlib import Path
import copy,json,hashlib
from contextlib import contextmanager
import numpy as np
from PIL import Image,ImageDraw
import autumn23
from autumn25 import fixture_gains
from reader25 import BOUNDS,PARTS,ORIGIN,HEIGHT
from wind25 import SHIFTS

F=330
FULL=(0,0,320,180)

def write(path,d):
    path.write_text(json.dumps(d,indent=2,ensure_ascii=False,allow_nan=False)+'\n')

def rect(mask,x0,y0,x1,y1):
    z=np.zeros(mask.shape,bool);z[y0:y1,x0:x1]=mask[y0:y1,x0:x1];return z

def bb(m):
    y,x=np.where(m)
    return None if not len(x) else [int(x.min()),int(y.min()),int(x.max()),int(y.max())]

def stats(v,den):
    v=np.asarray(v,dtype=float)
    return dict(min_changed=int(v.min()),max_changed=int(v.max()),mean_changed=round(float(v.mean()),3),
                denominator=int(den),min_pct=round(float(v.min()/den*100),4),
                max_pct=round(float(v.max()/den*100),4),mean_pct=round(float(v.mean()/den*100),4))

def native_rgb(src):
    return Image.fromarray(np.asarray(src,dtype=np.uint8),'RGB')

def strip(path,panels,labels,roi,cols=8,mul=4,footer=19):
    x,y,x1,y1=roi
    w=(x1-x)*mul;h=(y1-y)*mul;tilew=w+4;tileh=h+footer
    img=Image.new('RGB',(cols*tilew,((len(panels)+cols-1)//cols)*tileh),(32,32,35))
    d=ImageDraw.Draw(img)
    for i,(rgb,label) in enumerate(zip(panels,labels)):
        u=(i%cols)*tilew;v=(i//cols)*tileh
        img.paste(native_rgb(rgb[y:y1,x:x1]).resize((w,h),Image.Resampling.NEAREST),(u,v))
        d.text((u+1,v+h+2),label,fill=(238,230,213))
    img.save(path)

def heatmap(path,base,mask,heat):
    # Color ramp strictly counts actual native RGB A/B changes; no widened circles or interpolation.
    l=heat.astype(float)/(max(1.,float(heat.max())))
    colors=np.array([[36,24,41],[83,48,103],[166,59,93],[232,119,68],[254,206,96]],float)
    q=np.stack([np.interp(l,np.linspace(0.,1.,len(colors)),a) for a in colors.T],axis=2)
    shade=base.astype(float)*.26+[16.,12.,20.]
    shade[mask]=(base.astype(float)*.25+q*.75)[mask]
    native_rgb(shade).resize((1280,720),Image.Resampling.NEAREST).save(path)

def full_mask(a,src):
    x,y,X,Y=BOUNDS
    out=np.zeros((180,320)+src.shape[2:],src.dtype);out[y:Y,x:X]=src
    return out

def cohorts(a):
    out={}
    kiosk_body=(a.b['tag28']>=.45)
    # The existing main shelf left of the midpoint between trunks. It is not the reader mask.
    main_left=rect(kiosk_body,25,119,41,138)
    # Existing actual red sign geometry carries tex tag 4, and no neighboring facade enters this box.
    banner=rect(a.b['tag4']>.17,27,111,57,121)
    for k,g in (('main_left_rack',main_left),('header_sign',banner),('fixed_trunk',a.b['tag5']>.029)):
        assert g.any();out[k]=g
    return out

def trace_air(a,qa):
    import autumn23 as old
    import numpy as np
    groups=a.air.air
    paths=np.full((88,F,11),np.nan,np.float32)
    pose_crcs=np.zeros((88,F),np.uint32)
    unique_pairs=np.zeros((88,F),bool)
    geometry=copy.copy(a.air)
    base=a.static.copy()
    frame=0;idx=-1;first=True
    previous=old.paint_leaf

    # Reader is also part of visibility (if a leaf passes in front of the magazine rack).
    rdepth=[]
    for n in range(0,F,5):
        b=dict(a.b);b['depth']=z=a.b['depth'].copy()
        s=a.reader.get(n);q=z[a.reader.ys,a.reader.xs];sel=s.coverage>0
        q[sel]=s.primary_depth[sel];rdepth.append(b)
    def catch(dst,cam,plate,P,V,value,alpha,shadow=False):
        nonlocal first
        if not first or shadow:return
        first=False
        q=np.append(P[None],P+V,axis=0)
        x,y,d,z=cam.project(q); xx=x[1:]-(x[0]-np.floor(x[0])-.5);yy=y[1:]-(y[0]-np.floor(y[0])-.5)
        xl,xr=max(0,int(np.floor(xx.min()))),min(320,int(np.ceil(xx.max()))+1)
        yt,yb=max(0,int(np.floor(yy.min()))),min(180,int(np.ceil(yy.max()))+1)
        if xr>xl and yb>yt:
            u,v=np.mgrid[yt:yb,xl:xr];inside=np.zeros(u.shape,np.float32)
            edge=np.stack((xx,yy),axis=-1)
            for k,j in ((.29,.29),(.71,.29),(.29,.71),(.71,.71)):
                inside+=old.in_poly(v+k,u+j,edge)
            coverage=np.where(inside>=3,1.,np.where(inside==2,.79,.31))*(inside>0)
            clip=(plate['depth'][yt:yb,xl:xr]>d[0]-.042).mean(2)
            effective=coverage*clip*alpha
            footprint=int((coverage>0).sum());held=int((effective>.16).sum());vis=float(effective.max())
        else:
            footprint=held=0;vis=0.
        paths[idx,frame]=[x[0],y[0],d[0],float(alpha),*P,float(z[0]),float(footprint),float(held),vis]
        pose_crcs[idx,frame]=int.from_bytes(hashlib.sha256(np.asarray(V,dtype=np.float32).tobytes()).digest()[:4],'little')
        unique_pairs[idx,frame]=held>0
    try:
        old.paint_leaf=catch
        for idx,r in enumerate(groups):
            geometry.air=[r]
            for frame in range(F):
                geometry.b=rdepth[frame//5];first=True
                geometry.draw(base,frame/30)
    finally:
        old.paint_leaf=previous
    np.savez_compressed(qa/'autumn_air_paths.npz',paths=paths,visible=unique_pairs,rotation_signature_u32=pose_crcs)
    ids=[]
    for j,m in enumerate(a.air_info):
        v=int(unique_pairs[j].sum())
        th=np.abs(paths[j,:,3]);dark=((th>.20)&~unique_pairs[j])
        ids.append({**m,'native_raster_visible_frames':v,'not_visible_due_to_depth_or_projection_despite_inflight_alpha':int(dark.sum())})
    # All 88 release/render trajectories must hit the image, and each side retains all 44.
    assert len(ids)==88 and sum(m['side']=='left' for m in ids)==44
    assert all(v['native_raster_visible_frames']>0 for v in ids),[(m['id'],m['native_raster_visible_frames']) for m in ids if not m['native_raster_visible_frames']]
    q=dict(path_columns=['x_native','y_native','range_m','alpha','world_x','world_y','world_z','camera_z','geometry_pixel_count','visible_pixel_count','max_sample_coverage'],
           source_count=len(ids),visible_trajectory_count=sum(m['native_raster_visible_frames']>0 for m in ids),
           max_concurrent=int(unique_pairs.sum(0).max()),median_concurrent=float(np.median(unique_pairs.sum(0))),ids=ids)
    write(qa/'autumn_air_paths.json',q);print('air',q['visible_trajectory_count'],q['median_concurrent'],q['max_concurrent'],flush=True)

def trace_ground(a,qa):
    m=[];states=[]
    for n in range(F+1):
        rows=[]
        for track,world,a1,yaw,rot,scr in a.floor.states(n):
            rows.append([*world,float(a1),float(yaw),float(rot),*scr])
        states.append(rows)
    points=np.asarray(states,np.float32)
    source=points[:,:,:3].reshape(-1,3).astype(np.float32)
    origin=source.copy();origin[:,1]=.25
    floor_depth,floor_tri=a.acc.closest(origin,np.broadcast_to([0.,-1.,0.],origin.shape),tmax=.140)
    pad=(origin[:,1]-floor_depth).reshape(F+1,-1)
    assert (floor_tri>=0).all() and np.max(np.abs(pad-.15))<.001
    quiet=a.frame(0,only=())
    counts_by_pose=[]
    isolated=copy.copy(a.floor)
    for track in a.floor.tracks:
        isolated.tracks=[track];counts=[]
        for n in range(0,330,5):
            buf=a.static.copy();isolated.draw(buf,n)
            after=a.pa.quantize(autumn23.fx.bloom(buf,thresh=.50,sig=(1.2,4.5),gain=(.28,.20)))
            counts.append(int(np.any(after!=quiet,axis=2).sum()))
        assert np.max(counts)>0,track['id']
        counts_by_pose.append(counts)
    for j,track in enumerate(a.floor.tracks):
        row={k:(v.tolist() if isinstance(v,np.ndarray) else v) for k,v in track.items()}
        row['max_lift_m']=float(points[:,j,1].max()-row['source'][1])
        row['ending_rest_world_xyz_measured']=points[(row['start_f']+row['duration_f']+5)%330,j,:3].tolist()
        row['physical_pad_y_range_m']=[float(pad[:,j].min()),float(pad[:,j].max())]
        row['maximum_same_phase_rgb_pixels_single_leaf']=int(max(counts_by_pose[j]))
        row['visible_pose_count_single_leaf']=sum(v>0 for v in counts_by_pose[j])
        row['both_on_sidewalk']=abs(row['source'][1]-.1505)<.001 and abs(row['end'][1]-.1505)<.001
        assert row['both_on_sidewalk'] and .95<row['distance_px']<3.01 and .013<row['max_lift_m']<.06
        m.append(row)
    np.savez_compressed(qa/'autumn_curb_tracks.npz',trajectory=points,activity=a.bedding.moves,physical_bedding=a.bedding.bedding,
                        isolated_changed_pixels_66_by_id=np.asarray(counts_by_pose,np.uint16),raycast_pad_y_m=pad)
    write(qa/'autumn_curb_tracks.json',dict(tracks=m,columns='world_x world_y world_z opacity yaw flip screen_x screen_y distance'.split()))

def lockcheck(a,qa):
    """Compare immutable current and pinned v2.4 layers on all 330 phases, rather than by name."""
    import importlib.util
    if importlib.util.find_spec('autumn24') is None:
        write(qa/'autumn_old_locks.json',dict(status='optional frozen v2.4 original source ZIP not supplied'))
        return
    from autumn24 import AutumnV24
    old=AutumnV24()
    basis_arrays={}
    for name in ('static','lamp_r','tube_r','tv_r'):
        q=getattr(a,name);p=getattr(old,name)
        assert np.array_equal(p,q),name
        basis_arrays[name]=hashlib.sha256(np.ascontiguousarray(q).tobytes()).hexdigest()
    track={k:hashlib.sha256() for k in ('rolling','steam','birds','lamp','kiosk','tv')}
    for k in track:
        off=tuple(x for x in old.GROUPS if x!=k)
        for n in range(F):
            X=a.frame(n,only=(k,));Y=old.frame(n/30,omit=off)
            if not np.array_equal(X,Y):
                raise AssertionError(f'locked layer {k} differs on f{n}; {np.any(X!=Y,2).sum()} px')
            track[k].update(X.tobytes())
    write(qa/'autumn_old_locks.json',dict(frame_count=330,base_and_light_group_arrays_byte_exact_sha256=basis_arrays,
          actual_v24_layer_isolated_sha256={k:v.hexdigest() for k,v in track.items()}))
    print('v2.4 immutable effects matched',flush=True)

def prove(a,final,qa,baseline=None):
    h,w=180,320
    roi=np.stack(a.wind.rois)
    assert roi.shape==(2,h,w) and not (roi[0]&roi[1]).any()
    hard=a.wind.protected
    only_empty=a.frame(0,only=())
    crown_control=np.empty((F,h,w,3),np.uint8)
    D=np.empty((F,h,w),bool)
    O=np.empty_like(D);reader_rows=[]
    only=np.empty_like(crown_control)
    layers={'reader_off':[],'paper_off':[],'bed_off':[],'air_add_off':[],'crown_off':[]}
    samples=(0,65,80,125,135,140,145,150,155,160,165,170,175,180,185,190,195,200,205,210,218,230,238,253,270,310,329)
    actual_full_keys=('reader_off','paper_off','bed_off','air_add_off')
    geo_masks=cohorts(a);record=[];parts=[];contacts=[];shadows=[];cores=[]
    for n in range(F):
        control=a.frame(n,omit=('crown',));crown_control[n]=control
        D[n]=np.any(final[n]!=control,axis=2)
        only[n]=a.frame(n,only=('crown',));O[n]=np.any(only[n]!=only_empty,axis=2)
        # Edge support and change are checked every single phase of the assembled production frame.
        assert not (D[n]&~(a.wind.sample(n)>0)).any()
        if n%5==0:
            res=a.reader.get(n)
            cov=full_mask(a,res.coverage);cast=full_mask(a,res.lamp_shadow);ac=full_mask(a,res.contact)
            box=bb(cov>=.35);xmin,ymin,xmax,ymax=box
            main={k:int(np.count_nonzero((cov>.0)&v)) for k,v in geo_masks.items()}
            assert xmin>=39 and xmax<=54 and 24<=ymax-ymin+1<=26,(n,box)
            assert ymax<=154 and ymax>=151 and res.coverage.max()>=.5
            assert not main['fixed_trunk'] and not main['main_left_rack'] and not main['header_sign'],(n,main)
            assert main['main_left_rack']==0 and all(res.part_counts[k] for k in ('shoes','head','paper'))
            active=a.frame(n,only=('reader','reader_shadow'))
            neutral=a.frame(n,only=('reader',))
            foot_diff=np.any(active!=neutral,axis=2)
            q=dict(f=n,native_coverage_box=box, native_height_px=ymax-ymin+1,body_subrays=int((res.parts>0).sum()),
                   visible_part_subrays=res.part_counts,mesh_part_tag_codes=PARTS, actual_cast_box=bb(cast>.06),
                   contact_ground_box=bb(ac>.035), projected_and_behind_foreground=main,
                   true_lighting_contact_pixels=int(foot_diff.sum()), **res.meta)
            record.append(q)
            parts.append(res.parts);contacts.append(res.contact);shadows.append(res.lamp_shadow);cores.append(res.coverage)
        if n in samples:
            layers['crown_off'].append(control)
            for k,om in (('reader_off',('reader','reader_shadow')),('paper_off',('paper',)),('bed_off',('bed','pavement')),('air_add_off',('air_add',))):
                layers[k].append(a.frame(n,omit=om))
        if n%55==0:print(f'actual RGB proof frame {n:03}',flush=True)
    assert not (D&hard).any() and not (O&hard).any()
    assert np.array_equal(a.frame(330),final[0])
    same_edges=np.any(only!=np.roll(only,1,axis=0),axis=3)
    actual_edges=np.any(final!=np.roll(final,1,axis=0),axis=3)
    boundary=np.arange(F)%5==0
    assert not same_edges[~boundary].any()
    top=np.any(D,axis=0)
    groups={}
    for label,mask in (('left',roi[0]),('right',roi[1]),('both',roi.any(0))):
        active=(D&mask).sum((1,2));iso=(O&mask).sum((1,2));den=int(mask.sum())
        merged=(top&mask).sum();isolated_merged=int((O.any(0)&mask).sum())
        steady=np.ones(F,bool);steady[203:208]=False;steady[217:221]=False
        assert active[steady].min()>=.08*den and active[steady].max()<=.18*den and merged>=.70*den,(label,active.min(),active.max(),merged,den)
        inter=(same_edges&mask).sum((1,2));act=(actual_edges&mask).sum((1,2))
        groups[label]={'physical_roi_px':den,'eligible_depth_compatible_px':int((a.wind.domain&mask).sum()),
                       'active_production_same_phase_all330':stats(active,den),
                       'active_production_same_phase_non_ballast_321':stats(active[steady],den),
                       'time_union_pixels':int(merged),'time_union_pct':round(float(100*merged/den),4),
                       'isolated_active_same_phase':stats(iso,den),'isolated_time_union_px':isolated_merged,
                       'isolated_time_union_pct':round(100*isolated_merged/den,4),
                       'isolated_every_frame_temporal':stats(inter,den),
                       'isolated_pose_boundary_temporal':stats(inter[boundary],den),
                       'production_pose_boundary_temporal':stats(act[boundary],den),
                       'same_phase_changed_by_f':active.tolist(),'isolated_same_phase_changed_by_f':iso.tolist(),
                       'isolated_previous_rgb_by_f':inter.tolist(),'actual_previous_rgb_by_f':act.tolist()}
    metrics={'crown_definition':'per physical tag >= 6/9 native rays, excludes sky-heavy fringe. ROI independent of eligible donors. Pixel changed if any authored RGB differs.',
             'same_phase':groups,'protected_fixed_px_count':int(hard.sum()),'protected_motion_px':0,
             'crown_within_5_frame_holds_changed_pixels':int(same_edges[~boundary].sum()),
             'whole_production_f0_equals_f330':True,'rate_hz':6,
             'map_or_subpixel_in_crown':'none; one integer cardinal-neighbor donor per active leaf tap',
             'crown_primary_immutable_under_optical_glow':True}
    write(qa/'autumn_wind_stats.json',metrics)
    hm=D.sum(0).astype(np.uint16)
    heatmap(qa/'autumn_crown_330_heatmap.png',final[155],roi.any(0),hm)
    heatmap(qa/'autumn_crown_330_pose_boundaries.png',final[155],roi.any(0),same_edges.sum(0))
    indices=np.array(SHIFTS,np.int8)
    np.savez_compressed(qa/'autumn_crown_native_masks.npz',left=roi[0],right=roi[1],color_delta_count_330=hm,
                        nonmoving_protected=hard,protected_trunks=a.b['tag5']>.029,
                        protected_wire=a.b['tag6']>.029,eligible=a.wind.domain,donor_valid=a.wind.donors,
                        dirs_dy_dx=indices[a.wind.moves],any_rgb_same_phase_packed=np.packbits(D,axis=2),
                        only_wind_rgb_same_phase_packed=np.packbits(O,axis=2),only_wind_rgb_previous_packed=np.packbits(same_edges,axis=2),
                        **geo_masks)
    # Full 330-frame real OFF track, useful independently of the diagnostic heatmap/summary.
    np.savez_compressed(qa/'autumn_crown_off_native.npz',frames=crown_control)
    details=[{**record[n//5],'f':n,'held_pose_f':(n//5)*5} for n in range(F)]
    details.append({**record[0],'f':330,'held_pose_f':0})
    write(qa/'autumn_reader_331_frames.json',dict(origin_m=ORIGIN.tolist(),model_nominal_height_m=HEIGHT,
          shadow_method='actual seven-point kiosk-light shadow ray visibility and thirteen diffuse foot AO directions',
          local_raster_bounds=BOUNDS,primary_subsamples_per_pixel=16,
          terrain_solid_shoe_offsets_m=a.reader.floor_check,poses=details))
    np.savez_compressed(qa/'autumn_reader_masks.npz',packed_native_tags=np.stack(parts),dark_area_light=np.stack(shadows),
                        diffuse_contact=np.stack(contacts),primary_coverage=np.stack(cores),bounds=BOUNDS,
                        **geo_masks)
    export=dict(sample_frames=np.array(samples,np.int16),final=np.stack([final[n] for n in samples]))
    export.update({k:np.stack(v) for k,v in layers.items()})
    np.savez_compressed(qa/'autumn_scene_ab.npz',**export)
    for rubric,k in (('reader_geometry','reader_off'),('paper','paper_off'),('paving','bed_off'),('air_increase','air_add_off')):
        if k in ('paper_off','reader_off'):
            pans=[];txt=[]
            for n in (0,140,145,150,155,160,165,175,185,200):
                j=samples.index(n);pans.extend((final[n],layers[k][j]));txt.extend((f'F{n:03} ON',f'F{n:03} OFF'))
            strip(qa/f'autumn_{rubric}_ab_4x.png',pans,txt,(38,124,59,159),cols=8)
        elif k=='bed_off':
            for tag,area in (('left',(19,140,101,172)),('right',(213,141,305,176))):
                pans=[];txt=[]
                for n in (80,155,165,170,175,185,253):
                    j=samples.index(n);pans.extend((final[n],layers[k][j]));txt.extend((f'F{n:03} ON',f'F{n:03} OFF'))
                strip(qa/f'autumn_paving_{tag}_ab.png',pans,txt,area,cols=4,mul=3)
        else:
            pano=[];txt=[]
            for n in (80,150,155,170,185,230):
                j=samples.index(n);pano.extend((final[n],layers[k][j]));txt.extend((f'F{n:03} 88 source leaves',f'F{n:03} 44 increased layer OFF'))
            strip(qa/'autumn_88_vs_44_air_ab.png',pano,txt,(22,55,306,150),cols=4,mul=2)
    nlist=range(130,201)
    strip(qa/'autumn_turn_every_frame_4x.png',[final[n] for n in nlist],[
        f'F{n:03} / {n/30:.2f}s' for n in nlist],(38,125,58,157),cols=12)
    strip(qa/'autumn_turn_every_pose_4x.png',[final[n] for n in range(125,211,5)],[
        f'F{n:03} / {n/30:.2f}s' for n in range(125,211,5)],(35,124,61,160),cols=9)
    if baseline is not None:
        if hashlib.sha256(baseline.read_bytes()).hexdigest()!='850489623ee4f34c7cb2f2c95340ee78f0a2b3bab71c759557fe7c7aa1febc3f':
            raise ValueError('Wrong v2.4 autumn original native A/B')
        prev=np.load(baseline,mmap_mode='r')
        pts=(65,125,150,160,165,172,205,219,235)
        pans=[];txt=[]
        for n in pts:
            pans.extend((prev[n],final[n]));txt.extend((f'F{n:03} v2.4',f'F{n:03} v2.5'))
        strip(qa/'autumn_v24_v25_full_compare.png',pans,txt,FULL,cols=4,mul=2)
    trace_ground(a,qa)
    gates={k:dict(cur=fixture_gains(k)['lamp'],nominal=fixture_gains(k)['nominal_lamp'],kiosk=fixture_gains(k)['kiosk'],tv=fixture_gains(k)['tv'].tolist()) for k in range(F)}
    write(qa/'autumn_light_signals.json',gates)
    write(qa/'autumn_layout.json',dict(crowned={'roi_native_px':int(a.wind.physical.sum()),'whole_crown_continuous_field':True},reader_origin=ORIGIN.tolist(),warm_shade_dapple=a.dapple.data,
          rolling_original_count=len(a.leaves.road),steam_point=a.tea.tolist(),sky_bird_count=3))
    trace_air(a,qa)
    lockcheck(a,qa)
    print('wind',[(k,v['active_production_same_phase_all330'],v['time_union_pixels'],v['time_union_pct']) for k,v in groups.items()],flush=True)
