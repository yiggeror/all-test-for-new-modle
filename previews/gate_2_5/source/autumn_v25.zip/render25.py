#!/usr/bin/env python3
"""Render native autumn and the official bit-exact preview, or independently reproduce the proof."""
import argparse,hashlib,json,os,subprocess,sys,time,zipfile
from pathlib import Path
import numpy as np
from PIL import Image
N=330;FPS=30
V20='9c4e69ee6d6b1944cfc36a3030d24fe1db790ef74a83e9885d3abf6ca8354898'
V23='6b6be061999ce67c7585907eddc7b9fea1819ae34d35c4be52d12916045e8e2a'
V24='81e42a981e0188fc8247485db8d314343050f020e245e656daab670c61a0abaf'
SOURCE_FILES=('README.md','requirements.txt','autumn25.py','wind25.py','reader25.py','foliage25.py','render25.py','prove25.py','test_autumn25.py','verify.py','mobile.py')
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as ff:
        for b in iter(lambda:ff.read(2<<20),b''):h.update(b)
    return h.hexdigest()
def encode(a,out):
    pth=out.with_suffix('.pending.mp4')
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-nostdin','-y','-filter_threads','1','-f','rawvideo','-pixel_format','rgb24',
         '-video_size','320x180','-framerate','30','-i','-','-an','-vf','scale=1920:1080:flags=neighbor:out_color_matrix=bt709:out_range=tv,format=yuv420p',
         '-c:v','libx264','-preset','veryfast','-threads','2','-g','330','-keyint_min','330','-sc_threshold','0','-qp','0','-pix_fmt','yuv420p',
         '-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-color_range','tv','-movflags','+faststart',str(pth)]
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    for _ in range(2):p.stdin.write(memoryview(np.ascontiguousarray(a)).cast('B'))
    p.stdin.close()
    if p.wait():raise RuntimeError('QP0 encode failed')
    pth.replace(out)
def still(mp4,frame,out):
    expr=f'select=eq(n\\,{frame})'
    tmp=out.with_name(out.stem+'.pending.png')
    cmd=['ffmpeg','-v','error','-xerror','-y','-threads','2','-i',str(mp4),'-vf',expr,'-vsync','vfr','-frames:v','1','-threads','1',str(tmp)]
    subprocess.run(cmd,check=True)
    with Image.open(tmp) as im:
        if im.size!=(1920,1080):raise ValueError('Incorrect full-size peak still')
    tmp.replace(out)
def split(scene,mp4,work):
    root=work/'publish';base=root/'lossless_parts'/scene;base.mkdir(parents=True,exist_ok=True)
    parts=[];h=hashlib.sha256();size=0
    with mp4.open('rb') as src:
        for i,b in enumerate(iter(lambda:src.read(8_000_000),b'')):
            f=base/f'part-{i:02d}.bin';f.write_bytes(b)
            h.update(f.read_bytes());size+=len(b)
            parts.append({'path':str(f.relative_to(root)),'bytes':len(b),'sha256':sha(f)})
    whole=sha(mp4)
    if h.hexdigest()!=whole or size!=mp4.stat().st_size:raise AssertionError('lossless parts mismatch')
    entry={'output':mp4.name,'bytes':size,'sha256':whole,'parts':parts}
    (root/f'{scene}_parts.json').write_text(json.dumps(entry,indent=2)+'\n')
    return entry['bytes'],len(parts)


def setup(repo,work,legacy=False):
    # Inputs are release assets. Unverified archives must never enter the source import path.
    zips=(
      ('previews/gate_2/source/spring_autumn_source.zip',V20,'base','spring_autumn_gate2/src'),
      ('previews/gate_2_3/source/autumn_winter_v23.zip',V23,'basis_23','.'),
      ('previews/gate_2_4/source/autumn_winter_v24.zip',V24,'basis_24','.'))
    result=[]
    for rel,digest,root,sub in zips[:3 if legacy else 2]:
        f=repo/rel
        if not f.is_file() or sha(f)!=digest:raise ValueError(f'Wrong frozen fixture {f}')
        d=work/root;d.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(f) as zz:zz.extractall(d)
        result.append(str((d/sub).resolve()))
    sys.path[:0]=result

def save_native(state,out):
    dst=out/'autumn_native.npy'
    partial=dst.with_name(dst.stem+'.pending.npy')
    a=np.lib.format.open_memmap(partial,mode='w+',dtype=np.uint8,shape=(330,180,320,3))
    for n in range(N):
        a[n]=state.frame(n)
        if n%55==0:print(f'production frame {n:03}',flush=True)
    a.flush();del a;partial.replace(dst)
    return np.load(dst,mmap_mode='r')

def zip_source(out):
    source=out/'autumn_v25.zip'
    with zipfile.ZipFile(source,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name in SOURCE_FILES:
            data=(Path(__file__).parent/name).read_bytes()
            ref=zipfile.ZipInfo(name,date_time=(2026,11,24,0,0,0));ref.external_attr=0o644<<16
            z.writestr(ref,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    print('source',sha(source),flush=True)

def reader_previews(out):
    # Proxies are exactly 30 frames/s, consider neither a new render nor an approval source.
    src=out/'autumn_loop.mp4'
    settings=((74,251,'autumn_reader_normal_speed_1080p.mp4','',(1920,1080)),
              (125,211,'autumn_reader_normal_speed_detail.mp4',
               ',crop=192:228:210:738,scale=768:912:flags=neighbor',(768,912)))
    for i,j,name,crop,size in settings:
        dst=out/name;pending=dst.with_suffix('.pending.mp4')
        fil=f'trim=start_frame={i}:end_frame={j},settb=1/30,setpts=N{crop}'
        before=['ffmpeg','-hide_banner','-loglevel','error','-xerror','-nostdin','-y','-threads','2','-i',str(src)]
        codec=['-threads','2','-c:v','libx264','-profile:v','high','-level:v','4.0','-tune','animation',
               '-crf','15','-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709',
               '-color_range','tv','-movflags','+faststart']
        subprocess.run(before+['-an','-vf',fil,'-r','30','-fps_mode','cfr','-video_track_timescale','90000']+codec+[str(pending)],check=True)
        p=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(pending)]))['streams'][0]
        assert (p['width'],p['height'])==size and p['avg_frame_rate']=='30/1' and int(p['nb_frames'])==j-i
        assert abs(float(p['duration'])-(j-i)/30)<.00001
        subprocess.run(before[:-2]+['-i',str(pending),'-f','null','-'],check=True)
        pending.replace(dst)
        print(name,j-i,p['duration'],sha(dst),flush=True)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,required=True,help='repository with frozen source ZIPs and original palette mapping')
    p.add_argument('--work',type=Path,required=True)
    p.add_argument('--phase',choices=('full','picture','proof','compat','reader-preview'),default='full')
    p.add_argument('--candidate-cache',type=Path,help='developer-only raw plate cache; omitted by default')
    p.add_argument('--baseline-native',type=Path,help='optional old exact v2.4 330-frame native file for compare imagery')
    a=p.parse_args();work=a.work.resolve();repo=a.repo.resolve()
    out=work/'out';qa=work/'qa';out.mkdir(exist_ok=True,parents=True);qa.mkdir(exist_ok=True,parents=True)
    mode=a.phase
    if mode=='reader-preview':
        reader_previews(out);return
    if mode=='compat':
        from mobile import run
        run(out/'autumn_loop.mp4',out/'mobile/autumn_loop.mp4');return
    setup(repo,work,legacy=(repo/'previews/gate_2_4/source/autumn_winter_v24.zip').is_file())
    from autumn25 import AutumnV25
    state=AutumnV25(a.candidate_cache)
    if mode in ('full','picture'):
        arr=save_native(state,out);mp4=out/'autumn_loop.mp4'
        encode(arr,mp4)
        for f,key in ((0,'reader_standing'),(155,'page_release'),(160,'page_turn'),(172,'curb_and_air'),(205,'lamp_drop'),(219,'second_lamp_drop')):
            still(mp4,f,out/f'autumn_{key}_f{f:03}_1080p.png')
        print('QP0',split('autumn',mp4,work),sha(mp4),flush=True)
        from verify import run
        q=run('autumn',repo,out)
        (qa/'autumn_verified.json').write_text(json.dumps(q,indent=2)+'\n');print(q,flush=True)
    else:
        arr=np.load(out/'autumn_native.npy',mmap_mode='r')
    if mode in ('full','proof'):
        from prove25 import prove
        prove(state,arr,qa,a.baseline_native)
        zip_source(out)

if __name__=='__main__':
    main()
