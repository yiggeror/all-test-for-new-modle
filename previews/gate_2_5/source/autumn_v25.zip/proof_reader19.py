"""Round 19: verify true reader+cast OFF against the independent frozen Round 18 renderer."""
import argparse, hashlib, json, os, subprocess, sys, zipfile, copy
from pathlib import Path
import numpy as np

R18_ARCHIVE='2f5be01022e6217eeb4e962f6ecd3ca826a1da9aa3ba79fbfd4db7465247dfea'
N=330
STILL=(95,140,150,155,165,180,200)
UNTOUCHED=('autumn25.py','wind25.py','foliage25.py','verify.py','mobile.py','requirements.txt')
OFF=('reader','reader_shadow')

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def jsonout(p,s):
    p.write_text(json.dumps(s,indent=2,ensure_ascii=False,allow_nan=False)+'\n')

def off_seq(a,out):
    p=np.lib.format.open_memmap(out,mode='w+',dtype=np.uint8,shape=(330,180,320,3))
    for f in range(N):
        p[f]=a.frame(f,omit=OFF)
        if f%110==0:print('reader OFF actual',f,flush=True)
    p.flush()

def bbox(q,off=(0,0)):
    y,x=np.where(q)
    return None if len(x)==0 else [int(x.min()+off[0]),int(y.min()+off[1]),int(x.max()+off[0]),int(y.max()+off[1])]

def range_px(cam,vs):
    h,t,*_=cam.project(vs)
    return [(float(h.min()),float(t.min()),float(h.max()),float(t.max())),(float(h.max()-h.min()),float(t.max()-t.min()))]

def period_artifacts(a,native,control,qa,out):
    from prove25 import cohorts,strip
    from reader25 import PARTS,ORIGIN,BOUNDS,PAPER_TAGS,PAPER_TURN,model
    from render25 import still
    x0,y0,x1,y1=BOUNDS; offset=(int(x0),int(y0))
    mm=cohorts(a);r=a.reader
    actor_boxes=[];poses=[];paths=[]
    sf=[]
    covered=[];sh=[];ambient=[];headshots=[];pape=[];contrast=[]
    paper_isol=[]
    samples=(0,90,95,125,130,135,140,145,150,155,160,165,170,175,180,190,195,200,329)
    current=[];oldless=[];paperless=[];alb=[]
    for n in range(0,N,5):
        v=r.get(n);z=v.parts;hit=(z>0).mean(2)
        cbox=bbox(hit>=.35,offset)
        actor_boxes.append(cbox)
        # Query model directly for its actual projected mesh, not the colour of the room behind it.
        mg,meta=model(n//5);G=mg.finalize();mt=G['F']['tag'][G['tf']]
        def meshtag(tag):
            q=mt==tag
            if not q.any():return None
            return range_px(a.cam,np.concatenate([G[k][q] for k in ('v0','v1','v2')]))
        raw_rgb=np.asarray(native[n])
        true_no_paper=a.frame(n,omit=('paper',))
        parts={}
        for k,part in PARTS.items():
            mask=(z==k).mean(2)
            parts[part]={'hit_subrays':int((z==k).sum()),'support_xy':bbox(mask>.125,offset),
                         'dense_xy':bbox(mask>=.50,offset),'true_projected_mesh_bbox_and_dimensions_px':meshtag(k)}
        paper_zone=np.isin(z,PAPER_TAGS).mean(2)>.24
        p_off=r.get(n,True).parts
        backing_coat=np.isin(p_off,(101,102,104,105,109,110)).mean(2)
        d=raw_rgb[y0:y1,x0:x1].astype(np.int16)-true_no_paper[y0:y1,x0:x1].astype(np.int16)
        paper_delta=np.max(np.abs(d),axis=2)
        paper_only=np.count_nonzero(paper_zone&(paper_delta>=15))
        chest_seen=int(np.count_nonzero(paper_zone&(backing_coat>=.25)))
        paint_ratio=dict(paper_area_ge_four_rays=int(paper_zone.sum()),paper_pixels_with_max_channel_change_ge_15=int(paper_only),
                         paper_pixels_over_actor_dark_garment=int(chest_seen))
        protection={k:int(np.count_nonzero((hit>.0)&m[y0:y1,x0:x1])) for k,m in mm.items()}
        assert not protection['fixed_trunk'] and not protection['main_left_rack'] and not protection['header_sign'],(n,cbox,protection)
        assert parts['head']['hit_subrays']>0 and parts['paper']['hit_subrays']>0 and parts['shoes']['hit_subrays']>0
        assert 24<=cbox[3]-cbox[1]+1<=27 and cbox[0]>=39 and cbox[2]<=55,(n,cbox)
        assert 1.05 <= meta['spine_bottom'][1]-ORIGIN[1] <= 1.15
        assert all(abs(f[1]-.15)<.001 for f in meta['feet'])
        assert v.contact.sum()>0
        def project(world):
            x,y,d,z=a.cam.project(world)
            return [float(x),float(y),float(d)]
        decoded={name:project(val) for name,val in meta.items() if isinstance(val,list) and len(val)==3}
        decoded['feet']=[project(p) for p in meta['feet']]
        stencil=dict(f=n,bbox_35pct=cbox,world=meta,image=decoded,parts=parts,
                paper_contrast=paint_ratio,overlap_with_immutable_objects=protection,
                fixed_shoe_surface_offsets_m=r.floor_check,
                contact_box=bbox(v.contact>.035,offset),true_kiosk_soft_cast_box=bbox(v.lamp_shadow>.06,offset))
        poses.append(stencil)
        covered.append(z);sh.append(v.lamp_shadow);ambient.append(v.contact);paper_isol.append(p_off);pape.append(paper_delta)
    assert np.array_equal(a.frame(330),native[0]),'independent phase330 source call mismatches phase0'
    record=[{**poses[f//5],'f':f,'held_pose':(f//5)*5} for f in range(N)]
    record.append({**poses[0],'f':330,'held_pose':0})
    moving=[p['f'] for p in poses if p['parts']['turning_newsprint']['hit_subrays']>0]
    assert len(moving)>=6
    fr=np.array([p['image']['live_page_free_top'] for p in poses],np.float64)
    active=[p for p in poses if p['world']['active_turn_mesh']]
    normal=[p for p in poses if p['f']<115 or p['f']>205]
    tri=np.array([p['image']['live_page_free_top'] for p in active])
    height=[p['parts']['head']['true_projected_mesh_bbox_and_dimensions_px'][1][1] for p in poses]
    width=[p['parts']['head']['true_projected_mesh_bbox_and_dimensions_px'][1][0] for p in poses]
    jsonout(qa/'autumn_reader_331_frames.json',dict(pose_count=66,raw_frame_count=331,checked_equal_phase_330=True,
           nominal_station_ground_y_world=.15,head_width_native_min_max=[float(min(width)),float(max(width))],
           head_height_native_min_max=[float(min(height)),float(max(height))],
           live_fold_turn_five_frame_pose_starts=moving,
           live_outer_point_xy_travel_px=[float(fr[:,0].max()-fr[:,0].min()),float(fr[24,1]-tri[:,1].min())],
           projected_closed_to_open_station_bbox=actor_boxes,shadow_is_true_kiosk_plus_hemisphere_contact=True,
           no_protected_sign_or_rack_overlap_all_330=True,poses=record))
    np.savez_compressed(qa/'autumn_reader_masks.npz',labels16=np.stack(covered),paper_off_labels16=np.stack(paper_isol),
                        area_light_occlusion=np.stack(sh),ground_contact=np.stack(ambient),bounds=BOUNDS,
                        actual_paper_argb_difference_on_off=np.stack(pape),**mm)
    for f in samples:
        current.append(native[f]);oldless.append(control[f]);paperless.append(a.frame(f,omit=('paper',)))
    np.savez_compressed(qa/'autumn_reader_scope_ab.npz',sample_frames=np.array(samples),on=np.stack(current),
                        no_reader_or_shadow=np.stack(oldless),paper_off=np.stack(paperless))
    for f in STILL:
        still(out/'autumn_loop.mp4',f,out/f'autumn_reader_r19_f{f:03}_1080p.png')
    crop=(38,123,57,158);seq=range(120,197)
    strip(qa/'autumn_turn_every_frame_4x.png',[native[f] for f in seq],
          [f'F{f:03}  {f/30:.2f}s' for f in seq],crop,cols=12,mul=4)
    seq=range(125,196,5)
    strip(qa/'autumn_turn_every_pose_4x.png',[native[f] for f in seq],
          [f'F{f:03}  {f/30:.2f}s' for f in seq],crop,cols=8,mul=4)
    panels=[];labs=[]
    for j,n in enumerate(samples):
        if n not in (0,125,140,145,150,155,160,165,170,180,190,200):continue
        panels.extend((current[j],paperless[j],oldless[j]))
        labs.extend((f'F{n} ON',f'F{n} paper OFF',f'F{n} body OFF'))
    strip(qa/'autumn_reader_ab_4x.png',panels,labs,crop,cols=9,mul=4)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--work',type=Path);p.add_argument('--repo',type=Path);p.add_argument('--r18-source',type=Path)
    p.add_argument('--internal-off',nargs=5,metavar=('SRC','ENGINE','V23','DST','CACHE'))
    args=p.parse_args()
    if args.internal_off:
        src,engine,v23,dst,cache=args.internal_off
        sys.path[:0]=[src,engine,v23]
        from autumn25 import AutumnV25
        off_seq(AutumnV25(None if cache=='-' else cache),Path(dst));return
    w=args.work.resolve();qa=w/'qa';out=w/'out';qa.mkdir(parents=True,exist_ok=True)
    from render25 import setup,zip_source
    setup(args.repo.resolve(),w)
    from autumn25 import AutumnV25
    file=args.r18_source.resolve()
    assert sha(file)==R18_ARCHIVE
    old=w/'r18_witness';old.mkdir(exist_ok=True);(w/'drafts').mkdir(exist_ok=True)
    with zipfile.ZipFile(file) as z:z.extractall(old)
    fingerprints={}
    for name in UNTOUCHED:
        a=old/name;b=Path(__file__).parent/name
        assert a.read_bytes()==b.read_bytes(),name
        fingerprints[name]=sha(b)
    static=w/'r19_real_plate.npz'
    a=AutumnV25(static)
    old_off=w/'drafts/r18_actual_reader_off_native.npy'
    new_off=w/'qa/autumn_reader_off_native.npy'
    assert new_off.parent.is_dir()
    proc=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--internal-off',str(old),
             str(w/'base/spring_autumn_gate2/src'),str(w/'basis_23'),str(old_off),str(static)])
    off_seq(a,new_off)
    assert proc.wait()==0
    la=np.load(old_off,mmap_mode='r');lb=np.load(new_off,mmap_mode='r')
    frame_counts=[int(np.any(la[i]!=lb[i],axis=2).sum()) for i in range(N)]
    assert not any(frame_counts),[f for f,v in enumerate(frame_counts) if v]
    jsonout(qa/'autumn_r18_r19_reader_off_equality.json',dict(r18_zip_sha256=R18_ARCHIVE,
            untouched_production_source_sha256=fingerprints,disabled_exact_groups=list(OFF),
            independent_source_subprocesses=True,verified_frames=N,exact_read_off_native_npy_sha256=sha(new_off),
            differing_pixels_per_frame=frame_counts,all_r18_approved_layers_identical=True))
    native=np.load(out/'autumn_native.npy',mmap_mode='r')
    period_artifacts(a,native,lb,qa,out)
    zip_source(out)
    print('Round 19 all logical proof outputs written',flush=True)

if __name__=='__main__':
    main()
