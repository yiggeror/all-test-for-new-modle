"""Independent minimal Round 19 book height, bias, geometry, planting, and timed-turn tests."""
import sys,os,unittest
import numpy as np
if 'A25_FIXTURES' in os.environ:
    sys.path[:0]=os.environ['A25_FIXTURES'].split(os.pathsep)
from reader25 import model,ORIGIN,PARTS
from autumn_g15 import camera

def extent(cc,points):
    x,y,*_=cc.project(points)
    return float(x.max()-x.min()),float(y.max()-y.min())

class Reader19(unittest.TestCase):
    def test_held_spread_below_shoulders_is_not_a_bag(self):
        quiet,s=model(0)
        y=s['spine_bottom'][1]-ORIGIN[1]
        self.assertGreaterEqual(y,1.05)
        self.assertLessEqual(y,1.15)
        self.assertIn('gaze_direction',s)
        self.assertLess(s['gaze_direction'][1],-.30)
        self.assertGreater(np.dot(s['gaze_direction'],np.array(s['gaze_target'])-np.array(s['head'])),.20)
    def test_round_head_coat_and_two_grounded_feet(self):
        c=camera()
        g,info=model(0);p=g.finalize()
        tags=p['F']['tag'][p['tf']]
        dims=lambda k:extent(c,np.concatenate([p[q][tags==k] for q in ('v0','v1','v2')]))
        w,h=dims(105)
        self.assertGreater(w,2.8);self.assertLess(w,4.7)
        self.assertGreater(h,2.8);self.assertLess(h,4.7)
        w,h=dims(101)
        self.assertGreaterEqual(w,4.9);self.assertLess(w,7.8)
        feets=np.array(info['feet'])
        self.assertTrue(np.allclose(feets[:,1],.15))
        self.assertGreater(extent(c,feets)[0],3.)
    def test_page_moves_up_and_across_before_settling(self):
        cam=camera();seq=[model(n)[1] for n in range(66)]
        edge=np.array([m['live_page_free_top'] for m in seq])
        x,y,*_=cam.project(edge)
        self.assertGreaterEqual(float(np.max(x)-np.min(x)),4.)
        self.assertGreaterEqual(float(y[24]-np.min(y[25:37])),1.65)
        self.assertAlmostEqual(seq[0]['page_angle'],0.)
        self.assertAlmostEqual(seq[-1]['page_angle'],np.pi)
        self.assertTrue(np.allclose(model(0)[0].finalize()['v0'],model(66)[0].finalize()['v0']))

if __name__=='__main__':
    unittest.main()
