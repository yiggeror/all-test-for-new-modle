"""Round 18 integration checks through the production scene and same-phase A/B."""
import unittest
import numpy as np
import os
from pathlib import Path
if 'A25_FIXTURES' in os.environ:
    import sys
    sys.path[:0]=os.environ['A25_FIXTURES'].split(os.pathsep)
from autumn25 import AutumnV25

class Gate25(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.a=AutumnV25()
    def test_full_wind_replaces_old_sparse_tremor(self):
        a=self.a; g=a.wind
        reference=a.frame(0,only=('crown',),omit=('crown',))
        c=np.stack([np.any(a.frame(n,only=('crown',))!=reference,axis=2) for n in range(0,330,5)])
        for side in g.rois:
            totals=(c&side).sum((1,2))
            self.assertGreaterEqual(totals.min()/side.sum(),.08)
            self.assertLessEqual(totals.max()/side.sum(),.18)
            self.assertGreaterEqual((c.any(0)&side).sum()/side.sum(),.70)
        self.assertFalse((c.any(0)&g.protected).any())
        self.assertTrue(np.array_equal(a.frame(330,only=('crown',)),a.frame(0,only=('crown',))))
        self.assertTrue(np.array_equal(a.frame(151,only=('crown',)),a.frame(154,only=('crown',))))
    def test_3d_reader_contacts_and_one_real_turn(self):
        a=self.a;r=a.reader
        quiet=r.get(0);peak=r.get(160)
        self.assertGreater(quiet.coverage.max(),.50)
        self.assertGreater(np.count_nonzero(quiet.contact>.035),8)
        self.assertGreater(float(quiet.lamp_shadow.max()),.45)
        self.assertEqual(len(r.floor_check),2)
        for offset in r.floor_check.values():
            self.assertAlmostEqual(offset,0.,places=3)
        self.assertTrue(set(quiet.part_counts)&{'left_hand','right_hand'})
        self.assertTrue(quiet.part_counts['paper']>0 and peak.part_counts['paper']>0)
        self.assertAlmostEqual(quiet.upper_y-quiet.ground_y,1.69,places=4)
        self.assertFalse(np.array_equal(quiet.coverage,peak.coverage)&np.array_equal(quiet.incoming,peak.incoming))
        self.assertTrue(np.array_equal(quiet.incoming,r.get(330).incoming))
    def test_air_and_curb_seeds_are_real(self):
        a=self.a
        self.assertEqual(tuple(sum(m['side']==k for m in a.air_info) for k in ('left','right')),(44,44))
        self.assertTrue(all(m['tag']==1 for m in a.air_info))
        self.assertEqual(len(a.floor.tracks),8)
        for j in range(8):
            self.assertTrue(np.isfinite(a.floor.tracks[j]['source']).all())

if __name__=='__main__':
    unittest.main()
