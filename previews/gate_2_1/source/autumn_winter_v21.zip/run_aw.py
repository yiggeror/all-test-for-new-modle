#!/usr/bin/env python3
"""From the checked-out repository, render the autumn/winter native RGB masters and 22s lossless checks."""
import argparse,os,subprocess,sys
from pathlib import Path
def main():
    p=argparse.ArgumentParser();p.add_argument('scene',choices=['autumn','winter','both']);p.add_argument('--repo',type=Path,default=Path('.'));p.add_argument('--work',type=Path,default=Path('build/gate_2_1_aw'));a=p.parse_args();root=a.repo.resolve(); work=a.work.resolve()
    script=Path(__file__).resolve().parent; en=os.environ.copy();en.setdefault('NUMBA_NUM_THREADS','2');en.setdefault('OPENBLAS_NUM_THREADS','1')
    for s in (('autumn','winter') if a.scene=='both' else (a.scene,)):
        zipname='spring_autumn_source.zip' if s=='autumn' else 'gate2_summer_winter_source_qa.zip'
        basis=root/'previews'/'gate_2'/'source'/zipname
        if not basis.is_file(): raise SystemExit('Missing original Gate 2 source: '+str(basis))
        subprocess.run([sys.executable,str(script/'aw_background.py'),s,'--basis',str(basis),'--cache',str(work/'cache')],check=True,env=en)
        subprocess.run([sys.executable,str(script/'aw_finish.py'),s,'--cache',str(work/'cache'),'--output',str(work/'out'),'--proof',str(work/'qa')],check=True,env=en)
if __name__=='__main__': main()
