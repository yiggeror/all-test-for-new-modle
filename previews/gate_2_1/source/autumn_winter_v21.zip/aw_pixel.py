"""手绘原生鸟类关键姿态、足部落点和有风落叶。所有颜色只从季节冻结色板选择。"""
from __future__ import annotations
from dataclasses import dataclass
from functools import lru_cache
from math import sin,cos,pi,floor
import numpy as np

N=330
TAU=2*pi
def clip(x):return min(1.,max(0.,x))
def ease(x):
    x=clip(x);return x*x*(3.-2.*x)
def phase(t,start,end):
    return clip((t-start)/(end-start))
def iv(t,a,b):return a<=t<b

# Each array has its own centre of support; last row sits on the perch. D dark feather,
# W scapulars, M folded wing, H lit cap, K eye, C breast, E cheek, B bill, F leg, A stripe.
# Independent redraws with changed feather geometry and head joints; no rigid-frame rotations.
C={
'rest':(4,[
'.....HH.',
'....HEKB',
'..HWWEC.',
'.MWAMCC.',
'DDMWCC..',
'...DF...',
'...F.F..']),
'look':(4,[
'.....HH.',
'....HEKB',
'....HCE.',
'..HMWCC.',
'.MWAMCC.',
'DDMMCD..',
'...F.F..']),
'tip':(4,[
'......H.',
'....HEKB',
'..HMWCC.',
'.MWAMCC.',
'DDMWCC..',
'...DF...',
'...F.F..']),
'lean':(4,[
'.....HH..',
'...WMCEKB',
'.HMWMCEE.',
'DDMWWCC..',
'...DCD...',
'...F.F...']),
'peck':(4,[
'.HWWM....',
'DMWAMCH..',
'..MCCCHK.',
'...DCC.EB',
'...F.F..B']),
'bob':(4,[
'..WWWHH..',
'DMWAMCEKB',
'..MCCCC..',
'...DDC...',
'...F.F...']),
'tuck':(4,[
'....HH..',
'...WEKB.',
'..WHHEC.',
'DMWMWCC.',
'.DMMCD..',
'...F.F..']),
'hop':(4,[
'.....HH..',
'....HEKBB',
'..HWMEC..',
'DMWMWCC..',
'.DMMCC...',
'...D.F...',
'....F....']),
'fold':(4,[
'....WH...',
'...DMHH..',
'.DHHMCEKB',
'DMWMWCC..',
'..MDCC...',
'....DF...']),
'wingup':(4,[
'...D.....',
'..DW.....',
'..DWW....',
'...WMHH..',
'...WWEKBB',
'.DWMCCC..',
'DDMMCC...',
'....D....']),
'wingmid':(4,[
'DDW......',
'.DMWW.HH.',
'...MWEKBB',
'..MWWCC..',
'DDMWCC...',
'...DD....']),
'wingdown':(4,[
'.....HH..',
'....HEKBB',
'..WWHEC..',
'DMWMWCC..',
'..DWWC...',
'...DWM...',
'....DW...']),
'face':(4,[
'...HHH..',
'...KBE..',
'..WCECW.',
'..WCCCM.',
'..MCCCD.',
'...DCD..',
'...F.F..']),
'back':(4,[
'....HH..',
'...HHHD.',
'..WMWWH.',
'..MWWMM.',
'.DDMWD..',
'...DDD..',
'...F.F..']),
}
# Bullfinch: asymmetric black cap, folded wing bar, soft russet chest, heavier winter body.
# Feet are tucked into plumage in flight. Its winter profile differs from autumn sparrows.
WIN={
'rest':(5,[
'.....HH..',
'....DHE..',
'...HMEKBB',
'..HMMCCC.',
'..WAAECC.',
'.DMMWCC..',
'DDMWCD...',
'....F.F..']),
'look':(5,[
'.....HH..',
'....HEKB.',
'....HECC.',
'..HMMMCC.',
'..WAAECC.',
'.DMMWCCC.',
'DDMWMCD..',
'....F.F..']),
'tip':(5,[
'.....HH..',
'....HHKB.',
'...HMECC.',
'..HMWCCC.',
'..WAAECC.',
'.DMMWCC..',
'DDMWCD...',
'....F.F..']),
'face':(5,[
'....HHH..',
'....KBE..',
'...HCECH.',
'..WMCCCM.',
'..MACCCW.',
'..WMCCCD.',
'...WMCD..',
'....F.F..']),
'rear':(5,[
'....HHH..',
'...DHHE..',
'...HMMCB.',
'..WMAMWC.',
'..DWAMMC.',
'.DDMMMM..',
'DD..CD...',
'....F.F..']),
'fluff':(5,[
'.....HH...',
'....DHE...',
'..HHMEKBB.',
'.WHMMCCC..',
'.MWAAECCC.',
'DMWMMCCC..',
'.DMMCCD...',
'....F.F...']),
'fluff2':(5,[
'....HHH...',
'....HHE...',
'..HWMEKBB.',
'.DMMMACC..',
'.MWAAECC..',
'DDMWMCC...',
'.DMMCD....',
'....F.F...']),
'crouch':(5,[
'....HH...',
'...DHEKB.',
'..HMWCEC.',
'.MWAAECC.',
'DDMWMCC..',
'...DDCD..',
'....F.F..']),
'flightup':(5,[
'..D.......',
'..WW......',
'..DHW.....',
'...DAWHH..',
'...WMAHKB.',
'..HMMEECB.',
'DDMWMCCC..',
'.DDMCC....',
'....D.....']),
'flightmid':(5,[
'DDW.......',
'.DHWW..HH.',
'..DMWAHKB.',
'...WMACCB.',
'.DMMWCCC..',
'DDMMCCD...']),
'flightdown':(5,[
'......HH..',
'.....HEKBB',
'..HWMECC..',
'DDMMWACC..',
'.DDMMWAC..',
'....DMW...',
'.....DW...']),
'glide':(5,[
'.......H..',
'...H..EKB.',
'.DHHWAECCB',
'DDMMWCCC..',
'...MMCD...']),
'alight':(5,[
'...WD....',
'...WWHH..',
'..DHAHKB.',
'...WMECB.',
'.DHMWCCC.',
'DDMMWCC..',
'....F.F..']),
'hop':(5,[
'.....HH..',
'....DHEKB',
'..HMWCEC.',
'..WAAECC.',
'.DMMWCC..',
'DDMWCC...',
'....F....']),
}
AUT_PAL=[
dict(D=1,W=15,M=7,H=37,K=0,C=55,E=53,B=44,F=11,A=31),
dict(D=0,W=24,M=12,H=24,K=0,C=31,E=53,B=40,F=3,A=34),
dict(D=3,W=13,M=6,H=35,K=0,C=43,E=53,B=44,F=11,A=41)]
WIN_PAL=dict(D=0,W=8,M=5,H=18,K=0,C=45,E=55,B=49,F=5,A=48)

@dataclass
class Pose:
    x:float;y:float;name:str;face:int=1;ground:float=0.;height:float=0.
def keyed(t,segments):
    for a,b,pose in segments:
        if a<=t<b:return pose
    return 'rest'
def loci(t,origin,hops):
    x,y=origin; al=0.; active=None; u=0.
    for i,(start,end,tx,ty,h,kind,field) in enumerate(hops):
        if t<start:break
        if t>=end:x,y=tx,ty;continue
        u=phase(t,start,end)
        x=x+(tx-x)*ease(u);y=y+(ty-y)*ease(u)
        al=h*(4*u*(1-u) if kind!='winged' else (sin(pi*u))**.86)
        active=(kind,field);break
    return x,y,al,active,u
def get_face(t,items):
    face=items[0][1]
    for when,v in items:
        if when>t:break
        face=v
    return face

POSIT=[(54,168),(84,164),(70,155)]
HOPS=[
    [(23,38,59,167,3.3,'hop',1),(44,60,65,166,3.8,'hop',1),
     (174,190,61,168,3.4,'hop',-1),(199,219,54,168,4.1,'hop',-1)],
    [(84,99,88,164,3.0,'hop',1),(110,127,93,163,3.8,'hop',1),
     (218,248,84,164,7.8,'winged',-1)],
    [(132,146,73,154,2.6,'hop',1),(151,167,78,154,3.2,'hop',1),
     (260,278,74,155,3.1,'hop',-1),(281,298,70,155,2.8,'hop',-1)]
]
TURN=[[(0,1),(162,-1),(251,1)],[(0,-1),(68,1),(204,-1)],[(0,1),(240,-1),(309,1)]]
ACT=[
 [(8,16,'tip'),(17,23,'tuck'),(38,42,'tuck'),(61,69,'tuck'),(72,80,'lean'),(80,92,'peck'),(92,99,'bob'),(106,113,'lean'),(113,122,'peck'),(122,130,'bob'),(135,154,'look'),(156,162,'face'),(221,230,'tuck'),(236,247,'look'),(247,251,'face'),(273,292,'tip')],
 [(11,21,'lean'),(21,29,'peck'),(29,36,'bob'),(45,60,'look'),(61,68,'face'),(79,84,'tuck'),(128,135,'tuck'),(145,157,'tip'),(160,172,'lean'),(172,180,'peck'),(180,185,'bob'),(194,202,'look'),(202,207,'face'),(213,218,'tuck'),(249,256,'tuck'),(275,290,'look'),(300,310,'tip')],
 [(15,31,'look'),(57,65,'lean'),(65,73,'peck'),(73,79,'bob'),(101,115,'tip'),(124,132,'tuck'),(169,178,'tuck'),(182,190,'lean'),(190,197,'peck'),(198,205,'bob'),(219,233,'look'),(235,240,'face'),(299,304,'tuck'),(304,309,'face')]
]
def autumn_pose(i,t):
    t=t%N; x,y,h,active,u=loci(t,POSIT[i],HOPS[i])
    name=keyed(t,ACT[i]); face=get_face(t,TURN[i])
    if active:
        kind,face=active
        if kind=='winged':
            idx=min(8,int(u*9));name=('tuck','wingup','wingmid','wingdown','wingmid','wingup','fold','hop','tuck')[idx]
        else:name='tuck' if u<.13 or u>.90 else 'hop' if u<.72 else 'fold'
    return Pose(x,y-h,name,face,y,h)
def winter_pose(t):
    t=t%N
    sched=[(74,111,264,146,18.8,'winged',1),(141,158,269,146,3.9,'hop',1),
           (167,182,273,145,3.5,'hop',1),(244,286,227,131,17.6,'winged',-1)]
    x,y,h,active,u=loci(t,(227,131),sched)
    face=get_face(t,[(0,1),(186,-1),(294,1)])
    seq=[(9,23,'tip'),(26,34,'face'),(35,42,'fluff'),(42,47,'fluff2'),(47,52,'fluff'),(52,57,'crouch'),
         (60,70,'look'),(70,74,'crouch'),(111,117,'crouch'),(120,128,'tip'),(131,140,'look'),
         (159,163,'crouch'),(182,187,'face'),(194,208,'tip'),(213,226,'look'),(235,244,'crouch'),
         (286,290,'crouch'),(290,295,'face'),(299,317,'look')]
    name=keyed(t,seq)
    if active:
        kind,face=active
        if kind=='hop':name='crouch' if u<.11 or u>.90 else 'hop'
        else:
            if u<.095:name='alight'
            elif u>.88:name='alight'
            elif .57<u<.75:name='glide'
            else:
                beat=(u*(3.3 if face==1 else 3.85)+.13)%1
                name='flightup' if beat<.32 else 'flightmid' if beat<.51 or beat>.87 else 'flightdown'
    return Pose(x,y-h,name,face,y,h)

def paint(img,cels,pal,mapping,pose):
    anchor,rows=cels[pose.name]; sx,sy=round(pose.x),round(pose.y); marks=[]
    for j,row in enumerate(rows):
        for col,ch in enumerate(row):
            if ch=='.':continue
            xi=sx+pose.face*(col-anchor); yi=sy+j-(len(rows)-1)
            if 0<=xi<img.shape[1] and 0<=yi<img.shape[0]:
                img[yi,xi]=pal[mapping[ch]];marks.append((xi,yi))
    return marks

def near(pal,color):
    a=pal.astype(np.float32)-np.asarray(color,np.float32)
    return pal[np.argmin((a*a*np.array([.87,1.10,.69])).sum(1))]
def patchdot(im,pal,x,y,alpha,col):
    x,y=round(x),round(y)
    if not (0<=x<im.shape[1] and 0<=y<im.shape[0]):return
    color=im[y,x];im[y,x]=near(pal,color+(col.astype(float)-color)*clip(alpha))
def shadow(im,pal,p,snow=False):
    # Fixed ground plane shadow, faint and shortening in flight. No boxed matte.
    factor=clip(1-p.height/(7. if snow else 6.6))
    if factor<.055:return
    col=pal[3] if snow else pal[6]; off=.9 if snow else .95
    for dx in (-2,-1,0,1,2,3):
        weight=(1-(abs(dx-.30)/3.5)**1.7)*(.24 if snow else .32)*factor
        patchdot(im,pal,p.x+dx+off,p.ground+.60,weight,col)

def snow_puffs(im,pal,i):
    # Four flecks emerge from the powder on the bird after its ruffle, drift down,
    # then merge with the already-falling weather instead of flashing on a flat wall.
    for off,vx,vy,col in [(36,-.14,-.47,54),(39,.22,-.31,47),(44,-.20,-.28,48),(47,.16,-.46,54)]:
        age=i-off
        if 0<=age<18:
            x=227+(-2 if vx<0 else 2)+vx*age
            y=126+vy*age+.021*age**2
            patchdot(im,pal,x,y,.82*ease((age+2)/4)*ease((18-age)/7),pal[col])

def falling_leaves(im,pal,i):
    # A single passing gust rolls four leaves across the crossing. Each leaf lifts,
    # settles, yaws edge-on, exposes a warmer face, then gets carried out of sight.
    paths=[(87,239,91,158,63,1.4,.02),(104,255,101,166,76,2.2,.38),
           (119,270,109,160,81,1.7,.72),(129,272,97,164,62,2.7,.51)]
    for k,(a,b,x0,y0,dx,rise,ph) in enumerate(paths):
        if not a<=i<b:continue
        t=(i-a)/(b-a);env=ease(t/.13)*ease((1-t)/.16)
        x=x0+dx*(.27*t+.73*ease(t))+.9*sin(TAU*(2*t+ph))-.9*sin(TAU*ph)
        base=y0+.98*sin(TAU*(.9*t+ph))-.98*sin(TAU*ph)
        h=rise*max(0.,sin(TAU*(1.4*t+ph)))**1.5*env+.32
        y=base-h
        limb=cos(TAU*(2.3*t+ph));tilt=sin(TAU*(2.3*t+ph));glint=0.5+0.5*sin(TAU*(2.3*t+ph)+.47)
        col=pal[[56,57,44,56][k]] if glint>.30 else pal[[40,44,37,44][k]]
        # On light zebra paint the rolled-back russet edge defines the leaf;
        # over asphalt the gold face does the work. These are actual adjacent
        # native pixels of one leaf, not free glints flashing in the road.
        rim=pal[[21,27,16,21][k]]; edge=pal[[57,56,56,44][k]]; shade=pal[13]
        patchdot(im,pal,x+.6,base+.85,.34*env,shade)
        patchdot(im,pal,x,y,.96*env,col)
        if abs(limb)>.32:
            sl=1 if tilt>.36 else (-1 if tilt<-.53 else 0)
            patchdot(im,pal,x-1,y+sl,.94*env,col)
            patchdot(im,pal,x+1,y-sl,.87*env,edge)
            patchdot(im,pal,x-.75,y+1,.72*env,rim)
            if abs(limb)>.76 and k in (0,1):patchdot(im,pal,x-2,y+sl,.65*env,rim)
        else:
            patchdot(im,pal,x,y+1,.79*env,rim)
            patchdot(im,pal,x+1,y-1,.71*env,edge)

def decorate(scene,frame,i,pal):
    i=int(i)%N; out=frame.copy()
    if scene=='autumn':
        falling_leaves(out,pal,i)
        for k in (2,1,0):
            p=autumn_pose(k,i);shadow(out,pal,p)
            paint(out,C,pal,AUT_PAL[k],p)
    else:
        p=winter_pose(i);shadow(out,pal,p,True);paint(out,WIN,pal,WIN_PAL,p);snow_puffs(out,pal,i)
    return out
