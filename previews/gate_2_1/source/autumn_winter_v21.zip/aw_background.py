#!/usr/bin/env python3
"""Gate 2.1 autumn & winter. Rebuild atmospheric/room layers from the frozen ray-traced Gate 2 sources, never from a proxy."""
from __future__ import annotations
import argparse, hashlib, json, sys, zipfile, time
from pathlib import Path
from math import sin,cos,pi
import numpy as np

N,FPS=330,30
def herm(x):
    q=np.clip(x,0.,1.); return q*q*(3.-2.*q)

def unzip_basis(basis,scene,cache):
    basis=Path(basis)
    if not basis.is_file(): return basis.resolve()
    expect={'autumn':'9c4e69ee6d6b1944cfc36a3030d24fe1db790ef74a83e9885d3abf6ca8354898',
            'winter':'758fd46755f7ad8259b9ee20e1ba6e6f6472c485b89e67db03110d4b6f1b99ce'}[scene]
    if hashlib.sha256(basis.read_bytes()).hexdigest()!=expect: raise ValueError('Unknown Gate 2 source archive')
    root=cache/('basis_'+scene)
    with zipfile.ZipFile(basis) as z:z.extractall(root)
    return root/'spring_autumn_gate2' if scene=='autumn' else root

def tea_ribbons(lin,c,p):
    """Two evolving strands of one convecting vapour column. Visibility is cut by the retained world depth."""
    x,y,dist,_=c['cam'].project(c['tea_at']); ht=23.4+1.1*sin(2*pi*(p+.1))
    x0,x1,y0,y1=int(x)-7,int(x)+11,int(y)-26,int(y)+2
    yy,xx=np.mgrid[y0:y1,x0:x1]; q=(y-yy-.5)/ht
    # Up-convecting curls; the root is always fixed to the kettle.
    th=2*pi*p; qq=np.clip(q,0,1)
    root=herm(qq/.19)
    xc=x+.28+1.65*qq+root*((.53+1.65*qq)*np.sin(2*th-8.3*qq+.20)+.55*qq*np.sin(3*th-13*qq))
    wisps=.66+.34*(.5+.5*np.cos(3*th-12.2*qq))**1.3
    height=herm((q+.018)/.12)*herm((1.04-q)/.42)
    sigma=.52+.70*qq+.38*qq*(1+np.cos(2*th-9*qq))
    w=(xx+.50-xc)
    jet=np.exp(-.5*(w/sigma)**2)*.57*wisps
    tendril=np.exp(-.5*((w-(1.4+1.65*qq)*np.sin(1.3+2*th-8.3*qq))/(sigma*.76+.10))**2)*(.31*herm((qq-.15)/.32))
    envelope=np.exp(-.5*((w-.15)/(1.30+1.58*qq))**2)*.11
    a=np.minimum(.77,(jet+tendril+envelope)*height*(1-.27*qq))
    occ=(c['plate']['depth'][y0:y1,x0:x1,:]>float(dist)-.12).mean(axis=2)
    a*=occ
    c0=np.array([.52,.386,.276],np.float32); c1=np.array([.490,.390,.343],np.float32)
    tint=c0[None,None]*(1-qq[...,None])+c1[None,None]*qq[...,None]
    roi=lin[y0:y1,x0:x1]; roi+=(tint-roi)*a[...,None]

def swallows(lin,c,p):
    """Four distant birds fly out of cover and disappear behind the actual crown, not a rectangular dissolve."""
    from dynamic_fx import line
    # Different lanes, departure, crossing time, flap-to-glide rhythm, scale.
    tracks=((.055,.537,8.8,.9,0.,4.9),(.183,.795,16.8,2.1,.37,4.0),
            (.335,.896,11.5,-1.3,.74,4.6),(.477,.977,20.8,-2.5,.18,3.9))
    for s,(start,end,y0,dy,beat,span) in enumerate(tracks):
        u=(p-start)/(end-start)
        if not 0<u<1:continue
        x=121+(70-s*.8)*(u+.018*sin(2*pi*u+s*.9))
        y=y0+dy*sin(pi*u)+.84*sin(2*pi*u+1.7*s)
        rhythm=2*pi*(5.7*u+beat+.16*sin(2*pi*(1.45*u+beat)))
        glide=.34+.66*herm((.7+cos(2*pi*(1.6*u+beat)))/1.15)
        stroke=glide*sin(rhythm)
        half=(span/2)*(.86+.14*cos(rhythm)**2)
        cx=x+.18;cy=y+.32
        pts=[(x-half,y-1.69*stroke-.1),(x-.94,y-.67*stroke-.12),(cx,cy),
             (x+1.03,y-.55*stroke-.12),(x+half,y-1.42*stroke-.26)]
        # A hint of fuselage when the wings are gliding horizontally.
        col=np.array([.050,.032,.072],np.float32)
        line(lin,pts,1.01,.95,col,c['bird_access'])
        line(lin,[(cx-.55,cy+.26),(cx+.56,cy+.14)],.91,.86,col,c['bird_access'])

def setup_autumn(basis):
    sys.path.insert(0,str((basis/'src').resolve()))
    import render_cycle as rc
    rc.set_font_fallback();mod,shot,c=rc.setup('autumn');pa=rc.Palette('autumn')
    def actors(lin,cc,p): tea_ribbons(lin,cc,p); swallows(lin,cc,p)
    mod.steam_and_birds=actors
    tea=tuple(float(v) for v in c['cam'].project(c['tea_at'])[:3])
    print('tea anchor x y depth',tea,flush=True)
    return (lambda i:pa.map(mod.frame(c,(i%N)/N),shot.GRADE)),pa.rgb,{'tea_anchor':tea}

def setup_winter(basis):
    sys.path.insert(0,str(basis.resolve()))
    import winter_loop_scene as base
    from framework import FixedColors,use_cjk
    from engine import fx
    from engine.world import World,roty
    from engine import props as pr
    from timeline import reader_controls, wave,envelope
    use_cjk()
    # Identify existing glazing of a vertical run on the rear residential block. Retain all
    # geometry, RNG, mullions, snow recesses, reflections and tree occlusion. A low additive
    # light group is the only thing put behind these three dark windows.
    pane=pr.pane
    front=np.array([14.,0.,-49.])
    M=roty(.42)
    landings=[front+M@np.array([-20.05+.25+2.5*3.3,.7+2.9*f+1.675,5.05]) for f in (0,1,2,3)]
    touched=[]
    def panes(w,ow,oh,*a,**kw):
        center=w.xf((ow*.5,oh*.5,0)).reshape(3)
        for i,target in enumerate(landings):
            if np.linalg.norm(center-target)<.08:
                touched.append(i);kw.update(lit=(.30,.31,.29,.26)[i],col='#ffd391',grp=base.sc.G_ST+i)
                break
        return pane(w,ow,oh,*a,**kw)
    class Room(base.Winter):
        def controls(self,t):
            g=super().controls(t)
            for k in range(5):
                g[base.sc.G_ST+k]=.010+1.04*envelope(t,.76+1.40*k,2.87,.22,.36)
            return g
        def arm(self,t):
            # Single page turn kept at the same three cues as the existing paper sound.
            lift,turn,visible=reader_controls(t)
            breath=.012*wave(t,3,.10)
            start=(.73,.563+breath,-.123)
            hinge=np.array([1.293,.345,.028])
            angle=pi*(.05+.90*turn)
            length=.409
            # Fingers actually follow a taller arc above the top corner and transfer it left.
            off=length*cos(angle)
            elbow=(.927+.089*lift,.358+.205*lift+breath,-.035+.048*lift)
            hand=(1.18+lift*((hinge[0]+off*.94-.06)-1.18),.34+lift*(.036+.401*sin(angle)),.01+.098*lift)
            m=World(seed=23)
            with m.at(base.sc.GUARD_POS,yaw=base.sc.GUARD_YAW):
                with m.at(self.xform):
                    dark=dict(mat='plain',col='#493638',prm=(.20,0,0,0))
                    m.tube(start,elbow,.078,.067,sides=8,caps=True,**dark)
                    m.tube(elbow,hand,.065,.035,sides=8,caps=True,**dark)
                    m.sphere(hand,.049,n=8,squash=.86,mat='plain',col='#a37056',prm=(.32,0,0,0))
                    if visible>.004:
                        # Fan a real curved sheet around the binding; its upper curl captures warm lamp light.
                        for n in range(3):
                            u=n/3;v=(n+1)/3
                            def P(a,edge):
                                offset=(.026 if edge>0 else 0.)*a*a
                                return hinge+np.array([off*a+edge*(.075+.022*a),visible*(length*sin(angle)*(.96*a+.21*sin(pi*a))+offset),edge*(.121+.07*a)+.047*a])
                            gain=.51+.76*max(0.,sin(angle))
                            m.quads(P(u,-1),P(v,-1),P(v,1),P(u,1),mat='plain',col=('#d9ae7b','#f2d293','#fff0c0')[n],prm=(gain,0,0,0))
                        if visible>.1:
                            rr=(.029+.022*sin(angle))*visible
                            m.tube(P(1,-1),P(1,1),rr,rr*.61,sides=8,caps=True,mat='plain',col='#fff3c6',prm=(1.47,0,0,0))
                            m.tube(P(.22,1),P(1,1),rr*.40,rr*.49,sides=7,caps=True,mat='plain',col='#f9dfac',prm=(.94,0,0,0))
            return m
    pr.pane=panes
    try: st=Room()
    finally: pr.pane=pane
    if sorted(touched)!=[0,1,2,3]:raise RuntimeError(f'landing mismatch {touched}')
    wind=tuple(.177*st.cam.r+np.array([0.,0.,.009]))
    st.smoke=fx.Smoke(st.cam,st.b,st.roof,n=16,T=11.,loops=2,rise=.427,
                      wind=wind,r0=.082,grow=.099,seed=314,alpha=.255)
    physical=st.smoke.draw
    def warm(lin,ph,col):
        physical(lin,ph,np.array([.189,.179,.166],np.float32))
        # An anchored capillary wisp below the spreading parcels: no disconnected
        # puff at the mouth. It inherits exactly the flue's projection and depth.
        x,y,d,_=st.cam.project(st.roof)
        xa,xb,ya,yb=int(x)-3,int(x)+8,int(y)-14,int(y)+1
        yy,xx=np.mgrid[ya:yb,xa:xb];q=(y-yy-.4)/12.
        u=np.clip(q,0,1);zc=x+.18+3.25*u+(.33+1.05*u)*np.sin(2*pi*2*ph-u*6.3)*herm(u/.24)
        w=.38+u*.84
        alpha=.27*np.exp(-.5*((xx+.5-zc)/w)**2)*herm((q+.035)/.085)*herm((1.04-q)/.62)
        a=alpha*(st.b['depth'][ya:yb,xa:xb,:]>float(d)-.12).mean(axis=2)
        patch=lin[ya:yb,xa:xb]; patch+=(np.array([.226,.204,.174],np.float32)-patch)*a[...,None]
    st.smoke.draw=warm
    colors=FixedColors('winter',st.GRADE,st.VIGNETTE)
    pts=[tuple(round(float(x),2) for x in st.cam.project(w)[:2]) for w in landings]
    info={'reader_events_s':[4.30,5.21,5.64,6.28,6.90],'flue_xy_original':st.stats['flue_anchor'],'landing_centers':pts}
    print('windows',pts,flush=True)
    return lambda i:colors.quantize(st.frame((i%N)/FPS)),colors.rgb,info

def main():
    a=argparse.ArgumentParser();a.add_argument('scene',choices=['winter','autumn']);a.add_argument('--basis',required=True)
    a.add_argument('--cache',type=Path,required=True);args=a.parse_args(); args.cache.mkdir(exist_ok=True,parents=True)
    basis=unzip_basis(args.basis,args.scene,args.cache);t0=time.monotonic()
    at,rgb,info=(setup_autumn if args.scene=='autumn' else setup_winter)(basis)
    dst=args.cache/(args.scene+'_background.npy'); tmp=dst.with_name('.'+dst.name)
    out=np.lib.format.open_memmap(tmp,mode='w+',dtype=np.uint8,shape=(N,180,320,3))
    for i in range(N):
        out[i]=at(i)
        if i%55==0: print(args.scene,i,round(time.monotonic()-t0,2),flush=True)
    if not np.array_equal(out[0],at(N)):raise AssertionError('strict phase closure failed')
    out.flush();del out;tmp.replace(dst)
    (args.cache/(args.scene+'_scene.json')).write_text(json.dumps(dict(info,palette=rgb.tolist()),indent=2)+'\n')
    print('BACKGROUND_READY',dst,flush=True)
if __name__=='__main__':main()
