"""Visible-character and fixed-footing invariants. No model extrapolation between last/first frame."""
import unittest
from math import hypot
import numpy as np
from aw_pixel import C,WIN,N,decorate,autumn_pose,winter_pose,POSIT,WIN_PAL,AUT_PAL
class Check(unittest.TestCase):
    def test_anchor_closure_and_travel(self):
        for i,(ox,oy) in enumerate(POSIT):
            seq=[autumn_pose(i,n) for n in range(N+1)]; self.assertEqual(seq[0],seq[-1])
            self.assertEqual((seq[0].x,seq[0].y),(ox,oy))
            self.assertLess(max(hypot(b.x-a.x,b.y-a.y) for a,b in zip(seq,seq[1:])),1.6)
            self.assertTrue({'peck','look','hop'}.issubset({p.name for p in seq}))
            self.assertGreaterEqual(len({p.name for p in seq}),7)
    def test_sparrows_spread(self):
        for n in range(N):
            p=[autumn_pose(j,n) for j in range(3)]
            self.assertGreater(min(hypot(p[j].x-p[k].x,p[j].y-p[k].y) for j,k in [(0,1),(0,2),(1,2)]),8.0)
    def test_snowman_to_bench_return(self):
        seq=[winter_pose(i) for i in range(N+1)]
        self.assertEqual(seq[0],seq[-1]);self.assertEqual((seq[0].x,seq[0].ground),(227,131))
        self.assertEqual((seq[139].x,seq[139].ground),(264,146))
        self.assertEqual((seq[237].x,seq[237].ground),(273,145))
        self.assertEqual((seq[288].x,seq[288].ground),(227,131))
        self.assertGreater(max(s.height for s in seq),17.)
        self.assertLess(max(hypot(b.x-a.x,b.y-a.y) for a,b in zip(seq,seq[1:])),2.7)
        self.assertTrue({'tip','fluff','crouch','flightup','flightdown','glide','hop'}.issubset({s.name for s in seq}))
    def test_palette_locality_and_seam(self):
        pal=np.array([[(i*63)%251,(i*79)%251,(i*97)%251] for i in range(60)],np.uint8)
        for scene in ['autumn','winter']:
            ref=np.zeros((180,320,3),np.uint8);ref[:]=pal[33]
            self.assertTrue(np.array_equal(decorate(scene,ref,0,pal),decorate(scene,ref,330,pal)))
            allowed={tuple(rgb) for rgb in pal}
            for i in [0,55,113,160,193,219,258,309]:
                f=decorate(scene,ref,i,pal);y,x=np.nonzero(np.any(f!=ref,axis=2))
                self.assertTrue(all(tuple(px) in allowed for px in f[y,x]))
                self.assertTrue(((x<202)&(y>137)).all() if scene=='autumn' else ((x>=215)&(y>=104)&(x<=282)).all())
    def test_ink_tokens(self):
        for cs,pals in [(C,AUT_PAL),(WIN,[WIN_PAL])]:
            for a,rows in cs.values():
                for p in pals:
                    self.assertTrue(set(''.join(rows)) <= set(p)|{'.'})
if __name__=='__main__':unittest.main()
