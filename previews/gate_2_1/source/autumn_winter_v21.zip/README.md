# 秋 · 冬｜Gate 2.1 动画源

本目录只负责两条 11 秒循环，不生成 v2.1 总片，不更改配乐。相机、320×180 网格和每季 60 色冻结色板沿用 Gate 2。画面分两步：先按原版世界重渲，只替换需要升级的动态与灯光；再逐帧在原生网格上绘制前景鸟的手工动作格与贴地物体。没有插值放大后再描边，也没有对成片做图像变形。

## 一键复现

需要 Python 3.12、FFmpeg/libx264、Noto CJK Serif/Sans 字体（Debian 包 `fonts-noto-cjk`）。从仓库根目录执行，第一次建立虚拟环境；工作文件全部留在指定的 `--work` 路径：

```bash
repo="$PWD"
work="$repo/build/gate_2_1_aw"
mkdir -p "$work/src"
unzip -q -o previews/gate_2_1/source/autumn_winter_v21.zip -d "$work/src"
python3.12 -m venv "$work/venv"
"$work/venv/bin/python" -m pip install -r "$work/src/requirements.txt"
export OPENBLAS_NUM_THREADS=1 NUMBA_NUM_THREADS=2
"$work/venv/bin/python" "$work/src/run_aw.py" both --repo "$repo" --work "$work"
```

只重渲一季：把 `both` 换为 `autumn` 或 `winter`。入口从 `previews/gate_2/source/` 读取 **frozen source ZIP**，不使用有损预览、不需要另一台电脑或旧工作目录：

- `spring_autumn_source.zip`（SHA-256 `9c4e69ee6d6b1944cfc36a3030d24fe1db790ef74a83e9885d3abf6ca8354898`）
- `gate2_summer_winter_source_qa.zip`（SHA-256 `758fd46755f7ad8259b9ee20e1ba6e6f6472c485b89e67db03110d4b6f1b99ce`）

输出 `out/{autumn,winter}_native.npy`（uint8，330×180×320×3），以及 `out/{autumn,winter}_loop.mp4`（QP0，6× nearest，1920×1080，30fps，两轮 0–329，共660帧，22秒，无声）。`cache/` 保存只含大气和室内层的原生帧，`qa/` 保存动作时序图、真原生整幅截图及接缝报告。这些 `out/*.mp4` 是仓库无损分卷拼接后的正本；仓库 `previews/gate_2_1/*_loop.mp4` 为浏览器与移动端兼容审片版。

## 动态落点与相位

- **秋 · 地上三只觅食鸟**：三幅初始支撑点为 (54,168)、(84,164)、(70,155)。三只错开蹲低、弹跳、收脚、触地、前探啄食、抬头张望和转向。第一只两步寻食再踱回；第二只在第 218–248 帧扇翅跃回；第三只在较远亮人行道上小跳觅食。姿态逐格按头、喙、颊、翼、腹、双脚重新绘制，三组暖/冷色和各自的贴地影子区分距离。
- **秋 · 天上四只归鸟**：各自只飞过一次，起止相位分别约为 0.055–0.537、0.183–0.795、0.335–0.896、0.477–0.977。翼展约 4–5 原生像素，飞行中交替慢扇和展翼滑翔，原三维树冠遮挡实际决定进出。
- **秋 · 茶汽和地面风**：汽源投影 (75.49,135.38)，两束热汽随向上对流合拢、卷开并消散，正常可见高度约 20–23 px。第 87–272 帧内一阵风分批推动四片叶子滑过斑马线；叶面翻转、边缘变窄并投下短影，不移动静止斑马线图案。
- **冬 · 雪地小鸟**：暖栗色胖鸟先在雪人帽 (227,131) 上歪头抖雪；f74–111 短飞到石凳 (264,146)，两次蹦到 (273,145)，f244–286 返落雪人帽。飞行有抬翼、下击、滑翔、收翅着陆的原生重画，抖落雪粉只跟随起始动作。
- **冬 · 翻页**：既有本地 4.30–6.90 秒动作和三处轻纸声音的时相保持不变；其余时间约 76% 静读。书页绕真实书脊分三片弯曲、在台灯前短暂反光再落向左边；手指追随外侧纸角。f164–170 可清楚见到翻起的纸面。
- **冬 · 屋烟与楼灯**：烟囱仍在 (279.80,86.25)，近出口细烟连接到向右上散开的连续烟团。较远建筑现有四个窗孔按楼层从下往上亮灭，窗框、原有树枝遮挡及周围反射保留；原生窗口中心 x≈237.5，y≈80.0/62.6/45.3/28.0。逐层启动相隔 1.40 秒，单层约 2.87 秒缓升缓降。

## 核对

```bash
(cd "$work/src" && "$work/venv/bin/python" -m unittest -v test_aw)
for season in autumn winter; do
  "$work/venv/bin/python" "$work/src/aw_validate.py" "$season" --repo "$repo" --output "$work/out"
done
```

`aw_validate.py` 直接解码无损 MP4 的全部 YUV420p，检查 660 帧的亮度 6×6 格/色度 3×3 格、两周期逐帧相同，再用 Gate 2 冻结色板的可逆三元组逐像素核对全部 330 原生 RGB 帧。参考环境：Linux x86-64，Python 3.12.14，FFmpeg 7.1.5，具体 Python 版本见 `requirements.txt`。

| 文件 | 字节 | SHA-256 |
| --- | ---: | --- |
| autumn_native.npy | 57,024,128 | `3afc97e1ce68aaf114e22578ace12c44f18ece96eb2fcc200ec0891b56b2d913` |
| autumn_loop.mp4（QP0） | 16,142,419 | `ad899448d840cf0c30e87e7cdeacf162fe66d868361c0f44624358d55c09ca15` |
| winter_native.npy | 57,024,128 | `142f6b7fbfef38f4e30ad4467fba18eb76c43c9c3a08122b58f1e6c9f934bfc7` |
| winter_loop.mp4（QP0） | 27,450,451 | `d6cbfce58cdecf3fe6d571e41eee13643b03113586f645dfad47c0a45c734d7b` |

