#!/usr/bin/env python3
"""Render one 330-native-frame cycle with hand-pixel animals; export two identical nearest-neighbor cycles."""
import argparse,hashlib,json,subprocess
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from aw_pixel import decorate,autumn_pose,winter_pose,N,C,WIN,falling_leaves

def enc(a,dest,quality='qp0'):
    filt='scale=1920:1080:flags=neighbor:out_color_matrix=bt709:out_range=tv,format=yuv420p'
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-nostdin','-y','-filter_threads','1','-f','rawvideo','-pixel_format','rgb24','-video_size','320x180','-framerate','30','-i','-','-an','-vf',filt,'-c:v','libx264','-preset','veryfast','-threads','2','-g','330' if quality=='qp0' else '60','-keyint_min','330' if quality=='qp0' else '60','-sc_threshold','0','-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-color_range','tv']
    cmd+=['-qp','0'] if quality=='qp0' else ['-profile:v','high','-crf','17']
    temp=dest.with_suffix('.part.mp4');cmd+=['-movflags','+faststart',str(temp)]
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    for _ in (0,1):p.stdin.write(memoryview(np.ascontiguousarray(a)).cast('B'))
    p.stdin.close()
    if p.wait():raise RuntimeError('FFmpeg failed')
    temp.replace(dest)

def sheet(a,frames,box,w,scale,dst):
    x0,y0,x1,y1=box; dims=((x1-x0)*scale,(y1-y0)*scale)
    sh=Image.new('RGB',((dims[0]+4)*w,(dims[1]+22)*((len(frames)+w-1)//w)),(34,33,38));dr=ImageDraw.Draw(sh)
    for j,i in enumerate(frames):
        pic=Image.fromarray(a[i]).crop(box).resize(dims,Image.Resampling.NEAREST)
        x=(j%w)*(dims[0]+4);y=(j//w)*(dims[1]+22)
        sh.paste(pic,(x,y));dr.text((x+1,y+dims[1]+1),f'{i:03d} | {i/30:.2f} s',fill=(226,225,221))
    sh.save(dst)
def qc(s,a,b,d):
    if s=='autumn':
        actions=[10,29,46,56,83,99,122,157,178,204,230,251]
        sheet(a,actions,(46,140,105,174),4,4,d/'autumn_ground_contact.png')
        sheet(a,[15,49,73,109,139,173,194,225],(124,3,181,28),4,4,d/'autumn_sky_contact.png')
        sheet(a,[29,67,100,139,171,209,254,286],(66,107,88,138),4,6,d/'autumn_tea_contact.png')
        sheet(a,[93,128,151,176,201,238],(83,153,180,171),3,3,d/'autumn_leaves_contact.png')
    else:
        actions=[15,37,78,90,103,128,154,178,218,260,274,304]
        sheet(a,actions,(217,107,282,151),4,3,d/'winter_bird_contact.png')
        sheet(a,[0,128,145,156,168,176,189,210],(246,100,272,118),4,6,d/'winter_page_contact.png')
        sheet(a,[14,59,109,149,189,237,264,298],(275,62,300,90),4,4,d/'winter_flue_contact.png')
        sheet(a,[12,49,84,129,167,199],(229,18,246,88),6,2,d/'winter_landing_contact.png')
    picks=[0,56,112,168,224,280]
    for i in picks:
        pic=Image.fromarray(a[i]);pic.save(d/f'{s}_{i:03d}_native.png')
    sheet(a,picks,(0,0,320,180),2,1,d/(s+'_whole_sheet.png'))
    npz={'native_sha256':hashlib.sha256(memoryview(a).cast('B')).hexdigest(),
        'changed_pixels_by_new_pixel_art_peak':max(int(np.any(a[i]!=b[i],axis=2).sum()) for i in range(N)),
        'seam_mae':round(float(np.abs(a[0].astype(np.int16)-a[-1]).mean()),6),
        'step_maes_near_seam':[round(float(np.abs(a[i%N].astype(np.int16)-a[(i-1)%N]).mean()),6) for i in range(-5,7)]}
    (d/(s+'_native_check.json')).write_text(json.dumps(npz,indent=2)+'\n')
def finish(s,cache,output,proof,encode):
    output.mkdir(exist_ok=True,parents=True);proof.mkdir(exist_ok=True,parents=True)
    b=np.load(cache/(s+'_background.npy'),mmap_mode='r');info=json.loads((cache/(s+'_scene.json')).read_text());pal=np.array(info['palette'],np.uint8)
    a=np.stack([decorate(s,b[i],i,pal) for i in range(N)])
    assert np.array_equal(a[0],decorate(s,b[0],330,pal))
    np.save(output/(s+'_native.npy'),a,allow_pickle=False)
    qc(s,a,b,proof)
    if encode:enc(a,output/(s+'_loop.mp4'))
    print(s,'NATIVE',output/(s+'_native.npy'),'QP0' if encode else '',flush=True)
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('scene',choices=['autumn','winter']);a.add_argument('--cache',type=Path,required=True);a.add_argument('--output',type=Path,required=True);a.add_argument('--proof',type=Path,required=True);a.add_argument('--no-encode',action='store_true')
    args=a.parse_args();finish(args.scene,args.cache,args.output,args.proof,not args.no_encode)
