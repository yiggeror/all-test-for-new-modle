# Gate 2.1 · 春夏源文件

从本 ZIP 解出后仅使用其中场景源码、依赖及冻结 Gate 1.5 参考锁；不读取 v2.0 成片或本机旧场景。原 Gate 2 归档追溯：spring_autumn_source.zip SHA-256 9c4e69ee6d6b1944cfc36a3030d24fe1db790ef74a83e9885d3abf6ca8354898；gate2_summer_winter_source_qa.zip SHA-256 758fd46755f7ad8259b9ee20e1ba6e6f6472c485b89e67db03110d4b6f1b99ce。

Linux Python 3.12；安装春/夏目录的 requirements.txt，另需 FFmpeg/libx264、Noto Sans/Serif CJK。示例在解压目录：

```sh
export NUMBA_NUM_THREADS=3 OPENBLAS_NUM_THREADS=1
(cd spring/src && python -m unittest test_motion test_spring_g21 && python render_cycle.py spring)
(cd summer && python -m unittest test_gate21_timing && python render_loops.py summer)
```

春原生 `spring/qa/spring_native.npy`、无损 1080p `spring/out/spring_loop.mp4`。春猫由同一屋脊网格中独立头/吻/肩/尾重新投射，原地前爪支撑不漂移；门楼睡姿在 1.58–8.62 秒抬头跟视并缩回，3.75–5.11 与 5.61–7.04 秒两次摆尾。自行车真车把上麻雀随附着点做两短跃（4.90–5.85 秒）、两啄（6.48–7.54 秒）；四蛾围灯同环落在照明和深度实测中。

夏原生 `summer/qa/summer_native.npy`、无损 1080p `summer/outputs/summer_loop.mp4`。以实际原版 Rainroji 的灯管断续窗为参照，合成四次亮度掉到 21%–24% 的电流阶跃：帧 [192,197)、[204,209)、[216,220)、[229,234)，牌/墙/湿路共享同一增益，跨度 1.40 秒。暖棚花猫同一区域坐姿抬爪梳洗后回位，夜雨、檐滴、暖地小环和三色理发柱加粗细节不换布景。

两者从 320×180 原生扩为精确 6× 最近邻，生成两次同一 330 帧周期；非 1080p 代理转码。
