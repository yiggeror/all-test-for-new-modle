"""Continuous, exact 11 s event schedules in seconds (not wall clock)."""
from math import cos, pi

FPS = 30
COUNT = 330
PERIOD = COUNT / FPS


def frame_time(i):
    return (int(i) % COUNT) / FPS


def ease(x):
    x = min(1.,max(0.,float(x)))
    return x*x*x*(x*(6*x-15)+10)


def window(t,start,duration):
    return ((t-start) % PERIOD) / duration


def envelope(t,start,duration,entry=.24,exit_=.29):
    p=window(t,start,duration)
    if p >= 1: return 0.
    return ease(p/entry)*ease((1.-p)/exit_)


def wave(t,k=1.,phase=0.):
    return cos(2*pi*(k*(t % PERIOD)/PERIOD+phase))


def reader_controls(t):
    p=window(t,4.30,2.60)
    if p >= 1:
        return 0.,0.,0.
    lift=ease(p/.29)*ease((1.-p)/.30)
    turn=ease((p-.30)/.38)
    flick=ease((p-.27)/.085)*ease((.80-p)/.11)
    return lift,turn,flick


neon_drop_frames=((192,197,.22),(204,209,.24),(216,220,.21),(229,234,.235))


def neon(t):
    # Inherit the prototype's abrupt tube-current cut, not its random fast chatter.
    # One 1.4 s event per seam-closed cycle, four brief held dips and stable red between.
    i=round((t%PERIOD)*FPS,9)
    for lo,hi,level in neon_drop_frames:
        if lo<=i<hi:return level
    return .991+.008*wave(t,4,.12)


def cat_groom(t):
    paw=envelope(t,2.12,3.31,.27,.28)
    bow=envelope(t,2.62,2.34,.22,.28)
    stroke=(.8*envelope(t,3.16,.37,.49,.49)+.7*envelope(t,3.84,.39,.48,.48))
    swish=(.89*envelope(t,7.95,1.42,.39,.49)-.76*envelope(t,9.03,1.58,.43,.45))
    ear=.64*envelope(t,5.64,.35,.39,.49)
    return paw,bow,stroke,swish,ear


def cat_controls(t):
    lifts=.98*envelope(t,6.65,.52,.37,.45)+.55*envelope(t,7.13,.38,.40,.48)
    tail=envelope(t,8.70,1.29,.42,.43)
    return lifts,tail
