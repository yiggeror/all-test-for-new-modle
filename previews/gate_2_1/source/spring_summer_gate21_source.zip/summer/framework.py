"""Frozen Gate 1.5 plate + independently projected native motion layers."""
import json
from pathlib import Path

import numpy as np
from PIL import ImageFont
from scipy.spatial import cKDTree

from engine import fx, pix, render as ray
from engine.rt import Accel
from engine.world import World, srgb

ROOT = Path(__file__).resolve().parent


def use_cjk():
    original = ImageFont.truetype
    lookup = {
        "ukai.ttc":"NotoSerifCJK-Regular.ttc",
        "uming.ttc":"NotoSerifCJK-Regular.ttc",
        "wqy-zenhei.ttc":"NotoSansCJK-Regular.ttc",
    }
    def load(font, size=10, index=0, *args, **kwargs):
        try:
            return original(font,size,index,*args,**kwargs)
        except OSError:
            name = Path(font).name if isinstance(font, (str, Path)) else ""
            if name not in lookup: raise
            return original("/usr/share/fonts/opentype/noto/"+lookup[name], size, 2, *args, **kwargs)
    ImageFont.truetype = load


def plate(scene_module):
    fx.SC = 320/480
    cam = scene_module.camera(320,180)
    world = scene_module.build()
    shot,_ = ray.render(world,cam,scene_module.sky,S=3,**scene_module.RENDER)
    shot["lights"] = world.lights
    fx.denoise(shot,**scene_module.DENOISE)
    return shot,cam


class FixedColors:
    """Same ordered dither and palette as approved Gate 1.5, faster nearest-two lookup."""
    def __init__(self, scene, grade, vignette):
        meta=json.loads((ROOT/"references"/f"{scene}.json").read_text())
        self.rgb=np.array(meta["palette_rgb"],np.uint8)
        self.lab=pix.oklab(self.rgb/255.) * pix.LABW
        self.lookup=cKDTree(self.lab)
        self.thr=pix.threshold_map(180,320,meta.get("dither","mix"),seed=177)
        self.strength=meta["dither_strength"]
        self.vignette=fx.vignette(180,320,vignette)
        self.grade=grade

    def quantize(self, lin):
        c = pix.tonemap(lin*self.vignette, **self.grade)
        a = pix.oklab(c)*pix.LABW
        _, j = self.lookup.query(a,k=2,workers=1)
        k = self.lab[j[...,0]]
        d = self.lab[j[...,1]] - k
        share = np.sum((a-k)*d,axis=2)/np.maximum(np.sum(d*d,axis=2),1.e-9)
        other = np.clip(share,0.,1.)*self.strength > self.thr
        return self.rgb[np.where(other,j[...,1],j[...,0])]


class NativeActor:
    """Only a small native viewport is ray-traced anew for each articulated pose."""
    def __init__(self, cam, static, clip, samples=4):
        self.cam,self.static = cam,static
        self.x0,self.y0,self.x1,self.y1 = clip
        self.w,self.h = self.x1-self.x0, self.y1-self.y0
        self.samples = samples
        yy,xx=np.mgrid[:self.h*samples,:self.w*samples]
        self.d=cam.dirs(self.x0+(xx+.5)/samples,self.y0+(yy+.5)/samples).reshape(-1,3).astype(np.float32)
        self.o=np.broadcast_to(np.asarray(cam.pos,np.float32),self.d.shape).copy()
        self.bg=static["depth"][self.y0:self.y1,self.x0:self.x1]
        self.iy=(yy//samples).ravel()
        self.ix=(xx//samples).ravel()

    def composite(self, lin, body:World, light, gain=1.):
        g=body.finalize()
        rt=Accel(g["v0"],g["v1"],g["v2"],g["tm"])
        length,tri=rt.closest(self.o,self.d)
        ok=tri>=0
        ids=np.nonzero(ok)[0]
        if not len(ids):
            return 0
        face=g["tf"][tri[ids]]
        F=g["F"]
        pt=self.o[ids]+self.d[ids]*length[ids,None]
        normals=F["n"][face]
        normals=np.where((normals*self.d[ids]).sum(axis=1,keepdims=True)>0, -normals, normals)
        vd=np.asarray(light)[None]-pt
        vd=vd/np.maximum(np.linalg.norm(vd,axis=1,keepdims=True),1.e-5)
        diffuse=np.maximum(0,np.sum(normals*vd,axis=1))
        rim=np.maximum(0,normals[:,1])**1.3
        rgb=F["col"][face]*(.50+.26*diffuse+.17*rim)[:,None]*gain
        # Geometry carries deliberate material accents without a screen-space mask.
        rgb=rgb + F["col"][face]*F["prm"][face,0:1]*gain*.24
        y,x=self.iy[ids],self.ix[ids]
        visible=(self.bg[y,x] > length[ids,None]-.003).mean(axis=1).astype(np.float32)
        cov=np.zeros((self.h,self.w),np.float32)
        radiance=np.zeros((self.h,self.w,3),np.float32)
        np.add.at(cov,(y,x),visible)
        np.add.at(radiance,(y,x),visible[:,None]*rgb)
        cov /= self.samples**2
        radiance /= self.samples**2
        region=lin[self.y0:self.y1,self.x0:self.x1]
        region[:]=region*(1.-cov[...,None])+radiance
        return int(np.count_nonzero(cov>.12))


def over_line(lin, camera, plate_, p0, p1, color, alpha, spread=.39):
    """Project a short 3D water streak with analytic coverage and existing depth."""
    points=np.asarray((p0,p1))
    x,y,d,z=camera.project(points)
    if min(z)<.1 or alpha<=0: return
    i0,i1=max(0,int(x.min()-1.6)),min(camera.W,int(x.max()+2.2))
    j0,j1=max(0,int(y.min()-1.6)),min(camera.H,int(y.max()+2.2))
    if i0>=i1 or j0>=j1: return
    Y,X=np.mgrid[j0:j1,i0:i1]
    u,v=x[1]-x[0],y[1]-y[0]
    q=np.clip(((X+.5-x[0])*u+(Y+.5-y[0])*v)/max(u*u+v*v,1e-6),0,1)
    dd=(X+.5-x[0]-u*q)**2+(Y+.5-y[0]-v*q)**2
    visible=(plate_["depth"][j0:j1,i0:i1] > (d[0]+(d[1]-d[0])*q)[...,None]-.03).mean(axis=2)
    a=alpha*(.63+.37*q)*np.exp(-dd/spread)*visible
    lin[j0:j1,i0:i1] += np.asarray(color)[None,None,:]*a[...,None]
