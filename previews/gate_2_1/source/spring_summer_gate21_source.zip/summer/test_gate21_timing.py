import unittest
from timeline import COUNT, FPS, PERIOD, neon, neon_drop_frames, cat_groom
class Gate21Tests(unittest.TestCase):
    def test_one_cluster_of_four_snappy_deep_dips_closes(self):
        e=[i for i in range(COUNT) if neon(i/FPS)<.29]
        groups=[]
        for i in e:
            if not groups or i!=groups[-1][-1]+1:groups.append([])
            groups[-1].append(i)
        self.assertEqual(len(groups),4)
        self.assertGreaterEqual((e[-1]+1-e[0])/FPS,1.2)
        self.assertLessEqual((e[-1]+1-e[0])/FPS,1.5)
        self.assertTrue(all(.20<=neon(i/FPS)<=.25 for i in e))
        self.assertTrue(all(sum(a<=g[0]<a+FPS for g in groups)<=3 for a in range(COUNT)))
        self.assertEqual(neon(0.),neon(PERIOD))
    def test_cat_groom_moves_head_and_paw_but_settles(self):
        self.assertEqual(cat_groom(0),cat_groom(PERIOD))
        self.assertGreater(cat_groom(3.35)[0],.9)
        self.assertGreater(cat_groom(3.35)[1],.9)
        self.assertEqual(cat_groom(6.0)[:2],(0.,0.))
if __name__=='__main__':unittest.main()
