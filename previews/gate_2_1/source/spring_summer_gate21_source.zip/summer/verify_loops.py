#!/usr/bin/env python3
"""Inspect emitted frames, both-cycle decoded bytes, integer pixel blocks, and the actual seam."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from timeline import COUNT,FPS

ROOT=Path(__file__).resolve().parent
SEAM=(321,322,323,324,325,326,327,328,329,0,1,2,3,4,5,6,7,8)
SAMPLES={
    "summer":(10,133,144,208,218,279),
    "winter":(25,131,167,179,198,221),
}


def decode_probe(video):
    data=subprocess.check_output(["ffprobe","-v","error","-show_entries",
        "stream=codec_name,profile,pix_fmt,width,height,r_frame_rate,nb_frames,color_space:format=duration",
        "-of","json",str(video)])
    meta=json.loads(data)
    s=meta["streams"][0]
    assert len(meta["streams"])==1 and s["codec_name"]=="h264" and s["pix_fmt"]=="yuv420p"
    assert (s["width"],s["height"],s["r_frame_rate"],int(s["nb_frames"]))==(1920,1080,"30/1",2*COUNT)
    assert float(meta["format"]["duration"])==22.
    # ffmpeg's full decode produces digests per display frame; this checks both complete cycles.
    ff=subprocess.check_output(["ffmpeg","-v","error","-i",str(video),"-pix_fmt","yuv420p","-f","framehash","-"])
    hashes=[line.split(b",")[-1].strip() for line in ff.splitlines() if line and not line.startswith(b"#")]
    assert len(hashes)==2*COUNT
    identical=sum(a==b for a,b in zip(hashes[:COUNT],hashes[COUNT:]))
    assert identical==COUNT, f"{identical}/{COUNT} decoded frames repeat"
    assert hashes[COUNT-1]!=hashes[COUNT]
    return {"stream":s,"duration":22.,"matching_decoded_frames_across_both_cycles":identical}


def grid_check(video):
    pairs=sorted(set([0,17,128,168,220,260,321,323,326,328,329,330,331,332,334,336,338,450,655,659]))
    filt=r"select="+ "+".join(f"eq(n\\,{n})" for n in pairs)
    raw=subprocess.check_output(["ffmpeg","-v","error","-i",str(video),"-vf",filt,
          "-fps_mode","passthrough","-pix_fmt","yuv420p","-f","rawvideo","-"])
    n=1920*1080
    k=n+n//2
    assert len(raw)==k*len(pairs)
    bad=0; measured=0
    for chunk in np.frombuffer(raw,np.uint8).reshape(len(pairs),k):
        for a,b,h,w,s in ([0,n,1080,1920,6],[n,n+n//4,540,960,3],[n+n//4,k,540,960,3]):
            f=chunk[a:b].reshape(h//s,s,w//s,s)
            differs=(f!=f[:,0:1,:,0:1]).any(axis=(1,3))
            bad+=int(differs.sum())
            measured+=bool(differs.shape)*(h//s)*(w//s)
    assert bad==0, f"Decoded YUV has {bad} nonuniform integer blocks"
    return {"decoded_frame_indices":pairs,"Y_or_U_or_V_blocks_checked":measured,"nonuniform_blocks":bad}


def deltas(arr,roi=None):
    if roi:
        x,y,x1,y1=roi
        arr=arr[:,y:y1,x:x1]
    d=np.abs(arr[1:].astype(np.int16)-arr[:-1].astype(np.int16))
    return np.mean(d,axis=(1,2,3)),np.mean(np.any(d>0,axis=3),axis=(1,2))


def seam(arr,roi=None):
    sub=arr[list(SEAM)]
    a,p=deltas(sub,roi)
    k=SEAM.index(329)
    surrounding=np.delete(a,k)
    return {"chain":list(SEAM),"mean_absolute_RGB_by_step":[round(float(x),5) for x in a],
            "pct_pixels_changed_by_step":[round(100*float(x),3) for x in p],
            "seam_329_to_0_RGB":round(float(a[k]),5),"max_nearby_non_wrap_transition":round(float(surrounding.max()),5)}


def font(n, bold=False):
    which="Bold" if bold else "Regular"
    return ImageFont.truetype(f"/usr/share/fonts/opentype/noto/NotoSansCJK-{which}.ttc",n,index=2)


def visual_contacts(scene,arr,meta,out):
    out.mkdir(exist_ok=True,parents=True)
    bg="#17202b"; ink="#ece3d5"; accent="#eec17f"
    # True native-scale chain around the boundary, no cover/wait duplicate.
    ids=(321,325,329,0,1,3,6,8)
    title="夏 · 雨夜街角小店" if scene=="summer" else "冬 · 雪夜家属院"
    W=1364;outer=20;gap=12;full=Image.new("RGB",(W,534),bg);d=ImageDraw.Draw(full)
    d.text((outer,16),title+" · 原生接缝",font=font(32,True),fill=ink)
    d.text((outer,65),"320×180  ·  30 fps  ·  第 329 帧之后直接回到第 0 帧",font=font(22),fill="#b4c4cf")
    for i,n in enumerate(ids):
        x=outer+i%4*(320+gap);y=120+i//4*207
        full.paste(Image.fromarray(arr[n]),(x,y+24))
        d.text((x,y-3),f"F {n:03d}",font=font(18,True),fill=accent if n in (329,0) else ink)
    full.save(out/f"{scene}_seam_contact.png")
    row_h=230
    flags=list(meta["native_interest_xyxy"].items())
    obs=Image.new("RGB",(1440,118+row_h*len(flags)),bg);d=ImageDraw.Draw(obs)
    d.text((28,17),title+" · 逐帧动作核查",font=font(37,True),fill=ink)
    d.text((30,74),"下面为同一机位原生区域的整数放大，不是另画的放大特写。",font=font(20),fill="#b4c4cf")
    names={"neon_puddle":"网吧灯同组湿地红色碎光","shelter_cat":"檐内静坐猫","gutter":"雨棚前缘与暖地滴水",
           "window":"值班室：伏案 / 抬手 / 书页落下","lamp_snow":"路灯暖光与雪","chimney":"小烟囱淡烟"}
    for j,(name,(x,y,x1,y1)) in enumerate(flags):
        top=117+j*row_h
        d.text((30,top),names[name],font=font(25,True),fill=accent)
        for i,n in enumerate(SAMPLES[scene]):
            left=30+i*228
            im=Image.fromarray(arr[n,y:y1,x:x1])
            scale=min(205//im.width,154//im.height)
            im=im.resize((im.width*scale,im.height*scale),Image.Resampling.NEAREST)
            obs.paste(im,(left,top+36))
            d.text((left,top+192),f"{n/FPS:05.2f} s   F{n:03d}",font=font(17),fill=ink)
    obs.save(out/f"{scene}_action_contact.png")
    q=[Image.fromarray(arr[n]).resize((640,360),Image.Resampling.NEAREST) for n in SEAM]
    q[0].save(out/f"{scene}_seam.gif",save_all=True,append_images=q[1:],optimize=False,loop=0,duration=55)


def verify(scene):
    video=ROOT/"outputs"/f"{scene}_loop.mp4"
    qa=ROOT/"qa"
    arr=np.load(qa/f"{scene}_native.npy",mmap_mode="r")
    assert arr.shape==(COUNT,180,320,3) and arr.dtype==np.uint8
    assert not np.array_equal(arr[0],arr[-1])
    info=json.loads((qa/f"{scene}_build.json").read_text())
    window=seam(arr)
    assert window["seam_329_to_0_RGB"]<1.55*window["max_nearby_non_wrap_transition"]+0.05,window
    source_cols={tuple(x) for x in json.loads((ROOT/"references"/f"{scene}.json").read_text())["palette_rgb"]}
    frame_cols={tuple(x) for x in np.unique(np.concatenate(arr[::33],axis=0).reshape(-1,3),axis=0)}
    assert frame_cols <= source_cols
    wall=info["roi_xyxy"]
    base=np.load(qa/"layers"/f"{scene}_base_probe.npy")
    x,y,x1,y1=wall
    wall_delta=int(np.sum(base[0,y:y1,x:x1]!=base[1,y:y1,x:x1]))
    assert np.array_equal(base[0],base[2])
    breakdown={
        "native_frame_shape":list(arr.shape),"fixed_palette_base_colors":len(source_cols),
        "full_boundary_render_is_exact":info["closure_is_exact"],"actual_seam":window,
        "local_ROI_actual_seam":{k:seam(arr,xy) for k,xy in info["native_interest_xyxy"].items()},
        "still_wall_layer_disabled_RGB_changes":wall_delta,
        "still_wall_roi":wall,
        "near_seam_wall_including_weather":seam(arr,wall),
        "observable_layers":info["layers"],"ffprobe":decode_probe(video),"decoded_grid":grid_check(video),
        "mp4_sha256":hashlib.file_digest(video.open("rb"),"sha256").hexdigest(),
    }
    visual_contacts(scene,arr,info,qa)
    (qa/f"{scene}_verified.json").write_text(json.dumps(breakdown,ensure_ascii=False,indent=2)+"\n")
    print(scene, "660 frames and 330 bit-identical decoded repeated frames; seams",
          window["seam_329_to_0_RGB"],"/",window["max_nearby_non_wrap_transition"],
          "RGB mean; stable wall with effects off",wall_delta,"; grid blocks exact",flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("scene",choices=("summer","winter"))
    verify(p.parse_args().scene)
