#!/usr/bin/env python3
"""Render one native 330-frame cycle and encode twice, with no extra end frame."""
import argparse
import importlib
import json
import subprocess
import time
from pathlib import Path

import numpy as np
from PIL import Image
from framework import FixedColors, ROOT, use_cjk
from timeline import COUNT, FPS, PERIOD, frame_time


def name_for(scene):
    return importlib.import_module(f"{scene}_loop_scene").__dict__[scene.title()]


def encode(frames, dst, *, step, proxy):
    size="1280:720" if proxy else "1920:1080"
    color=f"scale={size}:flags=neighbor:out_color_matrix=bt709:out_range=tv,format=yuv420p"
    cmd=["ffmpeg","-v","error","-y","-f","rawvideo","-pixel_format","rgb24",
         "-video_size","320x180","-framerate",str(FPS//step),"-i","pipe:0",
         "-an","-vf",color,"-c:v","libx264","-preset","veryfast","-threads","4",
         "-g",str(len(frames)),"-keyint_min",str(len(frames)),"-sc_threshold","0",
         "-colorspace","bt709","-color_primaries","bt709","-color_trc","bt709","-color_range","tv"]
    cmd+=["-crf","18"] if proxy else ["-qp","0"]
    temp=dst.with_name(dst.stem+".partial.mp4")
    cmd += ["-movflags","+faststart",str(temp)]
    proc = subprocess.Popen(cmd,stdin=subprocess.PIPE)
    try:
        for _ in range(2):
            for fr in frames:proc.stdin.write(np.ascontiguousarray(fr).tobytes())
        proc.stdin.close()
    except BrokenPipeError as exc:
        proc.wait()
        raise RuntimeError(f"ffmpeg failed while encoding {dst.name}") from exc
    ret=proc.wait()
    if ret: raise RuntimeError(f"ffmpeg exited {ret}")
    temp.replace(dst)


def qa_layer_snaps(state, colors, scene, out):
    out.mkdir(exist_ok=True,parents=True)
    TIMES={
        "winter":{"actor":5.667,"smoke":1.2,"snow":3.9,"desk":1.05,"stairs":4.1,"tv":3.0,"lamp":7.6},
        "summer":{"cat":6.92,"rain":3.4,"drops":4.35,"wet":3.64,"neon":3.64,"tv":3.28,"barber":4.35},
    }
    all_outputs=[]
    for layer in state.OMIT:
        t=TIMES[scene].get(layer,3.57)
        base=colors.quantize(state.frame(t))
        off=colors.quantize(state.frame(t,omit=(layer,)))
        both=np.concatenate([base,off],axis=1)
        Image.fromarray(both).save(out/f"{scene}_{layer}_on_left_off_right.png")
        d=np.abs(base.astype(np.int16)-off.astype(np.int16))
        all_outputs.append({"layer":layer,"time_s":t,"diff_pixels":int(np.count_nonzero(np.any(d,axis=2))),"max_channel_delta":int(d.max())})
    sample=np.concatenate([colors.quantize(state.frame(t,omit=state.OMIT))[None] for t in (0.,7.17,PERIOD)],axis=0)
    np.save(out/f"{scene}_base_probe.npy",sample,allow_pickle=False)
    (out/f"{scene}_layer_audit.json").write_text(json.dumps(all_outputs,indent=2)+"\n")
    return all_outputs


def render(scene, proxy):
    use_cjk()
    state=name_for(scene)()
    colors=FixedColors(scene,state.GRADE,state.VIGNETTE)
    step=3 if proxy else 1
    indices=range(0,COUNT,step)
    frames=np.empty((len(indices),180,320,3),dtype=np.uint8)
    t0=time.perf_counter()
    for p,i in enumerate(indices):
        frames[p]=colors.quantize(state.frame(frame_time(i)))
        if (p+1)%33==0 or p+1==len(indices):
            print(f"{scene} native {p+1}/{len(indices)} @ {time.perf_counter()-t0:.1f}s",flush=True)
    if not proxy:
        qa=ROOT/"qa"
        qa.mkdir(exist_ok=True,parents=True)
        np.save(qa/f"{scene}_native.npy",frames,allow_pickle=False)
    out=ROOT/("drafts" if proxy else "outputs")
    out.mkdir(exist_ok=True,parents=True)
    dst=out/(f"{scene}_loop_proxy.mp4" if proxy else f"{scene}_loop.mp4")
    encode(frames,dst,step=step,proxy=proxy)
    print(f"{dst.name} encoded {len(frames)*2} frames; {dst.stat().st_size:,} bytes",flush=True)
    if not proxy:
        f0=frames[0]
        equal_at_wrap=np.array_equal(f0,colors.quantize(state.frame(PERIOD)))
        assert equal_at_wrap,"strict frame(11.00) closure failed"
        layers=qa_layer_snaps(state,colors,scene,qa/"layers")
        (qa/f"{scene}_build.json").write_text(json.dumps({
            "scene":scene,"period":PERIOD,"num_native_frames":len(frames),"fps":FPS,"closure_is_exact":bool(equal_at_wrap),
            "roi_xyxy":state.WALL,"native_interest_xyxy":state.INTEREST,"layers":layers,"stats":state.stats,
        },indent=2,ensure_ascii=False)+"\n")


def main():
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument("scene",choices=("summer","winter"))
    a.add_argument("--proxy",action="store_true",help="22-second true animation at 10fps/720p for early audition")
    args=a.parse_args()
    render(args.scene,args.proxy)


if __name__=="__main__":
    main()
