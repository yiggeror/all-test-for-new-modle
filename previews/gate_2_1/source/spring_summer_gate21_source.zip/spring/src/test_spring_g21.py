import unittest,numpy as np
from spring_v21 import roof_action,perch_action,moth_paths
class SpringMotionTests(unittest.TestCase):
    def test_roof_lift_chases_and_returns_with_two_waves(self):
        self.assertEqual(roof_action(.0),roof_action(1.))
        self.assertGreater(roof_action(4.1/11)[0],.9)
        self.assertEqual(roof_action(9.4/11)[0],0)
        self.assertGreater(abs(roof_action(4.35/11)[2]),.45)
        self.assertGreater(abs(roof_action(6.22/11)[2]),.45)
    def test_bicycle_hop_peck_and_moths_close(self):
        self.assertEqual(perch_action(.0),perch_action(1.))
        self.assertGreater(perch_action(5.12/11)[0],.85)
        self.assertGreater(perch_action(6.75/11)[1],.8)
        self.assertEqual(moth_paths(.0).shape,(4,4))
        self.assertTrue(np.array_equal(moth_paths(.0),moth_paths(1.)))
if __name__=='__main__':unittest.main()
