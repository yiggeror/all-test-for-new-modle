"""Gate 2.1 spring: linked roof-cat anatomy and a ray-traced perched sparrow."""
from math import cos, sin, pi

import numpy as np
from engine.rt import Accel
from engine.world import World, _n, roty
from motion_math import PERIOD, smooth


def _pose(t,left,duration,rise=.23,fall=.30):
    u=(t-left)/duration
    return float(smooth(u/rise)*smooth((1-u)/fall)) if 0<u<1 else 0.


def roof_action(ph):
    t=(ph%1.)*PERIOD
    raised=_pose(t,1.58,7.04,.215,.255)
    follow=raised*(-.46+.92*float(smooth((t-3.08)/3.12)))
    sweep=_pose(t,3.75,1.36,.43,.55)-.92*_pose(t,5.61,1.43,.43,.55)
    arch=.82*abs(sweep)-.185*sweep
    return raised,follow,sweep,arch


def perch_action(ph):
    t=(ph%1.)*PERIOD
    hop=_pose(t,4.90,.45,.47,.53)+.79*_pose(t,5.45,.40,.42,.57)
    peck=_pose(t,6.48,.61,.42,.46)+.70*_pose(t,7.14,.40,.42,.53)
    look=.58*_pose(t,1.25,2.60,.55,.40)-.48*_pose(t,7.3,2.50,.42,.47)
    away=float(smooth((t-4.92)/.42)*smooth((5.83-t)/.42))
    return hop,peck,look,away


def moth_paths(ph):
    ph=ph%1.
    th=2*np.pi*(ph+np.array([.075,.372,.691,.903]))
    x=.03+np.array([.60,.75,.46,.55])*np.cos(th)+.080*np.cos(3*th)
    y=-np.array([.64,.99,1.23,1.44])+np.array([.26,.27,.23,.18])*np.sin(np.array([1,2,1,2])*th+.35)
    z=np.array([.30,.19,.10,.23])+np.array([.30,.35,.26,.31])*np.sin(th+.25)
    beam=.36+.64*smooth((np.sin(th+.14)+.67)/1.62)
    pulse=.81+.19*(.5+.5*np.cos(14*th+np.array([.2,.9,1.9,.7])))
    return np.stack((x,y,z,beam*pulse),axis=1)


class RailSparrow:
    """Feet stand on the actual bicycle handle, with airborne hops drawn in world space."""
    rect=np.s_[143:161,96:114]

    def __init__(self,cam,plate,acc,lamp):
        self.cam,self.plate=cam,plate
        lean=-.095
        M=np.array([[1,0,0],[0,cos(lean),-sin(lean)],[0,sin(lean),cos(lean)]])
        self.origin=np.array([-1.78,0,13.30])+roty(.21)@M@np.array([.34,1.103,-.074])
        self.along=roty(.21)@M@np.array([0.,0.,1.])
        self.size=(18,18)
        # Same nine subrays as the static plate, with real front depth from the world BVH.
        yy,xx=np.mgrid[0:18*3,0:18*3]
        dirs=cam.dirs(96+(xx+.5)/3,143+(yy+.5)/3).reshape(18,3,18,3,3)
        self.rd=np.ascontiguousarray(dirs.transpose(0,2,1,3,4).reshape(-1,3),np.float32)
        self.ro=np.broadcast_to(np.asarray(cam.pos,np.float32),self.rd.shape).copy()
        td,id_=acc.closest(self.ro,self.rd)
        self.behind=np.where(id_>=0,td,1e9).astype(np.float32)
        self.original_depth=plate['depth'][self.rect].copy()
        self.lamp=np.asarray(lamp['pos'])

    def pose(self,ph):
        hop,peck,look,away=perch_action(ph)
        pos=self.origin.copy()+.142*away*self.along+.13*hop*self.cam.r+hop*.189*self.cam.u
        w=World(seed=82)
        brown=dict(mat='plain',col='#3d2a38')
        crown=dict(mat='plain',col='#503342')
        light=dict(mat='plain',col='#946d4e')
        dark=dict(mat='plain',col='#2c2331')
        wing=dict(mat='plain',col='#624238')
        toe=dict(mat='plain',col='#483548')
        yaw=.31+.66*look-.52*away
        with w.at(pos,yaw=yaw):
            with w.at((.012,.150-.018*peck,0),M=np.diag([1.21,.89,.91])):
                w.sphere((0,0,0),.132,n=9,**brown)
            w.sphere((-.092,.137-.023*peck,.046),.084,n=8,squash=1.16,**light)
            head=(-.111-.058*peck,.247-.115*peck,.042+.017*peck)
            w.sphere(head,.080,n=8,squash=.93,**crown)
            w.sphere((head[0]-.029,head[1]-.030,head[2]+.049),.048,n=7,squash=.66,**light)
            w.sphere((head[0]-.040,head[1]+.020,head[2]+.060),.019,n=5,**dark)
            w.poly([(head[0]-.054,head[1]-.008,head[2]+.040),
                    (head[0]-.107,head[1]-.023-.018*peck,head[2]+.041),
                    (head[0]-.053,head[1]-.043,head[2]+.052)],**dark)
            w.poly([(.086,.131,-.058),(.29,.187+.035*hop,-.023),(.267,.165+.040*hop,.020),(.107,.119,.047)],**dark)
            wing_lift=.096*hop*(.5+.5*cos(2*pi*(ph*PERIOD-5.0)*5.6))
            w.poly([(-.053,.177,.065),(.080,.241+wing_lift,.098),
                    (.205,.162+wing_lift,.094),(.060,.089,.083)],**wing)
            if hop>.02:
                w.poly([(-.032,.171,-.037),(.071,.237+1.50*wing_lift,-.129),
                        (.179,.183+1.12*wing_lift,-.159),(.063,.129,-.093)],**brown)
            for x,z in ((-.044,-.032),(.038,.030)):
                w.tube((x,.093,z),(x+.013*hop,.01+.072*hop,z+.045*hop),.013,.007,sides=5,caps=True,**toe)
                w.tube((x+.013*hop,.007+.072*hop,z+.045*hop),(x-.038,.004+.072*hop,z+.020+.045*hop),.009,.005,sides=5,**toe)
        return w

    def draw(self,lin,ph,lamp_gain):
        mesh=self.pose(ph).finalize()
        t,f=Accel(mesh['v0'],mesh['v1'],mesh['v2'],mesh['tm']).closest(self.ro,self.rd)
        visible=(f>=0)&(t<=self.behind+.004)
        i=np.flatnonzero(visible)
        normals=mesh['F']['n'][mesh['tf'][f[i]]]
        normal=normals*np.where((normals*self.rd[i]).sum(1)>0.,-1.,1.)[:,None]
        points=self.ro[i]+self.rd[i]*t[i,None]
        light=np.maximum(0.,(_n(self.lamp-points)*normal).sum(1))
        col=mesh['F']['col'][mesh['tf'][f[i]]]
        radiance=col*(.42+.19*light*lamp_gain+.15*np.maximum(0.,normal[:,1]))[:,None]
        raw=np.zeros((len(f),3),np.float32);raw[i]=radiance
        cov=visible.reshape(*self.size,9).mean(2).astype(np.float32)
        local=lin[self.rect]
        local[:]=local*(1-cov[...,None])+raw.reshape(*self.size,9,3).mean(2)
        self.plate['depth'][self.rect]=np.sort(np.minimum(self.behind,np.where(visible,t,1e9)).reshape(*self.size,9),axis=2)

    def reset_depth(self):
        self.plate['depth'][self.rect]=self.original_depth
