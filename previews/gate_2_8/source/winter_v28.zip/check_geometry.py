"""Ray-camera checks on inextensible leaf, desk-level wrist, coordinated nod and periodic breathing."""
import json
from pathlib import Path
import numpy as np
from winter28 import leaf,pose,SPINE,ALONG,ACROSS,PAGE_WIDTH,PAGE_DEPTH,sc
from shots import winter_gate15 as shot
cam=shot.camera(320,180); origin=np.array([sc.READING_OPENING[0]-sc.GUARD_SIZE[0]/2.,sc.READING_OPENING[1],sc.GUARD_SIZE[1]/2-.16]);
def proj(p):
 a=np.asarray(p)+origin;w=np.asarray(sc.GUARD_POS)+a@__import__('engine.world',fromlist=['roty']).roty(sc.GUARD_YAW).T
 return np.stack(cam.project(w)[:2],axis=-1)
def main():
 maxima=[];roots=[];lengths=[];elbows=[];head=[];wr=[];tips=[];stationary=None;xy0=np.array([.849,.837,-.231]);peak=(0,0.)
 for f in range(330):
  p=pose(f);head.append(proj(p['headpt'](xy0)));elbows.append(p['elbow'][1]);wr.append(p['cuff'][1]);tips.append(p['tip'][1]);
  for z in np.linspace(-1,1,11):
   r=leaf(f,z);ds=np.linalg.norm(np.diff(r,axis=0),axis=1);lengths.append(ds.sum());roots.append(np.linalg.norm(r[0]-(SPINE+ALONG*(.5*PAGE_DEPTH*z)+np.array([0.,.015-.023*z,0.]))));flat=r.copy();flat[:,1]=r[0,1];height=(proj(flat)[:,1]-proj(r)[:,1]).max();maxima.append(height);
   if height>peak[1]:peak=(f,height)
 a=np.asarray(head);fmax=int(np.argmax(a[143:195,1])+143);motion=float(a[fmax,1]-a[145,1]);
 assert max(roots)<1e-10 and max(lengths)<.1640001 and min(lengths)>.159 and 1.50<peak[1]<2.00 and .45<motion<1.05
 assert tuple(pose(0)['headpt'](xy0))==tuple(pose(330)['headpt'](xy0))
 report={'sheet_material_width_m_range':[min(lengths),max(lengths)],'max_spine_error_m':max(roots),'peak_sheet_height_above_gutter_native_px':peak[1],'peak_sheet_frame':peak[0], 'head_tracking_drop_native_px':motion,'head_deepest_tracking_frame':fmax,'elbow_height_above_desk_m_range':[min(elbows)-.3125,max(elbows)-.3125],'wrist_height_above_desk_m_range':[min(wr)-.3125,max(wr)-.3125],'audio_lock':'f156 initial paper friction, f169 settlement. Existing audio stays in the final film.'}
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()
