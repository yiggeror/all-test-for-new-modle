"""Continuous, exact 11 s event schedules in seconds (not wall clock)."""
from math import cos, pi

FPS = 30
COUNT = 330
PERIOD = COUNT / FPS


def frame_time(i):
    return (int(i) % COUNT) / FPS


def ease(x):
    x = min(1.,max(0.,float(x)))
    return x*x*x*(x*(6*x-15)+10)


def window(t,start,duration):
    return ((t-start) % PERIOD) / duration


def envelope(t,start,duration,entry=.24,exit_=.29):
    p=window(t,start,duration)
    if p >= 1: return 0.
    return ease(p/entry)*ease((1.-p)/exit_)


def wave(t,k=1.,phase=0.):
    return cos(2*pi*(k*(t % PERIOD)/PERIOD+phase))


def reader_controls(t):
    p=window(t,4.30,2.60)
    if p >= 1:
        return 0.,0.,0.
    lift=ease(p/.29)*ease((1.-p)/.30)
    turn=ease((p-.30)/.38)
    flick=ease((p-.27)/.085)*ease((.80-p)/.11)
    return lift,turn,flick


def neon(t):
    # Only two gentle current dips, each with a tiny second shoulder.
    dip=(.077*envelope(t,3.44,.34,.46,.41)
        +.026*envelope(t,3.77,.18,.44,.47)
        +.059*envelope(t,8.03,.27,.48,.44))
    return .991+.008*wave(t,4,.12)-dip


def cat_controls(t):
    lifts=.98*envelope(t,6.65,.52,.37,.45)+.55*envelope(t,7.13,.38,.40,.48)
    tail=envelope(t,8.70,1.29,.42,.43)
    return lifts,tail
