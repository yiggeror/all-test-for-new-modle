#!/usr/bin/env python3
"""Independently regenerates the winter single-cycle native frames and review / escrow media."""
from pathlib import Path
import sys,os,hashlib,subprocess,json,zipfile,argparse
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from room28 import prepare,X0,Y0,X1,Y1
from winter28 import WinterV28,WinterV24
N=330;FPS=30; OLD='499f216c23b6dfe1e9cfe51b4674865006a09cda28e5a4b7fc64be187ed91408'; HDR=['-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-color_range','tv']; EDIT=(250,105,264,116);DETAIL=(242,98,274,122)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''): h.update(b)
 return h.hexdigest()
def write_native(work,old):
 if not (work/'clean_room.npz').exists():prepare(work/'clean_room.npz')
 if old is None:
  old=work/'baseline_native.npy';a=np.lib.format.open_memmap(old,'w+',np.uint8,(N,180,320,3));v=WinterV24()
  for i in range(N):a[i]=v.frame(i/FPS)
  a.flush();del a,v
 base=np.load(old,mmap_mode='r');assert hashlib.sha256(base.data).hexdigest()==OLD
 v=WinterV28(work/'clean_room.npz');dst=work/'winter_native.npy';a=np.lib.format.open_memmap(dst,'w+',np.uint8,(N,180,320,3));
 x,y,X,Y=EDIT;raw_d=[];inside=[];mask=np.ones((180,320),bool);mask[y:Y,x:X]=False
 for f in range(N):
  new=v.frame(f/FPS);delta=np.any(base[f]!=new,axis=2);raw_d.append(int(delta[mask].sum()));inside.append(int(delta[~mask].sum()));
  a[f]=base[f];a[f,y:Y,x:X]=new[y:Y,x:X]
  assert np.array_equal(a[f,mask],base[f,mask])
  if f%55==0: print('native',f,flush=True)
 a.flush();new0=v.frame(11);assert np.array_equal(a[0,y:Y,x:X],new0[y:Y,x:X]);
 evidence={'source_baseline_native_sha256':OLD,'raw_geometry_hash':hashlib.sha256(a.data).hexdigest(),'editable_half_open_xyxy':EDIT,'outside_changed_pixels_by_frame':[0]*N,'raw_pre_lock_difference_outside_edit_pixels_by_frame':raw_d,'changed_pixels_inside_by_frame':inside,'detail_half_open_xyxy':DETAIL,'foley_centers':[156,169],'frame_period':330,'fps':30}
 (work/'native_proof.json').write_text(json.dumps(evidence,indent=2)+'\n');return a,base

def movie(a,dest,detail=False,twice=False,review=False):
 if detail:
  x,y,X,Y=DETAIL;w,h=X-x,Y-y;W,H=w*32,h*32
 else: w,h=320,180;W,H=1920,1080
 common=['ffmpeg','-v','error','-nostdin','-y','-filter_threads','1','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{w}x{h}','-framerate','30','-i','-','-an','-vf',f'scale={W}:{H}:flags=neighbor:out_color_matrix=bt709:out_range=tv,format=yuv420p','-c:v','libx264','-preset','veryfast','-threads','2','-g','330','-keyint_min','330','-sc_threshold','0',*(['-crf','15'] if review else ['-qp','0']),'-pix_fmt','yuv420p',*HDR,'-movflags','+faststart',str(dest)]
 p=subprocess.Popen(common,stdin=subprocess.PIPE)
 for _ in range(2 if twice else 1):
  for fr in a:p.stdin.write((fr[y:Y,x:X] if detail else fr).tobytes())
 p.stdin.close()
 if p.wait():raise RuntimeError('x264 failed')

def compare(a,b,dest):
 fs=range(120,213,4);scale=6; x0,y0,x1,y1=(245,100,271,118);w,h=(x1-x0)*scale,(y1-y0)*scale
 left,top,gap=90,52,8;row=h*2+31;im=Image.new('RGB',(left+6*(w+gap)+18,top+4*row+19),(26,32,44));dr=ImageDraw.Draw(im)
 fontfile='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
 try:font=ImageFont.truetype(fontfile,13);title=ImageFont.truetype(fontfile,20)
 except OSError:font=title=ImageFont.load_default()
 dr.text((left,13),'Winter / Reading room    ·    Same camera, same frame',font=title,fill=(229,220,200))
 for j,f in enumerate(fs):
  x,y=left+(j%6)*(w+gap),top+(j//6)*row;dr.text((x,y),f'f{f:03d}   {f/30:.2f}s',font=font,fill=(186,193,204));
  for s,t in enumerate((b,a)):
   Y=y+19+s*(h+2);tile=Image.fromarray(t[f,y0:y1,x0:x1]).resize((w,h),Image.Resampling.NEAREST);im.paste(tile,(x,Y));
   if j%6==0:dr.text((21,Y+h//2-8),('v2.7','v2.8')[s],font=title,fill=((156,176,202),(231,184,130))[s]);
 im.save(dest)

def main():
 cmd=argparse.ArgumentParser();cmd.add_argument('--work',type=Path,default=Path('work'));cmd.add_argument('--out',type=Path,default=Path('out'));cmd.add_argument('--baseline-native',type=Path);cmd.add_argument('--reuse',action='store_true');args=cmd.parse_args();work=args.work;out=args.out;work.mkdir(parents=True,exist_ok=True);out.mkdir(parents=True,exist_ok=True)
 if args.reuse:a=np.load(work/'winter_native.npy',mmap_mode='r');b=np.load(args.baseline_native or work/'baseline_native.npy',mmap_mode='r');assert hashlib.sha256(b.data).hexdigest()==OLD
 else:a,b=write_native(work,args.baseline_native)
 movie(a,out/'winter_reader_normal_speed_detail.mp4',detail=True);print('DETAIL READY',flush=True);compare(a,b,out/'winter_reader_comparison.png');movie(a,out/'winter_loop.mp4',review=True)
 master=work/'winter_lossless_660.mp4';movie(a,master,twice=True);directory=out/'lossless_parts'/'winter';directory.mkdir(parents=True,exist_ok=True);parts=[];
 with master.open('rb') as src:
  for i,buf in enumerate(iter(lambda:src.read(8_000_000),b'')):
   target=directory/f'part-{i:02d}.bin';target.write_bytes(buf);parts.append({'path':str(target.relative_to(out)),'bytes':len(buf),'sha256':sha(target)})
 assert len(parts)==6
 (work/'winter_parts.json').write_text(json.dumps({'output':'winter_loop.mp4','bytes':master.stat().st_size,'sha256':sha(master),'parts':parts},indent=2)+'\n')
 print('verified six parts / end',flush=True)
if __name__=='__main__':main()
