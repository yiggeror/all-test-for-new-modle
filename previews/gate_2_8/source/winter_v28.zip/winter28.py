"""A single, low winter page turn: spine-attached sheet, a supported wrist and a small reading nod.
World coordinates are metres. 30 frames/s. Native camera 320 × 180, unchanged from Gate 2.4.
"""
from __future__ import annotations
from math import sin,cos,pi
import numpy as np
from scipy.interpolate import PchipInterpolator
from engine.world import World,srgb
from framework import NativeActor
from winter24 import WinterV24
from winter23 import sc
from room28 import X0,Y0,X1,Y1

SPINE=np.array([1.153,.365,-.154]); PAGE_WIDTH=.162; PAGE_DEPTH=.228; YAW=.23
ACROSS=np.array([cos(YAW),0.,-sin(YAW)]); ALONG=np.array([sin(YAW),0.,cos(YAW)]); UP=np.array([0.,1.,0.]);

def ease(f,lo,hi):
    u=min(1.,max(0.,(f-lo)/(hi-lo)));return u*u*(3.-2.*u)

# The sheet settles progressively, rather than holding the arm out, then flicking it.
_TURN=PchipInterpolator([0,143,150,154,156,160,164,169,172,175,329,330],
                        [0,0,0,.018,.087,.294,.57,.893,.97,1,1,1])

def ctrl(f):
    f%=330
    # Keep the post-turn page flat on the left. At the cycle seam both identical sheets lie flat.
    return (float(_TURN(f)), ease(f,143,155),ease(f,174,193),
            ease(f,143,162)*(1.-ease(f,168,196)),ease(f,150,157)*(1.-ease(f,166,174)))

def leaf(f,z):
    """An inextensible strip: each one of eight segments is exactly 1/8 of 0.162 m.
    Its root shares the gutter at every longitudinal station; there is no free leading-edge object.
    z is -1 at the far edge and +1 at the nearest corner touched by the finger.
    """
    turn,_,_,_,pinch=ctrl(f); lag=1.30*(1-z)
    q=float(_TURN(max(0.,min(329.,f-lag)))) if 143<=f<178 else turn
    seg=8; s=(np.arange(seg)+.5)/seg; arc=sin(pi*q)
    theta=pi*q + arc*(.70*(s-.46)*2+.15*z*s) + pinch*.32*(.28+.72*(z+1)/2)*s**2
    # Descending left paper follows the very slight dish of the left page block.
    theta += .050*cos(pi*q)*(1.-arc)*s
    ds=PAGE_WIDTH/seg
    d=ds*(np.cos(theta)[:,None]*ACROSS+np.sin(theta)[:,None]*UP)
    root=SPINE+ALONG*(.5*PAGE_DEPTH*z)+UP*(.015-.023*z)
    return np.concatenate(([root],root+np.cumsum(d,axis=0)))

def paper(m,f):
    # Both stationary page blocks lean gently into a matte recessed gutter.
    # Subdued, brown cover lip grounds them on the existing wooden desk.
    zvals=(-1.,-.35,.35,1.)
    moving=150<f<175
    rows=[leaf(f,z) for z in zvals] if moving else []
    tris=np.stack([tri for a,b in zip(rows[:-1],rows[1:]) for i in range(8) for tri in ((a[i],a[i+1],b[i+1]),(a[i],b[i+1],b[i]))]) if moving else None
    def lit(center,col):
        if not moving:return col
        # Trace five rays towards the unchanged cloth shade. The lifted paper casts a moving soft shadow
        # onto the resting page (never onto the wall or on an artist-drawn substitute for the desktop).
        E=tris[:,1]-tris[:,0]; F=tris[:,2]-tris[:,0];rays=np.array([[1.755,.73,-.32],[1.805,.76,-.35],[1.71,.75,-.34],[1.75,.70,-.27],[1.73,.72,-.373]])-center
        U=np.cross(rays[:,None,:],F[None,:,:]);det=(U*E[None,:,:]).sum(-1);inv=np.divide(1.,det,out=np.zeros_like(det),where=abs(det)>1e-10)
        delta=center-tris[:,0];u=(U*delta[None,:,:]).sum(-1)*inv;Q=np.cross(delta,E);v=(rays[:,None,:]*Q[None,:,:]).sum(-1)*inv;t=(F*Q).sum(-1)[None,:]*inv
        visible=((u>=0)&(v>=0)&(u+v<=1)&(t>.01)&(t<1));k=visible.any(1).mean()
        return srgb(col)*(1.-.34*k)
    for side in (-1,1):
        edge=SPINE+side*ACROSS*(.164+.003)
        def v(r,z,dy):return SPINE+r*side*ACROSS+z*(PAGE_DEPTH*.5+.005)*ALONG+(dy+.015-.023*z)*UP
        m.quads(v(.003,-1,-.038),v(.167,-1,-.032),v(.167,1,-.032),v(.003,1,-.038),mat='plain',col='#695245',prm=.13)
        # Tilt changes continuously across the top; cover, page stack fore-edge and gutter stay connected.
        rs=(.004,.047,.109,.164);hs=(-.005,.009,.033,.042)
        for k,(r0,r1,h0,h1) in enumerate(zip(rs[:-1],rs[1:],hs[:-1],hs[1:])):
            col=(('#655649','#8c7c70','#a79f92') if side<0 else ('#756258','#97887a','#b1a597'))[k]
            for z0,z1 in zip(zvals[:-1],zvals[1:]):
                v0,v1,v2,v3=v(r0,z0,h0),v(r1,z0,h1),v(r1,z1,h1),v(r0,z1,h0)
                m.quads(v0,v1,v2,v3,mat='plain',col=lit((v0+v1+v2+v3)/4,col),prm=.16)
            m.quads(v(r0,1,-.043),v(r1,1,-.040),v(r1,1,h1),v(r0,1,h0),mat='plain',col='#a08b7e',prm=.12)
        m.quads(v(.003,1.05,-.028),v(.170,1.05,-.021),v(.170,1.05,-.040),v(.003,1.05,-.045),mat='plain',col='#64463b',prm=.16)
        m.quads(v(.164,-1,-.021),v(.164,1,-.021),v(.164,1,.015),v(.164,-1,.015),mat='plain',col='#a38970',prm=.13)
    # Render moving paper only while changing sides. At each end it coincides with the existing page block.
    def gutter(u,z):return SPINE+u*ACROSS+z*.5*PAGE_DEPTH*ALONG+(.020-.023*z)*UP
    m.quads(gutter(-.018,-1.025),gutter(.018,-1.025),gutter(.018,1.06),gutter(-.018,1.06),mat='plain',col='#4f4142',prm=.14)
    if not moving:return
    # One matte surface, no bright outlining tube. Slightly warmer/darker at the gutter.
    for a,b in zip(rows[:-1],rows[1:]):
        for i in range(8):
            col=('#5a5050','#6a5c58','#80736c','#91857a','#9b8e84','#a4968c','#a79c91','#aa9f93')[i]
            m.quads(a[i],a[i+1],b[i+1],b[i],mat='plain',col=col,prm=.18)

def pose(f):
    f=f%330;q,reach,retreat,nod,_=ctrl(f); ph=2*pi*f/330.
    # Seamless asymmetric breaths; small shoulder weight transfer leads the head by three frames.
    breath=.011*sin(3*ph-.5)+.003*sin(6*ph-.28); sb=.55*breath
    sh=ease(f,142,158)*(1.-ease(f,167,191));
    lean=.020*sh; neck=np.array([.746+lean,.658+sb-.015*sh,-.249]);
    angle=-.16*nod-.025*sin(3*ph-.79); C=cos(angle); S=sin(angle);R=np.array([[C,-S,0],[S,C,0],[0,0,1.]])
    def headpt(pos):return neck+R@(np.asarray(pos)-np.array([.746,.658,-.249]))+np.array([.002*nod,-.037*nod+breath*.38,0.])
    # Resting fingertips lie by the near left margin. The near corner flexes first and the far corner follows.
    rest=np.array([.950,.341,.006]); touch=leaf(f,.63)[-1]+np.array([.008,.011,.002]);
    tip=(1-reach)*rest + reach*touch
    tip=(1-retreat)*tip+retreat*rest
    tip[1]+=.008*sin(pi*reach)*(1.-retreat)
    extent=np.clip((tip[0]-.985)/.318,0,1)
    # Elbow remains on this side of the desktop, wrist below the fingertips' arc, and the free hand supports the book.
    elbow=np.array([.812+.116*extent,.337+.014*extent+.004*sh,.053+.03*(1-extent)])
    cuff=np.array([tip[0]-.077-.022*extent,.339+.42*max(0.,tip[1]-.34),tip[2]-.003])
    knuckle=np.array([tip[0]-.036,.346+.78*max(0.,tip[1]-.34),tip[2]+.001]);
    return dict(breath=breath,sb=sb,nod=nod,sh=sh,neck=neck,R=R,headpt=headpt,tip=tip,elbow=elbow,cuff=cuff,knuckle=knuckle)

def oval(m,p,xyz,shade,rot=None):
    with m.at(p,M=(np.eye(3) if rot is None else rot) @ np.diag(xyz)):
        m.sphere((0,0,0),1.,n=12,mat='plain',col=shade,prm=.22)

def reader(m,f):
    p=pose(f);sb=p['sb'];sh=p['sh']; headpt=p['headpt'];R=p['R'];
    # The lower back stays seated. The top of the jacket rocks around the hips, not as a translated cutout.
    oval(m,(.613,.389+.15*sb,-.270),(.209,.303,.160),'#282c38')
    m.tube((.627,.407,-.262),(.756+.019*sh,.632+sb-.015*sh,-.245),.150,.105,sides=10,caps=True,mat='plain',col='#353440',prm=.18)
    oval(m,(.72+.017*sh,.584+sb-.010*sh,-.195),(.132,.135,.115),'#3c3944')
    m.tube((.735+.02*sh,.608+sb,-.245),headpt((.825,.743,-.223)),.063,.066,sides=10,caps=True,mat='plain',col='#5d4b48',prm=.20)
    # One connected three-quarter silhouette: nape/crown, subtly forward forehead, cheek and jaw.
    oval(m,headpt((.849,.837,-.231)),(.135,.141,.112),'#272833',R)
    oval(m,headpt((.896,.801,-.207)),(.097,.104,.086),'#705a50',R)
    oval(m,headpt((.858,.868,-.213)),(.120,.097,.108),'#2b2a35',R)
    oval(m,headpt((.966,.797,-.194)),(.036,.034,.043),'#8d715b',R)
    shoulder=np.array([.73+.017*sh,.562+sb-.013*sh,-.115]);elbow=p['elbow'];cuff=p['cuff'];tip=p['tip'];kn=p['knuckle']
    # Two tapering cloth segments, cuffs, palm and finger pad: all overlap at a curved, supported wrist.
    m.tube(shoulder,elbow,.088,.068,sides=10,caps=True,mat='plain',col='#4b4249',prm=.20)
    m.tube(elbow,cuff,.068,.038,sides=10,caps=True,mat='plain',col='#574a4e',prm=.19)
    v=cuff-elbow;m.tube(cuff-v*.13,cuff,.044,.039,sides=8,caps=True,mat='plain',col='#6d5652',prm=.19)
    m.tube(cuff,kn,.036,.031,sides=8,caps=True,mat='plain',col='#9c765a',prm=.17)
    m.tube(kn,tip,.031,.015,sides=8,caps=True,mat='plain',col='#a98468',prm=.18)

class WinterV28(WinterV24):
    def __init__(self,cache):
        super().__init__();r=np.s_[Y0:Y1,X0:X1];a=np.load(cache)
        self.static[r]+=a['static_delta']
        # Keep original room geometry for ALL weather visibility. Only the reader itself sees the empty room.
        act_depth=np.copy(self.b['depth']);act_depth[r]=a['empty_depth'];
        self.st.actor=NativeActor(self.cam,{'depth':act_depth},(X0,Y0,X1,Y1),samples=12)
        self.st.arm=self.model
    def model(self,t):
        f=(t*30)%330;m=World(seed=28)
        with m.at(sc.GUARD_POS,yaw=sc.GUARD_YAW):
            with m.at(self.st.xform):paper(m,f);reader(m,f)
        return m
