"""Generate a clean local plate without the baked reader. The unmodified scene is authoritative outside the reader's silhouette."""
from __future__ import annotations
from pathlib import Path
import numpy as np
from scipy.ndimage import binary_dilation
import winter23
from winter24 import WinterV24
from engine.world import MASK_HIDDEN
from framework import NativeActor

# No camera-facing changes touch the wall, shade, lamp stem, window frame or front of the table.
X0,Y0,X1,Y1=250,105,264,116

def clean_reading_room(w,width,height):
    # Still append every primitive, with its original random seeds, material IDs,
    # lighting, and shadow rays. Only primary visibility of the old body and page blocks changes.
    old={n:getattr(w,n) for n in ('sphere','tube','box')}; counter={n:0 for n in old}
    def wrap(name):
        def go(*a,**kw):
            k=counter[name]; counter[name]+=1
            invisible=(name=='sphere' and k<3) or (name=='tube' and k==0) or (name=='box' and k in (1,2))
            if invisible:kw['mask']=kw.get('mask',0)|MASK_HIDDEN
            return old[name](*a,**kw)
        return go
    for n in old:setattr(w,n,wrap(n))
    try:orig_room(w,width,height)
    finally:
        for n in old:setattr(w,n,old[n])
orig_room=winter23.separate_reading_room

def prepare(path):
    # Cache only the small physical room inputs; not a sprite, painted BG or new animation.
    print('baking original room',flush=True); orig=WinterV24()
    winter23.separate_reading_room=clean_reading_room
    try:
        print('baking empty room',flush=True); clean=WinterV24()
    finally:winter23.separate_reading_room=orig_room
    r=np.s_[Y0:Y1,X0:X1]; d0=orig.b['depth'][r];d1=clean.b['depth'][r];
    # An old camera ray was occluded by figure/book if removing them reveals farther geometry.
    cover=np.any(d1>d0+.009,axis=2); cover=binary_dilation(cover,structure=np.ones((3,3),bool));
    # Drop only the old subject's primary contribution; light maps, all weather, and bloom are still live.
    change=(clean.static[r]-orig.static[r])*cover[:,:,None]
    np.savez_compressed(path,static_delta=change,empty_depth=d1,body_support=cover,original_static=orig.static[r],empty_static=clean.static[r]); print('prep ready',path,flush=True)

if __name__=='__main__':
    import sys;prepare(Path(sys.argv[1]));
