"""Check all 660 decoded frames against native RGB, all six volumes and seam, without an inverse-RGB roundoff."""
from pathlib import Path
import argparse,hashlib,json,subprocess,os
import numpy as np
from render28 import sha
SIZE=1920*1080; FRAME=SIZE*3//2;N=330

def concat_digest(parts,full):
 h=hashlib.sha256();size=0
 for p in parts:
  b=p.read_bytes();h.update(b);size+=len(b)
 assert size==full.stat().st_size and h.hexdigest()==sha(full);return h.hexdigest()

def verify(work,out):
 a=np.load(work/'winter_native.npy',mmap_mode='r');master=work/'winter_lossless_660.mp4';parts=sorted((out/'lossless_parts/winter').glob('part-*.bin'))
 assert len(parts)==6 and all(p.stat().st_size==8_000_000 for p in parts[:-1])
 whole=concat_digest(parts,master);rows=np.array(json.loads((Path(__file__).resolve().parent/'references/winter_yuv_to_rgb.json').read_text()),dtype='uint32');
 key=(rows[:,0]<<16)|(rows[:,1]<<8)|rows[:,2];table=np.zeros(1<<24,'uint8');table[key]=np.arange(1,len(rows)+1);rgb=np.concatenate((np.zeros((1,3),'uint8'),rows[:,3:].astype('uint8')))
 p=subprocess.Popen(['ffmpeg','-v','error','-xerror','-threads','2','-i',str(master),'-map','0:v:0','-an','-f','rawvideo','-pix_fmt','yuv420p','-threads','1','pipe:1'],stdout=subprocess.PIPE,bufsize=4<<20)
 n=0;dec=hashlib.sha256()
 while True:
  raw=p.stdout.read(FRAME)
  if not raw:break
  assert len(raw)==FRAME and n<2*N
  y=np.frombuffer(raw,'u1',SIZE).reshape(180,6,320,6);u=np.frombuffer(raw,'u1',SIZE//4,SIZE).reshape(180,3,320,3);v=np.frombuffer(raw,'u1',SIZE//4,SIZE*5//4).reshape(180,3,320,3)
  assert all(np.all(g==g[:,1:2,:,1:2]) for g in (y,u,v)),f'non-integer block, f{n}'
  y,u,v=(g[:,1,:,1].astype('uint32') for g in (y,u,v));k=table[(y<<16)|(u<<8)|v];assert k.min()>0
  rec=rgb[k];assert np.array_equal(rec,a[n%N]),f'RGB f{n}';
  if n<N:dec.update(rec.tobytes());n+=1
  else:n+=1
 p.stdout.close();assert p.wait()==0 and n==660
 report={'six_parts_sha256':whole,'escrow_bytes':master.stat().st_size,'all_660_lossless_frames_match_two_identical_native_cycles':True,'1920x1080_uniform_6x6_luma_and_3x3_chroma_blocks_all_frames':True,'decoded_native_330_rgb_sha256':dec.hexdigest()};print(json.dumps(report,indent=2))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('work',type=Path);ap.add_argument('out',type=Path);args=ap.parse_args();verify(args.work,args.out)
