# 冬夜值班室 · 贴桌翻页

320 × 180 原生像素，30 fps，330 帧。镜头、用色、暖墙、台灯与窗外的天气均沿用原版。人物、手与书从三维几何逐帧投影，最终画面沿用原固定色板。

## 运行

使用 Python 3.12、`requirements.txt` 中的依赖及带 libx264 的 FFmpeg 7.1。Linux 构建使用 Noto CJK 与 DejaVu Sans；原场景的宋/楷/黑体路径找不到时，`framework.py` 将其映射到 Noto 简中面。验证过的字体：`NotoSerifCJK-Regular.ttc`（SHA-256 `5d9c31a059600193c9d7968a998bde886ccdc77e934006ad243b41794c496a7d`），`NotoSansCJK-Regular.ttc`（`b76b0433203017ca80401b2ee0dd69350349871c4b19d504c34dbdd80541690a`）。

```sh
python3.12 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
export OPENBLAS_NUM_THREADS=1 NUMBA_NUM_THREADS=2
python render28.py --work ./work --out ./previews/gate_2_8
python check_geometry.py
python check_escrow.py ./work ./previews/gate_2_8
```

完整运行无需下载旧素材，也无需预置静帧。首先从随附的冬景 2.4 活跃源码重建 v2.7 锁定原生基线，校验 330 帧连续 RGB 的 SHA-256 `499f216c23b6dfe1e9cfe51b4674865006a09cda28e5a4b7fc64be187ed91408`。已有完全相同的原生数组时，可传 `--baseline-native /path/to/winter_native.npy`。只有重编码自身渲出的原生数据时才用 `--reuse`。

## 活跃文件

- `winter28.py`：暖窗读者、手腕和书。`pose()` 给出肩、颈、手肘、袖口、指尖的空间位置。头部绕颈部转动，躯干的下端维持坐姿；低肘支在桌边。`leaf()` 将一张 0.162 米的纸分成等长的八段，从书脊沿弧线积分。原生镜头与桌灯参与书的着色。`paper()` 保留桌面两张平页、封面前切口与正在变形的单页。
- `room28.py`：在原场景建模阶段解除旧人影和纸块的相机可见性，保留原随机序列及其余几何，得到真实空窗；仅用原被遮挡采样点和极窄边缘修补被旧人影盖住的底板。新姿态对清净底板作 12×12 子采样深度测试。烟尘与窗前落雪继续以原深度计算，在人物合成之后绘制。
- `winter24.py`、`winter23.py`、`framework.py`、`timeline.py`、`pixel_fx.py`、`pixel_wind.py`、`fixture.py`、`site_accents.py`、`shots/`、`engine/`、`references/`：原冬景完整活跃链、原生色板和正式无损 YUV→RGB 对照。旧的 `reader_controls()` 与弧线只参与 v2.7 对照和基线的复现；更新的暖窗使用 `winter28.py`。
- `render28.py`：帧 f144–155 伸指捻角，f156–174 翻过书脊、随即压平，f175–192 收手；其余时间伏案静读。f156 / f169 对齐现有两处纸声，循环预览为无声画面，正式音轨单独保留。

## 输出与核查

- `winter_loop.mp4`：1920 × 1080 / 330 帧 / 11 秒，完整场景原速审片。
- `winter_reader_normal_speed_detail.mp4`：原生 `(242,98)–(274,122)` 的完整窗框，32× 最近邻至 1024 × 768 / 330 帧 / 11 秒，QP0；不变速、不叠字。
- `winter_reader_comparison.png`：`f=120,124,…,212` 共 24 组，同机位、同尺寸、同相位的旧/新对比。
- `lossless_parts/winter/part-00.bin` 至 `part-05.bin`：前五卷每卷 8,000,000 字节，按顺序直接拼接即 1920 × 1080 的 BT.709 TV-range、yuv420p、H.264 QP0 共 660 帧 / 22 秒母版；两轮 330 帧循环逐像素完全相同。
- `check_geometry.py` 核验书脊固定、物理纸长、最大起拱、头部与手肘轨迹；`check_escrow.py` 逐帧逆查原有色板，验证两个循环及每个原生像素的 6×6 亮度、3×3 色度整数块。
- 整窗之外完全继承：实际可编辑区只有半开区间 `x=[250,264), y=[105,116)`；在最终合成前也逐帧统计直接重渲结果在该区外与旧版的差异，写入 `work/native_proof.json`。
