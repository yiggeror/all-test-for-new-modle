#!/usr/bin/env python3
"""Render the autumn cycle at the source grid, its two-cycle lossless master and review copies."""
import argparse,hashlib,json,os,subprocess,sys,zipfile
from pathlib import Path
import numpy as np

FILES=('README.md','requirements.txt','autumn27.py','reader27.py','wind25.py','wind26.py',
       'foliage25.py','render27.py','verify.py','test_reader27.py')
FROZEN=(
 ('previews/gate_2/source/spring_autumn_source.zip','9c4e69ee6d6b1944cfc36a3030d24fe1db790ef74a83e9885d3abf6ca8354898','base','spring_autumn_gate2/src'),
 ('previews/gate_2_3/source/autumn_winter_v23.zip','6b6be061999ce67c7585907eddc7b9fea1819ae34d35c4be52d12916045e8e2a','basis_23','.'))
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def setup(repo,work):
    roots=[]
    for rel,sha,name,sub in FROZEN:
        src=repo/rel
        if digest(src)!=sha: raise ValueError(f'Frozen asset hash mismatch: {rel}')
        target=work/name
        if not (target/'.frozen_sha256').is_file() or (target/'.frozen_sha256').read_text()!=sha:
            target.mkdir(exist_ok=True,parents=True)
            with zipfile.ZipFile(src) as z:z.extractall(target)
            (target/'.frozen_sha256').write_text(sha)
        roots.append(str((target/sub).resolve()))
    sys.path[:0]=roots
def encode(a,dst):
    opts=['ffmpeg','-hide_banner','-v','error','-xerror','-nostdin','-y','-filter_threads','1','-f','rawvideo',
          '-pixel_format','rgb24','-video_size','320x180','-framerate','30','-i','pipe:0','-an','-vf',
          'scale=1920:1080:flags=neighbor:out_color_matrix=bt709:out_range=tv,format=yuv420p','-c:v','libx264',
          '-preset','veryslow','-threads','2','-g','330','-keyint_min','330','-sc_threshold','0','-qp','0',
          '-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709',
          '-color_range','tv','-movflags','+faststart',str(dst)]
    with subprocess.Popen(opts,stdin=subprocess.PIPE) as p:
        for _ in range(2):
            for im in a:p.stdin.write(memoryview(np.ascontiguousarray(im)).cast('B'))
        p.stdin.close()
        if p.wait():raise RuntimeError('Lossless encode failed')
def preview(src,out,detail=False):
    # The detail box is sampled from the full decoded picture. The tree to the right and
    # the full strip of lit pavement below both planted shoes stay in view throughout.
    filt='trim=start_frame=0:end_frame=330,settb=1/30,setpts=N'
    if detail:filt+=',crop=216:264:204:720,scale=864:1056:flags=neighbor'
    common=['ffmpeg','-hide_banner','-v','error','-xerror','-nostdin','-y','-threads','2','-i',str(src),
          '-map','0:v:0','-an','-vf',filt,'-r','30','-fps_mode','cfr','-video_track_timescale','90000',
          '-threads','2','-c:v','libx264','-profile:v','high','-level:v','4.0','-preset','medium',
          '-tune','animation','-crf','15','-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709',
          '-color_trc','bt709','-color_range','tv','-movflags','+faststart']
    subprocess.run(common+[str(out)],check=True)
    q=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_streams',
                                          '-of','json',str(out)]))['streams'][0]
    expected=(864,1056) if detail else (1920,1080)
    assert (q['width'],q['height'])==expected and int(q['nb_frames'])==330 and q['avg_frame_rate']=='30/1' and float(q['duration'])==11
def source_zip(out):
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name in FILES:
            ref=zipfile.ZipInfo(name,date_time=(2026,11,25,0,0,0));ref.external_attr=0o644<<16
            z.writestr(ref,(Path(__file__).parent/name).read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--repo',type=Path,required=True)
    ap.add_argument('--work',type=Path,required=True)
    ap.add_argument('--plate-cache',type=Path,help='optional cache of the unchanged ray-traced street')
    a=ap.parse_args();repo=a.repo.resolve();work=a.work.resolve();out=work/'render';pack=work/'package'
    for d in (out,pack/'source',pack/'lossless_parts/autumn'):d.mkdir(exist_ok=True,parents=True)
    setup(repo,work)
    import unittest
    checks=unittest.defaultTestLoader.loadTestsFromName('test_reader27')
    if not unittest.TextTestRunner(verbosity=1).run(checks).wasSuccessful(): raise RuntimeError('Actor tests failed')
    from autumn27 import AutumnV27
    state=AutumnV27(a.plate_cache)
    arr=np.lib.format.open_memmap(out/'autumn_native.npy',mode='w+',dtype=np.uint8,shape=(330,180,320,3))
    for n in range(330):
        arr[n]=state.frame(n)
        if n%55==0:print('Frame',n,flush=True)
    arr.flush()
    master=out/'autumn_loop.mp4'
    encode(arr,master)
    from verify import run
    checks=run('autumn',repo,out)
    (out/'native_verification.json').write_text(json.dumps(checks,indent=2)+'\n')
    preview(master,pack/'autumn_loop.mp4')
    from shutil import copyfile
    copyfile(pack/'autumn_loop.mp4',pack/'autumn_girl_normal_speed_1080p.mp4')
    preview(master,pack/'autumn_girl_normal_speed_detail.mp4',True)
    chunks=[]
    with master.open('rb') as src:
        for i,buf in enumerate(iter(lambda:src.read(8_000_000),b'')):
            dst=pack/f'lossless_parts/autumn/part-{i:02}.bin'
            dst.write_bytes(buf);chunks.append({'path':str(dst.relative_to(pack)),'bytes':len(buf),'sha256':digest(dst)})
    record={'output':'autumn_loop.mp4','bytes':master.stat().st_size,'sha256':digest(master),'parts':chunks}
    (out/'autumn_parts.json').write_text(json.dumps(record,indent=2)+'\n')
    source_zip(pack/'source/autumn_v27.zip')
    print('Ready:',pack,record,flush=True)
if __name__=='__main__':main()
