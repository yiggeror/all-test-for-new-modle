"""Autumn reader: a supported standing contrapposto, wind through the hair, and one slow turn."""
from dataclasses import dataclass
from functools import lru_cache
import numpy as np
from engine import render as rt
from engine.world import World,roty,srgb,_n,MASK_HIDDEN
from engine.rt import Accel

PARTS={131:'coat',132:'skirt',133:'support_boot',134:'relaxed_boot',135:'face_and_neck',
       136:'hair_cap',137:'hair_tips',138:'support_hand',139:'turning_hand',140:'book',
       141:'turning_page',142:'fixed_hair_roots',143:'sleeves',144:'legs',145:'collar',146:'cover',147:'left_leaf'}
PAPER_TAGS=(140,141,146,147)
HAIR_TIP=137
HEIGHT=1.682
BOUNDS=(39,121,72,169)
YAW=-1.074
ORIGIN=np.array([-6.716,.15,5.665])
V=np.array([.929,0,.37])
C=np.array([.006,1.310,-.162])
H=np.array([-.010,.899,-.113])
COAT='#efdbb8'
FOLD='#f1dfc2'
SLEEVE='#dfc6a2'
CUFF='#c7aa88'
KNIT_RIM='#f1d6ae'
SKIRT='#454554'
HAIR='#2b1c22'
HAIRMID='#41272d'
HAIRLIT='#67402d'
SKIN='#c09a79'
HAND='#a38a6d'
TURN_HAND='#b19a7e'
DARK_CUFF='#c3a689'

def sigma(u):
    s=np.clip(u,0.,1.);return s*s*(3.-2.*s)

def ankle_sites():
    return [np.array([-.058,0.,.039]),np.array([.090,0.,-.065])]

def leg_landmarks(i):
    ankle=ankle_sites()[i]+[0,.079,-.032]
    pelvis=H+np.array([-.045 if i==0 else .053,0.,0.])
    knee=pelvis*.476+ankle*.524+([.002,0,.008] if i==0 else [-.008,0,.027])
    return pelvis,knee,ankle

def ball(w,c,r,tag,col,n=12,rot=None):
    M=np.diag(r) if rot is None else rot@np.diag(r)
    with w.at(c,M=M):
        w.sphere((0.,0.,0.),1.,n=n,mat='plain',col=col,tag=tag)

def tube(w,a,b,ra,rb,tag,col,n=8):
    w.tube(a,b,ra,rb,sides=n,mat='plain',col=col,tag=tag,caps=True)

def cloth(w,rings,tag,colors,N=20):
    t=np.arange(N)*2*np.pi/N
    seq=[]
    for j,(y,cx,cz,rx,rz,cr) in enumerate(rings):
        flex=1.+cr*np.cos(4*t+.4+j*.035)
        yy=y+(.010*np.cos(t+.9) if j==0 else 0.)
        seq.append(np.column_stack((cx+rx*flex*np.cos(t),np.broadcast_to(yy,t.shape),cz+rz*flex*np.sin(t))))
    col=np.stack([srgb(colors[-1] if i in (0,1,18,19) else colors[0]) for i in range(N)])
    for a,b in zip(seq[:-1],seq[1:]):
        w.quads(a,np.roll(a,-1,axis=0),np.roll(b,-1,axis=0),b,mat='plain',col=col,tag=tag)
    w.poly(seq[0][::-1],mat='plain',col=colors[0],tag=tag)
    w.poly(seq[-1],mat='plain',col=colors[0],tag=tag)

def book_panel(origin,spine,across,width,flex=0.):
    normal=_n(np.cross(across,spine))
    def pos(u,v):
        return origin+across*(width*u)+spine*v+normal*(.007*np.sin(np.pi*u))+[0,flex*u*v,0]
    return pos

def draw_book(w,pos,tag,col,edge=True,lift=0.):
    t=(0.,.11,.39,.72,.865,1.) if lift>0. else (0.,.11,.39,.72,1.)
    strips=((0.,.51),(.51,.78),(.78,1.)) if lift>0. else ((0.,.51),(.51,1.))
    for j,(u,U) in enumerate(zip(t[:-1],t[1:])):
        for v,B in strips:
            shade=.77 if j==0 else (.92 if j>=3 and edge else 1.)
            col0=col*shade
            if j>=3 and lift>0.:
                # Light unprinted paper at the turned curl, not a luminous outline. The
                # ~4 cm bent outer facet samples the same actual warm kiosk visibility.
                col0=(1.-lift)*col0+lift*srgb('#fff0d6')
            w.quads(pos(u,v),pos(U,v),pos(U,B),pos(u,B),mat='plain',col=col0,tag=tag)

def hair_shape(w,head,wind,prev,early):
    # A rooted fan of tapered ribbons. The shoulder, upper length and ends respond
    # at different times to the same passing gust.
    roots=[];tips=[]
    locks=((.091,-.048,.470,.050,1.00),(.126,-.029,.427,.047,.83),
           (.077,-.096,.380,.059,.68),(-.046,-.081,.415,.043,.70))
    for j,(rx,rz,drop,r,spread) in enumerate(locks):
        root=head+np.array([rx,.050 if j<2 else .038,rz])
        base=root+np.array([.012,-.130,.022])
        lst=[root,base]
        for u in (.32,.58,.80,1.):
            ts=(1-u)*wind+u*early
            wave=(.68*ts+.32*prev)
            swept=(.072+.163*wave)*spread
            lst.append(base+np.array([.013*np.sin(u*np.pi)+(.045 if j<2 else -.007)*u,
                         -(drop-.13)*u+(.050*wave+.011)*u*u,
                         .035*u+(.037 if j==1 else -.029)*u+swept*u**1.38]))
        for i,(a,b) in enumerate(zip(lst,lst[1:])):
            rs=(1.,.98,.96,.74,.42,.10); cs=[HAIR,HAIRMID,HAIRMID,HAIRLIT,HAIRMID]
            tube(w,a,b,r*rs[i],r*rs[i+1],142 if i==0 else 137,cs[i] if j in (0,1) else HAIR,10)
            if i>1:ball(w,a,(r*rs[i],)*3,137,cs[i],8)
        roots.append(w.xf(root).tolist());tips.append(w.xf(lst[-1]).tolist())
    return roots,tips

def joint_targets(k):
    k=int(k)%66;f=k*5
    # Ease in off the left page edge, give the fold a visible apogee, glide over the
    # hinge and release after the sheet settles. This is not an aliased arm switch.
    nt=np.interp(f,[0,131,139,147,154,161,168,175,329],[0,0,.12,.32,.60,.80,.96,1,1])
    roll=np.pi*sigma(nt);lift=float(np.sin(roll)**1.05)
    follow=np.interp(f,[0,126,139,153,161,173,190,329],[0,0,.13,.57,.93,.57,0,0])
    cm=np.array([.034,1.132,.238])+[0,.008*follow,.004*follow]
    spine=roty(YAW).T@np.array([.012,.085,-.136])
    hr=_n(roty(YAW).T@np.array([-.82,.59,.020]));hl=_n(roty(YAW).T@np.array([.96,.12,.061]))
    lw,rw=.126,.151
    L=book_panel(cm,spine,hl,lw);R=book_panel(cm,spine,hr,rw)
    axis=_n(spine);normal=_n(np.cross(axis,hr))
    if normal[1]<0:normal=-normal
    def arc_at(theta):
        return _n(hr*np.cos(theta)+normal*np.sin(theta)+(hl+hr)*((1.-np.cos(theta))*.5))
    arc=arc_at(roll)
    backing=cm+normal*.003*lift
    base_turn=book_panel(backing,spine,arc,rw,.087*lift)
    # The loose upper corner briefly catches, then sweeps across. Clear in two
    # successive held poses rather than giving a one-cell flash on the hairline.
    corner_delay=min(.91*roll,float(np.interp(f,[0,135,140,145,150,155,160,165,170,329],
                                                [0,.012,.092,.383,1.076,1.277,.510,.082,0,0])))
    def P(u,v):
        # The gripped part keeps the same actual contact throughout the turn. The
        # freely bending upper section, outside the grip, momentarily lags around
        # the book hinge; this changes its direction, not its size or brightness.
        curl=lift*u*u*np.sin(np.pi*v)
        outer=sigma((u-.705)/.295)*sigma((v-.39)/.61)
        lag=corner_delay*outer
        result=base_turn(u,v)+np.array([-.029,.023,.068])*curl
        if lag>1e-6:result+=(arc_at(roll-lag)-arc)*(rw*u)
        return result
    active=.015<roll<np.pi-.015
    out=[]
    for side in (-1,1):
        shoulder=np.array([side*.131+.006,1.314,-.141+.004*follow])
        guide=np.array([side*.131+.012,.997+(.026*lift if side>0 else 0.),-.104+.042*lift])
        if side<0:
            grip=L(.50,.16)
        else:
            rest=R(.48,.20)
            if active:
                # Contact point really remains on the turning sheet and migrates only
                # in that sheet's UV coordinates, as the finger rolls over its margin.
                along=.20+.54*sigma((f-127)/24)+.111*lift*(1.-sigma((f-151)/10))
                u=.48+.062*sigma((f-131)/17)+.123*lift
                grip=P(u,along)
            elif roll<=.015:
                grip=R(.48,.20+.54*sigma((f-127)/24))
            else:
                done=sigma((f-169)/17)
                grip=(1-done)*L(.564,.74)+done*rest
                grip=grip+[0,.026*np.sin(np.pi*done),-.019*np.sin(np.pi*done)]
        palm=grip+V*(.045 if side<0 else .044+.013*lift)+[0,-.027+(.007*lift if side>0 else 0.),-.011]
        out.append((shoulder,palm,grip,guide))
    return roll,follow,cm,spine,L,R,P,active,out

def arm_circle(shoulder,palm,guide):
    upper=.285; lower=.280
    d=palm-shoulder;dist=float(np.linalg.norm(d))
    if not abs(upper-lower)<dist<upper+lower:
        raise ValueError(f'Unreachable natural arm target: {dist:.5f}')
    u=d/dist;s=(upper**2-lower**2+dist**2)/(2*dist)
    v=_n(guide-shoulder-u*((guide-shoulder)@u))
    tangent=np.cross(u,v);r=np.sqrt(max(0.,upper**2-s**2))
    z=np.arange(144)*2*np.pi/144
    pts=shoulder+s*u+(np.cos(z)[:,None]*v+np.sin(z)[:,None]*tangent)*r
    x=(pts@roty(YAW).T)[:,0]
    admissible=(x<.212)&(pts[:,1]>.964)&(pts[:,1]<1.256)
    if not admissible.any():admissible=x<.212
    if not admissible.any():raise RuntimeError('Arm cannot clear the bearing tree')
    cost=(.34*(np.square(pts-guide).sum(1))+
          .14*np.square(np.maximum(pts[:,1]-1.135,0.)))
    cost[~admissible]=np.inf
    return pts,cost

@lru_cache(maxsize=1)
def linked_elbow_poses():
    # Solve the two-bone mechanism over the whole closed five-frame score.
    # Keeping a linked elbow branch avoids in/out flips in the middle of a subtle hand arc.
    scene=[joint_targets(n)[-1] for n in range(67)]
    tracks=[]
    for side in (0,1):
        opts=[]
        for lu in scene:
            shoulder,palm,grip,guide=lu[side]
            opts.append(arm_circle(shoulder,palm,guide))
        start=int(np.argmin(opts[0][1]))
        weight=np.full(144,np.inf);weight[start]=0.
        back=[]
        for k,((prev,_),(new,prefer)) in enumerate(zip(opts[:-1],opts[1:]),1):
            D=np.square(prev[:,None]-new[None]).sum(2)
            MM=weight[:,None]+8.6*D+prefer[None]
            ii=np.argmin(MM,axis=0)
            weight=MM[ii,np.arange(144)]
            if k<23 or k>=40:
                keep=weight[start];weight[:]=np.inf;weight[start]=keep
            back.append(ii)
        if not np.isfinite(weight[start]):
            raise RuntimeError('No cyclic constant-length arm trajectory')
        idx=[start]
        for link in reversed(back):
            idx.append(int(link[idx[-1]]))
        idx=idx[::-1]
        tracks.append(np.stack([p[j] for (p,_),j in zip(opts,idx)])[:66])
    return np.stack(tracks,axis=1)

def make_girl(k,origin,wind,prev=None,early=None):
    prev=wind if prev is None else prev; early=wind if early is None else early
    k=int(k)%66; f=k*5
    roll,following,cm,spine,L,R,P,active,grips=joint_targets(k)
    elbows=linked_elbow_poses()[k]
    w=World(seed=419)
    shoes=ankle_sites()
    result={}
    with w.at(origin,yaw=YAW):
        # Asymmetric weight, close feet, a relaxed toe a little forward. Both rest on actual paving.
        for i,t0 in enumerate(shoes):
            tag=133+i
            shoe='#43333d' if i==0 else '#795143'
            pelvis,knee,ankle=leg_landmarks(i)
            tube(w,ankle,knee,.033,.051,144,'#92776d' if i else '#594656')
            tube(w,knee,pelvis,.051,.066,144,'#554856')
            ball(w,knee,(.048,.052,.048),144,'#554856',10)
            # Flat base, gently rounded matching instep, genuine heel-toe silhouette.
            if i==0:
                w.box(t0+[0.,.015,.012],(.082,.030,.142),yaw=-.10,mat='plain',col=shoe,tag=tag)
                ball(w,t0+[0.,.042,.041],(.045,.034,.072),tag,shoe)
                ball(w,t0+[0.,.079,-.024],(.046,.067,.054),tag,shoe)
            else:
                w.box(t0+[0.,.015,.039],(.082,.030,.108),yaw=.31,mat='plain',col=shoe,tag=tag)
                ball(w,t0+[0.,.049,.035],(.044,.041,.066),tag,shoe)
                ball(w,t0+[0.,.085,-.020],(.045,.054,.060),tag,shoe)
                # This heel, distinct from the toe's flat grounded sole, remains above paving.
                w.box(t0+[0.,.053,-.036],(.077,.045,.077),yaw=.31,mat='plain',col=shoe,tag=tag)
        # The skirt falls from the hips following the line of the planted leg.
        cloth(w,((.398,-.013,-.055,.161,.087,.060),(.520,-.014,-.070,.153,.088,.046),
                 (.680,-.015,-.087,.142,.087,.033),(.817,-.013,-.102,.120,.083,.017),
                 (.925,-.010,-.115,.103,.070,.012)),132,[SKIRT,'#554b58'])
        # Short, fitted cardigan with a slight waist, not a filled block below the hip.
        cloth(w,((.845,-.011,-.110,.128,.083,.028),(.919,-.009,-.117,.108,.072,.016),
                 (1.005,-.006,-.128,.096,.066,.005),(1.092,-.003,-.139,.107,.075,.014),
                 (1.201,.002,-.149,.119,.084,.012),(1.308,.006,-.162,.132,.081,.011),
                 (1.357,.005,-.142,.112,.071,.005),(1.395,.005,-.112,.058,.054,.0)),131,[COAT,FOLD])
        # A sloping shoulder touches the bark at the outer rear quarter, not the skull.
        ball(w,(-.058,1.293,-.202),(.084,.077,.101),131,COAT,16)
        ball(w,(.004,1.390,-.107),(.067,.056,.059),145,CUFF,12)
        # An open little book, not an oversize glare block. The bindings and narrow cream pages
        # are physical facets, with no faux print or disconnected light spots.
        paper=srgb('#e4d2b0')
        # A dark rust cover, just the real binding silhouette.
        for pos0 in (L,R):
            under=np.array([.0,-.034,0.])
            w.quads(pos0(0,0)+under,pos0(1,0)+under,pos0(1,1)+under,pos0(0,1)+under,
                    mat='plain',col='#49444e',tag=146)
            for a,b in (((0.,0.),(1.,0.)),((1.,0.),(1.,1.))):
                p0,p1=pos0(*a),pos0(*b)
                w.quads(p0+under,p1+under,p1,p0,mat='plain',col='#746658',tag=146)
        draw_book(w,L,147,paper*.81);draw_book(w,R,140,paper)
        if active:draw_book(w,P,141,paper*(1.006+.047*np.sin(roll)),lift=float(np.sin(roll)))
        target=(L(.32,.63)+R(.32,.63))*.5
        target=target*(1.-.51*following)+.51*following*P(.72,.68)
        head=np.array([.004,1.552-.005*following,-.070+.002*following])
        # The neck rises above the clavicles; the chin alone tips toward the book.
        look=_n((target-head)*[1.,.57,1.])
        right=_n(np.cross([0,1.,0.],look));up=np.cross(look,right)
        ball(w,head+[0,-.120,-.003],(.044,.077,.044),135,SKIN,12)
        with w.at(head,M=np.column_stack((right,up,look))):
            ball(w,(.022,-.012,.040),(.094,.100,.114),135,SKIN,16)
            ball(w,(.005,.035,-.019),(.117,.106,.116),136,HAIR,16)
            ball(w,(-.073,.015,-.044),(.045,.079,.061),136,HAIR,12)
            ball(w,(.075,.018,-.050),(.046,.082,.068),136,HAIRMID,12)
        roots,tips=hair_shape(w,head,float(wind),float(prev),float(early))
        for j,s in enumerate((-1,1)):
            shoulder,palm,grip,guide=grips[j]
            el=elbows[j]
            wrist=palm*.82+el*.18
            tube(w,shoulder,el,.057,.044,143,COAT if s<0 else SLEEVE,10)
            ball(w,el,(.046,.050,.046),143,SLEEVE,10)
            tube(w,el,wrist,.045,.035,143,SLEEVE if s<0 else KNIT_RIM,10)
            # Turn wrist clears the sleeve edge. Land the distal pad exactly on the page
            # surface without a shape that reads as a second floating paper rectangle.
            cuff=.49*wrist+.51*palm
            tube(w,wrist,cuff,.039,.032,143,CUFF,8)
            tag=138 if s<0 else 139
            col=HAND if s<0 else TURN_HAND
            tube(w,cuff,palm,.024,.022,tag,col,8)
            ball(w,palm,(.040,.038,.034),tag,col)
            # The index rolls forward toward a thumbnail-sized grip; the bright page
            # and the cuff stay separate rather than becoming one rectangular strip.
            kn=(palm+grip)/2+[0,.012,.005]
            tube(w,palm,kn,.020,.017,tag,col,8)
            tube(w,kn,grip,.017,.010,tag,col,8)
            lbl='static' if s<0 else 'turn'
            result[lbl+'_arm']=[w.xf(q).tolist() for q in (shoulder,el,palm,grip)]
        v=roty(YAW)@(C-H)
        lean=float(np.rad2deg(np.arctan2(np.linalg.norm(v[[0,2]]),v[1])))
        result.update(feet=[w.xf(z).tolist() for z in shoes],
                      back_lean_deg=lean,
                      gaze_direction=w.xd(look).tolist(),head=w.xf(head).tolist(),gaze_target=w.xf(target).tolist(),
                      book_hinge_world=[w.xf(cm).tolist(),w.xf(cm+spine).tolist()],
                      paper_turn=active,turn_angle=float(roll),page_tip_world=w.xf(P(1.,1.)).tolist(),
                      hair_roots=roots,hair_tips=tips,wind=float(wind))
    return w,result

@dataclass
class BarkMount:
    origin: np.ndarray
    mesh: object
    contact_actor: np.ndarray
    contact_bark: np.ndarray
    clearance: float

    @classmethod
    def survey(cls,scene):
        d=scene.finalize()
        tri=np.flatnonzero(d['F']['tag'][d['tf']]==5)
        v=np.stack([d[q][tri] for q in ('v0','v1','v2')])
        c=v.mean(0)
        t=(c[:,0]>-7.1)&(c[:,0]<-4.8)&(c[:,2]>4.)&(c[:,2]<6.85)&(np.max(v[:,:,1],0)>.29)&(np.min(v[:,:,1],0)<1.90)
        if len(np.flatnonzero(t))<6:raise RuntimeError('Second actual tagged plane-tree trunk not found')
        acc=Accel(*v[:,t],d['tm'][tri[t]])
        g,_=make_girl(0,ORIGIN,0.)
        gg=g.finalize()
        tag=gg['F']['tag'][gg['tf']]
        v=np.concatenate([gg[z][tag==131] for z in ('v0','v1','v2')])
        v=v[(v[:,1]>.98)&(v[:,1]<1.46)]
        b=cls.bark_x(acc,v)
        ix=np.where(np.isfinite(b))[0]
        if len(ix)==0:raise RuntimeError('No backed torso vertices on second physical trunk')
        j=int(ix[np.argmin(b[ix]-v[ix,0])])
        delta=float(b[j]-v[j,0])-.0018
        base=ORIGIN.copy();base[0]+=delta
        p=v[j]+[delta,0,0]
        q=p.copy();q[0]=b[j]
        if np.linalg.norm(q-p)>.006:raise RuntimeError('Unseated torso')
        return cls(base,acc,p,q,float(q[0]-p[0]))

    @staticmethod
    def bark_x(acc,v):
        o=v.copy();o[:,0]=-8.2
        dp=np.broadcast_to([1.,0.,0.],v.shape)
        t,j=acc.closest(o,dp)
        return np.where(j>=0,(o[:,0]+t),np.inf)

class Together:
    def __init__(self,a,b):self.a,self.b=a,b
    def anyhit(self,o,d,tmax,mask=0):
        # Both physical acceleration structures participate in direct light visibility.
        s=self.a.anyhit(o,d,tmax,mask)
        if not s.all():
            ii=np.nonzero(~s)[0]
            tm=tmax if np.isscalar(tmax) else tmax[ii]
            s[ii]=self.b.anyhit(o[ii],d[ii],tm,mask)
        return s

@dataclass
class ReaderSample:
    coverage:np.ndarray
    contact:np.ndarray
    incoming:np.ndarray
    lamp_shadow:np.ndarray
    primary_depth:np.ndarray
    parts:np.ndarray
    part_counts:dict
    ground_y:float
    upper_y:float
    meta:dict

class Reader:
    def __init__(self,cam,world,acc,b,pressure,wind_envelope=None):
        self.cam,self.world,self.acc,self.b=cam,world,acc,b
        self.mount=BarkMount.survey(world)
        self.origin=self.mount.origin
        # Same signed FBM actually driving the locked crown, averaged around this tree's bough;
        # the accepted bedding's macro wind envelope weights the exact same 5-frame phase.
        p=np.mean(pressure[:,34:48,49:69],axis=(1,2))
        if wind_envelope is None:
            gg=.5+.5*np.sin(2*np.pi*(np.arange(66)/66*3-.23))
        else:
            gg=np.asarray(wind_envelope,dtype=np.float64)
            if gg.shape==(330,):gg=gg[::5]
            if gg.shape!=(66,) or not np.all(np.isfinite(gg)) or not np.all((gg>=0.)&(gg<=1.)):
                raise ValueError('Expected one shared normalized gust envelope at the 66 held phases')
        self.wind_bough=p
        self.wind_envelope=gg
        forcing=(.72+.42*gg)*p+.17*(gg-gg.mean())
        smooth=sum(np.roll(forcing,j)*w for j,w in enumerate((.36,.32,.22,.10)))
        self.wind=1.05*(2*(smooth-smooth.min())/(smooth.max()-smooth.min())-1.)
        x0,y0,x1,y1=BOUNDS;self.ys=slice(y0,y1);self.xs=slice(x0,x1)
        self.shape=(y1-y0,x1-x0)
        yy,xx=np.mgrid[y0:y1,x0:x1]
        # Four-by-four fixed subpixel rays per native cell. Pose holds remain exact.
        oy,ox=np.mgrid[0:4,0:4].reshape(2,-1)
        dv=cam.dirs((xx[...,None]+(.5+ox)/4).ravel(),(yy[...,None]+(.5+oy)/4).ravel()).astype(np.float32)
        self.d=dv;self.o=np.broadcast_to(cam.pos.astype(np.float32),dv.shape).copy()
        self.dist,ti=acc.closest(self.o,dv,mask=MASK_HIDDEN)
        safe=np.maximum(ti,0);g=world.finalize();ntag=g['F']['tag'][g['tf'][safe]]
        nn=g['F']['n'][g['tf'][safe]];self.P=self.o+dv*np.minimum(self.dist,1e3)[:,None]
        # Check existing kiosk sign (upper sign + left mag stand) and actual contact paving.
        self.structure=ntag.reshape(*self.shape,16)
        self.floor=(ti>=0)&(np.abs(nn[:,1])>.82)&(np.abs(self.P[:,1]-.15)<.011)
        self.kiosk=next(q for q in world.lights if q['grp']==3 and 'axis' not in q)
        self.near=[q for q in world.lights if q['kind']=='point' and np.linalg.norm(q['pos']-self.origin)<22.]
        # Integrate diffuse reflected/transmitted light from the actual nearby bright shelf.
        # These are surveyed positions and radiance of the fixed light group, not invented LEDs.
        hit=(b['tag28']>.96)&(np.indices(b['tag28'].shape)[1]<55)
        sc=np.argwhere(hit)
        if len(sc)>=12:
            sc=sc[np.linspace(0,len(sc)-1,12).astype(int)]
        self.panel_pos=b['P'][sc[:,0],sc[:,1]]
        self.panel_irr=b['layers'][3,sc[:,0],sc[:,1]]
        self.panel_normal=b['N'][sc[:,0],sc[:,1]]
        # Effective bright area of the actual magazine stand's face, sampled over its
        # louvered curved footprint. No added lamp, exposure change or selective outline.
        self.panel_patch_area=2.6/max(1,len(sc))
        self.samples=np.array(((0,0,0),(.67,0,0),(-.67,0,0),(0,.62,0),(0,-.62,0),(0,0,.61),(0,0,-.61)),np.float32)
        self.fidx=np.where(self.floor&(np.linalg.norm(self.P[:,[0,2]]-self.origin[[0,2]],axis=1)<1.95))[0]
        pp=self.P[self.fidx].copy();pp[:,1]+=.003
        v=self.kiosk['pos'][None,None]+self.kiosk['radius']*self.samples[None]-pp[:,None]
        self.sd=np.linalg.norm(v,axis=2);self.sdir=(v/self.sd[...,None]).reshape(-1,3)
        self.so=np.repeat(pp,len(self.samples),axis=0)
        basevis=~acc.anyhit(self.so,self.sdir,self.sd.ravel()-.005,mask=1)
        self.basevis=basevis.reshape(self.sd.shape)
        self.shadow_weight=np.maximum(self.sdir[:,1],0).reshape(self.sd.shape)/(self.sd**2+.36)
        self.floor_check={}
        for p in make_girl(0,self.origin,self.wind[0])[1]['feet']:
            pp=np.asarray(p,np.float32);o=pp+[0,.045,0];down=np.array([[0.,-1.,0.]])
            floor_t,idx=acc.closest(o[None],down,tmax=.075)
            self.floor_check[str(p)]=float(floor_t[0]-.045) if idx[0]>=0 else None
        # Stable set of hemisphere directions for contact ambient visibility.
        a=np.arange(13)*2.399963;xz=np.sqrt((np.arange(13)+.5)/13)
        self.updirs=np.stack((np.cos(a)*xz,np.sqrt(1-xz*xz),np.sin(a)*xz),axis=1).astype(np.float32)

    def get(self,n,omit_paper=False,omit_hair=False):
        return self._get((int(n)%330)//5,bool(omit_paper),bool(omit_hair))

    @lru_cache(maxsize=132)
    def _get(self,k,omit_paper=False,omit_hair=False):
        w,meta=make_girl(k,self.origin,self.wind[k],self.wind[(k-1)%66],self.wind[(k-2)%66])
        meta.update(bark_contact_actor=self.mount.contact_actor.tolist(),bark_contact_tree=self.mount.contact_bark.tolist(),
                    mount_clearance_m=self.mount.clearance,mount_origin=self.origin.tolist(),
                    same_bough_fbm_phase=float(self.wind_bough[k]),same_bedding_gust_envelope=float(self.wind_envelope[k]))
        w.pixang=2*self.cam.th/320
        g=w.finalize(); points=np.concatenate((g['v0'],g['v1'],g['v2']))
        meta['mesh_vertices_aabb_m']=[points.min(0).tolist(),points.max(0).tolist()]
        triangle_mask=g['tm'].copy()
        if omit_paper:triangle_mask[np.isin(g['F']['tag'][g['tf']],PAPER_TAGS)]|=MASK_HIDDEN|1
        if omit_hair:triangle_mask[g['F']['tag'][g['tf']]==HAIR_TIP]|=MASK_HIDDEN|1
        acc=Accel(g['v0'],g['v1'],g['v2'],triangle_mask)
        dist,tri=acc.closest(self.o,self.d,tmax=self.dist-.002,mask=MASK_HIDDEN)
        ii=np.where(tri>=0)[0]
        P=self.o[ii]+self.d[ii]*dist[ii,None]
        sf=rt.surface(w,g,tri[ii],P,self.d[ii],dist[ii])
        N=sf['N'];A=sf['alb'];tg=sf['tag'];accpair=Together(self.acc,acc)
        rng=np.random.default_rng(813)
        # Non-emissive material. Sample actual fog, directional sky, same global fixture groups,
        # direct shadow rays from real lamps. Paper reflects from either hemisphere when bent.
        full=rt.direct(self.near,accpair,P,N,rng,4)
        for q in range(3):
            full+=rt.direct(self.near,accpair,P,N,rng,4)
        full*=.25
        ksrc=self.kiosk['pos']-P;dn=np.linalg.norm(ksrc,axis=1)
        ld=ksrc/dn[:,None];face=np.abs((N*ld).sum(1))
        one=accpair.anyhit(P+ld*.004,ld,dn-.006,mask=1)
        pap=np.isin(tg,(140,141,147))
        # Integrate cosine-weighted one-bounce transfer from the real lit magazine
        # stand into the actual actor's world-space shading, including occlusion.
        rp=P+N*.0025
        for point,normal,radiance in zip(self.panel_pos,self.panel_normal,self.panel_irr):
            v=point-rp; ds=np.linalg.norm(v,axis=1); l=v/ds[:,None]
            response=np.maximum((N*l).sum(1),0.)*np.maximum((-l*normal).sum(1),0.)
            live=np.flatnonzero(response>.0001)
            if len(live):
                visible=~accpair.anyhit(rp[live],l[live],ds[live]-.024,mask=1)
                wght=self.panel_patch_area*response[live]/(np.pi*(ds[live]**2+.16))
                full[3,live]+=(wght*visible)[:,None]*radiance

        # Paper thin diffuse transmission restores a little of the kiosk light on the back.
        full[3,pap]+=(~one[pap]*.34*(.14+.86*face[pap])/(dn[pap]**2+.36))[:,None]*self.kiosk['color']
        up=floor_ambient(N)
        full[0]+=up+np.array([.019,.012,.006],np.float32)
        # Low, local diffuse floor reflection only, just separates soft hair from dark coat.
        strand=np.isin(tg,(136,137,142))
        full[0,strand]+=np.array([.029,.016,.011],np.float32)
        # Broad skylight reflected by the lighter paper fibres, never an emissive term.
        # Matte leaves face the evening sky and receive broad indirect light. Keep
        # the cooler binding on its own material: at this scale it carries the spine.
        for mat,k in ((140,.22),(147,.10),(141,.32)):
            lit=tg==mat
            full[0,lit]+=k*(.62+.38*np.maximum(0.,N[lit,1]))[:,None]*np.array([.91,.88,.74],np.float32)
        full[0,np.isin(tg,(131,143))]+=np.array([.035,.038,.038],np.float32)
        full[0,tg==135]+=np.array([.09,.08,.07],np.float32)
        full*=A[None]
        T=rt.fog_T(__import__('autumn_g15').FOG,self.o[ii],P,dist[ii])
        full*=T[None,:,None]
        full[0]+=(1.-T)[:,None]*__import__('autumn_g15').FOG['color'](self.d[ii])
        sh=np.zeros(len(self.o),np.float32)
        occ=acc.anyhit(self.so,self.sdir,self.sd.ravel()-.005,mask=1).reshape(self.sd.shape)
        wg=self.shadow_weight*self.basevis
        sh[self.fidx]=(wg*occ).sum(1)/np.maximum(wg.sum(1),.001)
        sh[ii]=0.
        pp=self.P[self.fidx].copy();pp[:,1]+=.003
        shadowdir=np.tile(self.updirs,(len(pp),1))
        corn=acc.anyhit(np.repeat(pp,13,axis=0),shadowdir,.41,mask=1).reshape(-1,13)
        cont=np.zeros(len(self.o),np.float32);cont[self.fidx]=corn.mean(1)*.9;cont[ii]=0.
        incoming=np.zeros((4,len(self.o),3),np.float32);incoming[:,ii]=full
        tags=np.zeros(len(self.o),np.uint8);tags[ii]=tg
        # Part tags retain all subpixel labels (no arbitrary display pad or flattening).
        tags=tags.reshape(*self.shape,16)
        vis=np.where(tri>=0,dist,self.dist).reshape(*self.shape,16)
        dep=np.sort(vis,axis=2)[...,np.rint(np.linspace(.5,14.5,9)).astype(int)]
        return ReaderSample((tags>0).mean(2).astype(np.float32),cont.reshape(*self.shape,16).mean(2),
                            incoming.reshape(4,*self.shape,16,3).mean(3),
                            sh.reshape(*self.shape,16).mean(2),dep,tags,
                            {s:int((tags==tag).sum()) for tag,s in PARTS.items()},
                            float(self.origin[1]),float(self.origin[1])+HEIGHT,meta)

    def draw(self,lin,n,gains,near_lit,with_shadows=True,with_body=True,omit_paper=False,omit_hair=False):
        v=self.get(n,omit_paper,omit_hair);sl=lin[self.ys,self.xs]
        if with_shadows:
            sl-=near_lit[self.ys,self.xs]*v.lamp_shadow[...,None]*gains['kiosk']*.84
            sl*=1.-v.contact[...,None]*.34
        if with_body:
            incoming=v.incoming[0]+v.incoming[1]*gains['lamp']+v.incoming[2]*gains['tv']+v.incoming[3]*gains['kiosk']
            sl*=1.-v.coverage[...,None]
            sl+=incoming

def floor_ambient(N):
    # Reflected ochre pavement also reaches underside of dark clothing.
    z=np.clip(N[:,1],-1,1);up=.045+.025*z
    return up[:,None]*np.array((.73,.82,1.03),np.float32)+(.044-.020*z)[:,None]*np.array((1.,.56,.28),np.float32)
