"""Geometry and timing invariants of the actor, independent of the pixel palette."""
import unittest
import numpy as np
from reader27 import leg_landmarks, ankle_sites, joint_targets, make_girl, YAW, ORIGIN

class ReaderTests(unittest.TestCase):
    def test_planted_support_and_small_relaxed_knee(self):
        for i,limit in enumerate((.030,.060)):
            hip,knee,ankle=leg_landmarks(i)
            d=ankle-hip
            near=hip+d*np.dot(knee-hip,d)/np.dot(d,d)
            self.assertLessEqual(np.linalg.norm(knee-near),limit)
            self.assertGreater(hip[1],knee[1]);self.assertGreater(knee[1],ankle[1])
        self.assertLess(np.linalg.norm(np.subtract(*ankle_sites())),.19)
        self.assertGreater(np.linalg.norm(np.subtract(*ankle_sites())),.10)
    def test_wind_bends_ends_not_roots(self):
        _,a=make_girl(0,ORIGIN,-1,-1,-1)
        _,b=make_girl(0,ORIGIN,1,1,1)
        self.assertTrue(np.array_equal(a['hair_roots'],b['hair_roots']))
        self.assertTrue(np.array_equal(a['feet'],b['feet']))
        self.assertGreater(np.linalg.norm(np.subtract(a['hair_tips'],b['hair_tips']),axis=1).max(),.18)
    def test_one_unbroken_page_turn(self):
        phases=[joint_targets(k) for k in range(66)]
        roll=np.array([p[0] for p in phases])
        self.assertTrue(np.all(np.diff(roll)>=0))
        self.assertAlmostEqual(roll[0],0)
        self.assertAlmostEqual(roll[-1],np.pi)
        motion=np.array([p[-2] for p in phases],bool)
        self.assertEqual(np.count_nonzero(motion&~np.roll(motion,1)),1)
        self.assertGreater(np.count_nonzero(motion),5)
        self.assertLessEqual(np.count_nonzero(motion),15)
        for k in (0,27,31,36,65):
            _,a=make_girl(k,ORIGIN,.1)
            j=np.array(a['turn_arm'])
            self.assertAlmostEqual(np.linalg.norm(j[0]-j[1]),.285,places=7)
            self.assertAlmostEqual(np.linalg.norm(j[1]-j[2]),.280,places=7)
            self.assertLess(a['gaze_direction'][1],-.16)
        _,first=make_girl(0,ORIGIN,.3,.1,.0)
        _,last=make_girl(66,ORIGIN,.3,.1,.0)
        self.assertEqual(first,last)
if __name__=='__main__':unittest.main()
