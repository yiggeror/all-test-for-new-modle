# 梧桐树下的读书人

秋天的镜头沿用原街道、树风、地面落叶、灯光和色板，只替换报刊亭旁读书人的模型与影子。承重脚落在髋下，另一只脚轻搭在前，肩背靠树。双臂在身前捧书，每 11 秒翻一次。发束从头皮固定点往发梢逐段响应原树冠的风。

## 运行
在仓库中解压本目录，安装 requirements.txt 的依赖，并准备 FFmpeg、ffprobe 和 Noto CJK 字体。将下面的 /repo 改为仓库根目录：

    OPENBLAS_NUM_THREADS=1 NUMBA_NUM_THREADS=2 python render27.py --repo /repo --work /tmp/autumn27

全景和含树干、双脚、地面的放大近景保存在 package/，都是 1080p 全景母片前 330 帧的原速画面。lossless_parts/autumn/ 中的母片含两个相同的 330 帧循环，用于正式合片；渲染时逐帧验证三个色度/亮度平面的整数倍像素网格、原生色板和两周期的一致性。render/ 中保留原生数组、母片和校验数据。

reader27.py 制作人物模型、发束、翻页、遮挡和接地投影。autumn27.py 将人物放回原有街景的同一组场景光源下。wind25.py、wind26.py、foliage25.py 来自 Gate 2.6。基础街景与色板来自仓库保留的 previews/gate_2/source/spring_autumn_source.zip、previews/gate_2_3/source/autumn_winter_v23.zip 和 tools/gate3/native_fingerprints.json。
